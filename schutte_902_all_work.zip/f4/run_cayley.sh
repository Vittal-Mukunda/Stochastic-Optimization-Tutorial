#!/bin/bash
for spec in "11 5 3" "19 3 7" "21 3 1" "7 9 2" "21 3 16"; do
  set -- $spec
  s=$(date +%s); ./cayley $1 $2 $3 4 0 0 >> out_cayley.txt 2>> err_cayley.txt; e=$(date +%s)
  echo "  (took $((e-s)) s)" >> out_cayley.txt
done
echo ALLDONE >> out_cayley.txt
