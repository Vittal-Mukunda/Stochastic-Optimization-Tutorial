// Tabu search over G-invariant tournaments (G given by generators) for property S_K.
// usage: gls K genfile seed maxsteps tenure [seedmatrix]
#include "sk.h"
#include <time.h>
#define MAXG 20000
int n,K,ng,order; int gens[64][MAXN]; static int G[MAXG][MAXN];
int nb; int pv[MAXN][MAXN], ps[MAXN][MAXN]; // pair -> base var index (0..nb-1), sign
// list of arcs (u,v) in reference orientation for each base var
int *arcU[8192],*arcV[8192]; int arcN[8192];
int nrep; int (*rep)[8];
static uint64_t rs=0x9E3779B97F4A7C15ULL; static inline uint64_t rnd(){ rs^=rs<<13; rs^=rs>>7; rs^=rs<<17; return rs; }
u128 inb[MAXN]; unsigned char val[8192];
static void apply_var(int b){ // flip orientation of all arcs of base var b
  for(int i=0;i<arcN[b];i++){ int u=arcU[b][i], v=arcV[b][i]; inb[u]^=bit(v); inb[v]^=bit(u); } val[b]^=1; }
static long long eval_bad(long long limit){ long long c=0; for(int r=0;r<nrep;r++){ u128 m=inb[rep[r][0]]; for(int i=1;i<K;i++) m&=inb[rep[r][i]]; if(!m){ c++; if(c>=limit) return c;} } return c; }
static long long C[MAXN+1][9];
int cmpi(const void*a,const void*b){return *(int*)a-*(int*)b;}
int main(int argc,char**argv){
  K=atoi(argv[1]); FILE*gf=fopen(argv[2],"r"); if(fscanf(gf,"%d %d",&n,&ng)!=2) return 1; for(int i=0;i<ng;i++) for(int j=0;j<n;j++) if(fscanf(gf,"%d",&gens[i][j])!=1) return 1; fclose(gf);
  rs ^= (uint64_t)atoll(argv[3])*0x2545F4914F6CDD1DULL; for(int i=0;i<20;i++) rnd();
  long long maxsteps=atoll(argv[4]); int tenure=atoi(argv[5]);
  for(int a=0;a<=MAXN;a++){ C[a][0]=1; for(int b=1;b<9;b++) C[a][b]= a? C[a-1][b-1]+C[a-1][b] : 0; }
  for(int j=0;j<n;j++) G[0][j]=j; order=1;
  for(int i=0;i<order;i++) for(int s=0;s<ng;s++){ int p[MAXN]; for(int j=0;j<n;j++) p[j]=gens[s][G[i][j]]; int f=0; for(int t=0;t<order;t++) if(!memcmp(G[t],p,sizeof(int)*n)){f=1;break;} if(!f) memcpy(G[order++],p,sizeof(int)*n); }
  memset(pv,-1,sizeof pv); nb=0;
  for(int u=0;u<n;u++)for(int v=u+1;v<n;v++) if(pv[u][v]<0){ int b=nb++; arcU[b]=malloc(sizeof(int)*order); arcV[b]=malloc(sizeof(int)*order); arcN[b]=0;
      for(int t=0;t<order;t++){ int a=G[t][u],c=G[t][v]; if(pv[a][c]>=0) continue; pv[a][c]=pv[c][a]=b; ps[a][c]=1; ps[c][a]=-1; arcU[b][arcN[b]]=a; arcV[b][arcN[b]]=c; arcN[b]++; } }
  // K-set orbit representatives
  long long tot=C[n][K]; unsigned char*seen=calloc(tot,1); rep=malloc(sizeof(int[8])*(tot/order*2+1000)); nrep=0; int X[8]; for(int i=0;i<K;i++) X[i]=i;
  while(1){ long long r=0; for(int i=0;i<K;i++) r+=C[X[i]][i+1];
    if(!seen[r]){ memcpy(rep[nrep++],X,sizeof(int)*K); for(int t=0;t<order;t++){ int Y[8]; for(int i=0;i<K;i++) Y[i]=G[t][X[i]]; qsort(Y,K,sizeof(int),cmpi); long long rr=0; for(int i=0;i<K;i++) rr+=C[Y[i]][i+1]; seen[rr]=1; } }
    int i=K-1; while(i>=0 && X[i]==n-K+i) i--; if(i<0) break; X[i]++; for(int j=i+1;j<K;j++) X[j]=X[j-1]+1; }
  fprintf(stderr,"n=%d |G|=%d base vars=%d K-set orbits=%d\n",n,order,nb,nrep);
  // initial assignment: all reference orientation (val=1 means reference), then random or seed matrix
  for(int i=0;i<n;i++) inb[i]=0;
  for(int b=0;b<nb;b++){ val[b]=1; for(int i=0;i<arcN[b];i++) inb[arcV[b][i]]|=bit(arcU[b][i]); }
  if(argc>6){ FILE*sf=fopen(argv[6],"r"); int nn; if(fscanf(sf,"%d",&nn)!=1||nn!=n){fprintf(stderr,"seed n mismatch\n");return 1;} char row[MAXN+5]; static int A[MAXN][MAXN];
    for(int i=0;i<n;i++){ if(fscanf(sf,"%s",row)!=1) return 1; for(int j=0;j<n;j++) A[i][j]=row[j]=='1'; } fclose(sf);
    int inv=0; for(int b=0;b<nb;b++){ int want=A[arcU[b][0]][arcV[b][0]]; for(int i=1;i<arcN[b];i++) if(A[arcU[b][i]][arcV[b][i]]!=want) inv=1; if(val[b]!=want) apply_var(b); }
    if(inv) fprintf(stderr,"WARNING: seed is not G-invariant (using representative arcs)\n"); }
  else { for(int b=0;b<nb;b++) if(rnd()&1) apply_var(b); }
  long long cur=eval_bad(1LL<<60), best=cur; fprintf(stderr,"initial bad orbits=%lld\n",cur);
  static long long tabu[8192]; memset(tabu,0,sizeof tabu); unsigned char bestval[8192]; memcpy(bestval,val,nb);
  time_t t0=time(0); long long lastimp=0;
  for(long long step=1; step<=maxsteps && cur>0; step++){
    long long bd=1LL<<60; int bb=-1, ties=0;
    for(int b=0;b<nb;b++){ apply_var(b); long long c=eval_bad(bd+1); apply_var(b);
      int ok = tabu[b]<=step || c<best; if(!ok) continue;
      if(c<bd){bd=c;bb=b;ties=1;} else if(c==bd){ ties++; if(rnd()%ties==0) bb=b; } }
    if(bb<0) continue;
    apply_var(bb); cur=bd; tabu[bb]=step+tenure+rnd()%(tenure+1);
    if(cur<best){ best=cur; memcpy(bestval,val,nb); lastimp=step; fprintf(stderr,"step %lld: bad orbits=%lld (t=%lds)\n",step,cur,(long)(time(0)-t0)); }
    if(step-lastimp>20000){ // perturb from best
      for(int b=0;b<nb;b++) if(val[b]!=bestval[b]) apply_var(b); for(int k=0;k<1+nb/10;k++) apply_var(rnd()%nb); cur=eval_bad(1LL<<60); lastimp=step; }
  }
  for(int b=0;b<nb;b++) if(val[b]!=bestval[b]) apply_var(b);
  Tour T; T.n=n; for(int i=0;i<n;i++){ T.in[i]=inb[i]; T.out[i]=0; } for(int i=0;i<n;i++) for(int j=0;j<n;j++) if(inb[j]&bit(i)) T.out[i]|=bit(j);
  init_bin(); long long full=count_bad(&T,K,1LL<<60);
  printf("RESULT n=%d |G|=%d best bad orbits=%lld, full check #bad %d-sets=%lld valid=%d\n",n,order,best,K,full,tour_valid(&T));
  if(full==0){ char fn[256]; sprintf(fn,"FOUND_S%d_n%d_%s.txt",K,n,argv[3]); FILE*o=fopen(fn,"w"); fprintf(o,"%d\n",n); for(int i=0;i<n;i++){ for(int j=0;j<n;j++) fputc(((T.out[i]>>j)&1)?'1':'0',o); fputc('\n',o);} fclose(o); printf("written %s\n",fn); }
  return 0; }
