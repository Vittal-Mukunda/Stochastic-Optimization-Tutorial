from math import comb
# Equality case of the Szekeres bound, k >= 4: N=(k+2)2^(k-1)-1, r=(N-1)/2, t=(N-3)/4, s=(t-1)/2.
# Checks: over cyclic triples, sum (lam-s)^2 == (t-s) * sum (lam-s)  (forces lam in {s,t}),
# and #heavy triples = N(N-1)/6 must be an integer (fails iff k = 1 mod 3).
for k in range(4,16):
    N=(k+2)*2**(k-1)-1; r=(N-1)//2; t=(N-3)//4; s=(t-1)//2
    ntr=N*comb(r,2); ncyc=comb(N,3)-ntr
    S1=N*comb(r,3); S2=S1+N*(N-1)*comb(t,3)
    c1=S1-s*ntr; c2=S2-s*s*ntr
    m1=c1-s*ncyc; m2=c2-2*s*c1+s*s*ncyc
    print(k, N, m2==(t-s)*m1, "heavy triples:", m1/(t-s), "IMPOSSIBLE" if (N*(N-1))%6 else "")
