// Exhaustive enumeration of all G-invariant tournaments (G from generators) for property S_K.
// usage: genum K genfile [maxbits]
#include "sk.h"
#define MAXG 20000
int n,K,ng,order; int gens[64][MAXN]; static int G[MAXG][MAXN];
int nb; int pv[MAXN][MAXN];
int *arcU[8192],*arcV[8192]; int arcN[8192];
int nrep; int (*rep)[8];
u128 inb[MAXN];
static long long C[MAXN+1][9];
int cmpi(const void*a,const void*b){return *(int*)a-*(int*)b;}
static inline void apply_var(int b){ for(int i=0;i<arcN[b];i++){ int u=arcU[b][i], v=arcV[b][i]; inb[u]^=bit(v); inb[v]^=bit(u);} }
int main(int argc,char**argv){
  K=atoi(argv[1]); FILE*gf=fopen(argv[2],"r"); if(fscanf(gf,"%d %d",&n,&ng)!=2) return 1; for(int i=0;i<ng;i++) for(int j=0;j<n;j++) if(fscanf(gf,"%d",&gens[i][j])!=1) return 1; fclose(gf);
  int maxbits = argc>3? atoi(argv[3]) : 34;
  for(int a=0;a<=MAXN;a++){ C[a][0]=1; for(int b=1;b<9;b++) C[a][b]= a? C[a-1][b-1]+C[a-1][b] : 0; }
  for(int j=0;j<n;j++) G[0][j]=j; order=1;
  for(int i=0;i<order;i++) for(int s=0;s<ng;s++){ int p[MAXN]; for(int j=0;j<n;j++) p[j]=gens[s][G[i][j]]; int f=0; for(int t=0;t<order;t++) if(!memcmp(G[t],p,sizeof(int)*n)){f=1;break;} if(!f){ if(order>=MAXG){fprintf(stderr,"group too big\n");return 1;} memcpy(G[order++],p,sizeof(int)*n);} }
  if(order%2==0){ fprintf(stderr,"even order\n"); return 1; }
  memset(pv,-1,sizeof pv); nb=0;
  for(int u=0;u<n;u++)for(int v=u+1;v<n;v++) if(pv[u][v]<0){ int b=nb++; arcU[b]=malloc(sizeof(int)*order); arcV[b]=malloc(sizeof(int)*order); arcN[b]=0;
      for(int t=0;t<order;t++){ int a=G[t][u],c=G[t][v]; if(pv[a][c]>=0) continue; pv[a][c]=pv[c][a]=b; arcU[b][arcN[b]]=a; arcV[b][arcN[b]]=c; arcN[b]++; } }
  long long tot=C[n][K]; unsigned char*seen=calloc(tot,1); rep=malloc(sizeof(int[8])*(tot/1+1)); nrep=0; int X[8]; for(int i=0;i<K;i++) X[i]=i;
  while(1){ long long r=0; for(int i=0;i<K;i++) r+=C[X[i]][i+1];
    if(!seen[r]){ memcpy(rep[nrep++],X,sizeof(int)*K); for(int t=0;t<order;t++){ int Y[8]; for(int i=0;i<K;i++) Y[i]=G[t][X[i]]; qsort(Y,K,sizeof(int),cmpi); long long rr=0; for(int i=0;i<K;i++) rr+=C[Y[i]][i+1]; seen[rr]=1; } }
    int i=K-1; while(i>=0 && X[i]==n-K+i) i--; if(i<0) break; X[i]++; for(int j=i+1;j<K;j++) X[j]=X[j-1]+1; }
  fprintf(stderr,"n=%d |G|=%d base vars=%d K-set orbits=%d\n",n,order,nb,nrep);
  if(nb>maxbits){ printf("SKIP n=%d |G|=%d nb=%d too many bits\n",n,order,nb); return 0; }
  for(int i=0;i<n;i++) inb[i]=0; for(int b=0;b<nb;b++) for(int i=0;i<arcN[b];i++) inb[arcV[b][i]]|=bit(arcU[b][i]);
  // move-to-front heuristic on reps: check the most recently failing reps first
  int *ord=malloc(sizeof(int)*nrep); for(int i=0;i<nrep;i++) ord[i]=i;
  long long total=1LL<<nb, found=0; int bestfail=0;
  for(long long g=0; g<total; g++){
    if(g>0) apply_var(__builtin_ctzll(g));
    int ok=1;
    for(int q=0;q<nrep;q++){ int r=ord[q]; u128 m=inb[rep[r][0]]; for(int i=1;i<K;i++) m&=inb[rep[r][i]]; if(!m){ ok=0; if(q>0){ int t=ord[q]; memmove(ord+1,ord,sizeof(int)*q); ord[0]=t; } if(q>bestfail) bestfail=q; break; } }
    if(ok){ found++; if(found<=3){ Tour T; T.n=n; for(int i=0;i<n;i++){T.in[i]=inb[i]; T.out[i]=0;} for(int i=0;i<n;i++)for(int j=0;j<n;j++) if(inb[j]&bit(i)) T.out[i]|=bit(j); init_bin(); long long full=count_bad(&T,K,1LL<<60);
          printf("FOUND S_%d tournament n=%d (full check bad=%d-sets %lld, valid=%d)\n",K,n,K,full,tour_valid(&T));
          char fn[128]; sprintf(fn,"FOUND_S%d_n%d_%lld.txt",K,n,found); FILE*o=fopen(fn,"w"); fprintf(o,"%d\n",n); for(int i=0;i<n;i++){ for(int j=0;j<n;j++) fputc(((T.out[i]>>j)&1)?'1':'0',o); fputc('\n',o);} fclose(o);} }
  }
  printf("DONE n=%d |G|=%d bits=%d orbits=%d : #S_%d found=%lld (max reps passed=%d)\n",n,order,nb,nrep,K,found,bestfail);
  return 0; }
