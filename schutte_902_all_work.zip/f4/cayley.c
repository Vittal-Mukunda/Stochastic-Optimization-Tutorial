// Exhaustive search over all Cayley tournaments on G = Z_m x|_r Z_k  (product (x1,y1)(x2,y2) = (x1 + r^y1 x2, y1+y2))
// for property S_K. Gray-code enumeration over the (n-1)/2 inverse pairs; branch-and-bound on #bad K-sets containing e.
#include "sk.h"
int m,kk,r,n,K;
int mul[MAXN][MAXN], inv_[MAXN];
int main(int argc,char**argv){
  if(argc<5){fprintf(stderr,"usage: m k r K [fixbits prefix]\n");return 1;}
  m=atoi(argv[1]); kk=atoi(argv[2]); r=atoi(argv[3]); K=atoi(argv[4]);
  int fixbits = argc>5? atoi(argv[5]):0; long long prefix = argc>6? atoll(argv[6]):0;
  n=m*kk; init_bin();
  int rp[64]; rp[0]=1; for(int i=1;i<64;i++) rp[i]=(rp[i-1]*r)%m;
  if(rp[kk]%m!=1%m){fprintf(stderr,"r^k != 1 mod m\n");return 1;}
  for(int a=0;a<n;a++)for(int b=0;b<n;b++){int x1=a/kk,y1=a%kk,x2=b/kk,y2=b%kk; int x=(x1+rp[y1]*x2)%m, y=(y1+y2)%kk; mul[a][b]=x*kk+y;}
  int e=-1; for(int a=0;a<n;a++){int ok=1; for(int b=0;b<n;b++) if(mul[a][b]!=b||mul[b][a]!=b){ok=0;break;} if(ok){e=a;break;}}
  if(e!=0){fprintf(stderr,"identity not 0\n");return 1;}
  for(int a=0;a<n;a++)for(int b=0;b<n;b++) if(mul[a][b]==0) inv_[a]=b;
  // associativity check
  for(int a=0;a<n;a++)for(int b=0;b<n;b++)for(int c=0;c<n;c++) if(mul[mul[a][b]][c]!=mul[a][mul[b][c]]){fprintf(stderr,"not assoc\n");return 1;}
  int P=0, ps[MAXN]; int used[MAXN]={0}; used[0]=1;
  for(int a=1;a<n;a++) if(!used[a]){ if(inv_[a]==a){fprintf(stderr,"involution!\n");return 1;} ps[P++]=a; used[a]=used[inv_[a]]=1; }
  // S initially = {ps[p]} for all p (bit=0 means s in S, bit=1 means s^{-1} in S)
  // g -> h iff g^{-1} h in S ; in[h] = { h s^{-1} : s in S }
  static u128 M[MAXN][MAXN]; // M[p][h] = bit(h*s_p) | bit(h*s_p^{-1})
  for(int p=0;p<P;p++) for(int h=0;h<n;h++) M[p][h]= bit(mul[h][ps[p]]) | bit(mul[h][inv_[ps[p]]]);
  Tour T; T.n=n;
  long long state=0;
  for(int h=0;h<n;h++){ T.in[h]=0; for(int p=0;p<P;p++) T.in[h]|=bit(mul[h][inv_[ps[p]]]); }
  // apply fixed prefix on top bits
  for(int b=0;b<fixbits;b++) if((prefix>>b)&1){ int p=P-1-b; for(int h=0;h<n;h++) T.in[h]^=M[p][h]; state|=1LL<<p; }
  int free_bits=P-fixbits; long long total=1LL<<free_bits;
  long long best=1LL<<60, found=0; long long nS3=0;
  for(long long g=0; g<total; g++){
    if(g>0){ int p=__builtin_ctzll(g); for(int h=0;h<n;h++) T.in[h]^=M[p][h]; state^=1LL<<p; }
    long long lim = (argc>7)? best+1 : 1; // we want min; count up to best (inclusive) 
    long long b = count_bad_v0(&T,K,lim);
    if(b<best){ best=b; fprintf(stderr,"[G=%d,%d,%d] new best bad=%lld state=%llx\n",m,kk,r,b,state); }
    if(b==0){ found++; printf("FOUND S_%d: m=%d k=%d r=%d state=%llx\n",K,m,kk,r,state); fflush(stdout); }
  }
  printf("done G=Z%d x|_%d Z%d (n=%d) K=%d prefix=%lld/%d: best #bad K-sets through e = %lld, #S_K found=%lld\n",m,r,kk,n,K,prefix,fixbits,best,found);
  return 0;
}
