import sys
# usage: mkgens.py n spec...   spec: "cyc:a,b,c,..." for cycle lengths list via orbits.  We support:
#  orbits m r f : r orbits of size m (cyclic shift), plus f fixed points  -> one generator
def orbits(m,r,f):
    n=m*r+f; p=list(range(n))
    for o in range(r):
        for i in range(m): p[o*m+i]=o*m+(i+1)%m
    return n,[p]
if __name__=="__main__":
    m,r,f=map(int,sys.argv[1:4]); n,gens=orbits(m,r,f)
    print(n,len(gens))
    for g in gens: print(" ".join(map(str,g)))
