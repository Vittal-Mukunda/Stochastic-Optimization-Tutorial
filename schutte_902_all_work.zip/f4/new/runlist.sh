#!/bin/bash
# usage: runlist.sh listfile famdir timeout_s logfile [VORD]
# runs genum2 on each family in listfile, 2 at a time, appending one line per family to logfile
L=$1; D=$2; TO=$3; LOG=$4; V=${5:-0}
run_one() {
  f=$1; r=$(VORD=$V timeout $TO ./genum2v 4 $D/$f 62 2>/dev/null | tail -1)
  [ -z "$r" ] && r="TIMEOUT after ${TO}s"
  echo "$f $(grep "^$f " $D/index.txt | cut -d' ' -f2-) => $r" >> $LOG
}
export -f run_one; export D TO LOG V
cat $L | xargs -P 2 -I{} bash -c 'run_one {}'
echo "LISTDONE $L" >> $LOG
