// gdfs: complete DFS solver (DPLL-style, native constraints, no learning) for
//   "tournament on n points invariant under permutation group G (odd order) with property S_K".
// Variables = G-orbits on unordered pairs. Constraint per K-set orbit representative X:
//   OR over w not in X of AND_{x in X} [w -> x].
// usage: gdfs K genfile [maxnodes] [mode]   mode: 0 = stop at first solution, 1 = count all (exhaustive)
#include "../sk.h"
#include <time.h>
#define MAXG 40000
int n,K,ng,order; int gens[64][MAXN]; static int G[MAXG][MAXN];
int nb; static int pv[MAXN][MAXN]; static signed char ps[MAXN][MAXN];
int *arcU[16384],*arcV[16384]; int arcN[16384];
// constraints / candidates
int nrep; int (*rep)[8];
int ncand; int *cX; unsigned char *clen; int (*clit)[8]; // literal = 2*b + val
int *cstart; // candidates of constraint X: cstart[X] .. cstart[X+1]-1
int *occS[2*16384], occN[2*16384]; // occ list for literal (b,val): candidates REQUIRING it
unsigned char *viol, *tru; int *alive, *satc;
signed char val_[16384]; int trail[16384], ntrail;
long long nodes=0, maxnodes; int mode; long long nsol=0;
static long long C[MAXN+1][9];
int cmpi(const void*a,const void*b){return *(int*)a-*(int*)b;}
int conflict;
static void assign(int b,int s){
  val_[b]=s; trail[ntrail++]=b;
  // literals (b,1-s) become false
  int L=2*b+(1-s); for(int i=0;i<occN[L];i++){ int c=occS[L][i]; if(viol[c]++==0){ int X=cX[c]; if(--alive[X]==0) conflict=1; } }
  L=2*b+s; for(int i=0;i<occN[L];i++){ int c=occS[L][i]; if(++tru[c]==clen[c]) satc[cX[c]]++; }
}
static void unassign_to(int t){
  while(ntrail>t){ int b=trail[--ntrail]; int s=val_[b];
    int L=2*b+(1-s); for(int i=0;i<occN[L];i++){ int c=occS[L][i]; if(--viol[c]==0) alive[cX[c]]++; }
    L=2*b+s; for(int i=0;i<occN[L];i++){ int c=occS[L][i]; if(tru[c]--==clen[c]) satc[cX[c]]--; }
    val_[b]=-1; }
}
// unit propagation: any unsatisfied constraint with exactly one alive candidate forces its literals
static int propagate(void){
  int changed=1;
  while(changed && !conflict){ changed=0;
    for(int X=0;X<nrep && !conflict;X++){ if(satc[X] || alive[X]!=1) continue;
      for(int c=cstart[X];c<cstart[X+1];c++) if(!viol[c]){
        for(int j=0;j<clen[c];j++){ int L=clit[c][j], b=L>>1, v=L&1; if(val_[b]<0){ assign(b,v); changed=1; if(conflict) break; } }
        break; } } }
  return !conflict;
}
static void output_solution(void){
  // free variables -> 1 (reference)
  u128 inb[MAXN]; for(int i=0;i<n;i++) inb[i]=0;
  for(int b=0;b<nb;b++){ int v= val_[b]<0? 1 : val_[b]; for(int i=0;i<arcN[b];i++){ int u=arcU[b][i], w=arcV[b][i]; if(v) inb[w]|=bit(u); else inb[u]|=bit(w); } }
  Tour T; T.n=n; for(int i=0;i<n;i++){T.in[i]=inb[i]; T.out[i]=0;} for(int i=0;i<n;i++)for(int j=0;j<n;j++) if(inb[j]&bit(i)) T.out[i]|=bit(j);
  init_bin(); long long full=count_bad(&T,K,1LL<<60);
  printf("SOLUTION n=%d valid=%d full_check_bad=%lld\n",n,tour_valid(&T),full); fflush(stdout);
  if(full==0){ char fn[128]; sprintf(fn,"FOUND_S%d_n%d_dfs%lld.txt",K,n,nsol); FILE*o=fopen(fn,"w"); fprintf(o,"%d\n",n); for(int i=0;i<n;i++){ for(int j=0;j<n;j++) fputc(((T.out[i]>>j)&1)?'1':'0',o); fputc('\n',o);} fclose(o); }
}
static int dfs(void){ // returns 1 to stop
  nodes++; if(maxnodes>0 && nodes>maxnodes) return 1;
  int t0=ntrail;
  if(!propagate()){ conflict=0; unassign_to(t0); return 0; }
  // choose unsatisfied constraint with min alive
  int best=-1, ba=1<<30; for(int X=0;X<nrep;X++){ if(satc[X]) continue; if(alive[X]<ba){ ba=alive[X]; best=X; if(ba<=2) break; } }
  if(best<0){ nsol++; output_solution(); unassign_to(t0); return mode==0; }
  // pick alive candidate with fewest unassigned literals; branch on one of them
  int bc=-1, bu=99; for(int c=cstart[best];c<cstart[best+1];c++) if(!viol[c]){ int u=clen[c]-tru[c]; if(u<bu){bu=u;bc=c;} }
  int L=-1; for(int j=0;j<clen[bc];j++){ int b=clit[bc][j]>>1; if(val_[b]<0){ L=clit[bc][j]; break; } }
  int b=L>>1, v=L&1;
  for(int pass=0;pass<2;pass++){ int s= pass==0? v : 1-v; int t1=ntrail;
    assign(b,s); if(!conflict){ if(dfs()) return 1; } else conflict=0; unassign_to(t1); }
  unassign_to(t0); return 0;
}
int main(int argc,char**argv){
  K=atoi(argv[1]); FILE*gf=fopen(argv[2],"r"); if(fscanf(gf,"%d %d",&n,&ng)!=2) return 1; for(int i=0;i<ng;i++) for(int j=0;j<n;j++) if(fscanf(gf,"%d",&gens[i][j])!=1) return 1; fclose(gf);
  maxnodes= argc>3? atoll(argv[3]) : 0; mode= argc>4? atoi(argv[4]) : 0;
  for(int a=0;a<=MAXN;a++){ C[a][0]=1; for(int b=1;b<9;b++) C[a][b]= a? C[a-1][b-1]+C[a-1][b] : 0; }
  for(int j=0;j<n;j++) G[0][j]=j; order=1;
  for(int i=0;i<order;i++) for(int s=0;s<ng;s++){ int p[MAXN]; for(int j=0;j<n;j++) p[j]=gens[s][G[i][j]]; int f=0; for(int t=0;t<order;t++) if(!memcmp(G[t],p,sizeof(int)*n)){f=1;break;} if(!f){ if(order>=MAXG){fprintf(stderr,"group too big\n");return 1;} memcpy(G[order++],p,sizeof(int)*n);} }
  if(order%2==0){ fprintf(stderr,"even order\n"); return 1; }
  memset(pv,-1,sizeof pv); nb=0;
  for(int u=0;u<n;u++)for(int v=u+1;v<n;v++) if(pv[u][v]<0){ int b=nb++; arcU[b]=malloc(sizeof(int)*order); arcV[b]=malloc(sizeof(int)*order); arcN[b]=0;
      for(int t=0;t<order;t++){ int a=G[t][u],c=G[t][v]; if(pv[a][c]>=0) continue; pv[a][c]=pv[c][a]=b; ps[a][c]=1; ps[c][a]=0; arcU[b][arcN[b]]=a; arcV[b][arcN[b]]=c; arcN[b]++; } }
  long long tot=C[n][K]; unsigned char*seen=calloc(tot,1); rep=malloc(sizeof(int[8])*(tot/order*4+1000)); nrep=0; int X[8]; for(int i=0;i<K;i++) X[i]=i;
  while(1){ long long r=0; for(int i=0;i<K;i++) r+=C[X[i]][i+1];
    if(!seen[r]){ memcpy(rep[nrep++],X,sizeof(int)*K); for(int t=0;t<order;t++){ int Y[8]; for(int i=0;i<K;i++) Y[i]=G[t][X[i]]; qsort(Y,K,sizeof(int),cmpi); long long rr=0; for(int i=0;i<K;i++) rr+=C[Y[i]][i+1]; seen[rr]=1; } }
    int i=K-1; while(i>=0 && X[i]==n-K+i) i--; if(i<0) break; X[i]++; for(int j=i+1;j<K;j++) X[j]=X[j-1]+1; }
  free(seen);
  // candidates
  int maxc=nrep*(n-K); cX=malloc(sizeof(int)*maxc); clen=malloc(maxc); clit=malloc(sizeof(int[8])*maxc); cstart=malloc(sizeof(int)*(nrep+1)); ncand=0;
  long long nlit=0; int empty=0;
  for(int r=0;r<nrep;r++){ cstart[r]=ncand; int first=ncand;
    for(int w=0;w<n;w++){ int inX=0; for(int i=0;i<K;i++) if(rep[r][i]==w) inX=1; if(inX) continue;
      int Ls[8], len=0, bad=0; for(int i=0;i<K;i++){ int x=rep[r][i]; int L=2*pv[w][x]+ps[w][x]; int dup=0; for(int j=0;j<len;j++){ if(Ls[j]==L) dup=1; if(Ls[j]==(L^1)) bad=1; } if(!dup) Ls[len++]=L; }
      if(bad) continue; qsort(Ls,len,sizeof(int),cmpi);
      // subsumption against existing candidates of this constraint
      int drop=0; for(int c=first;c<ncand && !drop;c++){ // if existing c subset of new -> drop new; if new subset of c -> replace c
        if(clen[c]==0) continue;
        int sub=1; for(int a=0;a<clen[c]&&sub;a++){ int in=0; for(int j=0;j<len;j++) if(Ls[j]==clit[c][a]) in=1; if(!in) sub=0; } if(sub){ drop=1; break; }
        int sub2=1; for(int a=0;a<len&&sub2;a++){ int in=0; for(int j=0;j<clen[c];j++) if(clit[c][j]==Ls[a]) in=1; if(!in) sub2=0; }
        if(sub2){ clen[c]=0; } }
      if(drop) continue;
      cX[ncand]=r; clen[ncand]=len; memcpy(clit[ncand],Ls,sizeof(int)*len); ncand++; }
    // compact (remove clen==0 entries)
    int wpos=first; for(int c=first;c<ncand;c++) if(clen[c]){ if(wpos!=c){ cX[wpos]=cX[c]; clen[wpos]=clen[c]; memcpy(clit[wpos],clit[c],sizeof(int)*clen[c]); } wpos++; }
    ncand=wpos; if(ncand==first) empty=1; }
  cstart[nrep]=ncand;
  for(int c=0;c<ncand;c++) nlit+=clen[c];
  fprintf(stderr,"n=%d |G|=%d vars=%d constraints=%d candidates=%d literals=%lld%s\n",n,order,nb,nrep,ncand,nlit, empty?" (EMPTY constraint => UNSAT)":"");
  if(empty){ printf("DONE n=%d |G|=%d vars=%d : UNSAT (empty constraint) nodes=0\n",n,order,nb); return 0; }
  for(int L=0;L<2*nb;L++) occN[L]=0;
  for(int c=0;c<ncand;c++) for(int j=0;j<clen[c];j++) occN[clit[c][j]]++;
  for(int L=0;L<2*nb;L++){ occS[L]=malloc(sizeof(int)*(occN[L]+1)); occN[L]=0; }
  for(int c=0;c<ncand;c++) for(int j=0;j<clen[c];j++){ int L=clit[c][j]; occS[L][occN[L]++]=c; }
  viol=calloc(ncand,1); tru=calloc(ncand,1); alive=malloc(sizeof(int)*nrep); satc=calloc(nrep,sizeof(int));
  for(int r=0;r<nrep;r++) alive[r]=cstart[r+1]-cstart[r];
  for(int b=0;b<nb;b++) val_[b]=-1; ntrail=0; conflict=0;
  clock_t t0=clock();
  int stopped=dfs();
  double secs=(double)(clock()-t0)/CLOCKS_PER_SEC;
  if(maxnodes>0 && nodes>maxnodes) printf("ABORT n=%d |G|=%d vars=%d : node limit, nodes=%lld sols=%lld (%.1fs)\n",n,order,nb,nodes,nsol,secs);
  else printf("DONE n=%d |G|=%d vars=%d constraints=%d : %s nodes=%lld sols=%lld (%.1fs)\n",n,order,nb,nrep, nsol? "SAT":"UNSAT", nodes,nsol,secs);
  (void)stopped; return 0; }
