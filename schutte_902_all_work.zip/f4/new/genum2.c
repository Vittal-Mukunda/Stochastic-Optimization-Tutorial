// genum2: exhaustive search over all G-invariant tournaments (G odd order, given by generators)
// for property S_K, with
//   * 64-bit assignment word (nb <= 62), each dominator candidate = (mask,val) test,
//   * move-to-front on failing constraints,
//   * conflict-directed skipping: if constraint X fails at assignment a, every candidate w of X
//     has a "killing" bit; with t = min_w (highest killing bit of w), all assignments that agree
//     with a on bits >= t also fail, so the enumeration jumps to the next multiple of 2^t.
// usage: genum2 K genfile [maxbits] [split_bits split_index]
//   split: only enumerate assignments whose top split_bits bits equal split_index (for parallel runs)
#include "../sk.h"
#include <time.h>
#define MAXG 40000
int n,K,ng,order; int gens[64][MAXN]; static int G[MAXG][MAXN];
int nb; static int pv[MAXN][MAXN]; static signed char ps[MAXN][MAXN];
int *arcU[8192],*arcV[8192]; int arcN[8192];
int nrep; int (*rep)[8];
uint64_t *cm,*cv; int *cs; // candidates (mask,val); constraint r has cs[r]..cs[r+1]-1
static long long C[MAXN+1][9];
int cmpi(const void*a,const void*b){return *(int*)a-*(int*)b;}
int LOOK=0;
int main(int argc,char**argv){
  K=atoi(argv[1]); FILE*gf=fopen(argv[2],"r"); if(fscanf(gf,"%d %d",&n,&ng)!=2) return 1; for(int i=0;i<ng;i++) for(int j=0;j<n;j++) if(fscanf(gf,"%d",&gens[i][j])!=1) return 1; fclose(gf);
  int maxbits = argc>3? atoi(argv[3]) : 40; if(getenv("LOOK")) LOOK=atoi(getenv("LOOK"));
  int splitb = argc>5? atoi(argv[4]) : 0; long long spliti = argc>5? atoll(argv[5]) : 0;
  for(int a=0;a<=MAXN;a++){ C[a][0]=1; for(int b=1;b<9;b++) C[a][b]= a? C[a-1][b-1]+C[a-1][b] : 0; }
  for(int j=0;j<n;j++) G[0][j]=j; order=1;
  for(int i=0;i<order;i++) for(int s=0;s<ng;s++){ int p[MAXN]; for(int j=0;j<n;j++) p[j]=gens[s][G[i][j]]; int f=0; for(int t=0;t<order;t++) if(!memcmp(G[t],p,sizeof(int)*n)){f=1;break;} if(!f){ if(order>=MAXG){fprintf(stderr,"group too big\n");return 1;} memcpy(G[order++],p,sizeof(int)*n);} }
  if(order%2==0){ fprintf(stderr,"even order\n"); return 1; }
  memset(pv,-1,sizeof pv); nb=0;
  for(int u=0;u<n;u++)for(int v=u+1;v<n;v++) if(pv[u][v]<0){ int b=nb++; arcU[b]=malloc(sizeof(int)*order); arcV[b]=malloc(sizeof(int)*order); arcN[b]=0;
      for(int t=0;t<order;t++){ int a=G[t][u],c=G[t][v]; if(pv[a][c]>=0) continue; pv[a][c]=pv[c][a]=b; ps[a][c]=1; ps[c][a]=0; arcU[b][arcN[b]]=a; arcV[b][arcN[b]]=c; arcN[b]++; } }
  if(nb>maxbits || nb>62){ printf("SKIP n=%d |G|=%d nb=%d too many bits\n",n,order,nb); return 0; }
  // variable renumbering: put variables with most arcs (largest orbits) at the high end
  // (keeps reference semantics: bit b of assignment = 1 means arcU->arcV orientation)
  long long tot=C[n][K]; unsigned char*seen=calloc(tot,1); rep=malloc(sizeof(int[8])*(tot/order*4+1000)); nrep=0; int X[8]; for(int i=0;i<K;i++) X[i]=i;
  while(1){ long long r=0; for(int i=0;i<K;i++) r+=C[X[i]][i+1];
    if(!seen[r]){ memcpy(rep[nrep++],X,sizeof(int)*K); for(int t=0;t<order;t++){ int Y[8]; for(int i=0;i<K;i++) Y[i]=G[t][X[i]]; qsort(Y,K,sizeof(int),cmpi); long long rr=0; for(int i=0;i<K;i++) rr+=C[Y[i]][i+1]; seen[rr]=1; } }
    int i=K-1; while(i>=0 && X[i]==n-K+i) i--; if(i<0) break; X[i]++; for(int j=i+1;j<K;j++) X[j]=X[j-1]+1; }
  free(seen);
  int maxc=nrep*(n-K)+1; cm=malloc(8*maxc); cv=malloc(8*maxc); cs=malloc(sizeof(int)*(nrep+1)); int nc=0; int empty=0;
  for(int r=0;r<nrep;r++){ cs[r]=nc; int first=nc;
    for(int w=0;w<n;w++){ int inX=0; for(int i=0;i<K;i++) if(rep[r][i]==w) inX=1; if(inX) continue;
      uint64_t m=0,v=0; int bad=0; for(int i=0;i<K;i++){ int x=rep[r][i]; int b=pv[w][x]; uint64_t bb=1ULL<<b; uint64_t want= ps[w][x]? bb:0; if(m&bb){ if((v&bb)!=want) bad=1; } else { m|=bb; v|=want; } }
      if(bad) continue;
      int drop=0; for(int c=first;c<nc;c++){ if(!cm[c]) continue; // existing subset of new -> drop new ; new subset of existing -> kill existing
        if((cm[c]&m)==cm[c] && (v&cm[c])==cv[c]){ drop=1; break; }
        if((cm[c]&m)==m && (cv[c]&m)==v){ cm[c]=0; } }
      if(drop) continue; cm[nc]=m; cv[nc]=v; nc++; }
    int wpos=first; for(int c=first;c<nc;c++) if(cm[c]){ cm[wpos]=cm[c]; cv[wpos]=cv[c]; wpos++; } nc=wpos; if(nc==first) empty=1; }
  cs[nrep]=nc;
  // optional variable reordering (env VORD: 0 none, 1 heavy->high bits, 2 heavy->low bits)
  int vord = getenv("VORD")? atoi(getenv("VORD")) : 0; int newpos[64]; for(int b=0;b<nb;b++) newpos[b]=b;
  if(vord){ long long wgt[64]={0}; for(int c=0;c<nc;c++) for(int b=0;b<nb;b++) if((cm[c]>>b)&1) wgt[b]++;
    int idx[64]; for(int b=0;b<nb;b++) idx[b]=b;
    for(int i=0;i<nb;i++) for(int j=i+1;j<nb;j++){ int sw = (vord==1)? (wgt[idx[j]]<wgt[idx[i]]) : (wgt[idx[j]]>wgt[idx[i]]); if(sw){ int t=idx[i]; idx[i]=idx[j]; idx[j]=t; } }
    for(int i=0;i<nb;i++) newpos[idx[i]]=i; // idx sorted ascending weight (vord1) -> heavy get high positions
    for(int c=0;c<nc;c++){ uint64_t m2=0,v2=0; for(int b=0;b<nb;b++){ if((cm[c]>>b)&1){ m2|=1ULL<<newpos[b]; if((cv[c]>>b)&1) v2|=1ULL<<newpos[b]; } } cm[c]=m2; cv[c]=v2; } }
  fprintf(stderr,"n=%d |G|=%d nb=%d constraints=%d candidates=%d\n",n,order,nb,nrep,nc);
  if(empty){ printf("DONE n=%d |G|=%d bits=%d orbits=%d : #S_%d found=0 (empty constraint)\n",n,order,nb,nrep,K); return 0; }
  int *ord=malloc(sizeof(int)*nrep); for(int i=0;i<nrep;i++) ord[i]=i;
  uint64_t lo=0, hi=(nb==64)?0:(1ULL<<nb);
  if(splitb>0){ int sh=nb-splitb; if(sh<0){ sh=0; } lo=((uint64_t)spliti)<<sh; hi=((uint64_t)spliti+1)<<sh; }
  long long found=0, checks=0, jumps=0; clock_t t0=clock();
  uint64_t a=lo;
  while(a<hi){
    int ok=1; int bestt=-1, bestq=-1, qend=nrep;
    for(int q=0;q<qend;q++){ int r=ord[q]; int alive=0;
      for(int c=cs[r];c<cs[r+1];c++) if(((a^cv[c])&cm[c])==0){ alive=1; break; }
      if(!alive){ ok=0; // compute jump
        int t=63; for(int c=cs[r];c<cs[r+1];c++){ uint64_t kill=(a^cv[c])&cm[c]; int hb=63-__builtin_clzll(kill); if(hb<t) t=hb; }
        if(t>bestt){ bestt=t; bestq=q; }
        if(bestq==q && qend==nrep){ qend = q+1+LOOK; if(qend>nrep) qend=nrep; }
      }
    }
    if(!ok){ int r=ord[bestq]; if(bestq>0){ memmove(ord+1,ord,sizeof(int)*bestq); ord[0]=r; }
      uint64_t na=((a>>bestt)+1)<<bestt; if(bestt>0) jumps++; a=na; }
    checks++;
    if(ok){ found++;
      // full independent check
      u128 inb[MAXN]; for(int i=0;i<n;i++) inb[i]=0;
      for(int b=0;b<nb;b++){ int v=(a>>newpos[b])&1; for(int i=0;i<arcN[b];i++){ int u=arcU[b][i], w=arcV[b][i]; if(v) inb[w]|=bit(u); else inb[u]|=bit(w); } }
      Tour T; T.n=n; for(int i=0;i<n;i++){T.in[i]=inb[i]; T.out[i]=0;} for(int i=0;i<n;i++)for(int j=0;j<n;j++) if(inb[j]&bit(i)) T.out[i]|=bit(j);
      init_bin(); long long full=count_bad(&T,K,1LL<<60);
      printf("FOUND S_%d n=%d assignment=%llx full_check_bad=%lld valid=%d\n",K,n,(unsigned long long)a,full,tour_valid(&T)); fflush(stdout);
      if(found<=5){ char fn[256]; sprintf(fn,"FOUND_S%d_n%d_%llx.txt",K,n,(unsigned long long)a); FILE*o=fopen(fn,"w"); fprintf(o,"%d\n",n); for(int i=0;i<n;i++){ for(int j=0;j<n;j++) fputc(((T.out[i]>>j)&1)?'1':'0',o); fputc('\n',o);} fclose(o); }
      a++; }
  }
  printf("DONE n=%d |G|=%d bits=%d orbits=%d : #S_%d found=%lld (visited=%lld jumps=%lld, %.1fs)%s\n",n,order,nb,nrep,K,found,checks,jumps,(double)(clock()-t0)/CLOCKS_PER_SEC, splitb? " [split]":"");
  return 0; }
