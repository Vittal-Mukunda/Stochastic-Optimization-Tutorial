# random tournament (optionally near-regular) on n vertices
import sys, random
n=int(sys.argv[1]); out=sys.argv[2]; seed=int(sys.argv[3]); random.seed(seed)
A=[[0]*n for _ in range(n)]
for i in range(n):
    for j in range(i+1,n):
        if random.random()<0.5: A[i][j]=1
        else: A[j][i]=1
with open(out,'w') as f:
    f.write(f"{n}\n")
    for i in range(n): f.write(''.join(map(str,A[i]))+'\n')
