#!/bin/bash
# usage: runfams.sh famdir maxnb timeout_s logfile
D=$1; MAXNB=$2; TO=$3; LOG=$4
awk -v m=$MAXNB '{split($3,a,"="); if (a[2]+0<=m) print $1}' $D/index.txt | \
  xargs -P 2 -I{} sh -c "r=\$(timeout $TO ./genum2 4 $D/{} 62 2>/dev/null | tail -1); [ -z \"\$r\" ] && r='TIMEOUT'; echo \"{} \$(grep '^{} ' $D/index.txt | cut -d' ' -f2-) => \$r\"" >> $LOG
echo ALLDONE >> $LOG
