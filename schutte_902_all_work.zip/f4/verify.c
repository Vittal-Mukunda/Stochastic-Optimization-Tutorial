// Read kissat model + map file, build tournament, verify property S_K independently; print adjacency rows.
#include "sk.h"
int main(int argc,char**argv){ int K=atoi(argv[1]); FILE*mf=fopen(argv[2],"r"); FILE*sf=fopen(argv[3],"r");
  int n; if(fscanf(mf,"%d",&n)!=1) return 1; static int val[20000000]; char line[1<<16]; int sat=0;
  while(fgets(line,sizeof line,sf)){ if(line[0]=='s'){ if(strstr(line,"UNSAT")) {printf("UNSAT\n"); return 0;} if(strstr(line,"SATISFIABLE")) sat=1; }
    if(line[0]=='v'){ char*p=line+1; while(*p){ while(*p==' ')p++; if(!*p||*p=='\n')break; int x=strtol(p,&p,10); if(x>0) val[x]=1; else if(x<0) val[-x]=0; } } }
  if(!sat){ printf("no SAT result\n"); return 0; }
  static unsigned char A[MAXN*MAXN]; memset(A,0,sizeof A); int u,v,l;
  while(fscanf(mf,"%d %d %d",&u,&v,&l)==3){ int x = l>0? val[l] : !val[-l]; if(x) A[u*n+v]=1; else A[v*n+u]=1; }
  Tour T; tour_from_adj(&T,n,A); init_bin();
  if(!tour_valid(&T)){ printf("INVALID tournament\n"); return 1; }
  long long b=count_bad(&T,K,1LL<<60); printf("n=%d: #undominated %d-sets = %lld  => %s\n",n,K,b, b? "NOT S_K":"HAS PROPERTY S_K");
  if(!b && argc>4){ FILE*o=fopen(argv[4],"w"); fprintf(o,"%d\n",n); for(int i=0;i<n;i++){ for(int j=0;j<n;j++) fputc(A[i*n+j]?'1':'0',o); fputc('\n',o);} fclose(o); }
  return 0; }
