# Local analysis around a vertex v of in-degree 23 in a hypothetical S_4 tournament on 48 vertices,
# assuming T[N^-(v)] = QR_23.  A = Z_23 (QR_23), B = N^+(v) (24 vertices), A_b = N^-(b) ∩ A.
import itertools
p=23; R={(x*x)%p for x in range(1,p)}
def arc(i,j): return i!=j and ((j-i)%p) in R      # i -> j
IN=[frozenset(i for i in range(p) if arc(i,j)) for j in range(p)]
OUT=[frozenset(j for j in range(p) if arc(i,j)) for i in range(p)]
def admissible(S):
    S=set(S)
    for z in range(p):
        if len(IN[z]&S)<5: return False
    for a in range(p):
        for b in range(a+1,p):
            if not (IN[a]&IN[b]&S): return False
    return True
adm11=[S for S in itertools.combinations(range(p),11) if admissible(S)]
print("admissible 11-sets:",len(adm11))
print(" equal to some IN[z]?", all(any(set(S)==IN[z] for z in range(p)) for S in adm11),
      " equal to some OUT[z]?", all(any(set(S)==OUT[z] for z in range(p)) for S in adm11))
# bad 4-sets of QR_23: no common in-neighbour inside A  -> must be inside some A_b
bad=[X for X in itertools.combinations(range(p),4) if not frozenset.intersection(*[IN[x] for x in X])]
print("4-sets of QR_23 with no dominator in A:",len(bad))
cov11=[X for X in bad if any(set(X)<=set(S) for S in adm11)]
print("  of which contained in an admissible 11-set:",len(cov11), " -> uncovered:",len(bad)-len(cov11))
