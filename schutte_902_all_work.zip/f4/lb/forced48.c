// Forced structure for a hypothetical 48-vertex S_4 tournament with a vertex v of in-degree 23 whose
// in-neighbourhood is QR_23:  vertices: v=0, A = a_x (1..23), A' = a'_x (24..46), b* = 47.
//   A: QR_23 (a_x -> a_y iff y-x is a QR);  A -> v;  v -> A';  v -> b*;  A => b*.
//   a_x -> a'_y iff a_x -> a_y (x != y);  a'_x -> a_x.   A': reversed QR_23 (a'_x -> a'_y iff a_y -> a_x).
//   free: the 23 arcs between b* and A'.   Enumerate all 2^23 and count undominated 4-sets.
#include "../sk.h"
int main(){ init_bin(); int p=23, isq[23]={0}; for(int x=1;x<p;x++) isq[(x*x)%p]=1;
  #define QR(x,y) ((x)!=(y) && isq[(((y)-(x))%p+p)%p])
  int n=48; static unsigned char A0[48*48]; memset(A0,0,sizeof A0);
  #define ARC(u,w) A0[(u)*n+(w)]=1
  int v=0, bs=47;
  for(int x=0;x<p;x++){ int a=1+x, ap=24+x;
    ARC(a,v); ARC(v,ap); ARC(a,bs); ARC(ap,a);
    for(int y=0;y<p;y++){ if(y==x) continue; int b=1+y, bp=24+y;
      if(QR(x,y)){ ARC(a,b); ARC(a,bp); ARC(bp,ap); } else { ARC(bp,a); } } }
  ARC(v,bs);
  // check partial structure is consistent (all pairs except b*-A' decided exactly once)
  int undec=0, bad=0; for(int i=0;i<n;i++) for(int j=i+1;j<n;j++){ int s=A0[i*n+j]+A0[j*n+i]; if(s==0) undec++; if(s==2) bad++; }
  printf("undecided pairs=%d conflicting=%d\n",undec,bad);
  // also: the 47-vertex doubled structure alone
  { static unsigned char A[47*47]; for(int i=0;i<47;i++)for(int j=0;j<47;j++) A[i*47+j]=A0[i*48+j]; Tour T; tour_from_adj(&T,47,A); printf("47-vertex doubled QR_23 (+v): valid=%d #undominated 4-sets=%lld\n",tour_valid(&T),count_bad(&T,4,1LL<<60)); fflush(stdout);
    long long nb_with_A=0, nb_onlyAp=0; for(int a=0;a<47;a++)for(int b=a+1;b<47;b++)for(int c=b+1;c<47;c++)for(int d=c+1;d<47;d++){ if(!(T.in[a]&T.in[b]&T.in[c]&T.in[d])){ if(a>=24) nb_onlyAp++; else nb_with_A++; } }
    printf("   undominated 4-sets meeting A or v: %lld ; inside A': %lld\n",nb_with_A,nb_onlyAp); fflush(stdout); if(nb_with_A>0){ printf("=> b* cannot fix them: NO completion is S_4\n"); return 0; } }
  long long best=1LL<<60; uint32_t bestm=0; long long nS4=0;
  for(uint32_t m=0;m<(1u<<23);m++){
    static unsigned char A[48*48]; memcpy(A,A0,sizeof A0);
    for(int x=0;x<p;x++){ int ap=24+x; if((m>>x)&1) A[bs*n+ap]=1; else A[ap*n+bs]=1; }
    Tour T; tour_from_adj(&T,n,A);
    long long c=count_bad(&T,4,1); if(c==0){ nS4++; printf("S4 completion mask %x\n",m); fflush(stdout);} }
  printf("min #undominated 4-sets over all 2^23 completions = %lld (mask %x); #S_4 = %lld\n",best,bestm,nS4);
  return 0; }
