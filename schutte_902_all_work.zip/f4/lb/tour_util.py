import itertools
def parse_upper(line, n):
    A=[[0]*n for _ in range(n)]; k=0
    for i in range(n):
        for j in range(i+1,n):
            if line[k]=='1': A[i][j]=1
            else: A[j][i]=1
            k+=1
    return A
def ins(A):
    n=len(A); return [frozenset(i for i in range(n) if A[i][j]) for j in range(n)]
def has_Sk(A,k):
    IN=ins(A); n=len(A)
    for X in itertools.combinations(range(n),k):
        if not frozenset.intersection(*[IN[x] for x in X]): return False
    return True

LABELG='/home/claude/tools/pynauty-2.8.8.1/src/nauty2_8_8/labelg'
def to_digraph6(A):
    n=len(A); bits=[A[i][j] for i in range(n) for j in range(n)]
    while len(bits)%6: bits.append(0)
    s='&'+chr(n+63)
    for k in range(0,len(bits),6):
        v=0
        for b in bits[k:k+6]: v=(v<<1)|b
        s+=chr(v+63)
    return s
def canon_many(As):
    import subprocess
    inp='\n'.join(to_digraph6(A) for A in As)+'\n'
    out=subprocess.run([LABELG,'-q'],input=inp,capture_output=True,text=True).stdout.split()
    return out
