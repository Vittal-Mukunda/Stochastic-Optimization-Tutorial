# Sanity test: A = QR_23 + a sink lies in the class A24, and (relabelled so that T[I] = R#301 and the
# O-columns are sorted) it must satisfy the SAT model built for R#301.
import itertools, time
from tour_util import parse_upper
import nbhd24
from pysat.solvers import Cadical153

lines = [l.strip() for l in open('reg11_S2.txt') if l.strip()]
R = parse_upper(lines[301], 11)
p = 23; Q = {(x*x) % p for x in range(1, p)}
A = [[0]*24 for _ in range(24)]
for i in range(p):
    for j in range(p):
        if i != j and (j-i) % p in Q: A[i][j] = 1
for i in range(p): A[i][23] = 1
print("QR23+sink satisfies (a)-(c):", nbhd24.check(A))
I = [i for i in range(24) if A[i][0]]; O = [j for j in range(24) if A[0][j]]
sub = [[A[a][b] for b in I] for a in I]
def iso(G, H):
    n = len(G); m = [-1]*n; used = [False]*n
    def bt(i):
        if i == n: return True
        for c in range(n):
            if used[c]: continue
            if all(G[i][j] == H[c][m[j]] and G[j][i] == H[m[j]][c] for j in range(i)):
                m[i] = c; used[c] = True
                if bt(i+1): return True
                used[c] = False
        return False
    return m if bt(0) else None
mp = iso(sub, R); assert mp is not None
newI = {I[k]: mp[k] for k in range(11)}          # QR vertex -> index in R
Iord = sorted(I, key=lambda t: newI[t])
cols = {y: tuple(A[x][y] for x in Iord) for y in O}
Osorted = sorted(O, key=lambda y: cols[y], reverse=True)
yidx = {y: k for k, y in enumerate(Osorted)}
cls, pool, B, Ov, o, arc, V = nbhd24.build_model(R)
units = []
for x in I:
    for y in O:
        lit = B[newI[x]][yidx[y]]
        units.append(lit if A[x][y] else -lit)
for y in O:
    for z in O:
        if y != z and yidx[y] < yidx[z]:
            lit = Ov[(yidx[y], yidx[z])]
            units.append(lit if A[y][z] else -lit)
t0 = time.time()
with Cadical153(bootstrap_with=cls) as s:
    print("model satisfiable with the known solution fixed:", s.solve(assumptions=units), f"({time.time()-t0:.1f}s)")
    t0 = time.time()
    print("model satisfiable (free):", s.solve(), f"({time.time()-t0:.1f}s)")
