import sys, time
from tour_util import parse_upper, canon_many
import nbhd24
from pysat.solvers import Cadical153
lines=[l.strip() for l in open('reg11_S2.txt') if l.strip()]
k=int(sys.argv[1]); ms=int(sys.argv[2])
R=parse_upper(lines[k],11)
t0=time.time(); cls,pool,B,Ov,o,arc,V=nbhd24.build_model(R); print("model built",round(time.time()-t0,1),"s; clauses",len(cls),flush=True)
base=[B[x][y] for x in range(11) for y in range(12)]+list(Ov.values())
n=0
with Cadical153(bootstrap_with=cls) as s:
    while n<ms and s.solve():
        m=set(l for l in s.get_model() if l>0); n+=1
        s.add_clause([-l if l in m else l for l in base])
        print(n,"solutions",round(time.time()-t0,1),"s",flush=True)
print("total",n,"in",round(time.time()-t0,1),"s")
