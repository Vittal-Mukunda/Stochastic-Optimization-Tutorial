// For each admissible subset S of QR_23 (conditions (1)-(3)), count how many of the 253 "doubly bad" 4-sets
// (no common in- and no common out-neighbour in QR_23) it contains; report max coverage per size.
#include <stdio.h>
#include <stdint.h>
int main(){
  int p=23, isq[23]={0}; for(int x=1;x<p;x++) isq[(x*x)%p]=1;
  uint32_t in[23],out[23]; for(int j=0;j<p;j++){ in[j]=0; out[j]=0; for(int i=0;i<p;i++){ if(i!=j && isq[((j-i)%p+p)%p]) in[j]|=1u<<i; if(i!=j && isq[((i-j)%p+p)%p]) out[j]|=1u<<i; } }
  uint32_t db[300]; int ndb=0;
  for(int a=0;a<p;a++)for(int b=a+1;b<p;b++)for(int c=b+1;c<p;c++)for(int d=c+1;d<p;d++){
    uint32_t ci=in[a]&in[b]&in[c]&in[d], co=out[a]&out[b]&out[c]&out[d];
    if(!ci && !co) db[ndb++]=(1u<<a)|(1u<<b)|(1u<<c)|(1u<<d); }
  printf("doubly-bad 4-sets: %d\n",ndb);
  int best[24]={0}; long long hist[24][64]={{0}};
  for(uint32_t S=0;S<(1u<<23);S++){ int sz=__builtin_popcount(S); if(sz<11) continue;
    int ok=1; for(int z=0;z<p&&ok;z++) if(__builtin_popcount(in[z]&S)<5) ok=0;
    for(int a=0;a<p&&ok;a++) for(int b=a+1;b<p;b++) if(!(in[a]&in[b]&S)){ok=0;break;}
    if(!ok) continue;
    int cov=0; for(int i=0;i<ndb;i++) if((db[i]&S)==db[i]) cov++;
    if(cov>best[sz]) best[sz]=cov; if(cov<64) hist[sz][cov]++; }
  for(int s=11;s<=23;s++){ printf("size %d (excess %d): max doubly-bad covered = %d   [per unit excess %.1f]\n",s,s-11,best[s], s>11? (double)best[s]/(s-11):0.0); }
  return 0; }
