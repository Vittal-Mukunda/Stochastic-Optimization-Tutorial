# For D2 (class 0): take covering families with a valid multiplicity vector m, build the 24 sets A_b,
# and test the remaining necessary conditions on the family {A_b}:
#  (i) every bad 4-set of D (no common in-neighbour in D) lies in some A_b
#  (ii) |A_b ∩ A_b'| >= 5 and, for every z in A, A_b ∩ A_b' ∩ IN(z) != {}   (4-set {v,b,b',z})
#  (iii) A_b ∩ A_b' ∩ A_b'' != {}                                             (4-set {v,b,b',b''})
import sys, itertools
import numpy as np
fn=sys.argv[1]; cov=sys.argv[2]
L=open(fn).read().split(); n=int(L[0]); A=[[int(c) for c in L[1+i]] for i in range(n)]
INm=[sum(1<<i for i in range(n) if A[i][j]) for j in range(n)]
OUTm=[sum(1<<j for j in range(n) if A[i][j]) for i in range(n)]
full=(1<<n)-1
fams=set()
for line in open(cov):
    if not line.startswith('cover:'): continue
    fams.add(tuple(sorted(int(t.split('(')[0],16) for t in line.split()[1:] if '(' in t)))
Mx=np.array([[1 if (z==a or A[z][a]) else 0 for z in range(n)] for a in range(n)],dtype=float); inv=np.linalg.inv(Mx)
bad=[]
for X in itertools.combinations(range(n),4):
    m=full
    for x in X: m&=INm[x]
    if m==0: bad.append(sum(1<<x for x in X))
survivors=[]
for F in sorted(fams):
    r=[12-sum(1 for S in F if not (S>>a)&1) for a in range(n)]
    mm=inv@np.array(r,dtype=float); mi=np.rint(mm)
    if not (np.allclose(mm,mi,atol=1e-6) and (mi>=0).all() and int(mi.sum())==24-len(F)): continue
    sets=list(F)+[INm[z] for z in range(n) for _ in range(int(mi[z]))]
    assert len(sets)==24
    why=[]
    unc=[X for X in bad if not any((X&S)==X for S in sets)]
    if unc: why.append(f"{len(unc)} bad 4-sets uncovered")
    pairfail=0
    for S,T in itertools.combinations(sets,2):
        I=S&T
        if bin(I).count('1')<5 or any((I&INm[z])==0 for z in range(n)): pairfail+=1
    if pairfail: why.append(f"{pairfail} pairs fail (ii)")
    trip=sum(1 for S,T,U in itertools.combinations(sets,3) if (S&T&U)==0)
    if trip: why.append(f"{trip} triples fail (iii)")
    print(("FAIL: "+"; ".join(why)) if why else "SURVIVES", "|F|=",len(F))
    if not why: survivors.append(sets)
print("survivors:",len(survivors))
import json; json.dump(survivors,open(sys.argv[3],'w'))
