# Pair-level covering test for n=49 (regular): P={u,v}, |D(P)|=11, R=T[D(P)] (one of 551 regular S_2 11-tournaments).
# Bad triples of R (no common in-neighbour in R) must be dominated by vertices w in W2 = N^-(v) ∩ N^+(u) (|W2|=12),
# each covering only bad triples inside R \ S_w, where S_w = R ∩ N^-(w) is "admissible": |S|>=5, S meets IN_R(r)\{r} for all r,
# and T[S] has no source.  Report for each R: #bad triples and 12*max coverage of a single admissible set.
import itertools
from tour_util import parse_upper
lines=[l.strip() for l in open('reg11_S2.txt') if l.strip()]
res=[]
for k,l in enumerate(lines):
    R=parse_upper(l,11); n=11
    IN=[sum(1<<i for i in range(n) if R[i][j]) for j in range(n)]
    OUT=[sum(1<<j for j in range(n) if R[i][j]) for i in range(n)]
    bad=[sum(1<<x for x in Y) for Y in itertools.combinations(range(n),3) if not (IN[Y[0]]&IN[Y[1]]&IN[Y[2]])]
    best=0
    for S in range(1<<n):
        if bin(S).count('1')<5: continue
        if any((IN[r]&S)==0 for r in range(n)): continue
        # no source in T[S]: every s in S has an in-neighbour in S
        if any((IN[s]&S)==0 for s in range(n) if (S>>s)&1): continue
        C=((1<<n)-1)&~S
        cov=sum(1 for Y in bad if (Y&C)==Y)
        best=max(best,cov)
    res.append((k,len(bad),best))
ok=sum(1 for k,b,c in res if 12*c<b)
print("R's:",len(res)," contradiction (12*maxcov < #bad) for",ok,"of them")
print("examples:",res[:5]," QR-type #301:",res[301])
print("max ratio #bad/(12*maxcov):",max(b/(12*c) if c else float('inf') for k,b,c in res), " min:",min(b/(12*c) if c else float('inf') for k,b,c in res))
