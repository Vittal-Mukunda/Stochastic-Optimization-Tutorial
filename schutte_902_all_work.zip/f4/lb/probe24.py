import sys, time
sys.argv=[sys.argv[0]]+sys.argv[1:]
from nbhd24 import *
lines=[l.strip() for l in open('reg11_S2.txt') if l.strip()]
k=int(sys.argv[1]); ms=int(sys.argv[2])
t0=time.time(); R=parse_upper(lines[k],11); tours=solve_R(R, maxsol=ms)
print("R#",k,":",len(tours),"solutions in",round(time.time()-t0),"s", flush=True)
cans=canon_many(tours); print("distinct iso classes among them:",len(set(cans)))
