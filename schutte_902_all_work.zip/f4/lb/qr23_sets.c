// For QR_23 (the in-neighbourhood of a minimum-in-degree vertex v in a hypothetical 48-vertex S_4 tournament,
// if that in-neighbourhood is QR_23), enumerate subsets S = D({v,b}) (b an out-neighbour of v) satisfying
// the necessary local conditions:
//  (1) every s in S has >= 5 in-neighbours inside S          (triple {v,b,s} has >= 5 dominators)
//  (2) every z not in S has >= 5 in-neighbours inside S       (triple {v,b,z} has >= 5 dominators)
//  (3) every pair {z1,z2} of QR_23 has a common in-neighbour in S \ {z1,z2}   (4-set {v,b,z1,z2})
#include <stdio.h>
#include <stdint.h>
int main(int argc,char**argv){
  int p=23, isq[23]={0}; for(int x=1;x<p;x++) isq[(x*x)%p]=1;
  uint32_t in[23]; for(int j=0;j<p;j++){ in[j]=0; for(int i=0;i<p;i++) if(i!=j && isq[((j-i)%p+p)%p]) in[j]|=1u<<i; }
  long long cnt[24]={0}; long long tot=0;
  for(uint32_t S=0; S<(1u<<23); S++){ int sz=__builtin_popcount(S); if(sz<11) continue;
    int ok=1;
    for(int z=0;z<p && ok;z++) if(__builtin_popcount(in[z]&S)<5) ok=0;
    for(int a=0;a<p && ok;a++) for(int b=a+1;b<p;b++) if(!(in[a]&in[b]&S)){ ok=0; break; }
    if(ok){ cnt[sz]++; tot++; }
  }
  for(int s=11;s<=23;s++) if(cnt[s]) printf("|S|=%d: %lld subsets\n",s,cnt[s]);
  printf("total %lld\n",tot); return 0; }
