"""CP-SAT version of the 24-vertex in-neighbourhood classification (see nbhd24.py for the conditions).
usage: python3 nbhd24_cp.py reg11_S2.txt k [timelimit_s]   -> counts solutions for R#k
"""
import sys, itertools, time
from ortools.sat.python import cp_model
from tour_util import parse_upper, canon_many

NI, NO = 11, 12
def model_for(R, extra_sym=True):
    m = cp_model.CpModel()
    B = [[m.NewBoolVar(f"b{x}_{y}") for y in range(NO)] for x in range(NI)]       # x -> y
    O = {}
    for y in range(NO):
        for z in range(y+1, NO): O[(y, z)] = m.NewBoolVar(f"o{y}_{z}")
    def o(y, z): return O[(y, z)] if y < z else O[(z, y)].Not()
    cache = {}
    def AND(a, b):
        key = (str(a), str(b)) if str(a) < str(b) else (str(b), str(a))
        if key in cache: return cache[key]
        v = m.NewBoolVar("")
        m.AddBoolAnd([a, b]).OnlyEnforceIf(v)
        m.AddBoolOr([a.Not(), b.Not()]).OnlyEnforceIf(v.Not())
        cache[key] = v; return v
    cR = [[sum(1 for w in range(NI) if R[w][a] and R[w][b]) for b in range(NI)] for a in range(NI)]
    for x in range(NI): m.Add(sum(B[x][y].Not() for y in range(NO)) >= 6)          # in-degree of x >= 11
    for y in range(NO):
        m.Add(sum(B[x][y] for x in range(NI)) >= 5)                                   # pair {u,y}
        m.Add(sum(B[x][y] for x in range(NI)) + sum(o(z, y) for z in range(NO) if z != y) >= 10)  # in-degree y >= 11
    for x in range(NI):
        for x2 in range(x+1, NI):
            m.Add(sum(AND(B[x][y].Not(), B[x2][y].Not()) for y in range(NO)) >= 5 - cR[x][x2])
    for y in range(NO):
        for y2 in range(y+1, NO):
            m.Add(sum(AND(B[x][y], B[x][y2]) for x in range(NI)) + sum(AND(o(w, y), o(w, y2)) for w in range(NO) if w not in (y, y2)) >= 4)
    for x in range(NI):
        for y in range(NO):
            m.Add(sum(B[x2][y] for x2 in range(NI) if R[x2][x]) + sum(AND(B[x][y2].Not(), o(y2, y)) for y2 in range(NO) if y2 != y) >= 5)
    V = [('u', 0)] + [('i', x) for x in range(NI)] + [('o', y) for y in range(NO)]
    def arc(p, q):
        if p == q: return None
        if p[0] == 'u': return None if q[0] == 'i' else True
        if q[0] == 'u': return True if p[0] == 'i' else None
        if p[0] == 'i' and q[0] == 'i': return True if R[p[1]][q[1]] else None
        if p[0] == 'i' and q[0] == 'o': return B[p[1]][q[1]]
        if p[0] == 'o' and q[0] == 'i': return B[q[1]][p[1]].Not()
        return o(p[1], q[1])
    for T in itertools.combinations(V, 3):
        opts = []; sat = False
        for w in V:
            if w in T: continue
            ls = [arc(w, t) for t in T]
            if any(l is None for l in ls): continue
            ls = [l for l in ls if l is not True]
            if not ls: sat = True; break
            if len(ls) == 1: opts.append(ls[0])
            else:
                v = m.NewBoolVar(""); m.AddBoolAnd(ls).OnlyEnforceIf(v); opts.append(v)
        if not sat: m.AddBoolOr(opts)
    # symmetry breaking: columns non-increasing as binary numbers (row 0 = most significant)
    for y in range(NO-1):
        m.Add(sum((1 << (NI-1-x)) * B[x][y] for x in range(NI)) >= sum((1 << (NI-1-x)) * B[x][y+1] for x in range(NI)))
    return m, B, O, V, arc

class Collector(cp_model.CpSolverSolutionCallback):
    def __init__(self, B, O, V, arc, limit):
        super().__init__(); self.B = B; self.O = O; self.V = V; self.arc = arc; self.sols = []; self.limit = limit
    def on_solution_callback(self):
        idx = {('u', 0): 0}
        for x in range(NI): idx[('i', x)] = 1 + x
        for y in range(NO): idx[('o', y)] = 12 + y
        A = [[0]*24 for _ in range(24)]
        for p in self.V:
            for q in self.V:
                if p == q: continue
                a = self.arc(p, q)
                if a is None: continue
                if a is True or self.BooleanValue(a): A[idx[p]][idx[q]] = 1
        self.sols.append(A)
        if len(self.sols) >= self.limit: self.StopSearch()

if __name__ == "__main__":
    lines = [l.strip() for l in open(sys.argv[1]) if l.strip()]
    k = int(sys.argv[2]); tl = float(sys.argv[3]) if len(sys.argv) > 3 else 600
    lim = int(sys.argv[4]) if len(sys.argv) > 4 else 10**9
    R = parse_upper(lines[k], 11)
    t0 = time.time(); m, B, O, V, arc = model_for(R)
    s = cp_model.CpSolver(); s.parameters.enumerate_all_solutions = True; s.parameters.max_time_in_seconds = tl
    s.parameters.num_workers = 1
    cb = Collector(B, O, V, arc, lim)
    st = s.Solve(m, cb)
    print(f"R#{k}: status={s.StatusName(st)} solutions={len(cb.sols)} time={time.time()-t0:.1f}s", flush=True)
    if cb.sols:
        c = canon_many(cb.sols); print("  distinct iso classes:", len(set(c)))
