# Completion test: given D (in-neighbourhood of v, 23 vertices) and the 24 sets A_b, decide by SAT whether
# the arcs inside B can be chosen so that the 48-vertex tournament has property S_4.
import sys, json, itertools, time
from pysat.solvers import Cadical153
from pysat.formula import IDPool
fn=sys.argv[1]; confs=json.load(open(sys.argv[2]))
L=open(fn).read().split(); nA=int(L[0]); D=[[int(c) for c in L[1+i]] for i in range(nA)]
N=48; v=0; Aidx=list(range(1,24)); Bidx=list(range(24,48))
def solve_conf(sets):
    # fixed arcs: fixed[u][w] = 1 if u->w fixed, 0 if w->u fixed, None if variable (both in B)
    fixed=[[None]*N for _ in range(N)]
    def setarc(u,w): fixed[u][w]=1; fixed[w][u]=0
    for a in range(23): setarc(1+a, v)
    for b in range(24): setarc(v, 24+b)
    for a in range(23):
        for c in range(23):
            if D[a][c]: setarc(1+a,1+c)
    for bi,S in enumerate(sets):
        for a in range(23):
            if (S>>a)&1: setarc(1+a,24+bi)
            else: setarc(24+bi,1+a)
    pool=IDPool(); X={}
    for i in range(24,48):
        for j in range(i+1,48): X[(i,j)]=pool.id((i,j))
    def lit(u,w): return X[(u,w)] if u<w else -X[(w,u)]
    fo=[0]*N; fp=[0]*N   # fixed-out mask, fixed-pair mask
    for u in range(N):
        for w in range(N):
            if u!=w and fixed[u][w] is not None:
                fp[u]|=1<<w
                if fixed[u][w]==1: fo[u]|=1<<w
    Bmask=sum(1<<b for b in Bidx)
    cls=[]; nclauses=0; t0=time.time(); empty=False
    for Xs in itertools.combinations(range(N),4):
        xm=0
        for x in Xs: xm|=1<<x
        sat=False; clause=[]
        for w in range(N):
            if (xm>>w)&1: continue
            if (xm & fp[w]) & ~fo[w]: continue           # some fixed arc points the wrong way
            if w<24 or not (xm & Bmask & ~(1<<w)):
                if (xm & ~fp[w])==0: sat=True; break      # all arcs fixed and correct
            vl=[lit(w,x) for x in Xs if not ((fp[w]>>x)&1)]
            if not vl: sat=True; break
            if len(vl)==1: clause.append(vl[0])
            else:
                key=('and',)+tuple(sorted(vl)); new=key not in pool.obj2id; a=pool.id(key)
                if new: cls.extend([[-a,l] for l in vl])
                clause.append(a)
        if sat: continue
        if not clause: empty=True; break
        cls.append(clause)
    if empty: return "UNSAT (some 4-set has no possible dominator)", time.time()-t0
    with Cadical153(bootstrap_with=cls) as s:
        r=s.solve()
    return ("SAT" if r else "UNSAT"), time.time()-t0
for k,sets in enumerate(confs):
    res,dt=solve_conf(sets)
    print(f"configuration {k}: {res}  ({dt:.0f}s)", flush=True)
