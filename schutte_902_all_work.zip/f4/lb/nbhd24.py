"""Classify the possible in-neighbourhoods of a vertex of in-degree 24 in an S_4 tournament.

If d^-(v) = 24 and A = N^-(v), then T[A] (24 vertices) satisfies:
  (a) every vertex has in-degree >= 11 inside A          (|D({a,v})| >= 11)
  (b) every pair has >= 5 common in-neighbours inside A  (|D(P u {v})| >= 5)
  (c) every triple has a common in-neighbour inside A    (S_4 applied to Y u {v})
Some vertex u of A has in-degree exactly 11 in A (degrees >= 11, sum 276); then I = N^-_A(u) induces a
regular (by (b)) S_2 (by (c)) tournament on 11 vertices, i.e. one of the 551 graphs R.  For each R we
enumerate all completions (O = N^+_A(u), 12 vertices) with a SAT solver; O-relabelling is broken by
requiring the I->O incidence columns to be lexicographically non-increasing.
usage: python3 nbhd24.py reg11_S2.txt out_prefix [start end]
"""
import sys, itertools, time
from pysat.solvers import Cadical153
from pysat.card import CardEnc, EncType
from pysat.formula import IDPool
from tour_util import parse_upper, canon_many

NI, NO = 11, 12
def build_model(R):
    cR = [[sum(1 for w in range(NI) if R[w][a] and R[w][b]) for b in range(NI)] for a in range(NI)]
    pool = IDPool()
    B = [[pool.id(('b', x, y)) for y in range(NO)] for x in range(NI)]
    Ov = {(y, z): pool.id(('o', y, z)) for y in range(NO) for z in range(y+1, NO)}
    def o(y, z): return Ov[(y, z)] if y < z else -Ov[(z, y)]
    cls = []; done = set()
    def AND(a, b):
        key = ('and',) + tuple(sorted((a, b)))
        new = key not in pool.obj2id; v = pool.id(key)
        if new: cls.extend([[-v, a], [-v, b], [v, -a, -b]])
        return v
    def atleast(lits, k):
        if k <= 0: return
        if k > len(lits): cls.append([]); return
        cls.extend(CardEnc.atleast(lits=lits, bound=k, vpool=pool, encoding=EncType.seqcounter).clauses)
    # (a) in-degrees >= 11
    for x in range(NI): atleast([-B[x][y] for y in range(NO)], 6)
    for y in range(NO): atleast([B[x][y] for x in range(NI)] + [o(z, y) for z in range(NO) if z != y], 10)
    # (b) pairs
    for y in range(NO): atleast([B[x][y] for x in range(NI)], 5)
    for x in range(NI):
        for x2 in range(x+1, NI):
            atleast([AND(-B[x][y], -B[x2][y]) for y in range(NO)], 5 - cR[x][x2])
    for y in range(NO):
        for y2 in range(y+1, NO):
            atleast([AND(B[x][y], B[x][y2]) for x in range(NI)] + [AND(o(w, y), o(w, y2)) for w in range(NO) if w not in (y, y2)], 4)
    for x in range(NI):
        for y in range(NO):
            atleast([B[x2][y] for x2 in range(NI) if R[x2][x]] + [AND(-B[x][y2], o(y2, y)) for y2 in range(NO) if y2 != y], 5)
    # (c) S_3 inside A
    V = [('u', 0)] + [('i', x) for x in range(NI)] + [('o', y) for y in range(NO)]
    def arc(p, q):
        if p == q: return None
        if p[0] == 'u': return None if q[0] == 'i' else True
        if q[0] == 'u': return True if p[0] == 'i' else None
        if p[0] == 'i' and q[0] == 'i': return True if R[p[1]][q[1]] else None
        if p[0] == 'i' and q[0] == 'o': return B[p[1]][q[1]]
        if p[0] == 'o' and q[0] == 'i': return -B[q[1]][p[1]]
        return o(p[1], q[1])
    for T in itertools.combinations(V, 3):
        clause = []; sat = False
        for w in V:
            if w in T: continue
            ls = [arc(w, t) for t in T]
            if any(l is None for l in ls): continue
            ls = [l for l in ls if l is not True]
            if not ls: sat = True; break
            if len(ls) == 1: clause.append(ls[0])
            else:
                key = ('dom',) + tuple(sorted(ls)); new = key not in pool.obj2id; v = pool.id(key)
                if new: cls.extend([[-v, l] for l in ls])
                clause.append(v)
        if not sat: cls.append(clause)
    # symmetry breaking: columns non-increasing lexicographically (row 0 most significant)
    for y in range(NO-1):
        u = [B[x][y] for x in range(NI)]; w = [B[x][y+1] for x in range(NI)]
        eq = pool.id(('eqT', y)); cls.append([eq])
        for i in range(NI):
            e = pool.id(('eq', y, i+1))
            cls.extend([[-e, eq], [-e, -u[i], w[i]], [-e, u[i], -w[i]], [e, -eq, u[i], w[i]], [e, -eq, -u[i], -w[i]]])
            cls.append([-eq, -w[i], u[i]])
            eq = e
    return cls, pool, B, Ov, o, arc, V

def solve_R(R, maxsol=10**7):
    cls, pool, B, Ov, o, arc, V = build_model(R)
    base = [B[x][y] for x in range(NI) for y in range(NO)] + list(Ov.values())
    sols = []
    with Cadical153(bootstrap_with=cls) as s:
        while s.solve():
            m = set(l for l in s.get_model() if l > 0)
            sols.append(m)
            if len(sols) % 1000 == 0: print("  ...", len(sols), "solutions", flush=True)
            if len(sols) >= maxsol: break
            s.add_clause([-l if l in m else l for l in base])
    idx = {('u', 0): 0}
    for x in range(NI): idx[('i', x)] = 1 + x
    for y in range(NO): idx[('o', y)] = 12 + y
    out = []
    for m in sols:
        A = [[0]*24 for _ in range(24)]
        for p in V:
            for q in V:
                if p == q: continue
                a = arc(p, q)
                if a is None: continue
                if a is True or (a > 0 and a in m) or (a < 0 and -a not in m): A[idx[p]][idx[q]] = 1
        out.append(A)
    return out

def check(A):
    n = len(A); IN = [sum(1 << i for i in range(n) if A[i][j]) for j in range(n)]
    for i in range(n):
        for j in range(i+1, n):
            if A[i][j] + A[j][i] != 1: return False
    if any(bin(IN[j]).count('1') < 11 for j in range(n)): return False
    if any(bin(IN[a] & IN[b]).count('1') < 5 for a in range(n) for b in range(a+1, n)): return False
    if any(not (IN[a] & IN[b] & IN[c]) for a, b, c in itertools.combinations(range(n), 3)): return False
    return True

if __name__ == "__main__":
    lines = [l.strip() for l in open(sys.argv[1]) if l.strip()]
    pref = sys.argv[2]
    st = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    en = int(sys.argv[4]) if len(sys.argv) > 4 else len(lines)
    found = {}
    t0 = time.time()
    with open(pref + "_log.txt", "a") as log:
        for k in range(st, en):
            R = parse_upper(lines[k], 11)
            tours = solve_R(R)
            for A in tours: assert check(A), "verification failed"
            cans = canon_many(tours) if tours else []
            new = 0
            for c in cans:
                if c not in found: found[c] = k; new += 1
            log.write(f"R#{k}: {len(tours)} completions, {new} new, classes so far {len(found)} ({time.time()-t0:.0f}s)\n"); log.flush()
            with open(pref + "_classes.txt", "w") as f:
                for c, kk in found.items(): f.write(f"{c} {kk}\n")
    print("done", len(found), "classes")
