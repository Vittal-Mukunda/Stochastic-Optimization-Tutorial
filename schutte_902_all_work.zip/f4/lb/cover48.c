// Exact search: families of admissible subsets (sizes 12..23) of D with total excess sum(|S|-11) <= BUDGET
// covering all "doubly bad" 4-sets (no common in- or out-neighbour in D). Reports all minimal such families
// (as lists of sets), up to a cap.
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
int p=23; uint32_t in[23], out_[23];
typedef struct { uint32_t S; int cost; uint64_t cov[4]; int ncov; } Cand;
Cand *cands; int ncand=0; uint32_t db[1000]; int ndb=0; int BUDGET=12;
int *bycover[1000]; int nbycover[1000];
long long nsol=0; uint32_t chosen[64]; int nch=0;
int maxratio_num=20;
static int popc256(const uint64_t*a){ return __builtin_popcountll(a[0])+__builtin_popcountll(a[1])+__builtin_popcountll(a[2])+__builtin_popcountll(a[3]); }
void dfs(uint64_t*unc,int budget){
  int left=popc256(unc);
  if(left==0){ nsol++; if(1){ printf("cover:"); for(int i=0;i<nch;i++) printf(" %06x(|%d|)",chosen[i],__builtin_popcount(chosen[i])); printf("  slack=%d\n",budget);} return; }
  if(budget<=0) return;
  // bound: each unit of budget covers at most maxratio sets
  if(left > budget*maxratio_num) return;
  // pick first uncovered
  int x=-1; for(int w=0;w<4&&x<0;w++) if(unc[w]) x=w*64+__builtin_ctzll(unc[w]);
  for(int k=0;k<nbycover[x];k++){ Cand*c=&cands[bycover[x][k]]; if(c->cost>budget) continue;
    uint64_t nu[4]; for(int w=0;w<4;w++) nu[w]=unc[w]&~c->cov[w];
    chosen[nch++]=c->S; dfs(nu,budget-c->cost); nch--; }
}
int main(int argc,char**argv){
  FILE*f=fopen(argv[1],"r"); int n; if(fscanf(f,"%d",&n)!=1) return 1; char row[64];
  if(argc>2) BUDGET=atoi(argv[2]);
  for(int i=0;i<23;i++){ in[i]=out_[i]=0; }
  for(int i=0;i<23;i++){ if(fscanf(f,"%s",row)!=1) return 1; for(int j=0;j<23;j++) if(row[j]=='1'){ out_[i]|=1u<<j; in[j]|=1u<<i; } }
  for(int a=0;a<p;a++)for(int b=a+1;b<p;b++)for(int c=b+1;c<p;c++)for(int d=c+1;d<p;d++){
    uint32_t ci=in[a]&in[b]&in[c]&in[d], co=out_[a]&out_[b]&out_[c]&out_[d];
    if(!ci && !co) db[ndb++]=(1u<<a)|(1u<<b)|(1u<<c)|(1u<<d); }
  printf("doubly bad: %d\n",ndb);
  cands=malloc(sizeof(Cand)*1200000);
  int maxr_num=0,maxr_den=1;
  for(uint32_t S=0;S<(1u<<23);S++){ int sz=__builtin_popcount(S); if(sz<12) continue;
    int ok=1; for(int z=0;z<p&&ok;z++) if(__builtin_popcount(in[z]&S)<5) ok=0;
    for(int a=0;a<p&&ok;a++) for(int b=a+1;b<p;b++) if(!(in[a]&in[b]&S)){ok=0;break;}
    if(!ok) continue;
    Cand c; c.S=S; c.cost=sz-11; memset(c.cov,0,sizeof c.cov); c.ncov=0;
    for(int i=0;i<ndb;i++) if((db[i]&S)==db[i]){ c.cov[i/64]|=1ULL<<(i%64); c.ncov++; }
    if(c.ncov==0) continue;
    if(c.ncov*maxr_den > maxr_num*c.cost){ maxr_num=c.ncov; maxr_den=c.cost; }
    cands[ncand++]=c; }
  maxratio_num=(maxr_num+maxr_den-1)/maxr_den; // ceil
  printf("candidates covering something: %d ; max coverage/excess = %d/%d -> bound %d\n",ncand,maxr_num,maxr_den,maxratio_num);
  for(int i=0;i<ndb;i++){ nbycover[i]=0; }
  for(int k=0;k<ncand;k++) for(int i=0;i<ndb;i++) if((cands[k].cov[i/64]>>(i%64))&1) nbycover[i]++;
  for(int i=0;i<ndb;i++){ bycover[i]=malloc(sizeof(int)*(nbycover[i]+1)); nbycover[i]=0; }
  for(int k=0;k<ncand;k++) for(int i=0;i<ndb;i++) if((cands[k].cov[i/64]>>(i%64))&1) bycover[i][nbycover[i]++]=k;
  uint64_t unc[4]={0}; for(int i=0;i<ndb;i++) unc[i/64]|=1ULL<<(i%64);
  dfs(unc,BUDGET);
  printf("number of covering families (ordered by first-uncovered rule) within budget %d: %lld\n",BUDGET,nsol);
  return 0; }
