// Local analysis for n=48: D = in-neighbourhood (23 vertices, S_3 DRT) of a vertex v of in-degree 23.
// Prints admissible-set statistics and the covering bound for bad 4-sets of D.
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
int p=23; uint32_t in[23], out_[23];
int main(int argc,char**argv){
  FILE*f=fopen(argv[1],"r"); int n; if(fscanf(f,"%d",&n)!=1||n!=23) return 1; char row[64];
  for(int i=0;i<23;i++){ in[i]=out_[i]=0; }
  for(int i=0;i<23;i++){ if(fscanf(f,"%s",row)!=1) return 1; for(int j=0;j<23;j++) if(row[j]=='1'){ out_[i]|=1u<<j; in[j]|=1u<<i; } }
  // bad 4-sets: no common in-neighbour; classify: covered by some IN[z] (common out-nbr) or doubly bad
  static uint32_t db[20000]; int ndb=0, nbad=0;
  for(int a=0;a<p;a++)for(int b=a+1;b<p;b++)for(int c=b+1;c<p;c++)for(int d=c+1;d<p;d++){
    uint32_t ci=in[a]&in[b]&in[c]&in[d], co=out_[a]&out_[b]&out_[c]&out_[d];
    if(!ci){ nbad++; if(!co) db[ndb++]=(1u<<a)|(1u<<b)|(1u<<c)|(1u<<d); } }
  printf("bad 4-sets (no dominator inside D): %d ; with no common out-neighbour either: %d\n",nbad,ndb);
  long long cnt[24]={0}; int best[24]={0}; int adm11_is_in=1; int nadm11=0;
  // also: bad 4-sets not inside any admissible 11-set
  static uint32_t adm11[5000];
  for(uint32_t S=0;S<(1u<<23);S++){ int sz=__builtin_popcount(S); if(sz<11) continue;
    int ok=1; for(int z=0;z<p&&ok;z++) if(__builtin_popcount(in[z]&S)<5) ok=0;
    for(int a=0;a<p&&ok;a++) for(int b=a+1;b<p;b++) if(!(in[a]&in[b]&S)){ok=0;break;}
    if(!ok) continue; cnt[sz]++;
    if(sz==11){ int isin=0; for(int z=0;z<p;z++) if(in[z]==S) isin=1; if(!isin) adm11_is_in=0; adm11[nadm11++]=S; }
    int cov=0; for(int i=0;i<ndb;i++) if((db[i]&S)==db[i]) cov++; if(cov>best[sz]) best[sz]=cov; }
  printf("admissible 11-sets: %d (all equal to in-neighbourhoods: %s)\n",nadm11, adm11_is_in?"yes":"NO");
  for(int s=11;s<=23;s++) printf("  size %2d: %8lld admissible, max doubly-bad covered %4d%s\n",s,cnt[s],best[s], s>11? "":"");
  // budget check: any family with total excess <=12 covering all doubly-bad sets?
  double maxratio=0; for(int s=12;s<=22;s++){ double r=(double)best[s]/(s-11); if(r>maxratio) maxratio=r; }
  printf("max coverage per unit excess over sizes 12..22: %.2f ; x12 = %.1f vs needed %d ; full set covers %d\n",maxratio,12*maxratio,ndb,best[23]);
  return 0; }
