# For each covering family F (large admissible sets) of the doubly-bad 4-sets of D, the remaining
# b in B have A_b = IN[z_b]; the in-degree-23 condition at every a in A gives (I+M) m = r.
import sys, itertools
from fractions import Fraction
fn=sys.argv[1]; cov=sys.argv[2]
L=open(fn).read().split(); n=int(L[0]); A=[[int(c) for c in L[1+i]] for i in range(n)]
IN=[frozenset(i for i in range(n) if A[i][j]) for j in range(n)]
fams=set()
for line in open(cov):
    if not line.startswith('cover:'): continue
    sets=[int(tok.split('(')[0],16) for tok in line.split()[1:] if '(' in tok]
    fams.add(tuple(sorted(sets)))
print(len(fams),"distinct covering families")
# matrix I+M where M[a][z] = 1 if z -> a
import numpy as np
Mx=np.array([[1 if (z==a or A[z][a]) else 0 for z in range(n)] for a in range(n)],dtype=float)
print("det(I+M) =", round(np.linalg.det(Mx)))
inv=np.linalg.inv(Mx)
good=[]
for F in fams:
    r=[12-sum(1 for S in F if not (S>>a)&1) for a in range(n)]
    m=inv@np.array(r,dtype=float)
    mi=np.rint(m)
    ok = np.allclose(m,mi,atol=1e-6) and (mi>=-1e-9).all() and abs(mi.sum()-(24-len(F)))<1e-6
    if ok: good.append((F,mi.astype(int)))
print("families admitting a nonnegative integer solution m:",len(good))
for F,m in good[:10]: print([hex(S) for S in F], list(m))
