# generators for G = Z_p x| <a> acting affinely on r copies of Z_p, plus f fixed points
import sys
p,a,r,f=map(int,sys.argv[1:5])
n=r*p+f
t=list(range(n)); m=list(range(n))
for o in range(r):
    for x in range(p):
        t[o*p+x]=o*p+(x+1)%p
        m[o*p+x]=o*p+(a*x)%p
print(n,2); print(" ".join(map(str,t))); print(" ".join(map(str,m)))
