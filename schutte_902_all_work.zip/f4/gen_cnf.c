// Generate CNF: tournament on n vertices invariant under a permutation group G (given by generators, odd order)
// with property S_K. Usage: gen_cnf K genfile out.cnf map.txt
// genfile: first line n g ; then g lines each a permutation of 0..n-1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#define MAXN 128
#define MAXG 20000
int n,K,ng; int gens[64][MAXN]; int G[MAXG][MAXN]; int order=0;
int var_[MAXN][MAXN], sgn[MAXN][MAXN]; int nbase=0;
// hash map for aux dedup
typedef struct { int lits[4]; int len; int id; } Key;
#define HSZ (1<<24)
Key *H; int nvars;
static uint64_t hkey(int*l,int len){ uint64_t h=1469598103934665603ULL; for(int i=0;i<len;i++){ h^=(uint64_t)(l[i]+1000003); h*=1099511628211ULL; } return h; }
static int get_aux(int*l,int len,FILE*f,long long*ncl){ uint64_t h=hkey(l,len)&(HSZ-1); while(H[h].len){ if(H[h].len==len && !memcmp(H[h].lits,l,sizeof(int)*len)) return H[h].id; h=(h+1)&(HSZ-1);} H[h].len=len; memcpy(H[h].lits,l,sizeof(int)*len); H[h].id=++nvars; for(int i=0;i<len;i++){ fprintf(f,"%d %d 0\n",-nvars,l[i]); (*ncl)++; } return nvars; }
static int cmpi(const void*a,const void*b){ return (*(int*)a)-(*(int*)b); }
static long long C[MAXN+1][8];
int main(int argc,char**argv){
  K=atoi(argv[1]); FILE*gf=fopen(argv[2],"r"); fscanf(gf,"%d %d",&n,&ng); for(int i=0;i<ng;i++) for(int j=0;j<n;j++) fscanf(gf,"%d",&gens[i][j]); fclose(gf);
  for(int a=0;a<=MAXN;a++){ C[a][0]=1; for(int b=1;b<8;b++) C[a][b]= a? C[a-1][b-1]+C[a-1][b] : 0; }
  // group closure (BFS on right multiplication by generators)
  for(int j=0;j<n;j++) G[0][j]=j; order=1;
  for(int i=0;i<order;i++) for(int s=0;s<ng;s++){ int p[MAXN]; for(int j=0;j<n;j++) p[j]=gens[s][G[i][j]];
      int found=0; for(int t=0;t<order;t++) if(!memcmp(G[t],p,sizeof(int)*n)){found=1;break;} if(!found){ if(order>=MAXG){fprintf(stderr,"group too big\n");return 1;} memcpy(G[order++],p,sizeof(int)*n);} }
  fprintf(stderr,"group order %d\n",order); if(order%2==0){fprintf(stderr,"even order group!\n");return 1;}
  memset(var_,0,sizeof var_);
  for(int u=0;u<n;u++)for(int v=u+1;v<n;v++) if(!var_[u][v]){ nbase++; for(int t=0;t<order;t++){ int a=G[t][u],b=G[t][v];
        if(var_[a][b] && (var_[a][b]!=nbase || sgn[a][b]!=1)){fprintf(stderr,"inconsistent pair orbit\n");return 1;}
        var_[a][b]=var_[b][a]=nbase; sgn[a][b]=1; sgn[b][a]=-1; } }
  fprintf(stderr,"base vars %d\n",nbase);
  nvars=nbase; H=calloc(HSZ,sizeof(Key));
  FILE*f=fopen(argv[3],"w"); long long ncl=0; fprintf(f,"p cnf %d %d\n",0,0); // header patched later
  // K-set orbits
  long long tot=C[n][K]; unsigned char*seen=calloc(tot,1); long long norb=0;
  int X[8];
  for(int i=0;i<K;i++) X[i]=i;
  long long *clause_lits = malloc(sizeof(long long)*MAXN*2); int big[MAXN*2];
  while(1){
    long long r=0; for(int i=0;i<K;i++) r+=C[X[i]][i+1];
    if(!seen[r]){ norb++;
      for(int t=0;t<order;t++){ int Y[8]; for(int i=0;i<K;i++) Y[i]=G[t][X[i]]; qsort(Y,K,sizeof(int),cmpi); long long rr=0; for(int i=0;i<K;i++) rr+=C[Y[i]][i+1]; seen[rr]=1; }
      int nb=0; int unit_opts[MAXN]; int nunit=0;
      // collect options
      int opts[MAXN][8]; int optlen[MAXN]; int nopt=0;
      for(int w=0;w<n;w++){ int inX=0; for(int i=0;i<K;i++) if(X[i]==w) inX=1; if(inX) continue;
        int L[8]; int len=0; int bad=0;
        for(int i=0;i<K;i++){ int l=var_[w][X[i]]*sgn[w][X[i]]; int dup=0; for(int j=0;j<len;j++){ if(L[j]==l) dup=1; if(L[j]==-l) bad=1; } if(!dup) L[len++]=l; }
        if(bad) continue; qsort(L,len,sizeof(int),cmpi); memcpy(opts[nopt],L,sizeof(int)*len); optlen[nopt]=len; nopt++; }
      // subsumption: drop options that are supersets of another option
      int keep[MAXN]; for(int a=0;a<nopt;a++) keep[a]=1;
      for(int a=0;a<nopt;a++) if(keep[a]) for(int b=0;b<nopt;b++) if(a!=b && keep[b] && optlen[a]<=optlen[b]){
          // is opts[a] subset of opts[b]?
          int sub=1; for(int i=0;i<optlen[a]&&sub;i++){ int in=0; for(int j=0;j<optlen[b];j++) if(opts[b][j]==opts[a][i]) in=1; if(!in) sub=0; }
          if(sub && !(optlen[a]==optlen[b] && a>b)) keep[b]=0; }
      for(int a=0;a<nopt;a++) if(keep[a]){ if(optlen[a]==1) big[nb++]=opts[a][0]; else big[nb++]=get_aux(opts[a],optlen[a],f,&ncl); }
      if(nb==0){ fprintf(stderr,"empty clause: orbit unsatisfiable\n"); fprintf(f,"0\n"); ncl++; }
      else { for(int i=0;i<nb;i++) fprintf(f,"%d ",big[i]); fprintf(f,"0\n"); ncl++; }
    }
    // next K-subset
    int i=K-1; while(i>=0 && X[i]==n-K+i) i--; if(i<0) break; X[i]++; for(int j=i+1;j<K;j++) X[j]=X[j-1]+1;
  }
  fclose(f);
  fprintf(stderr,"K-set orbits %lld, total vars %d, clauses %lld\n",norb,nvars,ncl);
  // write map: for each u<v: var and sign of (u->v)
  FILE*m=fopen(argv[4],"w"); fprintf(m,"%d\n",n); for(int u=0;u<n;u++)for(int v=u+1;v<n;v++) fprintf(m,"%d %d %d\n",u,v,var_[u][v]*sgn[u][v]); fclose(m);
  // patch header: rewrite file with header (simple approach: print to stdout the header line)
  printf("p cnf %d %lld\n",nvars,ncl);
  return 0;
}
