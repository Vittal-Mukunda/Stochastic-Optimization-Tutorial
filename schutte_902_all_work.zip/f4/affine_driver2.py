import subprocess
# Resume the affine multi-orbit search: skip configs already in out_affine.txt,
# skip r=1 (fixed points would have to lose to the whole orbit, so the orbit itself would need S_4),
# and cap enumeration at 28 free bits.
done = set()
for line in open("out_affine.txt"):
    if line.startswith("p="):
        done.add(line.split(":")[0].strip())

def primes(N):
    return [p for p in range(2, N) if all(p % q for q in range(2, int(p ** 0.5) + 1))]

def gen_of(p):
    fs = [f for f in range(2, p) if (p - 1) % f == 0 and all(f % r for r in range(2, f))]
    for g in range(2, p):
        if all(pow(g, (p - 1) // q, p) != 1 for q in fs):
            return g

for p in primes(67):
    if p < 5:
        continue
    g = gen_of(p)
    for d in range(3, p, 2):
        if (p - 1) % d:
            continue
        a = pow(g, (p - 1) // d, p)
        for r in range(2, 14):
            for f in range(0, 8):
                n = r * p + f
                if not (48 <= n <= 66):
                    continue
                key = f"p={p} |H|={d} r={r} f={f} n={n}"
                if key in done:
                    continue
                with open("aff_tmp.txt", "w") as fh:
                    subprocess.run(["python3", "affgens.py", str(p), str(a), str(r), str(f)], stdout=fh)
                res = subprocess.run(["./genum", "4", "aff_tmp.txt", "28"], capture_output=True, text=True)
                out = res.stdout.strip().splitlines()
                line = out[-1] if out else res.stderr.strip()
                print(f"{key}: {line}", flush=True)
print("AFFINE2 ALLDONE", flush=True)
