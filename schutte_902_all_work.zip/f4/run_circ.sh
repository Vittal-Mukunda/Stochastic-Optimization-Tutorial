#!/bin/bash
# re-verify Fisher: no circulant (rotational) tournament of odd order 49..65 has S_4
for N in 49 51 53 55 57 59 61 63 65; do
  s=$(date +%s); ./cayley $N 1 1 4 0 0 >> out_circ.txt 2>/dev/null; e=$(date +%s); echo "  (took $((e-s)) s)" >> out_circ.txt
done
echo ALLDONE >> out_circ.txt
