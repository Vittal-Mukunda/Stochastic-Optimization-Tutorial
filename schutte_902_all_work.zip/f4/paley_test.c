#include "sk.h"
int isqr(int a,int p){ a%=p; if(a<0)a+=p; for(int x=1;x<p;x++) if((x*x)%p==a) return 1; return 0; }
int main(){ init_bin();
  int primes[]={3,7,11,19,23,31,43,47,59,67,71,79,83};
  for(int t=0;t<13;t++){ int p=primes[t]; static unsigned char A[MAXN*MAXN]; memset(A,0,sizeof A);
    for(int i=0;i<p;i++)for(int j=0;j<p;j++) if(i!=j && isqr(j-i,p)) A[i*p+j]=1;
    Tour T; tour_from_adj(&T,p,A); if(!tour_valid(&T)){printf("invalid %d\n",p);continue;}
    printf("QR_%d:",p); for(int k=1;k<=5 && k<p;k++){ long long b=count_bad(&T,k,1LL<<60); printf("  S_%d bad=%lld",k,b);} printf("\n"); }
}
