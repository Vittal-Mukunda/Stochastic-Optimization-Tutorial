// Szekeres doubly-regular tournament S_p (p = 5 mod 8 prime), n = 2p+1; check S_k
#include "sk.h"
int p; int quartic[200]; // class of nonzero x: 0 if in H4, 1 if 2H4, 2 if 4H4, 3 if 8H4
int powmod(int b,int e,int m){ long long r=1,x=b%m; while(e){ if(e&1) r=r*x%m; x=x*x%m; e>>=1;} return (int)r; }
int main(int argc,char**argv){ p=atoi(argv[1]); init_bin(); int n=2*p+1;
  // find generator g of Z_p^*; H4 = <g^4>; cosets g^j H4. Identify which coset contains 2,4,8.
  int g=2; for(;g<p;g++){ int ok=1; for(int d=1;d<p-1;d++) if((p-1)%d==0 && powmod(g,d,p)==1){ok=0;break;} if(ok) break; }
  int dlog[200]; for(int e=0,x=1;e<p-1;e++){ dlog[x]=e; x=(long long)x*g%p; }
  int c2=dlog[2]%4; // coset index of 2
  if(c2%2==0){ printf("2 is a quadratic residue?? p=%d\n",p); return 1; }
  // class: coset of x relative to H4, expressed as power of 2-coset: H4 ->0, 2H4->1, 4H4->2, 8H4->3
  for(int x=1;x<p;x++){ int c=dlog[x]%4; // c = j*c2 mod 4 => j = c * c2^{-1} mod 4 (c2 odd so invertible mod 4)
    int inv = (c2==1)?1:3; quartic[x]=(c*inv)%4; }
  // vertices: a in Z_p -> a ; a° -> p+a ; t -> 2p
  static unsigned char A[MAXN*MAXN]; memset(A,0,sizeof A);
  #define ARC(u,v) A[(u)*n+(v)]=1
  for(int a=0;a<p;a++){
    for(int b=0;b<p;b++){ if(b==a) continue; int d=((b-a)%p+p)%p; int q=quartic[d];
      if(q==0||q==1) ARC(a,b);                // N+(a) ∩ Zp = a + (H4 ∪ 2H4)
      if(q==0||q==3) ARC(p+a,p+b); }          // N+(a°) ∩ Zp° = a° + (4H4° ∪ 8H4°)?? see below
  }
  // NOTE: from the paper: N+(a) = (a+(H4∪2H4)) ∪ {a°} ∪ (a°+(H4°∪8H4°));  N+(a°) = (a+(H4∪8H4)) ∪ {t} ∪ (a°+(4H4°∪8H4°)); N+(t)=Zp
  memset(A,0,sizeof A);
  for(int a=0;a<p;a++){
    ARC(a,p+a); ARC(p+a,2*p);
    for(int b=0;b<p;b++){ if(b==a) continue; int q=quartic[((b-a)%p+p)%p];
      if(q==0||q==1) ARC(a,b);          // a -> a + (H4 ∪ 2H4)
      if(q==0||q==3) ARC(a,p+b);        // a -> a° + (H4° ∪ 8H4°)
      if(q==0||q==3) ARC(p+a,b);        // a° -> a + (H4 ∪ 8H4)
      if(q==2||q==3) ARC(p+a,p+b);      // a° -> a° + (4H4° ∪ 8H4°)
    }
    ARC(2*p,a);
  }
  Tour T; tour_from_adj(&T,n,A);
  if(!tour_valid(&T)){ // report conflicts
    int bad=0; for(int i=0;i<n;i++)for(int j=i+1;j<n;j++) if(A[i*n+j]+A[j*n+i]!=1) bad++; printf("not a tournament: %d bad pairs\n",bad); return 1; }
  // check doubly regular
  int dmin=999,dmax=0; for(int i=0;i<n;i++){int d=popc(T.out[i]); if(d<dmin)dmin=d; if(d>dmax)dmax=d;}
  printf("Szekeres S_%d: n=%d, outdeg in [%d,%d]\n",p,n,dmin,dmax);
  for(int k=1;k<=5;k++){ long long b=count_bad(&T,k,1LL<<60); printf("  S_%d: #undominated %d-sets = %lld\n",k,k,b); if(b>0 && k>3) break; }
}
