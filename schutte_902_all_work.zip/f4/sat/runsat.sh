#!/bin/bash
# usage: runsat.sh genfile tag [timeout_s] [solver]
# builds CNF for S_4 G-invariant tournaments, solves, verifies.
G=$1; TAG=$2; TO=${3:-600}; SOLVER=${4:-kissat}
B=/home/claude/f4
$B/gen_cnf 4 $G $TAG.body.cnf $TAG.map 2> $TAG.gen.log > $TAG.hdr
tail -n +2 $TAG.body.cnf > $TAG.tmp && cat $TAG.hdr $TAG.tmp > $TAG.cnf && rm -f $TAG.tmp $TAG.body.cnf
if [ "$SOLVER" = "kissat" ]; then
  timeout $TO /home/claude/kissat/build/kissat -q $TAG.cnf > $TAG.sol 2>&1
else
  timeout $TO /home/claude/cadical/build/cadical -q $TAG.cnf > $TAG.sol 2>&1
fi
RES=$(grep -E "^s " $TAG.sol | head -1)
[ -z "$RES" ] && RES="s TIMEOUT"
INFO=$(tr '\n' ' ' < $TAG.gen.log)
if [ "$RES" = "s SATISFIABLE" ]; then V=$($B/verify 4 $TAG.map $TAG.sol FOUND_$TAG.txt); else V=""; fi
echo "$TAG: $RES | $INFO | $V"
rm -f $TAG.cnf
