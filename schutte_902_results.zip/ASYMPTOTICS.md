# Schütte's problem asymptotically: where the factor n is lost

f(n) is the least order of a tournament in which every n vertices have a common dominator (property S_n).
With explicit constants, the classical bounds are

  (n+2)·2^(n−1) − 1  ≤  f(n)  ≤  (ln 2 + o(1))·n²·2^n        (Szekeres–Szekeres 1965; Erdős 1963)

The two sides differ by a factor of about (2 ln 2)·n ≈ 1.39n. This note records an attempt to sharpen either side.
**Result of the attempt:** the order of f(n) is still undecided. Two things are new:

* **A better leading constant:** f(n) ≥ (0.7695… − o(1))·n·2^n, up from 1/2. It comes from a cross-level counting lemma (§2b, full proof in
  `LOWER_BOUND_CONSTANT.md`), and it also gives explicit gains for every n ≥ 5, such as f(5) ≥ 119 and f(10) ≥ 7383.
* **A structure theorem for the extremal case** (§3). It improves the lower bound only by O(1), and only for infinitely many n.

The note also pins down where each method stops.

---

## 1. Upper bound: why the random construction stops at n²2^n

**Erdős.** A uniformly random tournament on N vertices has

  E[#n-sets with no dominator] = C(N,n)·(1−2^(−n))^(N−n) ≈ exp( n ln N − ln n! − N/2^n ).

This is below 1 once N/2^n ≥ n² ln 2 + n ln n + O(n), which gives N = (ln 2 + o(1)) n² 2^n. The constant ln 2 is
ln C(N,n) / n² with N ≈ 2^n·poly(n). It is "the logarithm of the number of n-sets".

**Why the standard upgrades do not lower the constant.**

* *First moment is sharp for this model.* If N = (ln 2 − ε) n² 2^n, the expected number of undominated
  n-sets is e^{εn² + O(n log n)}.
* *Deletion / alteration.* Below the threshold there are e^{Θ(n²)} bad n-sets, which is far more than N. Patching each
  one costs at least one vertex, and the patch vertices create new n-sets that also need dominators.
* *Lovász Local Lemma.* Every two n-sets X, Y share arcs: for disjoint X and Y, the arc between x ∈ X and
  y ∈ Y decides both "y dominates X" and "x dominates Y". So the dependency graph is complete.
* *Symmetry (Cayley, affine or Paley constructions).* These reduce the number of events by factors polynomial in N.
  That only changes the O(n) term in the exponent. Paley tournaments are provably S_n only for p > n²4^n
  (Graham–Spencer, via Weil). Heuristically they behave like random ones. The Paley sizes 7, 19, 67, 331, 1163
  (n = 2,…,6) are 0.44, 0.26, 0.26, 0.41 and 0.50 times n²2^n.

**What any improvement needs.** For every n-set X, |D(X)| ≥ 1 while the mean is μ = N/2^n. A construction of
order o(n²2^n) must make the minimum count over N^n sets stay positive although μ = o(n²). That is a
*design-like* concentration of dominator counts, far stronger than Poisson.

## 2. Lower bound: the Szekeres argument and its ceiling

From S_n one gets the following (Moon, *Topics on Tournaments*, Thm 16 and its corollary):

* every (n−1)-set has at least n+1 dominators;
* in general, every (n−j)-set has at least (n+2)2^(j−1) − 1 dominators;
* hence N ≥ (n+2)2^(n−1) − 1.

A cleaner way to see the mechanism uses two lemmas.

**Lemma 1 (non-coverability).** If |A| = n − j, then D(A) is *not* covered by any j closed out-neighbourhoods
N⁺[z₁] ∪ … ∪ N⁺[z_j].
*Proof.* Vertices of A cover nothing in D(A), so assume all z_i ∉ A. Extend A ∪ {z_i} to an n-set X. Some
y ∉ X dominates X. Then y ∈ D(A), so y ∈ N⁺(z_i) for some i, which means z_i → y. But y → z_i, a contradiction. ∎

**Lemma 2 (greedy covering).** If T has S_n and minimum in-degree δ, then every set S with
|S| ≤ n·(N/(N−δ))^(j−1) is covered by j closed out-neighbourhoods.
*Proof.* We have Σ_z |R ∩ N⁺(z)| = Σ_{r∈R} d⁻(r) ≥ δ|R|. So some z removes a δ/N fraction of the remaining set R.
After j−1 such steps at most n vertices are left, and S_n supplies the last vertex. ∎

**Consequence.** For |A| = n − j we get |D(A)| > n·(N/(N−δ))^(j−1). Since δ ≤ (N−1)/2, this is at most about n·2^(j−1). Averaging over (n−j)-sets
(Σ_A |D(A)| = Σ_w C(d⁺(w), n−j)) gives N ≳ n·2^(n−1) at **every** level j. In a regular tournament the factor 2
gained per level in Lemma 2 exactly cancels the factor 2 lost per level in the averaging. So arguments that use only
Lemma 1, Lemma 2 and averaging cannot beat n·2^(n−1)(1 + o(1)). The next subsection gets past this with a different kind of count.

## 2b. New: a cross-level lemma beats the Szekeres constant

Let ν_s be the minimum of |D(X)| over s-sets X, so ν_0 = N and ν_n ≥ 1.

**Lemma.** For every s-set A with m = |D(A)|, and every 1 ≤ k ≤ n: (N − s)·C(m − ν_{s+1}, k) ≥ ν_k·C(m, k).

*Proof.* Count the pairs (U, y) with U a k-subset of D(A) and y a dominator of U. Each U has at least ν_k dominators. A
dominator y cannot lie in A. It is beaten by every vertex of D(A ∪ {y}) = D(A) ∩ N⁻(y), a set of at least ν_{s+1} vertices, so
U avoids that set. ∎

The Szekeres chain only halves from level to level. The lemma adds a second constraint: the n-subsets of D(A) must all be dominated, yet each
dominator handles only the n-subsets of a part of D(A) of size m − ν_{s+1}. At level s = n−2 this rules out |D(A)| ≈ 2n.
The lemma forces |D(A)| ≥ 2.562n, and the gain grows level by level to

  **f(n) ≥ (c\* − o(1))·n·2^n,  c\* = 0.769503…**,

compared with 1/2 for Szekeres. Proof, constant, tables and checks are in `LOWER_BOUND_CONSTANT.md`. The recursion starts from
ν_{n−1} ≥ n+1. That base is now the bottleneck: ν_{n−1} = ω(n) would give f(n) = ω(n·2^n).

**The gap in one sentence.** Deciding the order of f(n) amounts to deciding how small a j-non-coverable set can be
in an S_n tournament. Lemma 2 gives the general lower bound n·2^(j−1). In a random tournament the smallest one has
size about j·2^j·ln N ≈ j·n·2^j·ln 2, because a set of size m is covered by roughly N^j(1−2^(−j))^m of the j-sets. Taking
j = n turns the missing factor j into the missing factor n. A lemma of the form "j-non-coverable sets have size at least c·j·n·2^j" would give
f(n) = Θ(n²2^n). The same lemma for j ≈ log n alone would give f(n) = Ω(n log n·2^n), which would already be new.

## 3. The extremal structure (new)

**Theorem.** Let n ≥ 4 and suppose an S_n tournament T has exactly N = (n+2)2^(n−1) − 1 vertices. Put
r = (N−1)/2, t = (r−1)/2, s = (t−1)/2 and q = (s−1)/2. Then:

* (a) T is regular, and doubly regular: every pair has exactly t common dominators.
* (b) Every transitive triple has exactly s dominators. Every cyclic triple has either s or t. The "heavy" triples,
  those with t dominators, form a **Steiner triple system** on V. Moreover a heavy triple C = {a,b,c} satisfies D(C) = D({a,b}) = D({b,c}) = D({c,a}).
* (c) For each v there is a bijection ψ_v : N⁺(v) → N⁻(v), sending x to the third vertex of the heavy triple on {v,x}. It satisfies
  N⁻(v) ∩ N⁻(x) = N⁻(v) ∩ N⁻(ψ_v(x)). Consequently, every n-subset of N⁻(v) that has no dominator inside N⁻(v)
  has a source: a vertex beating the other n−1.
* (d) For n ≥ 5, every 4-set has exactly q or s dominators. The 4-sets with s dominators that contain no heavy triple form a
  system in which every non-heavy triple lies in exactly one block.

*Proof sketch.* (a) and the first part of (b) follow from equality in every step of the Szekeres chain. For example,
in-degrees inside N⁻(v) are at least t and sum to C(r,2) = rt, so they are all t. The same works one level down. The
identity Σ_{cyclic}(λ−s)(λ−t) = 0, together with s ≤ λ ≤ t, forces λ ∈ {s,t}. Counting per pair gives exactly one heavy
triple through each pair. For (c), D({v,x}) = D(heavy triple) = D({ψ_v(x), v}). A dominator x ∈ N⁺(v) of an n-set
X ⊆ N⁻(v) therefore requires X ⊆ {y} ∪ N⁺(y) with y = ψ_v(x). So either y ∈ N⁻(v) already dominates X, or y ∈ X is a source.
For (d), the identity Σ_{source-less 4-sets}(μ−q)(μ−s) = 0 holds. Every source-less 4-set has q ≤ μ ≤ s: one containing a heavy
triple has exactly s. So μ ∈ {q,s}. Per-triple counting then gives exactly 4 heavy extensions of every light triple, and
exactly 3 of those contain a heavy triple. ∎
The identities are checked symbolically for all n in `lower_bound/sts_identity.py` and `lower_bound/eq4_symbolic.py`.

**Corollaries.**
* An STS(N) needs N ≡ 1, 3 (mod 6), so equality is impossible for n ≡ 1 (mod 3). Hence f(n) ≥ (n+2)2^(n−1) for
  n = 4, 7, 10, … For n = 4 the bound 48 was first proved by Reid et al. (2004), who used the non-existence of triply regular tournaments.
  For n ≥ 5 the corollary is superseded by §2b, which shows that the Szekeres bound is never attained for n ≥ 4.
* For n = 4, combining (c) with the classification of S_3 doubly regular tournaments on 23 vertices gives the stronger f(4) ≥ 49 (`RESULTS.md`).
* The structure is also pushed one level further, to 5-sets: there, a third value of μ is forced to occur. That level gives no contradiction by divisibility (`eq5.py`).

**What this does and does not show.** The Szekeres bound could only be tight for an extraordinarily rigid
design: an STS together with a "quadruple system on its complement", and so on. That is strong evidence that the true
value is larger. But the argument rules out equality, and near-equality at n = 4, only by O(1) vertices. It does not
touch the leading term. Once N exceeds the bound by a constant factor, the slack in the counting (the "budget") grows
like (t+1)(N − N₀), and the rigid structure disappears.

## 4. Lines of attack, with an honest assessment

1. **A covering-array-type lemma.** This would be the lower-bound breakthrough: j-non-coverable sets have size Ω(j·n·2^j), even for j ≤ log n.
   The analogous log-factor in covering arrays comes from columns having to be distinct. Here only the all-ones pattern is required. Any proof must
   therefore use the tournament (skew) structure, not just covering.
2. **Stability plus discrepancy.** This would gain a constant factor on the lower bound. If N ≤ (1/2+ε)n2^n, every vertex must split every dominator set
   D(A) almost exactly in half: Lemma 2 is nearly tight at every level. A tournament-discrepancy theorem at the scale of sets of size about n
   would contradict this. No such theorem is known at that scale.
3. **Design-like constructions.** This would lower the upper bound. Candidates are semi-random "nibble" constructions that keep the uncovered n-sets
   structured, and algebraic tournaments with equidistribution of dominator counts better than the Weil bound gives.
   Computation can only screen candidates; it cannot establish an asymptotic.

4. **The (n−1)-level base.** After §2b this is the most direct target. Show that an (n−1)-set needs at least a_1·n dominators with
   a_1 > 1. With a_1 = 1.5 the constant would rise above 1. With a_1 → ∞ the order of f(n) would change. Lemma 1 gives only n+1,
   and the cross-level lemma gives nothing at this level, because its input ν_n ≥ 1 is too weak.

Lines 1–4 were not carried out here. Each is a research project, and the problem has been open since 1965. The parts
that can be written up as results are the constant c\* = 0.7695… (§2b), the explicit bounds f(5) ≥ 119, f(6) ≥ 279, …,
the fact that the Szekeres bound is attained only for n = 2, 3, f(4) ≥ 49, and the structure theorem above.
