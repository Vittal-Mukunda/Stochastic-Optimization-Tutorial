# Erdős #902 (Schütte's problem): results

> **Round 4:** f(4) ≥ 51 with a proof entirely by hand (`ROUND3_FINDINGS.md` §0).
>
> **Round 3:** f(4) ≥ 50. The proof combines the min-in-degree theorem of §3 below with a degree-sum count. There is also a five-line
> hand proof of f(4) ≥ 49, and sharper bounds f(5) ≥ 121, f(6) ≥ 281. Full details are in `ROUND3_FINDINGS.md`.
>
> **Round 2 (general n):** f(n) ≥ (0.7695… − o(1))·n·2^n, improving the Szekeres–Szekeres constant 1/2. There are also
> explicit improvements for every n ≥ 5, for example f(5) ≥ 119 (was 111) and f(6) ≥ 279 (was 255). The proof is in
> `LOWER_BOUND_CONSTANT.md`, and the scripts are in `asymptotic_lower_bound/`. The order of magnitude (n·2^n vs n²·2^n) is still open.

## The case k = 4

**Problem.** f(k) is the smallest n such that some n-vertex tournament has property S_k: every k vertices
are beaten by one common other vertex. f(1)=3, f(2)=7, f(3)=19 are known. f(4) is open.

| | literature | your research (README) | **now** |
|---|---|---|---|
| lower bound | 48 (Reid–McRae–Hedetniemi–Hedetniemi 2004, Cor. 7); 49 posted by J. Wilder (GitHub, Sep 2026, computer-assisted) | 48 (equality case) | **51** (round 4, by hand, `ROUND3_FINDINGS.md` §0); 50 in round 3 (computer-assisted) |
| upper bound | 67 (Paley tournament QR_67) | 67 | 67 (unchanged) |

So **51 ≤ f(4) ≤ 67** after round 4. The problem is not solved: the gap is still 17. The text below describes round 1, which reached 49 independently
of Wilder's repository. *Correction:* an earlier version of this table gave the
literature lower bound as 47. The bound 48 was already proved in 2004, by ruling out the equality case with the non-existence of
triply regular tournaments. Your README's 48 is therefore a rediscovery. This round adds:

1. **A new lower bound, f(4) ≥ 49.** Stronger structural facts come with it. Every S_4 tournament on at
   most 51 vertices has minimum in-degree at least 24, so an S_4 tournament on 49 vertices would have to be regular.
2. **A second proof of f(4) ≥ 48** (first proved by Reid et al. 2004). In the equality case the "heavy" triples form a Steiner triple
   system on 47 points, which cannot exist. The same argument gives f(k) ≥ (k+2)·2^(k−1) for every k ≡ 1 (mod 3) with k ≥ 4.
   For k ≥ 5 this is now superseded by `LOWER_BOUND_CONSTANT.md`.
3. **A much wider negative search for the upper bound.** 138 highly symmetric families on 48–66 vertices were
   enumerated exhaustively: 110 new ones and 28 independent re-checks of yours. One non-Cayley vertex-transitive family
   was also searched. None contains an S_4 tournament. The search also shows that QR_67 cannot be repaired locally.

---

## 1. Notation and the Szekeres facts

D(X) is the set of dominators of X, that is, the vertices outside X that beat every vertex of X.
T has S_4 iff D(X) ≠ ∅ for every 4-set X. N⁻(v) and N⁺(v) are the in- and out-neighbourhoods of v.

From Szekeres–Szekeres (see Moon, *Topics on Tournaments*, Thm 16 and its corollary), if T has S_4 then:

* **(F1)** every triple Y has |D(Y)| ≥ 5. If |D(Y)| ≤ 4, some x beats all of D(Y), and some y beats Y ∪ {x}. Then y ∈ D(Y), so x → y and y → x, a contradiction.
* **(F2)** for every pair P, each c ∈ D(P) has at least 5 in-neighbours inside D(P), because D(P ∪ {c}) ⊆ D(P) ∩ N⁻(c). Hence |D(P)| ≥ 11.
* **(F3)** for every vertex v, each a ∈ N⁻(v) has at least 11 in-neighbours inside N⁻(v), because D({a,v}) = N⁻(a) ∩ N⁻(v). Hence d⁻(v) ≥ 23, and so n ≥ 47.

## 2. f(4) ≥ 48 via a Steiner triple system (bound first proved by Reid et al. 2004)

Take n = 47. By (F3) every in-degree is exactly 23. Each in-neighbourhood is regular of degree 11, so every pair has exactly 11 common
dominators (T is doubly regular). Inside each D(P) every in-degree is exactly 5, so every **transitive** triple has exactly s = 5
dominators. Every **cyclic** triple has between s = 5 and t = 11. Regularity and double regularity fix Σλ and Σλ² over all triples, and they force

  Σ over cyclic triples of (λ − 5)(λ − 11) = 0,

so every cyclic triple has λ ∈ {5, 11}. For a fixed pair P, Σ_{x∉P} (λ(P∪{x}) − 5) = 11·21 − 5·45 = 6. So **each pair lies in exactly one
heavy triple** (one with λ = 11). The heavy triples would therefore form a Steiner triple system on 47 points, which is impossible because 47 ≡ 5 (mod 6).

`lower_bound/sts_identity.py` checks the identity symbolically for every k ≥ 4. The equality case N = (k+2)2^(k−1) − 1
always yields an STS(N), which is impossible when N ≡ 2 (mod 3), that is, when k ≡ 1 (mod 3). Hence **f(k) ≥ (k+2)·2^(k−1) for k = 4, 7, 10, …**

## 3. New: f(4) ≥ 49

**Lemma 1.** If T has S_4 and d⁻(v) = 23, then A = T[N⁻(v)] is a doubly regular tournament on 23 vertices with property S_3.

*Proof.* By (F3) the in-degrees inside A are at least 11 and sum to C(23,2) = 23·11, so A is regular. For a pair P ⊆ A, the
common in-neighbours of P inside A are exactly D(P ∪ {v}), and (F1) gives at least 5 of them. The sum over pairs is
23·C(11,2) = 253·5, so every pair has exactly 5. Every triple Y ⊆ A has a dominator for Y ∪ {v}, and that dominator lies in A. ∎

**Lemma 2 (computation).** Up to isomorphism there are exactly **37** doubly regular tournaments on 23 vertices. Exactly
**2** of them have S_3: the Paley tournament QR_23 (|Aut| = 253) and one more, D₂ (|Aut| = 55).

*Method.* Seen from any vertex 0 of such a tournament, the in-neighbourhood is a regular 11-tournament. Nauty's `gentourng`
lists all 1223 of these, and 551 of them have S_2. For each one, a SAT solver (CaDiCaL via PySAT) enumerates every
completion: the arcs from the in-neighbourhood to the out-neighbourhood, and the tournament on the out-neighbourhood. The completions satisfy double
regularity and (optionally) S_3. Relabelling of the out-neighbourhood is broken by sorting its incidence columns. Every
solution is verified directly and reduced up to isomorphism with nauty's `labelg`.
*Cross-checks.* Without the S_3 constraint, the method finds exactly 37 classes. That matches McKay's catalogue of
doubly-regular tournaments, which lists 37 on 23 vertices. Their bordered skew-Hadamard matrices fall into exactly 16
Hadamard-equivalence classes, which matches the known 16 skew-Hadamard matrices of order 24. Filtering those 37 by S_3 gives the
same 2 classes (`lower_bound/crosscheck.out`).

**Lemma 3.** Let T have S_4 on n vertices, d⁻(v) = 23, A = N⁻(v) and B = N⁺(v). For b ∈ B let A_b = A ∩ N⁻(b) = D({v,b}). Then:

* (i) A_b is **admissible**: |A_b| ≥ 11 by (F2); |A_b ∩ N⁻(z)| ≥ 5 for every z ∈ A, because that set is D({v,b,z}); and every pair
  {z₁,z₂} ⊆ A has a common in-neighbour in A_b, because D({v,b,z₁,z₂}) ≠ ∅.
* (ii) The **excess budget** satisfies Σ_{b∈B} (|A_b| − 11) ≤ 12n − 564. Indeed Σ_b |A_b| = Σ_{a∈A} (d⁺(a) − 1 − 11) ≤ 23(n − 36),
  using d⁻(a) ≥ 23, and |B| = n − 24.
* (iii) A 4-set X ⊆ A with no dominator inside A must be beaten by some b ∈ B, because v loses to all of A. So
  **X ⊆ A \ A_b** for some b.

**Lemma 4 (computation, for both D ∈ {QR_23, D₂}).** All 2²³ subsets were enumerated by two independent programs, one in C and one in Python.

* Call a 4-set of D *undominated* if it has no dominator inside D. The admissible 11-sets are exactly the 23 in-neighbourhoods N⁻(z).
  Their complements {z} ∪ N⁺(z) contain only undominated 4-sets that have a *source*, a vertex beating the other three.
* D has **1012** (QR_23) or **1045** (D₂) undominated 4-sets with no source.
* For an admissible A_b of size 11 + e with e ≥ 1, the complement contains at most 12.5·e (QR_23) or 20·e (D₂) of them.

**Theorem.** In an S_4 tournament on n ≤ 51 vertices, every vertex has in-degree at least 24. Hence **f(4) ≥ 49**, and an S_4
tournament on 49 vertices would have to be regular.

*Proof.* Suppose d⁻(v) = 23. Every source-less undominated 4-set of A must lie in A \ A_b for some b with |A_b| ≥ 12.
By Lemma 4, the b's together cover at most r·(12n − 564) ≤ 48r of them, with r = 12.5 or 20. That gives at most 600 or 960 covered sets,
fewer than 1012 or 1045, which is a contradiction. The table for every n is in `lower_bound/local48b_out.txt`. For n = 48 the budget is only 12,
so the bound is 150 or 240. So the minimum in-degree is at least 24, and since the minimum in-degree is at most (n − 1)/2, n ≥ 49. ∎

The margin is large: 600 against 1012, and 960 against 1045. The weakest computational link is Lemma 2, and it matches two independent published counts.

## 4. Upper-bound search (no S_4 tournament found below 67)

* **QR_67 is locally rigid.** Every vertex is the *unique* dominator of exactly 330 4-sets, so deleting any vertex
  leaves exactly 330 undominated 4-sets. Flipping an arc breaks about 40 others on average. Incremental local search (`s4ls.c`) never
  improved on 330. Tabu search inside the Z₃₃-invariant family that contains QR_67 − v got stuck at 10 bad orbits (= 330 sets).
  From random starts, local search stalls around 500 bad sets even at n = 90, where Paley examples exist. Unstructured search is
  hopeless here. Solutions are isolated "needles".
* **SAT is not competitive here.** Kissat did not finish the 29-variable cyclic family on 59 vertices in 4 minutes.
  Plain Gray-code enumeration takes 61 s on it. Kissat also failed to find QR_67 in the 33-variable cyclic family within 5 minutes.
* **New exhaustive enumerator `genum2.c`.** Each candidate dominator is a 64-bit (mask, value) test, and the program uses conflict-directed jumps. It is about
  200× faster than `genum` on large-group families. A 30-bit family took 1.5 s, against 317 s before.
* **New families (`families.py` + `gact.py`)** are built as unions of coset spaces of odd-order groups.
  The groups are Z_p ⋊ C_d (p ≤ 31), GF(25) ⋊ C₃, GF(27) ⋊ C₁₃, GF(27) ⋊ (C₁₃ ⋊ Frobenius) and GF(27) ⋊ Frobenius. The orbit types are affine, regular, quotient
  and fixed points. **All 138 catalogued families with at most 37 free bits were completed, covering every n from 48 to 66. All were negative.** That
  is 110 new families plus 28 independent re-checks of your DONE families, and it includes 8 that your `out_affine.txt` had SKIPped.
  Z₁₃⋊C₃ on n = 53 and Z₁₉⋊C₃ on n = 59 first timed out at 30 min. They were then finished by splitting each into two halves
  (`rerun_split.sh`, `reruns_log.txt`). The 77 catalogued families with 38–48 bits are not done.
* **Vertex-transitive but non-Cayley:** Z₁₉ ⋊ C₉ acting on the 57 cosets of C₃, 10 bits. Negative. It is not
  covered by "all Cayley tournaments".

## 5. What would move the bounds next

The asymptotic question (n·2^n versus n²·2^n) and a structure theorem for the extremal case for every n are covered in `ASYMPTOTICS.md`.


* **f(4) ≥ 50** needs ruling out a *regular* 49-vertex S_4 tournament. The same budget argument applies with budget exactly 12.
  The obstacle is classifying the possible 24-vertex in-neighbourhoods: min in-degree ≥ 11, ≥ 5 common in-neighbours per pair, S_3.
  They are not rigid, and both CaDiCaL and CP-SAT stall on them (`nbhd24*.py` were attempted, not included).
* **f(4) ≤ 66** needs a structure outside every family checked so far. That means a tournament with a small automorphism group,
  or one from a group or orbit pattern not in the catalogue. The remaining 38–48-bit families are the cheapest next step.

## Files

* `lower_bound/`: `reg11.txt` (all 1223 regular 11-tournaments), `reg11_S2.txt` (the 551 with S_2), `drt23_s3.py`
  and `drt23_all.py` (classification), `alldrt_classes.txt` (37 DRT(23), digraph6), `all_classes.txt` and
  `drt23_class{0,1}.txt` (the two S_3 DRT(23); class 1 = QR_23), `crosscheck.py/.out`, `local48b.c` with
  `local48b_out.txt`, `verify_cover_py.py` with `verify_class{0,1}.out`, `sts_identity.py`, `tour_util.py`.
* `asymptotic_lower_bound/`: `crosslevel.py` (exact recursion, table to n = 26 in `table_exact.txt`), `crosscheck_small.py`
  (independent re-implementation, n ≤ 9), `crossfloat.py` (large n, `large_n.txt`), `limit_const.py` (c\*), `sanity.py`
  (brute-force check of every proof step on QR_7, QR_19, QR_67 and random S_2 tournaments, `sanity_out.txt`),
  `szekeres_never_tight.py` (the Szekeres bound is not attained for n ≥ 8, by the one-line argument).
* `upper_bound/`: `gact.py`, `families.py`, `fams/` (generator files and `index.txt`), `genum2.c`, `runlist.sh`,
  `fams_log.txt`, `s4ls.c`, `qr_analyze.c`, `gen_qr_minus.py`, `fam_test.py` (Paley control and the non-Cayley 57 family), `sk.h`.

Build: `gcc -O3 -march=native -o genum2 genum2.c` and so on. Run `VORD=1 ./genum2 4 fams/fam0000.txt 62`.
The lower-bound scripts need `python-sat`, `numpy` and nauty's `gentourng`/`labelg` (the path is set in `tour_util.py`).

### Sources
* Erdős Problems #902: https://www.erdosproblems.com/902
* erdosproblems.ai wiki, E0902 (status, claims, references): https://erdosproblems.ai/wiki/problems/extremal_graph_theory/E0902
* K. B. Reid, A. A. McRae, S. M. Hedetniemi, S. T. Hedetniemi, Domination and irredundance in tournaments,
  Australas. J. Combin. 29 (2004) 157–172 (Cor. 7: f(4) ≥ 48): https://ajc-new.maths.uq.edu.au/pdf/29/ajc_v29_p157.pdf
* J. W. Moon, *Topics on Tournaments* (1968), §11, Thm 16 and corollary: https://www.gutenberg.org/ebooks/42833
* E. and G. Szekeres, On a problem of Schütte and Erdős, Math. Gazette 49 (1965) 290–293
* B. McKay, digraph data (doubly-regular tournaments: 37 on 23 vertices): https://users.cecs.anu.edu.au/~bdm/data/digraphs.html
* "Type II codes from the 16 skew Hadamard matrices of order 24": https://www.researchgate.net/figure/Type-II-codes-from-the-16-skew-Hadamard-matrices-of-order-24_tbl1_220639288
* OEIS A362137 (Paley sizes 1, 3, 7, 19, 67, …): https://oeis.org/A362137
