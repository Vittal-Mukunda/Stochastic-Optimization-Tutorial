# Erdős #902 (Schütte's tournament problem) — search code and logs

f(k) = smallest n such that some n-vertex tournament has property S_k
(every k vertices are all beaten by one other vertex). Known: f(4) ∈ [48, 67].

## Programs (C, gcc -O3 -march=native)
- `sk.h` — bitset checker for property S_k (n ≤ 128). Validated in `paley_test.c`:
  QR_7 has S_2, QR_19 has S_3, QR_67 has S_4, every smaller QR_p fails S_4.
- `cayley.c` — exhaustive search over ALL Cayley tournaments on G = Z_m ⋊_r Z_k
  (Gray code over the (|G|-1)/2 inverse pairs, checks 4-sets through the identity).
  `./cayley m k r 4 0 0`; cyclic group Z_n is `./cayley n 1 1 4 0 0`.
  Positive control: `./cayley 67 1 1 4 13 110` finds QR_67.
- `genum.c` — exhaustive search over all tournaments invariant under a permutation
  group given by generators (`affgens.py p a r f` builds Z_p ⋊ <a> acting on r copies
  of Z_p plus f fixed points). `./genum 4 gens.txt 28`.
- `szekeres.c` — Szekeres doubly-regular tournaments S_p (2p+1 vertices).
- `gen_cnf.c`, `verify.c` — SAT (DIMACS) encoding of S_k for group-invariant tournaments
  and an independent verifier of solver output. `gls.c` — tabu search in the same spaces.

## Logs (all negative for S_4)
- `out_circ.txt` — every circulant tournament of odd order 49–65 (re-checks Fisher 1996).
- `out_7x7.txt`, `out_cayley.txt` — every Cayley tournament on Z7×Z7 (49), Z11⋊Z5 (55),
  Z19⋊Z3 (57), Z3×Z21, Z7⋊Z9, Z3×(Z7⋊Z3) (63).
- `out_affine.txt` — 28 affine multi-orbit families, 48–66 vertices
  (lines marked SKIP were too large to enumerate and were not searched).

Tournaments have no automorphisms of even order, so Cayley tournaments exist only on
groups of odd order; with f(4) ≥ 48 the logs cover every Cayley tournament on 48–66 vertices.
