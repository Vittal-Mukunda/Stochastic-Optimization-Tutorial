# Independent check of the base agent's planted example: S_4 tournament on 70 vertices with a thin triple.
import itertools, sys
fn = sys.argv[1]; n = int(sys.argv[2])
lines = [l for l in open(fn) if not l.startswith('#') and l.strip()]
N = len(lines)
out = [0]*N
for v, l in enumerate(lines):
    for w in map(int, l.split()): out[v] |= 1 << w
# tournament check
for v in range(N):
    assert not (out[v] >> v) & 1
    for w in range(v+1, N):
        assert ((out[v] >> w) & 1) ^ ((out[w] >> v) & 1), (v, w)
inn = [sum(1 << u for u in range(N) if (out[u] >> v) & 1) for v in range(N)]
full = (1 << N) - 1
bad = 0
for X in itertools.combinations(range(N), n):
    m = full
    for x in X: m &= inn[x]
    if m == 0: bad += 1
print(f"{fn}: N={N}, undominated {n}-sets: {bad}")
B = [67, 68, 69]
m = full
for b in B: m &= inn[b]
print("D(B) =", [v for v in range(N) if (m >> v) & 1])
