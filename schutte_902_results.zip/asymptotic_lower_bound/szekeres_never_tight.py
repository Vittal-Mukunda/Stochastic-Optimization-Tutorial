# For n >= 8: if N <= (n+2)2^(n-1) - 1, the lemma at s = n-2, k = n (with nu_{n-1} >= n+1) forces |D(A)| >= 2n+4
# for every (n-2)-set A, because C(m,n)/C(m-n-1,n) >= C(2n+3,n)/C(n+2,n) > N - n + 2 for m <= 2n+3.
# Then (M2) gives N >= 2^(n-2)(2n+5) - 1 > (n+2)2^(n-1) - 1, a contradiction. So f(n) > (n+2)2^(n-1) - 1.
from math import comb
from fractions import Fraction
bad = []
for n in range(8, 401):
    S = (n+2)*2**(n-1) - 1
    if not Fraction(comb(2*n+3, n), comb(n+2, n)) > S - n + 2: bad.append(n)
print("n in [8,400] where the one-line argument fails:", bad)
for n in range(5, 9):
    S = (n+2)*2**(n-1) - 1
    print(n, "ratio C(2n+3,n)/C(n+2,n) =", round(comb(2*n+3, n)/comb(n+2, n), 1), " vs  S-n+2 =", S - n + 2)
