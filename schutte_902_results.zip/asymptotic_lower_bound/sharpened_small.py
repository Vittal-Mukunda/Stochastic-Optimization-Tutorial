# Sharpened cross-level lemma (verifier's refinement): dominators y inside R = D(A) also exclude themselves, so
#   (N - s - m) C(m - h, k) + m C(m - h - 1, k) >= nu_k C(m, k),   h = nu_{s+1}.
from math import comb
def feasible(n, N, sharp=True):
    nu = {n: 1}
    for s in range(n-1, -1, -1):
        h = nu[s+1]
        lowk = lambda k: nu[k] if k > s else 2**(s+1-k)*(h+1) - 1
        def ok(m):
            for k in range(1, min(m, n)+1):
                lhs = ((N-s-m)*comb(m-h, k) + m*comb(m-h-1, k)) if sharp else (N-s)*comb(m-h, k)
                if lhs < lowk(k)*comb(m, k): return False
            return True
        m = 2*h + 1
        while not ok(m):
            m += 1
            if m > N - s: return False
        nu[s] = m
    return nu[0] <= N
for n in range(2, 13):
    sz = (n+2)*2**(n-1) - 1
    N = sz
    while not feasible(n, N): N += 1
    M = sz
    while not feasible(n, M, sharp=False): M += 1
    print(f"n={n:2d}  Szekeres={sz:6d}  lemma={M:6d}  sharpened={N:6d}", flush=True)
# hand proof of f(4) >= 49: N <= 48, pair with m = 11 dominators, k = 3
N = 48; m = 11; h = 5
print("f(4) hand check: upper", (N-2-m)*comb(m-h,3) + m*comb(m-h-1,3), "vs lower", 5*comb(m,3))
