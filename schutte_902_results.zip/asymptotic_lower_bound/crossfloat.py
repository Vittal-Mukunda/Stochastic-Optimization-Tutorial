# float (lgamma) version of crosslevel.py for large n; k restricted to windows near n and near m
import sys
from crosslevel import nu_chain, consistent, lcomb
from math import log
def fbound_float(n, kwin=12):
    kw = dict(exact=False, kwin=kwin)
    lo = 2**(n+1) - 2
    hi = 4*n*n*2**n
    assert not consistent(n, lo, **kw)[0] and consistent(n, hi, **kw)[0]
    # bisection on log scale first, then integer
    while hi - lo > max(1, hi // 10**9):
        mid = (lo+hi)//2
        if consistent(n, mid, **kw)[0]: hi = mid
        else: lo = mid
    return hi, consistent(n, hi, **kw)[1]
for n in [int(a) for a in sys.argv[1:]]:
    N, nu = fbound_float(n)
    print(f"n={n:4d}  N >= {N:.6e}   N/(n 2^n) = {N/(n*2**n):.4f}   N/Szekeres = {N/((n+2)*2**(n-1)-1):.4f}   "
          f"nu[n-j]/(n 2^(j-1)) j=1..6: {[round(nu[n-j]/(n*2**(j-1)),3) for j in range(1,7)]}", flush=True)
