# Asymptotic constant of the cross-level bound: nu_{n-j} ~ a_j n, with a_1 = 1 and
#   I(a_j, a_{j-1}) = ln 2,   I(a,b) = int_0^1 ln((a-x)/(a-b-x)) dx,
# and f(n) >= (a_j / 2^j + o(1)) n 2^n for every fixed j.
from mpmath import mp, mpf, log, findroot
mp.dps = 40
def xlx(x): return mpf(0) if x == 0 else x*log(x)
def I(a, b): return (xlx(a) - xlx(a-1)) - (xlx(a-b) - xlx(a-b-1))
a = [None, mpf(1)]
for j in range(2, 41):
    b = a[-1]
    lo, hi = b + 1, 4*b + 4          # I(b+1,b) = +inf-ish, I large a -> 0
    for _ in range(200):
        mid = (lo+hi)/2
        if I(mid, b) > log(2): lo = mid
        else: hi = mid
    a.append((lo+hi)/2)
for j in range(1, 41):
    if j <= 10 or j % 5 == 0:
        print(f"j={j:2d}  a_j = {mp.nstr(a[j], 12):>22}   a_j/2^j = {mp.nstr(a[j]/2**j, 12)}   a_j - 2a_(j-1) = {mp.nstr(a[j]-2*a[j-1], 8) if j>1 else ''}")
