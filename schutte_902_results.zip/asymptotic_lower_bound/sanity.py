"""Brute-force check of every step of the cross-level inequality on concrete S_n tournaments.
For each s-set A (all of them), R = D(A), m = |R|, and each y not in A:
  * Q_y = R ∩ N^-(y) equals D(A + y) and has >= nu[s+1] elements
  * #k-subsets of R dominated by y  = C(|R ∩ N^+(y)|, k) <= C(m - nu[s+1], k)
  * sum_y C(|R ∩ N^+(y)|,k) = sum_{U subset R,|U|=k} |D(U)| >= nu[k] C(m,k)   (exact identity + bound)
  * (N - s) C(m - nu[s+1], k) >= nu[k] C(m,k)
"""
import itertools, random, sys
from math import comb

def paley(p):
    Q = {(x*x) % p for x in range(1, p)}
    return [[1 if (i != j and (j-i) % p in Q) else 0 for j in range(p)] for i in range(p)]

def masks(A):
    N = len(A)
    inn = [sum(1 << i for i in range(N) if A[i][v]) for v in range(N)]   # vertices beating v
    out = [sum(1 << j for j in range(N) if A[v][j]) for v in range(N)]
    return inn, out

def D(inn, N, X):
    m = (1 << N) - 1
    for x in X: m &= inn[x]
    return m

def has_Sn(A, n):
    N = len(A); inn, _ = masks(A)
    return all(D(inn, N, X) for X in itertools.combinations(range(N), n))

def check(A, n, label):
    N = len(A); inn, out = masks(A); pc = lambda x: bin(x).count('1')
    nu = [min(pc(D(inn, N, X)) for X in itertools.combinations(range(N), s)) for s in range(n+1)]
    assert nu[n] >= 1, "not S_n"
    worst = {}
    for s in range(n):
        for Aset in itertools.combinations(range(N), s):
            R = D(inn, N, Aset); m = pc(R)
            Aset_m = sum(1 << a for a in Aset)
            for y in range(N):
                if Aset_m >> y & 1:
                    assert R & out[y] == 0          # y in A dominates nothing in R
                    continue
                Qy = R & inn[y]
                assert Qy == D(inn, N, Aset + (y,))
                assert pc(Qy) >= nu[s+1]
            for k in range(1, n+1):
                lhs_exact = sum(comb(pc(R & out[y]), k) for y in range(N))
                # exact identity check on small cases
                if comb(m, k) <= 3000:
                    Rl = [v for v in range(N) if R >> v & 1]
                    tot = sum(pc(D(inn, N, U)) for U in itertools.combinations(Rl, k))
                    assert tot == lhs_exact
                assert lhs_exact >= nu[k] * comb(m, k)
                assert lhs_exact <= (N - s) * comb(m - nu[s+1], k)
                slack = (N - s) * comb(m - nu[s+1], k) / max(1, nu[k] * comb(m, k))
                worst[(s, k)] = min(worst.get((s, k), 1e300), slack)
    print(f"{label}: N={N} n={n} nu={nu}  all checks passed; min slack of (N-s)C(m-nu,k)/(nu_k C(m,k)) per (s,k):",
          {key: round(v, 3) for key, v in sorted(worst.items())}, flush=True)

check(paley(7), 2, "QR_7")
check(paley(19), 3, "QR_19")
random.seed(1)
found = 0
for trial in range(4000):
    N = random.randint(9, 14)
    A = [[0]*N for _ in range(N)]
    for i in range(N):
        for j in range(i+1, N):
            if random.random() < 0.5: A[i][j] = 1
            else: A[j][i] = 1
    if has_Sn(A, 2):
        check(A, 2, f"random S_2 #{found}"); found += 1
        if found >= 4: break
if len(sys.argv) > 1:
    check(paley(67), 4, "QR_67")
