"""Cross-level counting bound for Schutte's problem (Erdos #902).

T: tournament on N vertices with S_n.  nu[s] = min |D(A)| over s-sets A  (nu[0] = N, nu[n] >= 1).
For an s-set A with R = D(A), m = |R|, and 1 <= k <= n:
   (N - s) * C(m - nu[s+1], k)  >=  nu[k] * C(m, k)          (*)
because every k-subset U of R has >= nu[k] dominators y, none in A, and each y has
R ∩ N^-(y) = D(A+y) of size >= nu[s+1] and disjoint from U.
Also (Moon) nu[s] >= 2 nu[s+1] + 1.
Given N we compute lower bounds for nu[n-1], ..., nu[0] and test N >= nu[0].
"""
from math import comb, lgamma, log, exp
import sys

from math import log1p
def lratio(m, h, k):
    """log( C(m-h,k) / C(m,k) ), computed stably"""
    if m - h < k: return float('-inf')
    return sum(log1p(-h/(m-i)) for i in range(k))

def lcomb(a, b):
    if b < 0 or b > a: return float('-inf')
    return lgamma(a+1) - lgamma(b+1) - lgamma(a-b+1)

def nu_chain(n, N, exact=True, kwin=None):
    nu = [0]*(n+1); nu[n] = 1
    for s in range(n-1, -1, -1):
        h = nu[s+1]
        def nuk(k):                      # valid lower bound for nu[k]
            if k > s: return nu[k]
            return 2**(s+1-k)*(h+1) - 1   # Moon chain from level s+1 (nu is non-increasing in k)
        def ks_for(m):
            top = min(m, n)
            if kwin is None: return range(1, top+1)
            return sorted(set(range(max(1, top-kwin), top+1)) | set(range(max(1, n-kwin), top+1)))
        def ok(m):
            for k in ks_for(m):
                if exact:
                    if (N-s)*comb(m-h, k) < nuk(k)*comb(m, k): return False
                else:
                    if log(N-s) + lratio(m, h, k) < log(nuk(k)) - 1e-12: return False
            return True
        lo = 2*h + 1
        if lo > N - s: return None                  # impossible: |D(A)| <= N - s
        if ok(lo): nu[s] = lo; continue
        hi = N - s
        if not ok(hi): return None
        while hi - lo > 1:
            mid = (lo+hi)//2
            if ok(mid): hi = mid
            else: lo = mid
        nu[s] = hi
    return nu

def consistent(n, N, **kw):
    nu = nu_chain(n, N, **kw)
    if nu is None: return False, None
    return nu[0] <= N, nu

def fbound(n, **kw):
    lo = 2**(n+1) - 2
    assert not consistent(n, lo, **kw)[0]
    hi = max(lo+1, 4*n*n*2**n)
    assert consistent(n, hi, **kw)[0]
    while hi - lo > 1:
        mid = (lo+hi)//2
        if consistent(n, mid, **kw)[0]: hi = mid
        else: lo = mid
    return hi, consistent(n, hi, **kw)[1]

if __name__ == "__main__":
    nmax = int(sys.argv[1]) if len(sys.argv) > 1 else 30
    print(f"{'n':>3} {'Szekeres':>14} {'new bound':>14} {'new/Sz':>7} {'new/(n2^n)':>10}  nu[n-1..n-4]")
    for n in range(2, nmax+1):
        exact = n <= 40
        N, nu = fbound(n, exact=exact, kwin=None if n <= 25 else 12)
        sz = (n+2)*2**(n-1) - 1
        print(f"{n:>3} {sz:>14} {N:>14} {N/sz:7.4f} {N/(n*2**n):10.4f}  {nu[n-1:n-5:-1] if n>=5 else nu[::-1]}", flush=True)
