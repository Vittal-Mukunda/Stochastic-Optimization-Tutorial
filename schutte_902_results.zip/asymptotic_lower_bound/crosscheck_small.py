# Independent re-implementation (plain loops, exact integers) of the cross-level bound for small n.
from math import comb
def feasible(n, N):
    nu = {n: 1}
    for s in range(n-1, -1, -1):
        h = nu[s+1]
        def lowk(k):                          # proven lower bound for nu_k
            return nu[k] if k > s else 2**(s+1-k)*(h+1) - 1
        m = 2*h + 1                           # Moon: T[D(A)] has min in-degree >= h
        while True:
            if m > N - s: return False
            if all((N-s)*comb(m-h, k) >= lowk(k)*comb(m, k) for k in range(1, min(m, n)+1)):
                break
            m += 1
        nu[s] = m
    return nu[0] <= N
for n in range(2, 10):
    N = (n+2)*2**(n-1) - 1                    # Szekeres
    while not feasible(n, N): N += 1
    print(n, (n+2)*2**(n-1) - 1, N)
