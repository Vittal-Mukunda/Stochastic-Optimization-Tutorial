# Independent re-check of the extended min-in-degree claim: with Lemma T, a vertex v of in-degree 23 in an S_4
# tournament on N vertices leaves excess budget sum_b (|A_b|-11) <= 12N - 610 over the N-24 vertices b of N^+(v);
# each b with excess e covers at most best[e] of the source-less undominated 4-sets of A = N^-(v) (local48b_out.txt).
# Greedy is not safe, so do an exact bounded knapsack by DP over (items used, budget used).
tables = {'D2': (1045, {1:20, 2:24, 3:25, 4:17, 5:10, 6:9, 7:3, 8:1}),
          'QR23': (1012, {1:0, 2:25, 3:21, 4:14, 5:9, 6:5, 7:3, 8:1})}
def maxcover(N, best):
    budget, items = 12*N - 610, N - 24
    if budget < 0: return 0
    # f[w] = max coverage using total excess exactly <= w with unlimited count; then enforce item count via 2-D DP
    NEG = float('-inf')
    dp = [[NEG]*(budget+1) for _ in range(items+1)]; dp[0][0] = 0
    for k in range(items):
        row, nxt = dp[k], dp[k+1]
        for w, val in enumerate(row):
            if val == NEG: continue
            if val > nxt[w]: nxt[w] = val                      # item with e = 0 (covers nothing)
            for e, c in best.items():
                if w + e <= budget and val + c > nxt[w+e]: nxt[w+e] = val + c
    return max(max(r) for r in dp)
last_ok = {}
for N in range(48, 70):
    res = []
    for name, (need, best) in tables.items():
        mc = maxcover(N, best); ok = mc < need
        res.append(f"{name}: {mc} vs {need} {'OK' if ok else 'FAIL'}")
        if ok: last_ok[name] = N
    print(N, " | ".join(res))
print("no in-degree-23 vertex is possible for every N <=", min(last_ok.values()), "(both classes OK)")
