# Round 3 (multi-agent) findings — Erdős #902

The agent runs were cut short by usage limits. The results below come from the notes and files they left,
in `round3_agents/`. Each one is marked by how much it has been checked.

## Headline

| result | status |
|---|---|
| **f(4) ≥ 51, entirely by hand** | **New** (round 4, f4 agent). The proof uses no computer (§0). I checked every step. It supersedes the computer-assisted 50 below. |
| **f(4) ≥ 50** | **New.** The previous record was 49. The proof combines the computer-assisted min-in-degree theorem of `RESULTS.md` with a hand count (§1). The hand count was re-checked by me and by an independent verifier agent. The computer step was re-done with a different method and against McKay's published catalogue (§1). |
| f(4) ≥ 49 with a **five-line hand proof** | New proof of a known bound. J. Wilder's GitHub repository posted f(4) ≥ 49 on 11 Sep 2026 as a computer-assisted candidate (§2). |
| Sharpened cross-level lemma: f(5) ≥ 121, f(6) ≥ 281, f(7) ≥ 665, f(8) ≥ 1485, … | Verified independently by the verifier agent and by me (§3). |
| f(n) ≥ (n + 5/2)·2^(n−1) − 1 for every n ≥ 5, by hand | Verified by the verifier agent (§3). |
| f(n) ≥ (0.7695… − o(1))·n·2^n | Adversarially verified. No error was found (`LOWER_BOUND_CONSTANT.md`). |
| (M1) "n−1 vertices have ≥ n+1 common dominators" is **best possible** for every n | Proved by the base agent and verified independently. The verification covered the union bound in exact arithmetic and both explicit examples (§4). |
| Random symmetric tournaments (Cayley, or invariant under a free action of an odd-order group) cannot beat (ln 2)·n²·2^n, asymptotically | Proof by the uppertheory agent, verified independently. Two statements were narrowed (§5). |
| Paley tournaments behave like "random subject to double regularity" | Numerical (Monte Carlo, n = 7…14) (§5). |
| No cyclotomic tournament on a prime p < 331 has S_5 | Exhaustive for all odd-order subgroups except 9 families with the smallest subgroup, H of order 3 or 5. Those are too large to enumerate (§6). |

The main question, whether f(n) is of order n·2^n or n²·2^n, is still open.

---

## 0. f(4) ≥ 51 by hand (round 4)

This section is from the f4 agent (`round3_agents/f4/notes.md`, "CLEAN PROOF"), and I re-checked it line by line. T is an S_4 tournament.
Every triple has at least 5 dominators (F1). Every pair has at least 11, and T[D(P)] has minimum in-degree at least 5 (F2). Every
in-degree is at least 23 (F3). A pair is *tight* if it has exactly 11 dominators.

**Lemma T.** If P is tight, every r ∈ D(P) has in-degree at least 25.

*Proof.*
1. Let R = D(P). T[R] has minimum in-degree at least 5 and in-degree sum 55, so it is 5-regular.
2. A vertex y ∉ P ∪ R loses to the at least 5 vertices of D(P ∪ {y}) = R ∩ N⁻(y), so it beats at most 6 vertices of R.
3. Fix r ∈ R. The 45 triples U ⊆ R that contain r need at least 225 dominator incidences in total.
4. A dominator w of such a U beats r, so w ∈ N⁻(r), and w ∉ P because r beats P.
5. The 5 vertices w ∈ R ∩ N⁻(r) each dominate at most C(4,2) = 6 of these triples. The d⁻(r) − 5 vertices of N⁻(r) outside R each dominate at most C(5,2) = 10.
6. So 30 + 10(d⁻(r) − 5) ≥ 225, which gives d⁻(r) ≥ 24.5. ∎

**Corollary 1.** If N ≤ 50, no vertex has in-degree 23.

*Proof.*
1. Suppose d⁻(v) = 23 and let A = N⁻(v). In-degrees inside A are at least 11 by F2 and sum to 253 = 23·11, so all are exactly 11.
2. Each pair {a, v} is therefore tight, with D({a,v}) = N⁻(a) ∩ A. These sets cover A, so every a ∈ A has d⁻(a) ≥ 25 by Lemma T.
3. Count, with B = N⁺(v): 11(N − 24) ≤ Σ_{b∈B} |D({v,b})| = Σ_{a∈A} |N⁺(a) ∩ B| ≤ 23·(N − 1 − 25 − 11 − 1) = 23(N − 38).
4. This forces N ≥ 610/12 > 50. ∎

This replaces the computer-assisted min-in-degree theorem for N ≤ 50.

**Claim Q.** Let Z be the set of vertices of in-degree exactly 24. If d⁻(v) = 24, then v has at most 2 in-neighbours in Z.

*Proof.*
1. Inside N⁻(v), write each in-degree as 11 + f_a. Then Σ f_a = C(24,2) − 24·11 = 12.
2. The set L = {a : f_a = 0} has l ≥ 12 elements, and each pair {a, v} with a ∈ L is tight.
3. By Lemma T, every in-neighbour of such an a inside N⁻(v) has in-degree at least 25. So a beats every other vertex of Z ∩ N⁻(v), and hence |L ∩ Z| ≤ 1.
4. Each z ∈ Q := (Z ∩ N⁻(v)) \ L is beaten by all of L, so f_z ≥ l − 11 + d⁻_Q(z).
5. Summing over the 24 − l vertices outside L gives 12 ≥ q(l − 11) + C(q,2) + (24 − l − q), that is, (q − 1)(l − 12) + C(q,2) ≤ 0.
6. So q ≤ 1, and |Z ∩ N⁻(v)| ≤ 2. ∎

**Theorem.** f(4) ≥ 51.

*Proof.* Let N ≤ 50. By F3 and Corollary 1, every in-degree is at least 24.
* If N ≤ 48, minimum in-degree 24 is impossible.
* If N ∈ {49, 50}, the excesses d⁻ − 24 sum to C(N,2) − 24N, which is 0 or 25. So at least 25 vertices lie in Z.
* By Claim Q, T[Z] has every in-degree at most 2, so C(|Z|,2) ≤ 2|Z| and |Z| ≤ 5. This contradicts |Z| ≥ 25. ∎

*Computer-assisted extension (I re-checked it independently with my own exact knapsack, `asymptotic_lower_bound/budget_check.py`):*
* With Lemma T, the budget for a vertex of in-degree 23 drops to 12N − 610, down from 12N − 564. The covering tables of
  `lower_bound/local48b_out.txt` then exclude such a vertex for every N ≤ 64. QR_23 first fails at 65 and D₂ at 66.
  So **every S_4 tournament on at most 64 vertices has minimum in-degree at least 24.**

*Further claim by the f4 agent (computer-assisted; I have not checked it):*
* For N = 51, LP/MILP runs over all 551 local classes indicate that a regular S_4 tournament on 51 vertices would have no tight pair, and so would be doubly regular (`t51_lp.out`).

The cases left open for N = 51 are a doubly regular 51-vertex tournament, and 1 ≤ |Z| ≤ 5.

## 1. f(4) ≥ 50

**Ingredient (computer-assisted, `RESULTS.md` §3).** In an S_4 tournament on at most 51 vertices, every vertex has
in-degree at least 24. So an S_4 tournament on 49 vertices is regular: in- and out-degree are both 24.

**Lemma.** No regular tournament on 49 vertices has S_4.

*Proof.* By (M1) every triple has at least 5 dominators. By (M2) every pair has at least 11. Suppose a pair P = {a, b} has
exactly 11 dominators R = D(P).
* For y ∈ R, its in-neighbours inside R are exactly D(P ∪ {y}), which has at least 5 vertices. The in-degrees inside the
  11-vertex tournament T[R] sum to 55, so every y ∈ R has exactly 5 in-neighbours and 5 out-neighbours in R.
* Let O be the 36 vertices outside P ∪ R. For y ∈ O, put q_y = |R ∩ N⁻(y)| = |D(P ∪ {y})|, so q_y ≥ 5.
* *Degree count.* Each r ∈ R has out-degree 24. It beats a, b and 5 vertices of R, so it beats exactly 17 vertices of O.
  Hence Σ_{y∈O} q_y = 11·17 = 187 = 36·5 + 7. With e_y = q_y − 5 we have 0 ≤ e_y ≤ 6 and Σ e_y = 7.
* *Pair count over triples U ⊆ R.* The vertices of P dominate nothing in R, so
  Σ_U |D(U)| = Σ_{y∈R} C(5,3) + Σ_{y∈O} C(6 − e_y, 3).
  The loss ℓ(e) = 20 − C(6−e, 3) takes the values 0, 10, 16, 19, 20, 20, 20. It is concave with ℓ(0) = 0, hence subadditive, so
  Σ ℓ(e_y) ≥ 20. Therefore Σ_U |D(U)| ≤ 110 + 36·20 − 20 = 810.
  But each of the 165 triples has at least 5 dominators, so the sum is at least 825. Contradiction.

So every pair has at least 12 dominators. Then every in-neighbourhood T[N⁻(v)] has minimum in-degree at least 12, so
d⁻(v) ≥ 25 > 24, which contradicts regularity. ∎

**Corollary.** f(4) ≥ 50.

The crosslevel agent found this argument (`round3_agents/crosslevel/notes.md`, Step 1). I re-checked it line by line, and so did
an independent verifier agent (`round3_agents/verifier2/notes.md`, Item 1). The count only needs the dominators of P to have
average out-degree above 23.36.

The only computer-assisted input is the min-in-degree theorem. The verifier re-derived its logic: the admissibility conditions are
exactly the sets D({v,b}), D({v,b,z}) and D({v,b,z₁,z₂}), and the budget is 12N − 564. It then re-did the covering computation with a
different method (a subset-sum transform over all 2^23 subsets, `verifier2/lemma4.c`), and obtained 1012 sets with r = 12.5 for QR_23
and 1045 with r = 20 for D₂, identical to before. It also downloaded McKay's catalogue of the 37 doubly regular tournaments on
23 vertices. Exactly two of them have S_3, lines 34 (D₂) and 35 (QR_23), and running the computation directly on them gives the
same numbers. The converses give the same result.

*Why 50 does not fall the same way.* At N = 50 the same count gives a contradiction only for those pairs with 11 dominators
whose dominators have total in-degree excess at most 6. The total excess over all vertices is 25, so a global argument
is needed. This is the agents' next target.

## 2. A hand proof of f(4) ≥ 49 (sharpened lemma)

**Sharpened cross-level lemma** (the verifier agent's refinement). Let A be an s-set, R = D(A), m = |R|, h = ν_{s+1}, and 1 ≤ k ≤ n. Then

  (N − s − m)·C(m − h, k) + m·C(m − h − 1, k) ≥ ν_k·C(m, k).

The proof is as before. A dominator y lying inside R also excludes itself from U, which gives the second term.

**f(4) ≥ 49 by hand.** Let N ≤ 48.
1. ν_3 ≥ 5 and ν_2 ≥ 11. If every pair had at least 12 dominators, (M2) would give ν_1 ≥ 25 and N ≥ 51. So some pair has
   exactly 11 dominators, R.
2. Count the dominator pairs of triples U ⊆ R. Each triple has at least 5 dominators, so there are at least 5·165 = 825 pairs.
3. A vertex y ∈ R has at least 5 in-neighbours in R, so it dominates at most C(5,3) = 10 triples. The 11 vertices of R give at most 110.
4. Each of the at most 35 other vertices beats at most 6 vertices of R, so it dominates at most 20 triples. These give at most 700.
5. In total at most 810 < 825. Contradiction. ∎

Wilder's repository (jaredwilder/erdos902, `f4-ge49-candidate/`) reached 49 by a computer-assisted route close to ours.
The bound 49 is therefore not ours. The short proof above appears to be new.

## 3. Better explicit bounds

Both the verifier and I (`asymptotic_lower_bound/sharpened_small.py`) solved the sharpened recursion with exact integers and
every k:

| n | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 |
|---|---|---|---|---|---|---|---|---|---|
| Szekeres | 47 | 111 | 255 | 575 | 1279 | 2815 | 6143 | 13311 | 28671 |
| lemma (round 2) | 47 | 119 | 279 | 661 | 1474 | 3380 | 7383 | 16564 | 35637 |
| **sharpened** | **49** | **121** | **281** | **665** | **1485** | **3388** | **7398** | **16569** | **35655** |

The asymptotic constant c\* = 0.7695032191504894… is unchanged.

**Hand bound for every n ≥ 5** (from the verifier). Take s = n−2 and k = n−1, and use ν_{n−1} ≥ n+1 on both sides. If some (n−2)-set had
only 2n+3 dominators, then N − n + 2 ≥ (n+1)·C(2n+3, n−1)/C(n+2, 3). This fails for every n ≥ 5. So ν_{n−2} ≥ 2n+4, and
**f(n) ≥ (n + 5/2)·2^(n−1) − 1** for all n ≥ 5. In particular the Szekeres bound is never attained for n ≥ 4.

Corrections to `LOWER_BOUND_CONSTANT.md` found by the verifier:
* The n = 26 row was computed with a restricted range of k. Using every k gives 1311419060, not 1311410175. The old value is valid, only weaker.
* The −O(1) Riemann step should be replaced by the exact inequality G(m,h) ≥ n·Φ((m+1)/n, h/n), valid whenever m − h ≥ n.
* `limit_const.py` is accurate to about 12 digits, not 40. The 40-digit value is c\* = 0.7695032191504894326990652683098231346767.

## 4. The base level is tight (base agent)

**Theorem.** For every n ≥ 2 there is an S_n tournament with ν_{n−1} = n+1, on ⌈2n²2^n⌉ + 2n vertices.

*Construction.* Take W (n+1 vertices) containing a Hamiltonian cycle, B (n−1 vertices) with W → B, and M random "max-type"
vertices. Each of these is beaten by exactly one vertex of B and by a uniformly chosen non-empty subset of W. Then
D(B) = W, and a union bound shows S_n holds with positive probability. The bound is analytic for n ≥ 5 and computed exactly for n = 2, 3, 4.

The same construction works with M = (ln 2 + o(1))·n²·2^n, so a thin set costs nothing at the scale of the best known constructions.

*Explicit examples.*
* `thin_S4_N70.txt` is QR_67 plus 3 vertices. Its 4-sets are all dominated, and one triple has exactly 5 dominators. I re-checked this by full enumeration.
* `thin_S5_N335.txt` is QR_331 plus 4 vertices. All 2,000,693,421 5-sets meeting the new vertices are dominated, and one 4-set has exactly 6 dominators.

*Verification.* An independent agent re-checked the case analysis and independence, recomputed the union bound in exact rational
arithmetic, and re-verified both explicit examples with its own code. The only slip it found is immaterial: the stated closed form
for ln E1 at n = 5 is −1.396, not ≤ −1.40, and the three bounds still sum to less than 0.45.

*Consequence.* Any improvement of (M1), and with it any change in the order of f(n) along this route, must use the fact that N is small.
In the planted examples thin sets are extremely rare: only 2 of the 54,740 triples in the 70-vertex example are thin. The
cross-level recursion would gain if near-thin extensions D(A ∪ {y}) were exponentially rare. That is the open target.

## 5. Constructions: barrier results (uppertheory agent; proofs in `round3_agents/uppertheory/THEOREMS.md`)

An independent verifier agent checked these proofs (`round3_agents/verifier2/notes.md`, Item 3).
* **Theorem A.** Fix ε > 0. For every n ≥ n₀(ε), every group G of odd order acting freely on the vertex set, and N ≤ (ln 2 − ε)·n²·2^n,
  a uniformly random G-invariant tournament fails S_n with high probability. This covers random tournaments and random Cayley
  tournaments on any odd-order group. The proof combines the Lovász Local Lemma for the lower tail, Suen's inequality for joint
  probabilities, and a second moment.
  *Scope:* the result is asymptotic and needs a free action. It says nothing about n = 4, nor about the orbit families with
  fixed points or quotient orbits used in the f(4) searches. The agent's remark about actions with small stabilisers is unproved.
* **Theorem B.** Random Cayley tournaments on F_3^m are *worse* than random by a factor log₃ n, because linear subspaces dominate.
* **Proposition C.** Lexicographic compositions never help.
* **Proposition D.** In a regular tournament, the variance of the dominator count of a random s-set is at least
  (1 − (1 + s + C(s,2))·2^(−s) − O(sλ_s/N)) times its mean, with equality exactly for doubly regular tournaments. Doubly regular
  tournaments *are* sub-Poisson: the variance/mean ratio is 0.21 for QR_19 with s = 3, and 0.66 for N = 1163 with s = 6. The
  reduction can only come from the 1 + s + C(s,2) low-order patterns, so it vanishes as s grows.
* **Proposition E.** Correlations of order 4 and higher are at least as large as random on average (Welch bound).
* **Numerics.** The lower-tail exponent ψ_n of Paley tournaments matches the "random subject to double regularity" prediction for
  n = 7…14, with ψ_n → 1. Heuristically, Paley needs (ln 2 + o(1))·n²·2^n vertices, so it is no better than random even in the constant.

*Reading.* None of the natural symmetric or random constructions can reach o(n²2^n). A construction of order n·2^n would
have to be highly structured in a new way. This is evidence, not proof, that the truth may be order n²·2^n.

## 6. Small constructions (smallcon agent)

* The checkers were validated: QR_67 has S_4 and QR_331 has S_5. Every QR_p with p ≡ 3 (mod 4) and p < 331 fails S_5. QR_103 and QR_379 also fail, so Paley is non-monotone.
* **No cyclotomic tournament on a prime 121 ≤ p < 331 has S_5.** This is exhaustive over every non-trivial odd-order subgroup H and every choice of
  cosets, up to isomorphism. The trivial subgroup, i.e. all circulants, is out of reach. The exceptions are the 8 families with |H| = 3 and p ≥ 223, plus (p, |H|) = (311, 5). These have up to 2^51 members, more than can be enumerated.
* Multiplier-invariant circulants on composite N in [121, 330] were set up (`fams5b/`) but not finished.

## 7. Literature (literature agent; `round3_agents/literature/bibliography.md`)
* f(4) ≥ 48 is due to Reid–McRae–Hedetniemi–Hedetniemi (2004). f(4) ≥ 49 was posted by J. Wilder (GitHub, Sep 2026) as a computer-assisted candidate.
* In domination-number form, Szekeres reads γ(T) ≤ log₂N − log₂log₂N + 2 (Lu–Wang–Wong 2000 give a short proof). Our constant improves the
  additive 2 to about 1.378 asymptotically.
* No source found improves the asymptotic constant, or gives bounds for f(5), f(6), … beyond Szekeres. This includes Jeffries 2026 (arXiv:2604.08790), the erdosproblems.ai wiki, Wilder's repository and Bonato's surveys.
* Analogues have the same factor-n gap: n-e.c. graphs and tournaments, and covering arrays (Kleitman–Spencer). Domination in k-majority tournaments (Alon et al. 2006) uses VC-dimension methods.
