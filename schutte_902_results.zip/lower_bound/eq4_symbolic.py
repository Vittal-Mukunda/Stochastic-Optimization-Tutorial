# Symbolic verification (all n >= 5) of the 4-set level of the Szekeres equality case.
# Parameters: X = 2^(n-5); q = X(n+2)-1, s = 2q+1, t = 2s+1, r = 2t+1, N = 2r+1.
import sympy as sp
n, X = sp.symbols('n X', positive=True)
q = X*(n+2) - 1; s = 2*q + 1; t = 2*s + 1; r = 2*t + 1; N = 2*r + 1
C = lambda a, k: sp.binomial(a, k)
def Cf(a, k):   # falling-factorial binomial as a polynomial in a
    e = sp.Integer(1)
    for i in range(k): e *= (a - i)
    return e / sp.factorial(k)
heavy = N*(N-1)/6; light = Cf(N,3) - heavy
S1 = N*Cf(r,4); S2 = N*Cf(r,4) + N*(N-1)*Cf(t,4)
nsrc = s*light + t*heavy
src1 = s*q*light + t*s*heavy; src2 = s*q**2*light + t*s**2*heavy
nsl = Cf(N,4) - nsrc; sl1 = S1 - src1; sl2 = S2 - src2
Phi4 = sp.expand(sl2 - (q+s)*sl1 + q*s*nsl)
print("sum over source-less 4-sets of (mu-q)(mu-s) =", sp.simplify(Phi4))
a = sp.simplify((s*(r-3) - q*(N-3))/(s-q))
b = sp.simplify((t*(r-3) - q*(N-3))/(s-q))
print("4-sets with mu=s through a light triple:", a, "| through a heavy triple:", sp.simplify(b), " (N-3 =", sp.expand(N-3), ")")
# triple level (for completeness)
Phi3 = sp.expand((N*Cf(r,3) + N*(N-1)*Cf(t,3) - s**2*N*Cf(r,2)) - (s+t)*(N*Cf(r,3) - s*N*Cf(r,2)) + s*t*(Cf(N,3) - N*Cf(r,2)))
print("sum over cyclic triples of (lam-s)(lam-t) =", sp.simplify(Phi3))
