# decode digraph6 canonical strings of the S_3 DRT(23) classes into adjacency files
import sys
def from_digraph6(s):
    assert s[0]=='&'; n=ord(s[1])-63; bits=[]
    for ch in s[2:]:
        v=ord(ch)-63
        for k in range(5,-1,-1): bits.append((v>>k)&1)
    return [[bits[i*n+j] for j in range(n)] for i in range(n)]
for idx,line in enumerate(open(sys.argv[1])):
    s=line.split()[0]; A=from_digraph6(s); n=len(A)
    with open(f"drt23_class{idx}.txt","w") as f:
        f.write(f"{n}\n"); [f.write(''.join(map(str,row))+'\n') for row in A]
    print("class",idx,"n=",n)
