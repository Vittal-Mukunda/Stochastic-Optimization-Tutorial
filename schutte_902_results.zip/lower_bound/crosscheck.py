import itertools, subprocess
from tour_util import canon_many
def from_digraph6(s):
    n=ord(s[1])-63; bits=[]
    for ch in s[2:]:
        v=ord(ch)-63; bits += [(v>>k)&1 for k in range(5,-1,-1)]
    return [[bits[i*n+j] for j in range(n)] for i in range(n)]
alld=[from_digraph6(l.split()[0]) for l in open('alldrt_classes.txt')]
s3c=set(l.split()[0] for l in open('all_classes.txt'))
def isS3(A):
    n=len(A); IN=[sum(1<<i for i in range(n) if A[i][j]) for j in range(n)]
    return all(IN[a]&IN[b]&IN[c] for a,b,c in itertools.combinations(range(n),3))
def isDRT(A):
    n=len(A); IN=[sum(1<<i for i in range(n) if A[i][j]) for j in range(n)]
    return all(bin(IN[j]).count('1')==11 for j in range(n)) and all(bin(IN[a]&IN[b]).count('1')==5 for a in range(n) for b in range(a+1,n))
print("all 37 verified DRT(23):", all(isDRT(A) for A in alld))
s3=[l.split()[0] for l,A in zip(open('alldrt_classes.txt'),alld) if isS3(A)]
print("S_3 among them:", len(s3), " same as the direct S_3 classification:", set(s3)==s3c)
# Hadamard equivalence classes of the bordered skew-Hadamard matrices H = I + S (order 24)
def hadamard(A):
    n=len(A); N=n+1
    H=[[0]*N for _ in range(N)]
    for i in range(N): H[i][i]=1
    for j in range(1,N): H[0][j]=1; H[j][0]=-1
    for i in range(n):
        for j in range(n):
            if i!=j: H[i+1][j+1]= 1 if A[i][j] else -1
    return H
def had_graph6(H):
    # vertices: r+ r- for rows (0..2N-1), c+ c- for columns (2N..4N-1), hubs: R (4N), C (4N+1), pendant P (4N+2) on R
    N=len(H); V=4*N+3; E=set()
    for i in range(N):
        E.add((2*i,2*i+1)); E.add((2*N+2*i,2*N+2*i+1))
        E.add((2*i,4*N)); E.add((2*i+1,4*N)); E.add((2*N+2*i,4*N+1)); E.add((2*N+2*i+1,4*N+1))
        for j in range(N):
            if H[i][j]==1: E.add((2*i,2*N+2*j)); E.add((2*i+1,2*N+2*j+1))
            else: E.add((2*i,2*N+2*j+1)); E.add((2*i+1,2*N+2*j))
    E.add((4*N,4*N+2))
    adj=[[0]*V for _ in range(V)]
    for a,b in E: adj[a][b]=adj[b][a]=1
    bits=[adj[j][i] for i in range(1,V) for j in range(i)]
    while len(bits)%6: bits.append(0)
    s=chr(63+V) if V<63 else '~'+chr(63+((V>>12)&63))+chr(63+((V>>6)&63))+chr(63+(V&63))
    for k in range(0,len(bits),6):
        v=0
        for b in bits[k:k+6]: v=(v<<1)|b
        s+=chr(v+63)
    return s
Hs=[hadamard(A) for A in alld]
N=24
ok=all(sum(Hs[t][i][k]*Hs[t][j][k] for k in range(N))==(N if i==j else 0) for t in range(len(Hs)) for i in range(N) for j in range(N))
print("all bordered matrices are Hadamard:", ok, "; skew:", all(Hs[t][i][j]==-Hs[t][j][i] for t in range(len(Hs)) for i in range(N) for j in range(N) if i!=j))
LABELG='labelg'   # nauty's labelg must be on PATH
out=subprocess.run([LABELG,'-q'],input='\n'.join(had_graph6(H) for H in Hs)+'\n',capture_output=True,text=True).stdout.split()
print("Hadamard-equivalence classes among the 37 skew matrices:", len(set(out)))
