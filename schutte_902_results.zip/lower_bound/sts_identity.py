# Symbolic check of the equality-case identity behind f(4) >= 48 (and f(k) >= (k+2)2^(k-1) for k = 1 mod 3).
# In the equality case N = (k+2)2^(k-1) - 1 the tournament is doubly regular, transitive triples have
# exactly s dominators and cyclic triples have between s and t.  Then
#   sum over cyclic triples of (lam - s)(lam - t) = 0,
# so every cyclic triple has lam in {s, t}; the "heavy" ones (lam = t) contain each pair exactly once,
# i.e. they form a Steiner triple system on N points, which needs N = 1 or 3 (mod 6).
import sympy as sp
k, X = sp.symbols('k X', positive=True)      # X = 2^(k-4), k >= 4
s = X*(k+2) - 1; t = 2*s + 1; r = 2*t + 1; N = 2*r + 1
C2 = lambda a: a*(a-1)/2; C3 = lambda a: a*(a-1)*(a-2)/6
ntr = N*C2(r); ncyc = N*(N-1)*(N-2)/6 - ntr
S1 = N*C3(r); S2 = S1 + N*(N-1)*C3(t)
sc = S1 - s*ntr; sc2 = S2 - s**2*ntr
print("sum_cyc (lam-s)(lam-t) =", sp.simplify(sc2 - (s+t)*sc + s*t*ncyc))
print("heavy triples through each pair =", sp.simplify((t*(r-2) - s*(N-2))/(t-s)))
for kk in range(4, 14):
    NN = (kk+2)*2**(kk-1) - 1
    print(f"k={kk}: N={NN}, N mod 6 = {NN % 6}", "-> no STS(N), so f(k) >= N+1" if NN % 6 not in (1, 3) else "")
