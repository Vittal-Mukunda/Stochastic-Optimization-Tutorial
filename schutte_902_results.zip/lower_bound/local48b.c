// CORRECTED local analysis for n=48 (dominator of a 4-set X inside A must be a vertex b in B with X ⊆ A \ A_b).
// D = in-neighbourhood of v (S_3 DRT(23)). For b in B, A_b = A ∩ N^-(b) is admissible (|A_b|>=11) and
// C_b = A \ A_b (size <= 12) must contain every bad 4-set X of D that b is to dominate.
// Admissible 11-sets are IN[z] => C_b = {z} ∪ OUT[z], which covers exactly the bad 4-sets with source z.
// Source-less bad 4-sets need C_b with |A_b| >= 12 (excess >= 1); total excess <= 12.
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
int p=23; uint32_t in[23], out_[23];
int main(int argc,char**argv){
  FILE*f=fopen(argv[1],"r"); int n; if(fscanf(f,"%d",&n)!=1||n!=23) return 1; char row[64];
  for(int i=0;i<23;i++){ in[i]=out_[i]=0; }
  for(int i=0;i<23;i++){ if(fscanf(f,"%s",row)!=1) return 1; for(int j=0;j<23;j++) if(row[j]=='1'){ out_[i]|=1u<<j; in[j]|=1u<<i; } }
  static uint32_t sl[20000]; int nsl=0, nbad=0, nsrc=0;
  for(int a=0;a<p;a++)for(int b=a+1;b<p;b++)for(int c=b+1;c<p;c++)for(int d=c+1;d<p;d++){
    uint32_t X=(1u<<a)|(1u<<b)|(1u<<c)|(1u<<d);
    if(in[a]&in[b]&in[c]&in[d]) continue; nbad++;
    int hassrc=0; int v4[4]={a,b,c,d}; for(int i=0;i<4;i++){ if(((out_[v4[i]]|(1u<<v4[i]))&X)==X) hassrc=1; }
    if(hassrc) nsrc++; else sl[nsl++]=X; }
  printf("bad 4-sets: %d ; with a source: %d ; source-less: %d\n",nbad,nsrc,nsl);
  int best[24]={0}; long long cnt[24]={0}; uint32_t full=(1u<<23)-1; int adm11_not_in=0;
  for(uint32_t S=0;S<(1u<<23);S++){ int sz=__builtin_popcount(S); if(sz<11) continue;
    int ok=1; for(int z=0;z<p&&ok;z++) if(__builtin_popcount(in[z]&S)<5) ok=0;
    for(int a=0;a<p&&ok;a++) for(int b=a+1;b<p;b++) if(!(in[a]&in[b]&S)){ok=0;break;}
    if(!ok) continue; cnt[sz]++;
    if(sz==11){ int isin=0; for(int z=0;z<p;z++) if(in[z]==S) isin=1; if(!isin) adm11_not_in++; }
    uint32_t C=full&~S; int cov=0; for(int i=0;i<nsl;i++) if((sl[i]&C)==sl[i]) cov++; if(cov>best[sz]) best[sz]=cov; }
  printf("admissible 11-sets: %lld, of which NOT an in-neighbourhood N^-(z): %d ; max source-less bad sets in complement of an admissible 11-set: %d\n",cnt[11],adm11_not_in,best[11]);
  double mr=0; for(int s=12;s<=23;s++){ printf("  |A_b|=%2d (excess %2d): %7lld admissible; max source-less bad sets inside complement: %d\n",s,s-11,cnt[s],best[s]); if(best[s]>0){ double r=(double)best[s]/(s-11); if(r>mr) mr=r; } }
  printf("max per unit excess r = %.2f\n",mr);
  for(int n=48;n<=53;n++){ int budget=12*n-564; printf("  n=%d: budget <= %d -> at most %.0f of %d source-less undominated 4-sets coverable%s\n",n,budget,budget*mr,nsl, budget*mr<nsl? "  ==> CONTRADICTION (no vertex of in-degree 23)":"  (no contradiction)"); }
  return 0; }
