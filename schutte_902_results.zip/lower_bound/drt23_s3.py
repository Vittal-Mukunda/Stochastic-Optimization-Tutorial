"""Classify all doubly-regular tournaments on 23 vertices with property S_3.

Every such tournament D, seen from any vertex 0, has T[N^-(0)] = a regular S_2 tournament R on 11
vertices (all 1223 regular 11-tournaments come from nauty's gentourng; 551 have S_2).  For each R we
enumerate, with a SAT solver, every completion: O = N^+(0) (11 vertices), the arcs I->O and the
tournament on O, subject to double regularity (every pair has exactly 5 common in-neighbours) and S_3.
Relabelling of O is broken by requiring the I->O incidence columns to be strictly decreasing.
All solutions are verified directly and reduced to isomorphism classes with nauty (labelg).
usage: python3 drt23_s3.py reg11_S2.txt out_prefix [start end]
"""
import sys, itertools, time
from pysat.solvers import Cadical153
from pysat.card import CardEnc, EncType
from pysat.formula import IDPool
from tour_util import parse_upper, ins, canon_many

def solve_R(R):
    n = 11
    cR = [[sum(1 for w in range(n) if R[w][a] and R[w][b]) for b in range(n)] for a in range(n)]
    pool = IDPool()
    B = [[pool.id(('b', x, y)) for y in range(n)] for x in range(n)]       # x -> y  (x in I, y in O)
    Ov = {}
    for y in range(n):
        for z in range(y+1, n): Ov[(y, z)] = pool.id(('o', y, z))
    def o(y, z):            # literal "y -> z" inside O
        return Ov[(y, z)] if y < z else -Ov[(z, y)]
    cls = []
    def AND(a, b):           # aux <-> a & b
        v = pool.id(('and', a, b)) if a < b else pool.id(('and', b, a))
        if ('done', v) not in done:
            done.add(('done', v)); cls.extend([[-v, a], [-v, b], [v, -a, -b]])
        return v
    done = set()
    def card_eq(lits, k):
        if k < 0 or k > len(lits): cls.append([]); return
        enc = CardEnc.equals(lits=lits, bound=k, vpool=pool, encoding=EncType.seqcounter)
        cls.extend(enc.clauses)
    # degrees
    for x in range(n): card_eq([B[x][y] for y in range(n)], 5)
    for y in range(n): card_eq([B[x][y] for x in range(n)], 5)
    for y in range(n): card_eq([o(y, z) for z in range(n) if z != y], 5)
    # double regularity
    for x in range(n):
        for x2 in range(x+1, n):
            card_eq([AND(-B[x][y], -B[x2][y]) for y in range(n)], 5 - cR[x][x2])
    for y in range(n):
        for y2 in range(y+1, n):
            lits = [AND(B[x][y], B[x][y2]) for x in range(n)] + [AND(o(w, y), o(w, y2)) for w in range(n) if w not in (y, y2)]
            card_eq(lits, 4)
    for x in range(n):
        for y in range(n):
            lits = [B[x2][y] for x2 in range(n) if R[x2][x]] + [AND(-B[x][y2], o(y2, y)) for y2 in range(n) if y2 != y]
            card_eq(lits, 5)
    # S_3: vertices: 0 = 'z', I: ('i',x), O: ('o',y). arc literal function (None=false, True=true, int=literal)
    V = [('z', 0)] + [('i', x) for x in range(n)] + [('o', y) for y in range(n)]
    def arc(u, w):
        if u == w: return None
        if u[0] == 'z':
            return None if w[0] == 'i' else True      # 0 -> O, I -> 0
        if w[0] == 'z':
            return True if u[0] == 'i' else None
        if u[0] == 'i' and w[0] == 'i': return True if R[u[1]][w[1]] else None
        if u[0] == 'i' and w[0] == 'o': return B[u[1]][w[1]]
        if u[0] == 'o' and w[0] == 'i': return -B[w[1]][u[1]]
        return o(u[1], w[1])
    for T in itertools.combinations(V, 3):
        clause = []; sat = False
        for w in V:
            if w in T: continue
            ls = [arc(w, t) for t in T]
            if any(l is None for l in ls): continue
            ls = [l for l in ls if l is not True]
            if not ls: sat = True; break
            if len(ls) == 1: clause.append(ls[0])
            else:
                v = pool.id(('dom', tuple(sorted(ls))))
                if ('done', v) not in done:
                    done.add(('done', v)); cls.extend([[-v, l] for l in ls])
                clause.append(v)
        if not sat: cls.append(clause)
    # symmetry breaking: columns of B strictly decreasing (lex, row 0 most significant)
    for y in range(n-1):
        u = [B[x][y] for x in range(n)]; w = [B[x][y+1] for x in range(n)]
        eq = [None]*(n+1)
        eq[0] = pool.id(('eqT', y)); cls.append([eq[0]])
        for i in range(n):
            e = pool.id(('eq', y, i+1))
            # e <-> eq[i] & (u_i <-> w_i)
            cls.extend([[-e, eq[i]], [-e, -u[i], w[i]], [-e, u[i], -w[i]], [e, -eq[i], u[i], w[i]], [e, -eq[i], -u[i], -w[i]]])
            cls.append([-eq[i], -w[i], u[i]])        # if equal so far then u_i >= w_i
            eq[i+1] = e
        cls.append([-eq[n]])                          # strict
    sols = []
    base = [B[x][y] for x in range(n) for y in range(n)] + list(Ov.values())
    with Cadical153(bootstrap_with=cls) as s:
        while s.solve():
            m = set(l for l in s.get_model() if l > 0)
            sols.append(m)
            s.add_clause([-l if l in m else l for l in base])
    out = []
    idx = {('z', 0): 0}
    for x in range(n): idx[('i', x)] = 1 + x
    for y in range(n): idx[('o', y)] = 12 + y
    for m in sols:
        N = 23; A = [[0]*N for _ in range(N)]
        for u in V:
            for w in V:
                if u == w: continue
                a = arc(u, w)
                if a is None: continue
                val = True if a is True else ((a in m) if a > 0 else (-a not in m))
                if val: A[idx[u]][idx[w]] = 1
        out.append(A)
    return out

def check_drt_s3(A):
    N = len(A)
    for i in range(N):
        if A[i][i]: return False
        for j in range(i+1, N):
            if A[i][j] + A[j][i] != 1: return False
    IN = ins(A)
    if any(len(IN[j]) != 11 for j in range(N)): return False
    for i in range(N):
        for j in range(i+1, N):
            if len(IN[i] & IN[j]) != 5: return False
    for T in itertools.combinations(range(N), 3):
        if not (IN[T[0]] & IN[T[1]] & IN[T[2]]): return False
    return True

if __name__ == "__main__":
    lines = [l.strip() for l in open(sys.argv[1]) if l.strip()]
    pref = sys.argv[2]
    st = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    en = int(sys.argv[4]) if len(sys.argv) > 4 else len(lines)
    found = {}
    t0 = time.time()
    with open(pref + "_log.txt", "a") as log:
        for k in range(st, en):
            R = parse_upper(lines[k], 11)
            tours = solve_R(R)
            for A in tours:
                assert check_drt_s3(A), "verification failed"
            cans = canon_many(tours) if tours else []
            for c in cans: found.setdefault(c, k)
            log.write(f"R#{k}: {len(tours)} completions, classes so far {len(found)} ({time.time()-t0:.0f}s)\n"); log.flush()
    with open(pref + "_classes.txt", "w") as f:
        for c, k in found.items(): f.write(f"{c} {k}\n")
    print("done", len(found), "isomorphism classes of S_3 DRT(23)")
