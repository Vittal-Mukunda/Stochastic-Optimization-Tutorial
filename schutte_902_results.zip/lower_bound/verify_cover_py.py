# Independent re-check (pure Python, different code path) of the n=48 covering contradiction.
# For D (23-vertex S_3 DRT): count source-less bad 4-sets and, over ALL subsets S with |S|>=11 that are
# admissible, the maximum number of source-less bad 4-sets contained in the complement of S.
import sys, itertools
L=open(sys.argv[1]).read().split(); n=int(L[0]); A=[[int(c) for c in L[1+i]] for i in range(n)]
assert n==23
IN=[0]*n; OUT=[0]*n
for i in range(n):
    for j in range(n):
        if A[i][j]: OUT[i]|=1<<j; IN[j]|=1<<i
# sanity: DRT + S_3
assert all(bin(IN[j]).count('1')==11 for j in range(n))
assert all(bin(IN[a]&IN[b]).count('1')==5 for a in range(n) for b in range(a+1,n))
assert all(IN[a]&IN[b]&IN[c] for a,b,c in itertools.combinations(range(n),3))
srcless=[]
for X in itertools.combinations(range(n),4):
    if IN[X[0]]&IN[X[1]]&IN[X[2]]&IN[X[3]]: continue
    xm=sum(1<<x for x in X)
    if any(((OUT[x]|(1<<x))&xm)==xm for x in X): continue
    srcless.append(xm)
print("source-less bad 4-sets:",len(srcless))
pairs=[(IN[a]&IN[b]) for a in range(n) for b in range(a+1,n)]
full=(1<<n)-1
# Enumerate complements C (|C| <= 12) instead of S: S = full & ~C must be admissible.
best={}
for k in range(0,13):
    for Cs in itertools.combinations(range(n),k):
        C=sum(1<<c for c in Cs); S=full&~C
        if any(bin(IN[z]&S).count('1')<5 for z in range(n)): continue
        if any((pm&S)==0 for pm in pairs): continue
        cov=sum(1 for X in srcless if (X&C)==X)
        s=n-k
        if cov>best.get(s,-1): best[s]=cov
for s in sorted(best): print(f"|A_b|={s}: max source-less bad sets in complement = {best[s]}")
r=max(best[s]/(s-11) for s in best if s>11)
print("max per unit excess:",r,"; budget 12 =>",12*r,"<",len(srcless),"?",12*r<len(srcless))
