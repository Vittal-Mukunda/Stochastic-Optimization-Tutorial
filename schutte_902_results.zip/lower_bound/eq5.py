# Equality case of the Szekeres bound, one level beyond eq4_symbolic.py (n >= 6).
# For a "heavy" 4-set Y (exactly s dominators) there is a light triple Z in Y with D(Y) = D(Z), so for x outside
# Y the 5-set Y+x has D(Y+x) = D(Z+x), whose size is q or s (4-set level).  Counting
#   sum_{x not in Y} |D(Y+x)| = s(r-4)
# gives the number k of extensions with s dominators:  k = (s(r-4) - q(N-4)) / (s - q).
# k = 3 > 0 for every n, so 5-sets with s dominators (a third value, besides p and q) must occur; the level-5
# structure is therefore not two-valued and yields no divisibility contradiction by this simple count.
from fractions import Fraction as F
for n in range(6, 14):
    N = (n+2)*2**(n-1) - 1; r = (N-1)//2; t = (N-3)//4; s = (t-1)//2; q = (s-1)//2
    k = F(s*(r-4) - q*(N-4), s - q)
    print(f"n={n} N={N}: extensions of a heavy 4-set with s dominators: k = {k}")
