# A better constant in the lower bound for Schütte's problem

f(n) is the least order of a tournament in which every n vertices have a common dominator outside them
(property S_n; Erdős Problem #902). The classical bounds are

  (n+2)·2^(n−1) − 1 ≤ f(n) ≤ (ln 2 + o(1))·n²·2^n      (Szekeres–Szekeres 1965; Erdős 1963).

**New result.** A short double-counting lemma that links two neighbouring levels of the Szekeres chain gives

  **f(n) ≥ (c\* − o(1))·n·2^n,  with c\* = 0.769503219…**

so the leading constant of the lower bound goes from 1/2 to about 0.77. It also gives explicit improvements for
every n ≥ 5, for example f(5) ≥ 119 (was 111), f(6) ≥ 279 (was 255) and f(10) ≥ 7383 (was 6143); the table is in §5.

**What this does not do.** It does not decide the order of magnitude: f(n) is still between order n·2^n and
order n²·2^n. The upper-bound constant ln 2 is untouched.

**Novelty check.** I found no earlier improvement of the Szekeres bound. A paper posted to arXiv in April 2026
(arXiv:2604.08790) states that the Erdős and Szekeres bounds "remain the best known" and "have remained un-improved
for 60 years". The erdosproblems.com page lists no partial results. The erdosproblems.ai wiki page for E0902 (last updated 8 October 2026)
records three accepted partial results: Erdős 1963, Szekeres–Szekeres 1965, and Reid–McRae–Hedetniemi–Hedetniemi 2004
(f(4) ≥ 48). None of them improves the asymptotic lower bound, the wiki gives f(4) only as 48–67, and its proof-claim tab is empty.
A public Lean formalisation (jaredwilder/erdos902)
formalises the Szekeres bound and says the factor-n gap remains open. A specialist should still check the result
before it is written up as new.

---

## 1. Notation and the two classical facts

T is a tournament on N vertices with S_n. For X ⊆ V, D(X) is the set of vertices outside X that beat every vertex of X.
For 0 ≤ s ≤ n put

  ν_s = min { |D(X)| : |X| = s }.

So ν_0 = N, and S_n says ν_n ≥ 1. Since D(X) shrinks when X grows, ν_s is non-increasing in s. C(x,k) is the binomial
coefficient, with C(x,k) = 0 when x < k.

* **(M1)** ν_{n−1} ≥ n + 1. *(Szekeres.)* If |X| = n−1 and |D(X)| ≤ n, some z beats all of D(X), and a dominator of X ∪ {z}
  would have to lie in D(X) and beat z.
* **(M2)** ν_s ≥ 2ν_{s+1} + 1 for 0 ≤ s ≤ n−1. Let A be an s-set and v ∈ D(A). The in-neighbours of v inside D(A) are
  exactly D(A ∪ {v}), so T[D(A)] has minimum in-degree at least ν_{s+1}, and a tournament with minimum in-degree δ has at least 2δ+1 vertices.

Chaining (M2) from (M1) gives N = ν_0 ≥ 2^(n−1)(n+2) − 1, which is the Szekeres bound. That chain only ever uses
"halving". The lemma below adds a second, independent constraint at every level.

## 2. The cross-level lemma

**Lemma.** Let A be an s-set, 0 ≤ s ≤ n−1, let R = D(A) and m = |R|. Then for every 1 ≤ k ≤ n,

  (N − s) · C(m − ν_{s+1}, k)  ≥  ν_k · C(m, k).

*Proof.* Count the pairs (U, y) where U is a k-subset of R and y ∈ D(U).

* Each U is a set of at most n vertices, so it has at least ν_k dominators. Hence there are at least ν_k·C(m,k) pairs.
* If y ∈ A, every vertex of R beats y, so y dominates no non-empty subset of R.
* Let y ∉ A and put Q_y = R ∩ N⁻(y). A vertex is in Q_y exactly when it beats every vertex of A and also beats y,
  so Q_y = D(A ∪ {y}). Since |A ∪ {y}| = s+1, this gives |Q_y| ≥ ν_{s+1}. If y dominates U, then no vertex of U beats y,
  so U ⊆ R \ Q_y. So y lies in at most C(m − ν_{s+1}, k) pairs.

There are N − s vertices outside A, so there are at most (N − s)·C(m − ν_{s+1}, k) pairs. Comparing this with the first count
proves the inequality. ∎

**How it is used.** C(m − h, k)/C(m, k) increases with m. So for fixed N and fixed ν_{s+1}, …, ν_n, the lemma says
that every s-set has at least some number of dominators. Together with (M2) this gives a top-down recursion from
ν_n ≥ 1 to ν_0. A value of N is ruled out when the recursion forces ν_0 > N. (Taking s = n−1 and k = min(m, n)
recovers (M1), so the recursion needs no other input.)

**Why it beats Szekeres.** At level s = n−2 the Szekeres chain allows |D(A)| = 2n+3. Take k = n. The lemma then needs
C(2n+3, n)/C(n+2, n) ≤ N − n + 2. The left side is about 4^n/n^2.5. That is far larger than any N of order n·2^n, so for large n every
(n−2)-set must have noticeably more than 2n dominators. Informally, each n-subset of D(A) needs a dominator, but every
such dominator y is beaten by at least n+1 vertices of D(A), namely the dominators of A ∪ {y}. So y covers only
n-subsets of a part of D(A) of size m − n − 1. When m is close to 2n that part is too small, and about 4^n/n^2.5 vertices would be
needed to cover all the n-subsets.

**Corollary (the Szekeres bound is attained only for n = 2, 3).** f(n) > (n+2)·2^(n−1) − 1 for every n ≥ 4. According to the
erdosproblems.ai wiki, Szekeres and Szekeres conjectured that their bound is exact. Reid et al. (2004) refuted this at n = 4, and the
lemma refutes it for every n ≥ 5.

*Proof.* For n = 4 see Reid et al. (2004), or `RESULTS.md` (f(4) ≥ 49). For n = 5, 6, 7 see the table in §5.

For n ≥ 8, let S = (n+2)·2^(n−1) − 1 and suppose N ≤ S. By (M1), ν_{n−1} ≥ n+1. Suppose an (n−2)-set A had |D(A)| = m ≤ 2n+3.
The lemma with k = n would give C(m,n)/C(m−n−1,n) ≤ N − n + 2 < (n+2)·2^(n−1). But the left side is at least
C(2n+3,n)/C(n+2,2), or is infinite when m ≤ 2n, and C(2n+3,n)/C(n+2,2) > (n+2)·2^(n−1) for n ≥ 8:

* At n = 8 the left side is 1679.6 and the right side is 1280.
* From n to n+1, the left side grows by the factor (2n+5)(2n+4)/((n+4)(n+3)) and the right side by 2(n+3)/(n+2).
  The ratio of these factors, (2n+5)(n+2)²/((n+4)(n+3)²), exceeds 1 for n ≥ 3.

So every (n−2)-set has at least 2n+4 dominators. Then (M2) gives N ≥ 2^(n−2)(2n+5) − 1 > S, a contradiction. ∎
`szekeres_never_tight.py` checks the inequality for 8 ≤ n ≤ 400.

## 3. The asymptotic constant

Define

  Φ(a, b) = ∫₀¹ ln( (a − x)/(a − b − x) ) dx = [a ln a − (a−1) ln(a−1)] − [(a−b) ln(a−b) − (a−b−1) ln(a−b−1)].

Φ is strictly decreasing in a and strictly increasing in b, for a > b+1. Let a_1 = 1. For j ≥ 2, let a_j be the solution
of Φ(a_j, a_{j−1}) = ln 2 with a_j > a_{j−1} + 1.

| j | a_j | a_j / 2^j |
|---|---|---|
| 1 | 1 | 0.5 (Szekeres) |
| 2 | 2.5622 | 0.6405 |
| 3 | 5.6487 | 0.7061 |
| 4 | 11.8085 | 0.7380 |
| 5 | 24.1224 | 0.7538 |
| 6 | 48.7474 | 0.7617 |
| 10 | 787.4712 | 0.7690 |
| ∞ | | **c\* = 0.7695032191…** |

The differences a_j − 2a_{j−1} decrease to 1/2. In absolute terms each level gains about n/2 over plain doubling, so a_j/2^j converges.

**Theorem.** f(n) ≥ (c\* − o(1))·n·2^n.

*Proof.* Let T have S_n on N = f(n) vertices. Since c\* < 1 we may assume N < n·2^n. Fix j. We show by induction on
i ≤ j that ν_{n−i} ≥ (a_i − o(1))·n as n → ∞. The case i = 1 is (M1).

For the step, apply the lemma with s = n−i, k = n (ν_n ≥ 1), m = ν_{n−i} and h = ν_{n−i+1}. It gives

  G(m, h) := Σ_{t=0}^{n−1} ln( (m − t)/(m − h − t) ) = ln[ C(m,n)/C(m−h,n) ] ≤ ln N < n ln 2 + ln n.

The lemma also forces m − h ≥ n, since otherwise the right-hand side C(m−h, n) would be 0. G is increasing in h and decreasing in m.
Its summand is positive and increasing in t, so G(m, h) ≥ n·Φ(m/n, h/n) − O(1), as long as m − h − n ≥ cn.

Suppose m ≤ (a_i − ε)n while h ≥ (a_{i−1} − δ)n, with δ small compared with ε. Then
G ≥ n·Φ(a_i − ε, a_{i−1} − δ) − O(1), and Φ(a_i − ε, a_{i−1} − δ) > ln 2. For large n this contradicts the bound on G.

Finally, (M2) gives N = ν_0 ≥ 2^(n−j)(ν_{n−j} + 1) − 1 ≥ (a_j/2^j − o(1))·n·2^n. Now let j → ∞. ∎

## 4. Where the bottleneck is now

The whole chain starts from (M1), ν_{n−1} ≥ n+1, and that base is tight for n = 2 and 3 (QR_7 and QR_19). If the base could be
raised to ν_{n−1} ≥ a_1·n, the same recursion would give:

| a_1 | 1 | 1.1 | 1.25 | 1.5 | 2 | 3 |
|---|---|---|---|---|---|---|
| constant | 0.770 | 0.818 | 0.891 | 1.013 | 1.260 | 1.757 |

The constant is about a_1/2 + 0.27. A bound ν_{n−1} = ω(n), meaning that (n−1)-sets need superlinearly many
dominators, would already give f(n) = ω(n·2^n) through (M2) alone. In random S_n tournaments, ν_{n−1} is of order n².
So **the order of f(n) comes down to how few dominators an (n−1)-set can have.** The lemma cannot help with that, because at
level n−1 its input ν_n ≥ 1 is too weak.

The lemma also has a natural limit of its own. Once the minima ν_s are fixed, its bound is attained, up to factors 2^(o(n)),
only under two conditions. First, almost every n-subset of D(A) must have few dominators. Second, almost all of those dominators must be
vertices y for which A ∪ {y} has close to the minimum number of dominators. To push
further, one would have to show that this cannot happen for many sets A at once. I did not find such an argument.

## 5. Explicit bounds for small n

The recursion is solved with exact integers, all k from 1 to n, and the valid bounds ν_k ≥ 2^(s+1−k)(ν_{s+1}+1) − 1 for k ≤ s
(`asymptotic_lower_bound/crosslevel.py`). The values for n ≤ 9 were reproduced by a separate implementation
(`crosscheck_small.py`).

| n | Szekeres | **new** | new/Szekeres | new/(n·2^n) |
|---|---|---|---|---|
| 2 | 7 | 7 | 1.000 | 0.875 |
| 3 | 19 | 19 | 1.000 | 0.792 |
| 4 | 47 | 47 (49 by `RESULTS.md`) | 1.000 | 0.734 |
| 5 | 111 | **119** | 1.072 | 0.744 |
| 6 | 255 | **279** | 1.094 | 0.727 |
| 7 | 575 | **661** | 1.150 | 0.738 |
| 8 | 1279 | **1474** | 1.153 | 0.720 |
| 9 | 2815 | **3380** | 1.201 | 0.734 |
| 10 | 6143 | **7383** | 1.202 | 0.721 |
| 12 | 28671 | **35637** | 1.243 | 0.725 |
| 16 | 589823 | **787088** | 1.334 | 0.751 |
| 20 | 11534335 | **15772340** | 1.367 | 0.752 |
| 26 | 939524095 | **1311419060** | 1.396 | 0.752 |

*Update (round 3).* The verifier agent found a sharper form of the lemma, (N − s − m)·C(m − ν_{s+1}, k) + m·C(m − ν_{s+1} − 1, k) ≥ ν_k·C(m,k).
A dominator inside D(A) also excludes itself. This raises the table to f(4) ≥ 49, f(5) ≥ 121, f(6) ≥ 281, f(7) ≥ 665, f(8) ≥ 1485,
f(9) ≥ 3388 and f(10) ≥ 7398, and gives a five-line hand proof of f(4) ≥ 49. A degree-sum refinement then gives f(4) ≥ 50.
See `ROUND3_FINDINGS.md`. The n = 26 row above was corrected from 1311410175, which had been computed with a restricted range of k.

The full table for n ≤ 26 is in `table_exact.txt`. Floating-point runs for larger n (`crossfloat.py`, `large_n.txt`) give N/(n·2^n) =
0.757 (n = 40), 0.762 (n = 80), 0.766 (n = 120 and 160) and 0.767 (n = 240). These approach c\* from below. The approach is slow because of the
ln N/n − ln 2 = O(log n / n) term.

**Worked example, n = 5.** By (M1), ν_4 ≥ 6. Suppose N ≤ 125, and suppose some 3-set A has |D(A)| ≤ 13. Then the lemma with k = 4
fails: 122·C(7,4) = 4270 < 6·C(13,4) = 4290, and smaller m only makes it worse. So every 3-set has at least 14 dominators, and
(M2) gives N ≥ 2³·15 − 1 = 119. If N ≥ 126 there is nothing to prove. Hence f(5) ≥ 119.

## 6. Checks

* `sanity.py` checks every step of the proof by brute force: Q_y = D(A ∪ {y}), |Q_y| ≥ ν_{s+1}, the exact pair-count identity and both
  inequalities, for all s-sets A and all k. It runs on QR_7 (n = 2), QR_19 (n = 3), QR_67 (n = 4) and four random S_2 tournaments. All checks pass
  (`sanity_out.txt`). In QR_67 the actual minima are ν = (67, 33, 16, 6, 1).
* `limit_const.py` computes c\* with mpmath, accurate to about 12 digits (`limit_const.out`). The verifier's 40-digit value is
  c\* = 0.7695032191504894326990652683098231346767.
* Riemann step: the exact inequality G(m,h) ≥ n·Φ((m+1)/n, h/n), valid for m − h ≥ n, can replace the "−O(1)" estimate in §3.
* The computed bounds stay below the known upper bounds: f(5) ≤ 331 and f(6) ≤ 1163 (Paley tournaments).

## Sources

* Erdős Problems #902: https://www.erdosproblems.com/902
* erdosproblems.ai wiki, E0902: https://erdosproblems.ai/wiki/problems/extremal_graph_theory/E0902
* K. B. Reid, A. A. McRae, S. M. Hedetniemi, S. T. Hedetniemi, Domination and irredundance in tournaments, Australas. J. Combin. 29 (2004)
  157–172: https://ajc-new.maths.uq.edu.au/pdf/29/ajc_v29_p157.pdf
* "Schütte's property for sets of tournaments and an application to dice games", arXiv:2604.08790 (2026): https://arxiv.org/html/2604.08790
* Lean formalisation of the classical bounds: https://github.com/jaredwilder/erdos902
* J. W. Moon, *Topics on Tournaments* (1968), Thm 16 and corollary: https://www.gutenberg.org/ebooks/42833
* E. and G. Szekeres, On a problem of Schütte and Erdős, Math. Gazette 49 (1965) 290–293
