#!/usr/bin/env python3
# verifier2: sample L(n,M) as described in base/notes.md Step 2 and test S_n, D(B)=W, nu_{n-1}
import random, itertools, sys
def build(n, M, rng):
    W = list(range(n+1)); U = list(range(n+1, n+1+M)); B = list(range(n+1+M, n+1+M+n-1)); N = 2*n+M
    A = [[0]*N for _ in range(N)]
    def arc(x, y): A[x][y] = 1; A[y][x] = 0
    for a, b in itertools.combinations(W, 2): arc(a, b) if rng.random() < .5 else arc(b, a)
    for i in range(n+1): arc(W[i], W[(i+1) % (n+1)])        # Hamiltonian cycle (overrides)
    for w in W:
        for b in B: arc(w, b)
    for a, b in itertools.combinations(B, 2): arc(a, b) if rng.random() < .5 else arc(b, a)
    for u in U:
        beta = rng.choice(B)
        for b in B: arc(b, u) if b == beta else arc(u, b)
        while True:
            P = [w for w in W if rng.random() < .5]
            if P: break
        for w in W: arc(w, u) if w in P else arc(u, w)
    for a, b in itertools.combinations(U, 2): arc(a, b) if rng.random() < .5 else arc(b, a)
    for i in range(N):
        for j in range(N):
            if i != j: assert A[i][j] + A[j][i] == 1
    IN = [sum(1 << i for i in range(N) if A[i][j]) for j in range(N)]
    return N, IN, W, B
n, M, seed = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
N, IN, W, B = build(n, M, random.Random(seed))
bad = sum(1 for X in itertools.combinations(range(N), n) if not eval('&'.join('IN[%d]' % x for x in X)))
DB = IN[B[0]]
for b in B[1:]: DB &= IN[b]
print("n=%d M=%d N=%d undominated n-sets=%d |D(B)|=%d D(B)==W:%s" % (n, M, N, bad, bin(DB).count('1'), DB == sum(1 << w for w in W)))
