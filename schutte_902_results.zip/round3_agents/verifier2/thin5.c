// verifier2: independent check of base/thin_S5_N335.txt
// (1) tournament; (2) T[0..330] = QR_331; (3) QR_331 has S_5 via 5-sets through {0,1} (arc-transitivity);
// (4) every 5-set meeting B = {331..334} has a dominator in V; (5) D(B).
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#define N 335
#define P 331
#define W 6
typedef struct { uint64_t w[W]; } bs;
static bs IN[N], OUT[N];
static inline void setb(bs *s, int i) { s->w[i >> 6] |= 1ull << (i & 63); }
static inline int getb(const bs *s, int i) { return s->w[i >> 6] >> (i & 63) & 1; }
static inline bs and2(bs a, bs b) { bs r; for (int i = 0; i < W; i++) r.w[i] = a.w[i] & b.w[i]; return r; }
static inline int nz(bs a) { uint64_t o = 0; for (int i = 0; i < W; i++) o |= a.w[i]; return o != 0; }
static inline int pc(bs a) { int c = 0; for (int i = 0; i < W; i++) c += __builtin_popcountll(a.w[i]); return c; }
int main(int argc, char **argv) {
  FILE *f = fopen(argv[1], "r"); char *line = NULL; size_t cap = 0; int v = 0;
  while (getline(&line, &cap, f) > 0) {
    if (line[0] == '#') continue;
    char *p = line, *e; long x;
    while ((x = strtol(p, &e, 10)), e != p) { setb(&OUT[v], (int)x); setb(&IN[x], v); p = e; }
    v++;
  }
  printf("rows=%d\n", v);
  long bad = 0;
  for (int i = 0; i < N; i++) for (int j = 0; j < N; j++) if (i != j && getb(&OUT[i], j) + getb(&OUT[j], i) != 1) bad++;
  for (int i = 0; i < N; i++) if (getb(&OUT[i], i)) bad++;
  printf("tournament violations=%ld\n", bad);
  int qr[P] = {0}; for (int x = 1; x < P; x++) qr[(x * x) % P] = 1;
  long qbad = 0;
  for (int i = 0; i < P; i++) for (int j = 0; j < P; j++) if (i != j && getb(&OUT[i], j) != qr[((j - i) % P + P) % P]) qbad++;
  printf("arcs in V0 disagreeing with QR_331: %ld ; 0->1: %d\n", qbad, getb(&OUT[0], 1));
  // (3) QR_331 S_5 restricted to V0: 5-sets {0,1,a,b,c}, dominator must lie in V0
  bs V0; memset(&V0, 0, sizeof V0); for (int i = 0; i < P; i++) setb(&V0, i);
  long und = 0; int mn = 1 << 30;
  bs m01 = and2(and2(IN[0], IN[1]), V0);
  for (int a = 2; a < P; a++) { bs ma = and2(m01, IN[a]);
    for (int b = a + 1; b < P; b++) { bs mb = and2(ma, IN[b]);
      for (int c = b + 1; c < P; c++) { bs mc = and2(mb, IN[c]); int k = pc(mc); if (!k) und++; if (k < mn) mn = k; } } }
  printf("QR_331: 5-sets through {0,1} undominated (in V0) = %ld, min |D| = %d\n", und, mn);
  // (4) all 5-sets meeting B
  long cnt = 0; und = 0;
  for (int mask = 1; mask < 16; mask++) {
    int k = __builtin_popcount(mask); bs base; memset(&base, 0xff, sizeof base);
    for (int t = 0; t < 4; t++) if (mask >> t & 1) base = and2(base, IN[P + t]);
    int r = 5 - k;   // vertices from V0
    if (r == 4) {
      for (int a = 0; a < P; a++) { bs ma = and2(base, IN[a]);
        for (int b = a + 1; b < P; b++) { bs mb = and2(ma, IN[b]);
          for (int c = b + 1; c < P; c++) { bs mc = and2(mb, IN[c]);
            if (!nz(mc)) { und += P - 1 - c; cnt += P - 1 - c; continue; }
            for (int d = c + 1; d < P; d++) { cnt++; if (!nz(and2(mc, IN[d]))) und++; } } } }
    } else if (r == 3) {
      for (int a = 0; a < P; a++) { bs ma = and2(base, IN[a]);
        for (int b = a + 1; b < P; b++) { bs mb = and2(ma, IN[b]);
          for (int c = b + 1; c < P; c++) { cnt++; if (!nz(and2(mb, IN[c]))) und++; } } }
    } else if (r == 2) {
      for (int a = 0; a < P; a++) for (int b = a + 1; b < P; b++) { cnt++; if (!nz(and2(and2(base, IN[a]), IN[b]))) und++; }
    } else if (r == 1) {
      for (int a = 0; a < P; a++) { cnt++; if (!nz(and2(base, IN[a]))) und++; }
    }
  }
  printf("5-sets meeting B: %ld, undominated: %ld\n", cnt, und);
  bs DB; memset(&DB, 0xff, sizeof DB); for (int t = 0; t < 4; t++) DB = and2(DB, IN[P + t]);
  printf("D(B):"); for (int i = 0; i < N; i++) if (getb(&DB, i)) printf(" %d", i); printf("  (|D(B)|=%d)\n", pc(DB));
  return 0;
}
