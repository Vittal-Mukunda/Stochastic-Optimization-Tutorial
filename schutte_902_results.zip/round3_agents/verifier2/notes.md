# verifier2 notes (adversarial verification, Erdős #902)

Started 2026-10-17. Verdicts are appended per item as they are settled.

## Item 1 — f(4) >= 50

### 1a. ROUND3_FINDINGS §1 hand count (regular N=49 impossible)
VERIFIED (by hand). Checked: D(P∪{y}) = R ∩ N⁻(y) for y ∉ P (y∈R or y∈O); in-degrees in T[R] sum to 55 = 11·5, so all exactly 5;
|O| = 49−13 = 36; r∈R beats a,b and 5 of R, out-degree 24 ⇒ 17 arcs into O; Σq_y = 187 = 180+7; e_y ≤ 6.
a,b beat nothing in R; z∈R dominates C(5,3)=10 triples of R, z∈O dominates C(6−e_z,3).
ℓ = 0,10,16,19,20,20,20 (differences 10,6,3,1,0,0 non-increasing ⇒ concave, ℓ(0)=0 ⇒ subadditive; with Σe=7 the true
minimum of Σℓ is 30 (6+1), so ≥ 20 is safe). Σ ≤ 110+720−20 = 810 < 825 = 5·C(11,3). Then ν_2 ≥ 12 ⇒ T[N⁻(v)] has min
in-degree ≥ 12 ⇒ d⁻(v) ≥ 25 > 24. Note: only needs d⁺(r) ≥ 24 for r ∈ R (in fact Σ_{r∈R} d⁺(r) ≥ 258 suffices, since
any Σe_y ≥ 1 already gives Σℓ ≥ 10 > 5 = 830−825). Regularity at N=49 comes from the min-in-degree theorem.
f(4) ≥ 50 also needs N ≤ 48 excluded: min in-degree ≥ 24 ⇒ N ≥ 49. OK.

### 1b. Min-in-degree theorem (RESULTS §3), logic
VERIFIED. F1/F2/F3 re-derived (F1: if |D(Y)| ≤ 4 a dominator x of D(Y) exists; if x∈Y contradiction directly, else a
dominator y of Y∪{x} lies in D(Y) and beats x). Lemma 1: in-degrees in A ≥ 11 sum to 253 ⇒ regular; Σ_pairs common
in-nbrs = 23·C(11,2) = 1265 = 253·5 ⇒ doubly regular; dominator of Y∪{v} lies in A ⇒ S_3. Lemma 3(i): A_b = D({v,b}),
A_b∩N⁻(z) = D({v,b,z}) (z∈A), A_b∩N⁻(z1)∩N⁻(z2) = D({v,b,z1,z2}) — all necessary conditions. (ii) arcs A→B:
d⁺(a) − 1 − 11 ≤ n − 36 ⇒ Σ_b(|A_b|−11) ≤ 23(n−36) − 11(n−24) = 12n − 564 (=48 at n=51). (iii) the dominator of X is
not v (v loses to A) and not in A, so it is b∈B with X ⊆ A∩N⁺(b) = A\A_b. 11-set case: complement {z}∪N⁺(z) only
holds undominated 4-sets with source z (trivial). Final: Σ_b cov(A_b) ≤ r·Σe_b ≤ 48r < #sourceless. Correct.

### 1c. Lemma 4 computation — re-implemented independently (verifier2/lemma4.c)
VERIFIED. Different method: covered counts via a subset-sum (zeta) transform over 2^23 (uint16 table), admissibility via
253 precomputed pair masks. Runs in 0.5 s per tournament. Results identical to local48b_out.txt / verify_class*.out:
 class1 (QR_23): undominated 2530, with source 1518, sourceless 1012; adm 11-sets = 23 = the in-nbhds; maxcov by size
   12..19: 0,25,21,14,9,5,3,1; r = 12.5 (at e=2). 48·12.5 = 600 < 1012.
 class0 (D2): undominated 2475, source 1430, sourceless 1045; adm 11-sets = 23 = in-nbhds; maxcov 20,24,25,17,10,9,3,1;
   r = 20 (at e=1). 48·20 = 960 < 1045.
 Admissible counts per size also coincide (309, 31383, 223190, ... for D2; 276, 24288, 201135, ... for QR_23).

### 1d. Lemma 2 vs McKay's catalogue
VERIFIED independently of the agents' SAT classification. Downloaded users.cecs.anu.edu.au/~bdm/data/drtourn23.txt
(37 lines, upper-triangle format; all 37 checked regular and doubly regular). Exactly 2 have S_3 (lines 34, 35).
Converses checked too (in case the list were up to iso+converse): converses with S_3 are of lines 0 and 35; conv(0)
has the same invariants as line 34 (D2 is not self-converse; QR_23 is). Lemma 4 run directly on McKay's lines 34, 35 and on
conv(0), conv(35): identical numbers (1045/r=20, 1012/r=12.5). So the min-in-degree theorem holds given McKay's
(Spence–McKay) catalogue alone, with no reliance on the agents' SAT enumeration.

### Item 1 verdict: VERIFIED. f(4) ≥ 50 holds (computer-assisted part re-done two ways; hand count checked).

## Item 2 — base level tight (base/notes.md Step 2)
### 2a. Construction / case analysis: VERIFIED.
Complete tournament (W–W with Ham. cycle, W→B, B–B arbitrary, U–B via β, U–W via P(u), U–U random). D(B) = W since
every u loses to β(u) ∈ B ⇒ ν_{n−1} ≤ n+1; (M1) gives equality once S_n holds. k = |X∩B| = n−1: X = B∪{x} dominated by
x's cycle predecessor (x∈W) or by any w∈P(x) ≠ ∅ (x∈U), both ∉ X and → B. k ≤ n−2: u∈U\X dominates X iff β(u) ∉ X∩B
[(n−1−k)/(n−1) > 0], P(u) ⊆ W\X [(2^{n+1−j}−1)/(2^{n+1}−1), j ≤ n so ≥ 1 choice], u beats X∩U [2^{−s}]: product = q.
Events for distinct u use disjoint random variables (β(u), P(u), arcs u–(X∩U)); arcs inside U\X are not involved ⇒
independent ⇒ P(X undominated) ≤ (1−q)^{M−s} (other dominators ignored: upper bound). Count C(n−1,k)C(n+1,j)C(M,s) right.
### 2b. Union bound values: VERIFIED by exact rational arithmetic (verifier2/ub_exact.py, own code):
 ln F(n, 2n²2^n) = −1.8044, −5.3493, −10.8915, −18.4974, −28.4248, −40.7896, −55.6426 for n = 2..8 (= union_bound.out).
 (M = 2n²2^n is an integer, so the ceiling is exact.)
### 2c. Analytic E0, E1, E2 (n ≥ 5): VERIFIED with one immaterial numerical slip.
 ρ_j = (2^{n+1}−2^j)/(2^{n+1}−1) ≥ 1−2^{j−n−1}; q·2^n = ρ_j·(n−1−k)2^k/(n−1); min over 1≤k≤n−2 of (n−1−k)2^k at k=1
 (ratio test: increasing up to k=n−3, equal at n−2), giving (n−2)/(n−1) with ρ ≥ 1/2. q(M−s) ≥ ρ'(2n² − n2^{−n}) ≥ ρ'(2n²−1).
 Vandermonde for E0 ok; E1 uses Σ_j C(n+1,j) ≤ 2^{n+1}, C(M,n−j) ≤ M^{n/2}; E2 uses (n−2) values of k, C(n−1,k) ≤ 2^{n−1},
 C(M+n+1,n−k) ≤ (M+n+1)^{n−1}. Closed forms: constant 5.5 in E0 is valid (max_n 2^{−n/2}n² = 4.5 at n=6, + 1, Stirling slack).
 SLIP: the stated closed form for ln E1 equals −1.396 at n = 5, not "≤ −1.40" (exact ln E1 = −1.897; the +1.6931 has 0.5 slack).
 Sum of closed forms at n=5: e^−10.6 + e^−1.396 + e^−1.6 = 0.4495 < 0.45 still; exact E-sum at n=5 = 0.185. All three closed
 forms are decreasing for n ≥ 5. Conclusion F < 1 holds. The (ln2+o(1)) remark also checks (exponents n²(ln2 − c) + O(n ln n)).
### 2d. Monte Carlo sanity (verifier2/mc_L.py): L(2,32) ×3 and L(3,144) ×2 sampled: all S_n, D(B) = W every time.
### 2e. thin_S5_N335.txt spot check (verifier2/thin5.c, own code, 3.2 s): VERIFIED.
 Tournament OK; T[0..330] = QR_331 exactly (0 disagreeing arcs); QR_331 S_5 via all 5,881,204 5-sets ⊇ {0,1} (dominator in V0;
 reduction valid: x ↦ ax+b, a ∈ QR, is arc-transitive, and each pair carries one arc); all 2,000,693,421 = C(335,5) − C(331,5)
 5-sets meeting B dominated; D(B) = {5,87,218,266,279,312}, size 6 = n+1. Justification for restricting to sets meeting B:
 a 5-set inside V0 has a dominator in T[V0] = QR_331 and arcs inside V0 are unchanged in T.
### Item 2 verdict: VERIFIED (S_n tournament with ν_{n−1} = n+1 on 2n²2^n + 2n vertices, every n ≥ 2).

## Item 3 — uppertheory/THEOREMS.md (in progress; hand checks so far)
- A0 (a)-(d): VERIFIED. A1(a) conflict ⇒ g(y,x)=(x',y), g²x=x' fixes g ⇒ ≤ n(n−1) conflicted y; μ_X ∈ [λ−n²2^−n, λ]: VERIFIED.
- A1(b) type i uses the unique g with gy=y' and shares exactly r_g=|gX∩X'| coins (any other sharing is type ii ⇒ P=0); A1(c) ≤ 2n²: VERIFIED.
- A2 (LLL with x=2^−n(1+η), η=8n²2^−n; (1−x)^{2^nμ}; ln(1−x) ≥ −x−x²; μ_X ≤ λ ≤ n²): VERIFIED.
- A3 (Janson's Suen form, Δ over unordered adjacent pairs, δ ≤ 4n²2^−n; Δ_X ≤ (N/2)2^−2n Σ_{g≠e} r_g2^{r_g} ≤ (λ/2)n²2^{R0−n};
  Δ_XX' ≤ λn²2^{R−n} using Σ_g r_g ≤ n²): VERIFIED.
- A4 (runs/full cycles, |gX∩X| = n−a, a+3b ≤ n, ≤ 2^n N^{a+b}, a+b < 2n/3, |G| ≤ N; ratio ≤ n^{n+2}2^n N^{1−n/3} → 0): VERIFIED.
- Thm A first moment ln EZ ≥ εn² − n ln2 − o(1); second moment: count |G|C(n,r)C(N,n−r) ≤ C(N,n)N(n²/(N−n))^r/r!; the r ≤ n−k0
  range: ln N − 2L ≤ −(n−1)ln2 + 4 ln n + O(1) (doc says 3 ln n: harmless slip), plus (ln2/4)n ⇒ −(3/4)n ln2 → −∞, geometric in r;
  r > n−k0 with min = λ: −εn² + O(n log n). Var Z/(EZ)² ≤ 1/EZ + o(1) → 0, P(S_n) ≤ P(Z=0) → 0. All bounds uniform in G (only
  |G| ≤ N and freeness used). VERIFIED.
- (Item 1 addendum) QR_23 built from scratch: S_3, DRT, sourceless undominated 4-sets 1012, r = 12.5 — same as class1 / McKay #35.
- (Item 2 addendum) thin_S4_N70.txt fully re-checked (verifier2/thin4.py): tournament, T[0..66] = QR_67, all C(70,4) 4-sets
  dominated, ν_3 = 5, exactly 2 thin triples. VERIFIED.

### Item 3 (continued)
- Thm B: VERIFIED. Exact formula P(U dom) = (1−2^{1−n})^{(3^{m−d}−1)/2} brute-forced over all S for (m,d) = (2,1), (3,1), (3,2)
  (several subspaces): exact equality (3/4, 81/256, 255/256). Pairing U±c (c∉U ⇔ 2c∉U), exclusivity, n distinct ± pairs,
  disjoint coins: all correct. Second moment: consistent overlaps are cosets of U∩U' (≤ 3^e ≤ n/3 shared coins), ≤ 3^{d−e}
  consistent partners (inconsistent ones give P = 0, so the factor 2 is only needed for δ), Δ ≤ N2^{−5n/3} → 0,
  δ ≤ (2n+1)2^{−n}; P(both) ≤ (1+o(1))P·P' uniformly; EZ = [m,d]_3 P(U dom) → ∞. thmB_demo EZ = 193.1 recomputed (193.2).
- Prop C: VERIFIED (projection argument; total-domination fix with an in-neighbour of the unique source of T1[U]; a source in T2
  gives γ(T1[T2]) ≤ γ(T1), hence |T2| ≥ 3 is forced).
- Prop D: inequality VERIFIED (E d(d−1) = Σ_{y≠z} C(c_yz,s)/C(N,s), Σ c_yz = N r(r−1), Jensen on the convex piecewise-linear
  extension). Identity checked EXACTLY on QR_19 (s=2,3), QR_23 (s=3), QR_43 (s=3). Numerics 0.6605 (N=1163,s=6), 0.9457
  (N=7383,s=10) reproduced. GAP (wording): the title "never sub-Poisson" and ROUND3 §5 "can never be sub-Poisson in
  variance" are FALSE as literal statements — DRTs ARE sub-Poisson (Var/mean = 0.21 for QR_19, s=3; 0.66 for N=1163, s=6).
  Correct statement: Var d ≥ (1 − (1+s+C(s,2))2^{−s} − O(sλ_s/N))·E d, with equality for DRTs; sub-Poisson only by an
  O(s²2^{−s}) fraction.
- Prop E: VERIFIED (Gram matrix of w_S, (trG)² ≤ rank·tr G²); numerically sane on random tournaments. Remark: averages mix
  orders 2..2j; "order 4 and higher" needs the lower orders controlled (fine for j = 2 + DRT as stated).
- Scope GAP (ROUND3 §5 / Thm A "special cases"): Theorem A needs a FREE action of an odd-order group and is asymptotic
  (n ≥ n0(ε)). The f(4) search families include affine/quotient/fixed-point orbit types (non-free), so "covers random k-orbit
  families of the kind used in the f(4) searches" is an overstatement; Remark (2) (stabilisers ≤ s) is unproved, and is not just
  "a factor s in degree bounds": with stabilisers, two literals of one A_y^X can share a coin with EQUAL orientation
  (g(y,x) = (y,x'), g ∈ Stab(y)), so P(A_y^X) can exceed 2^{−n} and μ_X can exceed λ.
### Item 3 verdict: Theorems A, B and Props C, D (inequality), E VERIFIED; two wording/scope GAPs (Prop D slogan; Thm A coverage
  of non-free f(4) families / Remark 2).

## OVERALL (verifier2, final)
Item 1 f(4) ≥ 50: VERIFIED (hand count + min-in-degree theorem; Lemma 4 recomputed by a different algorithm; Lemma 2 confirmed
  directly from McKay's drtourn23.txt incl. converses — proof no longer depends on the agents' SAT enumeration).
Item 2 base level tight: VERIFIED (case analysis, independence, exact F for n = 2..8, analytic E0–E2; one immaterial slip:
  stated closed form for ln E1 is −1.396 at n = 5, not ≤ −1.40; both explicit examples re-checked).
Item 3 barriers: Thm A, Thm B, Props C, D (inequality), E VERIFIED; GAPs only in wording/scope: "never sub-Poisson" is false
  literally (DRTs are sub-Poisson by ≈ (1+s+C(s,2))2^{−s}); Thm A does not cover the non-free (affine/quotient/fixed-point)
  f(4) search families, and Remark (2) is unproved (and misdescribed: stabilisers also allow equal-orientation coin
  coincidences inside one A_y^X). Minor: "3 ln n" should be "4 ln n" in the r = 2 estimate of Thm A (harmless).
