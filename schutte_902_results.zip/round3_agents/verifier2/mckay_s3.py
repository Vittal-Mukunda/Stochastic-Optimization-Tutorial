#!/usr/bin/env python3
# verifier2: read McKay's drtourn23.txt (upper-triangle strings), check DRT property and S_3 for each,
# write the S_3 members as 23x23 matrices for lemma4.c.
import sys, itertools
path = sys.argv[1]; outdir = sys.argv[2]
lines = [l.strip() for l in open(path) if l.strip()]
n = 23
print("lines:", len(lines), "lengths:", set(len(l) for l in lines))
res = []
for idx, l in enumerate(lines):
    A = [[0]*n for _ in range(n)]; k = 0
    for i in range(n):
        for j in range(i+1, n):
            if l[k] == '1': A[i][j] = 1
            else: A[j][i] = 1
            k += 1
    IN = [0]*n; OUT = [0]*n
    for i in range(n):
        for j in range(n):
            if A[i][j]: OUT[i] |= 1 << j; IN[j] |= 1 << i
    reg = all(bin(OUT[i]).count('1') == 11 for i in range(n))
    dr = all(bin(IN[a] & IN[b]).count('1') == 5 for a, b in itertools.combinations(range(n), 2))
    s3 = all(IN[a] & IN[b] & IN[c] for a, b, c in itertools.combinations(range(n), 3))
    nund3 = sum(1 for a, b, c in itertools.combinations(range(n), 3) if not (IN[a] & IN[b] & IN[c]))
    res.append((idx, reg, dr, s3, nund3))
    if s3:
        with open(f"{outdir}/mckay_s3_{idx}.txt", "w") as f:
            f.write("23\n")
            for i in range(n): f.write("".join(str(A[i][j]) for j in range(n)) + "\n")
print("all regular:", all(r[1] for r in res), " all doubly regular:", all(r[2] for r in res))
print("S_3 members (index):", [r[0] for r in res if r[3]])
print("undominated-triple counts:", sorted(r[4] for r in res))
