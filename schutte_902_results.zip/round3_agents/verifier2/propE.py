#!/usr/bin/env python3
# verifier2: numeric sanity check of the Welch-type bound in Prop E
import itertools, random
from math import comb
def check(N, j, seed):
    rng = random.Random(seed)
    M = [[1]*N for _ in range(N)]
    for a, b in itertools.combinations(range(N), 2):
        if rng.random() < .5: M[a][b], M[b][a] = 1, -1
        else: M[a][b], M[b][a] = -1, 1
    def c(U):
        t = 0
        for y in range(N):
            p = 1
            for x in U: p *= M[y][x]
            t += p
        return t
    sets = list(itertools.combinations(range(N), j)); K = len(sets)
    tot = sum(c(set(S) ^ set(T))**2 for S in sets for T in sets if S != T)
    lhs = tot / (K*(K-1)); rhs = N*(1 - (N-1)/(K-1))
    return lhs, rhs
for N, j, s in [(9, 2, 1), (11, 2, 2), (7, 3, 3), (12, 1, 4)]:
    l, r = check(N, j, s); print(N, j, "lhs=%.4f rhs=%.4f ok=%s" % (l, r, l >= r - 1e-9))
