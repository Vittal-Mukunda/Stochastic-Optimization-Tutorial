#!/usr/bin/env python3
# verifier2: S_3 check for the converses of McKay's 37 DRT(23); write S_3 converses for lemma4.c
import sys, itertools
lines=[l.strip() for l in open(sys.argv[1]) if l.strip()]; n=23
hits=[]
for idx,l in enumerate(lines):
    A=[[0]*n for _ in range(n)]; k=0
    for i in range(n):
        for j in range(i+1,n):
            if l[k]=='1': A[j][i]=1   # converse
            else: A[i][j]=1
            k+=1
    IN=[0]*n
    for i in range(n):
        for j in range(n):
            if A[i][j]: IN[j]|=1<<i
    if all(IN[a]&IN[b]&IN[c] for a,b,c in itertools.combinations(range(n),3)):
        hits.append(idx)
        with open(f"conv_s3_{idx}.txt","w") as f:
            f.write("23\n"+"\n".join("".join(str(A[i][j]) for j in range(n)) for i in range(n))+"\n")
print("converses with S_3:", hits)
