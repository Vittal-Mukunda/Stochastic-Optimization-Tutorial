#!/usr/bin/env python3
# verifier2: brute-force P(U dominating) in a uniformly random Cayley tournament on F_3^m, vs (1-2^{1-n})^{(3^{m-d}-1)/2}
import itertools
from fractions import Fraction as Fr
def vecs(m): return list(itertools.product(range(3), repeat=m))
def add(a, b): return tuple((x+y) % 3 for x, y in zip(a, b))
def neg(a): return tuple((-x) % 3 for x in a)
def span(gens, m):
    S = {tuple([0]*m)}
    for g in gens:
        S = {add(s, tuple((k*x) % 3 for x in g)) for s in S for k in range(3)}
    return S
for m, gens in [(2, [(1,0)]), (3, [(1,0,0)]), (3, [(1,0,0),(0,1,0)]), (3, [(1,1,1)]), (3, [(1,2,0),(0,1,1)])]:
    V = vecs(m); zero = tuple([0]*m)
    reps = []; seen = set()
    for v in V:
        if v == zero or v in seen: continue
        reps.append(v); seen.add(v); seen.add(neg(v))
    U = span(gens, m); d = len(gens); n = len(U)
    good = 0
    for bits in itertools.product((0, 1), repeat=len(reps)):
        S = set(r if b else neg(r) for r, b in zip(reps, bits))
        # U dominating: every y not in U has an in-neighbour in U, i.e. no y outside U with u-y in S for all u in U
        dom = all(not all(add(u, neg(y)) in S for u in U) for y in V if y not in U)
        good += dom
    P = Fr(good, 2**len(reps)); F = (1 - Fr(2, 2**n))**((3**(m-d)-1)//2)
    print(f"m={m} d={d} n={n}: brute {P} formula {F} equal={P==F}")
