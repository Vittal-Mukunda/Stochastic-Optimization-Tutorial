#!/usr/bin/env python3
# verifier2: full check of base/thin_S4_N70.txt (S_4 on all 4-sets, nu_3, T[0..66] = QR_67)
import sys, itertools
rows = [l.split() for l in open(sys.argv[1]) if l.strip() and not l.startswith('#')]
N = len(rows); OUT = [0]*N; IN = [0]*N
for v, r in enumerate(rows):
    for x in map(int, r): OUT[v] |= 1 << x; IN[x] |= 1 << v
ok = all(((OUT[i] >> j) & 1) + ((OUT[j] >> i) & 1) == 1 for i in range(N) for j in range(N) if i != j) and all(not (OUT[i] >> i) & 1 for i in range(N))
Q = {(x*x) % 67 for x in range(1, 67)}
qr = all(((OUT[i] >> j) & 1) == ((j - i) % 67 in Q) for i in range(67) for j in range(67) if i != j)
und4 = sum(1 for X in itertools.combinations(range(N), 4) if not (IN[X[0]] & IN[X[1]] & IN[X[2]] & IN[X[3]]))
c3 = [bin(IN[a] & IN[b] & IN[c]).count('1') for a, b, c in itertools.combinations(range(N), 3)]
print("N=%d tournament=%s T[0..66]=QR67:%s undominated 4-sets=%d nu_3=%d #thin triples=%d" % (N, ok, qr, und4, min(c3), c3.count(5)))
