// verifier2: independent re-implementation of Lemma 4 (RESULTS.md §3).
// Input: 23x23 0/1 adjacency (row i, col j = 1 iff i -> j), optionally preceded by "23".
// Method differs from local48b.c: covered counts are obtained by a subset-sum (zeta) transform over 2^23,
// admissibility is checked with precomputed pair masks.
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#define P 23
static uint32_t IN[P], OUT[P];
static uint16_t g[1u<<P];
int main(int argc, char **argv) {
  FILE *f = fopen(argv[1], "r"); if (!f) return 1;
  char tok[256]; int row = 0;
  while (row < P && fscanf(f, "%255s", tok) == 1) {
    if (strlen(tok) != P) continue;
    for (int j = 0; j < P; j++) if (tok[j] == '1') { OUT[row] |= 1u << j; IN[j] |= 1u << row; }
    row++;
  }
  fclose(f);
  // sanity: tournament, regular, doubly regular, S_3
  int ok = 1;
  for (int i = 0; i < P; i++) {
    if (OUT[i] >> i & 1) ok = 0;
    if ((OUT[i] | IN[i]) != (((1u << P) - 1) & ~(1u << i))) ok = 0;
    if (OUT[i] & IN[i]) ok = 0;
    if (__builtin_popcount(OUT[i]) != 11) ok = 0;
  }
  int dr = 1;
  for (int a = 0; a < P; a++) for (int b = a + 1; b < P; b++) if (__builtin_popcount(IN[a] & IN[b]) != 5) dr = 0;
  int s3 = 1;
  for (int a = 0; a < P; a++) for (int b = a + 1; b < P; b++) for (int c = b + 1; c < P; c++) if (!(IN[a] & IN[b] & IN[c])) s3 = 0;
  printf("tournament+regular=%d doubly_regular=%d S3=%d\n", ok, dr, s3);
  // undominated 4-sets
  int nund = 0, nsrc = 0, nsl = 0;
  memset(g, 0, sizeof g);
  for (int a = 0; a < P; a++) for (int b = a + 1; b < P; b++) for (int c = b + 1; c < P; c++) for (int d = c + 1; d < P; d++) {
    if (IN[a] & IN[b] & IN[c] & IN[d]) continue;
    nund++;
    uint32_t X = (1u << a) | (1u << b) | (1u << c) | (1u << d);
    int v[4] = {a, b, c, d}, src = 0;
    for (int i = 0; i < 4; i++) if ((X & ~(1u << v[i]) & ~OUT[v[i]]) == 0) src++;
    if (src) nsrc++; else { nsl++; g[X] = 1; }
  }
  printf("undominated 4-sets=%d with_source=%d sourceless=%d\n", nund, nsrc, nsl);
  // zeta transform: g[C] = number of sourceless undominated 4-sets contained in C
  for (int i = 0; i < P; i++) { uint32_t bit = 1u << i; for (uint32_t m = 0; m < (1u << P); m++) if (m & bit) g[m] += g[m ^ bit]; }
  uint32_t pm[253]; int np = 0;
  for (int a = 0; a < P; a++) for (int b = a + 1; b < P; b++) pm[np++] = IN[a] & IN[b];
  long long cnt[P + 1] = {0}; int best[P + 1] = {0}; uint32_t bestS[P + 1] = {0};
  int adm11_bad = 0, inn_adm = 0; uint32_t full = (1u << P) - 1;
  for (uint32_t S = 0; S <= full; S++) {
    int sz = __builtin_popcount(S); if (sz < 11) continue;
    int a = 1;
    for (int z = 0; z < P && a; z++) if (__builtin_popcount(IN[z] & S) < 5) a = 0;
    for (int k = 0; k < np && a; k++) if (!(pm[k] & S)) a = 0;
    if (!a) continue;
    cnt[sz]++;
    if (sz == 11) { int isin = 0; for (int z = 0; z < P; z++) if (IN[z] == S) isin = 1; if (!isin) adm11_bad++; else inn_adm++; }
    int c = g[full & ~S];
    if (c > best[sz]) { best[sz] = c; bestS[sz] = S; }
  }
  // are all 23 in-neighbourhoods admissible?
  printf("admissible 11-sets=%lld (in-nbhds among them=%d, non-in-nbhd=%d)\n", cnt[11], inn_adm, adm11_bad);
  double r = 0;
  for (int s = 11; s <= P; s++) {
    printf(" size %2d e=%2d adm=%7lld maxcov=%3d", s, s - 11, cnt[s], best[s]);
    if (s > 11) { double q = (double)best[s] / (s - 11); printf(" ratio=%.3f", q); if (q > r) r = q; }
    printf("\n");
  }
  printf("r=%.3f ; n=51 budget 48 -> %.1f vs %d\n", r, 48 * r, nsl);
  return 0;
}
