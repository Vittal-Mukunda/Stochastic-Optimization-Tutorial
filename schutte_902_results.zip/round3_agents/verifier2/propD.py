#!/usr/bin/env python3
# verifier2: Prop D numerics and an exact check of the variance identity on Paley tournaments
from fractions import Fraction as Fr
from math import comb
import itertools
def rhs(N, s):
    r = (N-1)//2
    lam = Fr(N*comb(r, s), comb(N, s))
    t2 = Fr(N*(N-1)*comb((N-3)//4, s), comb(N, s))
    return lam, lam + t2 - lam*lam
for N, s in [(1163, 6), (7383, 10)]:
    lam, v = rhs(N, s)
    print(N, s, "lambda=%.4f" % float(lam), "Var_lb/lambda=%.4f" % float(v/lam), "1-(1+s+C(s,2))2^-s=%.4f" % (1-(1+s+comb(s,2))/2**s))
def qr(p):
    Q = {(x*x) % p for x in range(1, p)}
    return [[1 if (j-i) % p in Q else 0 for j in range(p)] for i in range(p)]
for p, s in [(19, 2), (19, 3), (23, 3), (43, 3)]:
    A = qr(p); OUT = [sum(1 << j for j in range(p) if A[i][j]) for i in range(p)]
    ds = []
    for X in itertools.combinations(range(p), s):
        m = sum(1 << x for x in X)
        ds.append(sum(1 for y in range(p) if OUT[y] & m == m))
    K = len(ds); mean = Fr(sum(ds), K); var = Fr(sum(d*d for d in ds), K) - mean*mean
    lam, v = rhs(p, s)
    print(f"QR_{p} s={s}: mean={mean} (lambda={lam}) Var={var} formula={v} equal={var==v} Var/mean={float(var/mean):.4f}")
