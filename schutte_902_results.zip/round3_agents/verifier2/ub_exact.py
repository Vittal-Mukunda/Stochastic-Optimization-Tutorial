#!/usr/bin/env python3
# verifier2: exact rational union bound F(n,M) for L(n,M), independent of base/union_bound.py
from fractions import Fraction as Fr
from math import comb, log
import sys
def F(n, M):
    tot = Fr(0)
    for k in range(0, n-1):              # k = |X cap B| <= n-2
        for j in range(0, n-k+1):        # j = |X cap W|
            s = n-k-j
            if j > n+1 or s > M: continue
            q = Fr(n-1-k, n-1) * Fr(2**(n+1-j)-1, 2**(n+1)-1) / 2**s
            tot += comb(n-1,k)*comb(n+1,j)*comb(M,s) * (1-q)**(M-s)
    return tot
def lnfr(x):  # natural log of a positive Fraction
    a, b = x.numerator, x.denominator
    sh = a.bit_length() - b.bit_length()
    return log(a / b * 1.0) if abs(sh) < 900 else log((a >> max(0, a.bit_length()-60)) / (b >> max(0, b.bit_length()-60))) + (max(0,a.bit_length()-60)-max(0,b.bit_length()-60))*log(2)
for n in range(2, 9):
    M = 2*n*n*2**n
    f = F(n, M)
    print(n, M, "lnF=%.4f" % lnfr(f), "F<1:", f < 1)
