"""Local relaxation at a tight pair P={a,b}, a->b, |D(P)|=11, head b with e_b=0, in an S_4 tournament on N=50 vertices
with min in-degree >= 24.  Variables x[S,t] >= 0 (continuous) = number of outside y with Q_y = R n N^-(y) = S, type t
(t0: y->a, b->y; t1: a->y, y->b; t2: a->y, b->y).  z_r binary: z_r = 0 forces e_r = 0 i.e. deg_O(r) = 18.
Objective: minimise kappa = sum z_r  (kappa = number of dominators of P with positive excess)  or E_R.
All constraints are necessary conditions (see notes.md Step 3)."""
import sys, itertools, time
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix, csr_matrix
sys.path.insert(0, '/home/claude/f4/pkg/lower_bound')
from tour_util import parse_upper
def popc(x): return bin(x).count('1')
N = 50; O = N - 13; DEGMAX = N - 32      # deg_O(r) <= 18  <=> e_r >= 0
KMAX = 8

def model(A, headZ=True, bigcut=True):
    n = 11; Rng = range(n)
    inR = [sum(1 << i for i in Rng if A[i][j]) for j in Rng]
    outR = [sum(1 << j for j in Rng if A[i][j]) for i in Rng]
    assert all(popc(m) == 5 for m in inR)
    adm = [S for S in range(1 << n) if popc(S) >= 5 and all(S & inR[z] for z in Rng)]
    nS = len(adm); nx = 3 * nS; nv = nx + 11
    X = lambda i, t: 3 * i + t; Zr = lambda r: nx + r
    rows, lo, hi = [], [], []
    def add(co, l, h): rows.append(co); lo.append(l); hi.append(h)
    def cR(Um): return sum(1 for y in Rng if not (Um >> y) & 1 and (outR[y] & Um) == Um)
    add({X(i, t): 1 for i in range(nS) for t in range(3)}, O, O)
    nu = {2: 11, 3: 5, 4: 1}
    for k in (2, 3, 4):                       # subsets U of R: dominators in R or outside y with S n U = 0
        for U in itertools.combinations(Rng, k):
            Um = sum(1 << i for i in U); need = nu[k] - cR(Um)
            if need > 0: add({X(i, t): 1 for i, S in enumerate(adm) if not (S & Um) for t in range(3)}, need, np.inf)
    for t in (0, 1):                          # U+{a} (t=0) and U+{b} (t=1)
        for k, need0 in ((3, 1), (2, 5), (1, 11)):
            for U in itertools.combinations(Rng, k):
                Um = sum(1 << i for i in U); need = need0 - cR(Um)
                if need > 0: add({X(i, t): 1 for i, S in enumerate(adm) if not (S & Um)}, need, np.inf)
    for r in Rng:                             # 18(1-z_r) <= deg_O(r) <= 18
        co = {X(i, t): 1 for i, S in enumerate(adm) if (S >> r) & 1 for t in range(3)}
        add(co, -np.inf, DEGMAX)
        co2 = dict(co); co2[Zr(r)] = DEGMAX; add(co2, DEGMAX, np.inf)
    nA = {X(i, 0): 1 for i in range(nS)}; nB = {X(i, 1): 1 for i in range(nS)}
    add(nA, 13, np.inf)                       # d^-(a) = 11 + nA >= 24
    if headZ: add(nB, 12, 12)                 # d^-(b) = 12 + nB = 24
    else: add(nB, 12, np.inf)
    # total excess: sum_r e_r + e_a + e_b <= 25, e_r = 18 - deg_O(r), e_a = nA - 13, e_b = nB - 12
    co = {}
    for i, S in enumerate(adm):
        for t in range(3): co[X(i, t)] = -popc(S) + (1 if t < 2 else 0)
    add(co, -np.inf, 25 - 11 * DEGMAX + 25)
    if bigcut: add({X(i, t): 1 for i, S in enumerate(adm) if popc(S) >= 6 for t in range(3)}, -np.inf, 2)
    M = lil_matrix((len(rows), nv))
    for r_, co in enumerate(rows):
        for j, v in co.items(): M[r_, j] = v
    return adm, csr_matrix(M), np.array(lo, float), np.array(hi, float), nx, nv

def solve(A, obj='kappa', fixz=None, tl=120, **kw):
    adm, M, l, h, nx, nv = model(A, **kw)
    c = np.zeros(nv); integ = np.zeros(nv)
    lb = np.zeros(nv); ub = np.full(nv, float(O)); ub[nx:] = 1
    if obj == 'kappa':
        c[nx:] = 1; integ[nx:] = 1
    else:   # minimise E_R = 11*18 - sum |S| x  (z relaxed to 1)
        for i, S in enumerate(adm):
            for t in range(3): c[3 * i + t] = -popc(S)
        lb[nx:] = 1
    if obj == 'k8':      # feasibility of kappa <= KMAX (z binary)
        integ[nx:] = 1
        row = np.zeros((1, nv)); row[0, nx:] = 1
        from scipy.sparse import vstack
        M = vstack([M, csr_matrix(row)]); l = np.append(l, -np.inf); h = np.append(h, KMAX)
    if fixz is not None:
        for r in range(11):
            if r in fixz: ub[nx + r] = 0
    res = milp(c=c, constraints=LinearConstraint(M, l, h), bounds=Bounds(lb, ub), integrality=integ,
               options={'time_limit': tl})
    if res.x is None: return res.status, None
    val = res.fun + (11 * DEGMAX if obj == 'ER' else 0)
    if obj == 'k8': val = int(round(sum(res.x[nx:])))
    return res.status, round(val, 4)

if __name__ == "__main__":
    lo_, hi_ = int(sys.argv[1]), int(sys.argv[2]); obj = sys.argv[3] if len(sys.argv) > 3 else 'kappa'
    lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
    for cl in range(lo_, min(hi_, len(lines))):
        t0 = time.time()
        st, val = solve(parse_upper(lines[cl], 11), obj)
        print(cl, st, val, round(time.time() - t0, 1), flush=True)
