"""Type-free relaxation of runJ.py/tightJ51.py (drops the U+{a}, U+{b} constraints and nA, nB): full-integer MILP,
feasibility of sum_r j_r <= JMAX at a tight pair (N=51, 38 outside vertices, dominators d^- = 25 + j_r).
Valid for both modes (in/out).  Usage: python3 runJnt.py JMAX lo hi tl"""
import sys, itertools, time
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix, csr_matrix
sys.path.insert(0, '/home/claude/f4/pkg/lower_bound')
from tour_util import parse_upper
def popc(x): return bin(x).count('1')
O = 38
def build(A, JMAX):
    n = 11; Rng = range(n)
    inR = [sum(1 << i for i in Rng if A[i][j]) for j in Rng]
    outR = [sum(1 << j for j in Rng if A[i][j]) for i in Rng]
    adm = [S for S in range(1 << n) if popc(S) >= 5 and all(S & inR[z] for z in Rng)]
    nS = len(adm); nv = nS + 11; J = lambda r: nS + r
    rows = []
    def cR(Um): return sum(1 for y in Rng if not (Um >> y) & 1 and (outR[y] & Um) == Um)
    rows.append(({i: 1 for i in range(nS)}, O, O))
    nu = {2: 11, 3: 5, 4: 1}
    for k in (2, 3, 4):
        for U in itertools.combinations(Rng, k):
            Um = sum(1 << i for i in U); need = nu[k] - cR(Um)
            if need > 0: rows.append(({i: 1 for i, S in enumerate(adm) if not (S & Um)}, need, np.inf))
    for r in Rng:
        co = {i: 1 for i, S in enumerate(adm) if (S >> r) & 1}; co[J(r)] = 1; rows.append((co, 18, 18))
        co = {i: 1 for i, S in enumerate(adm) if not (S >> r) & 1 and 7 <= popc(S) <= 10}; co[J(r)] = -2
        rows.append((co, -np.inf, 0))
        co = {i: 1 for i, S in enumerate(adm) if not (S >> r) & 1 and popc(S) == 6}; co[J(r)] = -2.5
        rows.append((co, -np.inf, 1))
    rows.append(({J(r): 1 for r in Rng}, 0, JMAX))
    rows.append(({i: 1 for i, S in enumerate(adm) if popc(S) >= 6}, 0, 4))
    M = lil_matrix((len(rows), nv))
    for r_, (co, l, h) in enumerate(rows):
        for j, v in co.items(): M[r_, j] = v
    l = np.array([r[1] for r in rows], float); h = np.array([r[2] for r in rows], float)
    ub = np.full(nv, float(O)); ub[nS:] = JMAX
    return csr_matrix(M), l, h, ub, nv
if __name__ == "__main__":
    jm, lo, hi, tl = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), float(sys.argv[4])
    lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
    for cl in range(lo, min(hi, len(lines))):
        t0 = time.time(); M, l, h, ub, nv = build(parse_upper(lines[cl], 11), jm)
        res = milp(c=np.zeros(nv), constraints=LinearConstraint(M, l, h), bounds=Bounds(0, ub),
                   integrality=np.ones(nv), options={'time_limit': tl})
        print(cl, jm, res.status, round(time.time() - t0, 1), flush=True)
