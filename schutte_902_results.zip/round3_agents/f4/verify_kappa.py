"""Independent verifier for the local theorem used at N=50 (written separately from kappa.py).

Claim (per 5-regular S_2 11-tournament T[R]): in the relaxed local system at a tight pair P={a,b}, a->b,
|D(P)|=11, e_b=0, N=50, forcing e_r0 = 0 (deg_O(r0) >= 18) for a single r0 in R is infeasible, for at least 9 r0.
For each (class, r0) we look for a Farkas certificate y >= 0 (rows written as  row.x >= rhs) with
      y.rhs - 37 * sum_j max(0, (y^T A)_j)  > 0,
which proves infeasibility because every feasible x satisfies 0 <= x_j <= 37 (sum x = 37).
The LP solver (HiGHS) is only used to *find* y; the check is done in exact rational arithmetic.
Usage: python3 verify_kappa.py lo hi   -> prints, per class, the list of r0 with a verified certificate."""
import sys, itertools
from fractions import Fraction
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

def parse(line):                      # upper-triangle bit string, '1' at (i,j) means i -> j
    n = 11; beats = [[False] * n for _ in range(n)]; k = 0
    for i in range(n):
        for j in range(i + 1, n):
            if line[k] == '1': beats[i][j] = True
            else: beats[j][i] = True
            k += 1
    return beats

def system(beats, r0):
    n = 11; V = list(range(n))
    inn = [frozenset(i for i in V if beats[i][j]) for j in V]
    assert all(len(s) == 5 for s in inn)
    adm = []
    for size in range(5, 12):
        for S in itertools.combinations(V, size):
            S = frozenset(S)
            if all(S & inn[z] for z in V): adm.append(S)
    cols = [(S, t) for S in adm for t in range(3)]
    def dom_in_R(U):                 # vertices of R outside U beating every vertex of U
        return sum(1 for y in V if y not in U and all(beats[y][u] for u in U))
    rows = []                        # (dict col->coef, rhs) meaning sum coef*x >= rhs
    allc = {j: 1 for j in range(len(cols))}
    rows.append((allc, 37)); rows.append(({j: -1 for j in allc}, -37))
    nu = {2: 11, 3: 5, 4: 1}
    for k in (2, 3, 4):
        for U in itertools.combinations(V, k):
            need = nu[k] - dom_in_R(U)
            if need > 0:
                rows.append(({j: 1 for j, (S, t) in enumerate(cols) if not (S & set(U))}, need))
    for tt in (0, 1):
        for k, nd in ((1, 11), (2, 5), (3, 1)):
            for U in itertools.combinations(V, k):
                need = nd - dom_in_R(U)
                if need > 0:
                    rows.append(({j: 1 for j, (S, t) in enumerate(cols) if t == tt and not (S & set(U))}, need))
    for r in V:
        rows.append(({j: -1 for j, (S, t) in enumerate(cols) if r in S}, -18))
    rows.append(({j: 1 for j, (S, t) in enumerate(cols) if r0 in S}, 18))
    rows.append(({j: 1 for j, (S, t) in enumerate(cols) if t == 0}, 13))
    rows.append(({j: 1 for j, (S, t) in enumerate(cols) if t == 1}, 12))
    rows.append(({j: -1 for j, (S, t) in enumerate(cols) if t == 1}, -12))
    rows.append(({j: len(S) - (1 if t < 2 else 0) for j, (S, t) in enumerate(cols)}, 148))
    rows.append(({j: -1 for j, (S, t) in enumerate(cols) if len(S) >= 6}, -2))
    return cols, rows

def certificate(cols, rows):
    m = len(rows); nc = len(cols)
    # dual search LP: variables y (m) in [0,1], t (nc) >= 0 ; maximise y.b - 37 sum t ; s.t. (A^T y)_j - t_j <= 0
    I, J, Vv = [], [], []
    for i, (co, b) in enumerate(rows):
        for j, a in co.items(): I.append(j); J.append(i); Vv.append(a)
    for j in range(nc): I.append(j); J.append(m + j); Vv.append(-1)
    Aub = coo_matrix((Vv, (I, J)), shape=(nc, m + nc)).tocsr()
    c = np.concatenate([-np.array([b for _, b in rows], float), 37 * np.ones(nc)])
    res = linprog(c, A_ub=Aub, b_ub=np.zeros(nc), bounds=[(0, 1)] * m + [(0, None)] * nc, method='highs')
    if res.status != 0 or -res.fun <= 1e-7: return None
    y = [Fraction(v).limit_denominator(10 ** 6) if v > 1e-12 else Fraction(0) for v in res.x[:m]]
    # exact check
    lhs = sum(y[i] * b for i, (_, b) in enumerate(rows))
    colsum = [Fraction(0)] * nc
    for i, (co, b) in enumerate(rows):
        if y[i]:
            for j, a in co.items(): colsum[j] += y[i] * a
    pen = 37 * sum(v for v in colsum if v > 0)
    val = lhs - pen
    return val if val > 0 else None

if __name__ == "__main__":
    lo, hi = int(sys.argv[1]), int(sys.argv[2])
    lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
    for cl in range(lo, min(hi, len(lines))):
        beats = parse(lines[cl]); ok = []
        for r0 in range(11):
            cols, rows = system(beats, r0)
            v = certificate(cols, rows)
            if v is not None: ok.append(r0)
        print(cl, len(ok), 'PASS' if len(ok) >= 9 else 'FAIL', ok, flush=True)
