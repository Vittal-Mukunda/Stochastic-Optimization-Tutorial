"""Min-in-degree theorem with Lemma T: if d^-(v)=23 then every a in A=N^-(v) has d^-(a)>=25 (Lemma T), so the excess
budget sum_b (|A_b|-11) <= 12N-610 (instead of 12N-564), with |B| = N-24 vertices b.  Source-less undominated 4-sets of
A (1045 for D2, 1012 for QR23) must be covered by complements of A_b with |A_b|=11+e, e>=1, each covering <= best[e]
(table from lower_bound/local48b_out.txt).  Knapsack: max sum best[e_b] s.t. sum e_b <= budget, #b <= N-24."""
best = {'D2': (1045, [0, 20, 24, 25, 17, 10, 9, 3, 1, 0, 0, 0, 0]),
        'QR23': (1012, [0, 0, 25, 21, 14, 9, 5, 3, 1, 0, 0, 0, 0])}
for N in range(48, 72):
    budget = 12 * N - 610; nb = N - 24; out = []
    for name, (need, b) in best.items():
        if budget < 0: out.append(f'{name}: budget<0'); continue
        # dp[k][w] = max coverage with k items and total weight w
        NEG = -10**9; dp = [[NEG] * (budget + 1) for _ in range(nb + 1)]; dp[0][0] = 0
        for k in range(nb):
            for w in range(budget + 1):
                if dp[k][w] == NEG: continue
                for e in range(1, 13):
                    if w + e <= budget: dp[k + 1][w + e] = max(dp[k + 1][w + e], dp[k][w] + b[e])
        mx = max(max(r) for r in dp)
        out.append(f'{name}: max cover {mx} vs {need} -> {"OK" if mx < need else "FAIL"}')
    print(N, 'budget', budget, '|', ' ; '.join(out))
