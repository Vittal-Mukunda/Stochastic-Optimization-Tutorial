"""Regular case N=51 (all in-degrees 25): LP/MILP relaxation of the local configuration at a tight pair
P={a,b}, a->b, |D(P)|=11, R=D(P).  Outside O (38 vertices): x[S,t] = #y with Q_y = R n N^-(y) = S, type t
(t0: y->a,b->y ; t1: a->y,y->b ; t2: a->y,b->y).  Regular => deg_O(r)=18 for all r in R, nA=14, nB=13, nC=11.
Derived (hand, notes Step 7): exactly one y with Q_y = R, exactly two with |Q_y| = 6, all other |Q_y| = 5.
Usage: python3 tight51.py lo hi [mode]   mode: 'lp' (continuous) or 'mip' (integer x)."""
import sys, itertools, time
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix, csr_matrix
sys.path.insert(0, '/home/claude/f4/pkg/lower_bound')
from tour_util import parse_upper
def popc(x): return bin(x).count('1')
O = 38

def build(A, structure=True):
    n = 11; Rng = range(n); full = (1 << n) - 1
    inR = [sum(1 << i for i in Rng if A[i][j]) for j in Rng]
    outR = [sum(1 << j for j in Rng if A[i][j]) for i in Rng]
    adm = [S for S in range(1 << n) if popc(S) >= 5 and all(S & inR[z] for z in Rng)]
    if structure: adm = [S for S in adm if popc(S) in (5, 6, 11)]
    nS = len(adm); nv = 3 * nS
    X = lambda i, t: 3 * i + t
    rows, lo, hi = [], [], []
    def add(co, l, h): rows.append(co); lo.append(l); hi.append(h)
    def cR(Um): return sum(1 for y in Rng if not (Um >> y) & 1 and (outR[y] & Um) == Um)
    add({X(i, t): 1 for i in range(nS) for t in range(3)}, O, O)
    nu = {2: 11, 3: 5, 4: 1}
    for k in (2, 3, 4):
        for U in itertools.combinations(Rng, k):
            Um = sum(1 << i for i in U); need = nu[k] - cR(Um)
            if need > 0: add({X(i, t): 1 for i, S in enumerate(adm) if not (S & Um) for t in range(3)}, need, np.inf)
    for t in (0, 1):
        for k, need0 in ((3, 1), (2, 5), (1, 11)):
            for U in itertools.combinations(Rng, k):
                Um = sum(1 << i for i in U); need = need0 - cR(Um)
                if need > 0: add({X(i, t): 1 for i, S in enumerate(adm) if not (S & Um)}, need, np.inf)
    for r in Rng:   # deg_O(r) = d^+(r) - 7 = 18
        add({X(i, t): 1 for i, S in enumerate(adm) if (S >> r) & 1 for t in range(3)}, 18, 18)
    add({X(i, 0): 1 for i in range(nS)}, 14, 14)
    add({X(i, 1): 1 for i in range(nS)}, 13, 13)
    if structure:
        add({X(i, t): 1 for i, S in enumerate(adm) if S == full for t in range(3)}, 1, 1)
        add({X(i, t): 1 for i, S in enumerate(adm) if popc(S) == 6 for t in range(3)}, 2, 2)
    M = lil_matrix((len(rows), nv))
    for r_, co in enumerate(rows):
        for j, v in co.items(): M[r_, j] = v
    return adm, csr_matrix(M), np.array(lo, float), np.array(hi, float), nv

def solve(A, mode='lp', tl=60, structure=True):
    adm, M, l, h, nv = build(A, structure)
    res = milp(c=np.zeros(nv), constraints=LinearConstraint(M, l, h), bounds=Bounds(0, O),
               integrality=np.ones(nv) if mode == 'mip' else np.zeros(nv), options={'time_limit': tl})
    return res.status

if __name__ == "__main__":
    lo_, hi_ = int(sys.argv[1]), int(sys.argv[2]); mode = sys.argv[3] if len(sys.argv) > 3 else 'lp'
    structure = not (len(sys.argv) > 4 and sys.argv[4] == 'nostruct')
    lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
    for cl in range(lo_, min(hi_, len(lines))):
        t0 = time.time(); st = solve(parse_upper(lines[cl], 11), mode, structure=structure)
        print(cl, st, round(time.time() - t0, 1), flush=True)
