# f4 agent notes (round 4: N=50,51)
Sat Oct 17 05:51:10 Asia 2026

## Step 0 (setup, 06:00): read ROUND3_FINDINGS §1, RESULTS §3, crosslevel notes + n4/*.py (local CP-SAT/MILP model at a tight pair; no results recorded).
Basic N=50 facts derived (d^-(v)=24+e_v, sum e=25, d^+(v)=25-e_v):
- tight pair P={a,v}, a->v, R=D(P): T[R] 5-regular; outside O (37): types t0 (y->a only) n_A=13+e_a, t1 (y->v only) n_B=12+e_v,
  t2 (neither) n_C=12-e_a-e_v (so e_a+e_v<=12). sum_O p_y = 209+E_R, p_y=|N^+(y)nR|<=6, need sum_O C(p_y,3)>=715 => E_R>=7.
- k=2,4 counts and the a-/v- side counts at a tight pair are slack (not binding).
- For v in Z (e_v=0): A_v=T[N^-(v)], in-deg 11+f_r, sum f=12, L_v={f=0}, |L_v|>=12; |N^+(r) n N^+(v)| = 12+f_r-e_r;
  for b in N^+(v): |D(v,b)| = 23+e_b-d^-_{B_v}(b), sum_b(|D(v,b)|-11) = E^+(v) = 25-E^-(v).
- Averaging obstacle: in 0/1 case (25 vertices e=1), sum_{v in Z}E^-(v)=300 (avg 12) so per-vertex bounds E^-(v)>=c can't
  conclude unless c>=13.

## Step 1 (06:20): structural lemmas at a tight pair (N=50), all derived by hand (re-check before use)
(L1) Loss function: at tight P, sum_{y in O} l(q_y-5) <= 25 with l = 0,10,16,19,20,20,20 => at most 2 outside y have
     q_y>5; total deficit S=13-E_R in {0..6}; patterns {},{1},{2},{1,1},{3},{4},{5},{6}.
(L2) For v with e_v=e and tight in-pair a->v (a in L_v), R=R_a: A_v-side deficit 6+6e-F(R), out-side deficit
     7-6e+F(R)-E(R)  [F(R)=sum_{x in R} f_x, f_x=|D(x,v)|-11].  For v in Z: F(R_a)<=6, E(R_a)<=7+F(R_a).
(L3) Tight out-pair v->b, R=D(v,b): A_v-side deficit 12+6e-F(R), out-side 1-6e+F(R)-E(R). For v in Z: F(R)>=6.
(L4) Linear algebra at v in Z: the 49 sets D(v,z) in {0,1}^24, Gram = 5J + diag(6+h) + Eps (Eps>=0 offdiag),
     rank<=24 => #non-tight z + #twin pairs (D(v,z)=D(v,z')) >= 25; #non-tight <= 37-E^-(v) => twins >= E^-(v)-12.
(L5) E^-(v)=7 impossible for v in Z in 0/1 case (X_v would have to beat all of L_v).
- CP-SAT on full tight-pair model (prev agent's formulation, tight_pair.py): UNKNOWN after 60s on classes 0-2.

## Step 2 (06:45): core LP over all 551 T[R] classes (lp_core.py, lp_core_N50.out)
LP (no types/intersecting/integrality) min E_R: 21 classes infeasible; ceil(LP) = 8 (1 class: #0), 10 (16), 11 (180), 12 (243), 13 (90).
KEY GLOBAL ARGUMENT (found, needs only a local bound):
 Let X = {e>=1}, m=|X|<=25, Z = rest. For v in Z, X_v = N^-(v) n X, p=|X_v|. Suppose every tight pair a->v (v in Z) has
 kappa := |D(a,v) n X| >= c'. L=L_v (|L|>=12) splits L_Z (e=0), L_X. For a in L_Z: in-deg in T[L_Z] <= 11-c' => |L_Z|<=23-2c'.
 For a in L_X: in-deg in T[X_v] >= c' => c'|L_X| <= C(|L_X|,2)+|L_X|(p-|L_X|) => |L_X| <= 2p-2c'-1.  So 12<=|L| => p >= 2c'-5.
 Global: sum_{v in Z} p_v = #arcs X->Z = 25m-25-C(m,2).  With c'=9: 13(50-m) > 25m-25-C(m,2) for all m<=25 (equiv m^2/2-38.5m+675>0, roots 27,50).
 => CONTRADICTION at N=50 provided kappa>=9 for every tight pair with zero-excess head.  (c'=8 fails for m in [23,25].)
 TODO: local MILP: min kappa = #{r in R: deg_O(r)<=17} per class (z_r binary, x continuous is a valid relaxation).

## Step 3 (07:00): kappa.py (scipy/HiGHS) local model with types, head e_v=0 (n_B=12), big-set cut (<=2 sets |Q|>=6)
- class 0: INFEASIBLE once head has e=0 (core LP gave 7.94 without types). class 1: min kappa = 11 (MILP optimal, 29 s).
- class 2: LP min E_R 11.17 (headZ).  MILP ~30 s/class => need faster route for 530 classes (check Sum z<=8 infeasible,
  or single-vertex LPs: max deg_O(r) < 18 => r always excess).
- All model constraints re-derived and checked (see kappa.py docstring).  Global argument needs kappa>=9 only for
  tight pairs with zero-excess head (exactly what kappa.py models).

## Step 4 (07:20) *** HAND LEMMA T + HAND PROOF OF f(4) >= 51 ***
LEMMA T (any S_4 tournament, any N): if |D(P)|=11 then every r in D(P) has d^-(r) >= 25.
 Proof: R=D(P) 5-regular (F1 + sum 55). y outside P u R beats <= 6 of R (|D(P+y)|>=5). The 45 triples U of R through r
 need >=225 dominator incidences; a dominator w of U beats r so w in N^-(r), w not in P. w in N^-_R(r) (5 of them):
 <= C(4,2)=6 triples; w outside (d^-(r)-5 of them): <= C(5,2)=10.  30+10(d^-(r)-5) >= 225 => d^-(r) >= 24.5.  QED
(Found because kappa.py showed kappa=11 (KMAX=10 infeasible) for classes 1,2; the 551-class k8 run agrees so far.)
COR 1 (min in-degree >= 24 for N <= 50, BY HAND): if d^-(v)=23, A=T[N^-(v)] is a DRT (RESULTS Lemma 1, hand), every
 {a,v} (a in A) is tight with D = N^-_A(a); union = A, so every a in A has d^-(a) >= 25. Then
 11(N-24) <= sum_{b in B}|D(v,b)| = sum_{a in A}|N^+(a) n B| <= 23(N-38)  =>  N >= 610/12 > 50.8.
COR 2 (N=49 by hand): regular 24 => no tight pair (dominators would have in-degree 25) => all pairs >=12 => d^- >= 25. Contra.
THM (N=50 impossible, BY HAND given Cor 1): X={e>=1}, m=|X|<=25, Z nonempty. v in Z: |L_v|>=12, and for a in L_v,
 D(a,v) subset of X (Lemma T). a in L_v n Z has no in-neighbour in L_v n Z => |L_v n Z| <= 1. So >= 11 vertices of
 L_v n X each have >= 11 in-neighbours in X_v = N^-(v) n X; 11*11 <= C(11,2) + 11(p-11) => p=|X_v| >= 17.
 sum_{v in Z} |X_v| = #arcs X->Z = 25m-25-C(m,2) <= 300 (m<=25) < 17*25 <= 17(50-m).  CONTRADICTION.  => f(4) >= 51.

## Step 5 (07:35) sharper structure at a zero-excess vertex (hand) -> N=50 one-liner, N=51 reduced to z<=5
CLAIM Q: if d^-(v)=24 (and min in-degree>=24, Lemma T applies), then |N^-(v) n Z| <= 2, Z={d^-=24}.
 Proof: L=L_v (|L|=l>=12), each a in L has all A_v-in-nbrs in X (Lemma T) => a beats all of Z_v\{a} => |L n Z|<=1.
 Q := Z_v \ L (subset of K_v={f>=1}); each z' in Q is beaten by all of L => f_{z'} >= l-11+d^-_Q(z').
 12 = sum_K f >= q(l-11)+C(q,2)+(24-l-q)  =>  (q-1)(l-12)+C(q,2) <= 0  => q<=1.  So |Z_v|<=2.  QED
 => T[Z] has max in-degree <=2 => |Z| <= 5.
N=50: |Z| >= 25 (sum e = 25)  => contradiction immediately.  (f(4) >= 51, hand proof: Lemma T + Cor 1 + Claim Q.)
N=51: sum e = 51; either regular (all d^-=25) or 1<=|Z|<=5 (then >=46 vertices in X, sum_X (e-1) <= 5).
 Regular/near-regular structure at a tight pair whose 11 dominators all have d^-=25 (N=51): total outside deficit
 S = 6N-23-sum_r d^-(r) = 8; refined Lemma T => each such r has <=1 deficient outside in-nbr and it has q=6;
 so exactly one 'shadow' w with R subset N^-(w) (q_w=11) and two q=6 vertices beating disjoint 5-subsets of R.
 Open: DRT(51)-type case (all pairs 12 dominators) is not touched by these counts.

## Step 6 (07:55) cross-checks + min-in-degree theorem extended
- k8_all.out: all 551 classes INFEASIBLE for kappa<=8 (HiGHS MILP) -- consistent with Lemma T (kappa=11 always).
- check_lemmaT.py: randomised test of the counting inequality behind Lemma T, 3300 cases, max(LHS-RHS)=0 (<=0 OK, tight).
- budget_lemmaT.py: with Lemma T the in-degree-23 budget is 12N-610 (was 12N-564); knapsack over the per-excess
  coverage table of local48b_out.txt => no vertex of in-degree 23 in any S_4 tournament with N <= 64 (D2 and QR23 both
  OK up to 64; QR23 fails at 65).  For N <= 50 this needs NO computer (budget < 0).

## Step 7 (08:05) N=51 regular case: rigid structure at a tight pair, LP test
Regular N=51 (all d^-=25), tight P=(a->b), R=D(P): deg_O(r)=18 all r, nA=14, nB=13, nC=11; total deficit 8;
refined Lemma T => no outside y with 7<=q_y<=10, q=6 vertices beat disjoint 5-sets => exactly ONE y with Q_y=R
(shadow), TWO with |Q_y|=6, 35 with |Q_y|=5.  Also: excess triples of R are exactly {r*} u pi_i (5 pairs), eps=1.
tight51.py (LP, with this structure): classes 1..11 infeasible, class 0 LP-feasible; full run -> t51_lp.out.

## CLEAN PROOF: f(4) >= 51 (entirely by hand)   [written 08:15]
Facts (Szekeres): F1 |D(triple)|>=5; F2 |D(pair)|>=11 (T[D(P)] min in-deg >=5); F3 d^-(v)>=23.
Lemma T. |D(P)|=11 => every r in D(P) has d^-(r) >= 25.   (proof in Step 4)
Lemma 1 (RESULTS.md, hand). d^-(v)=23 => T[N^-(v)] regular (in-degree 11) [and doubly regular].
Cor 1. N<=50 => no vertex of in-degree 23.  (Step 4: 11(N-24) <= 23(N-38) needs N>=51.)
Claim Q. If min in-degree >= 24 and d^-(v)=24 then v has at most 2 in-neighbours of in-degree 24.  (Step 5)
Theorem. No S_4 tournament on 50 vertices.  Min in-degree >= 24 (F3 + Cor 1); sum (d^- - 24) = 1225-1200 = 25, so
 |Z| >= 25 where Z = {d^-=24}; by Claim Q, T[Z] has all in-degrees <= 2, so C(|Z|,2) <= 2|Z|, |Z| <= 5. Contradiction.
Also N=49 (Cor 2) and N<=48 (F3: N>=47; N=47,48 => some d^-<=23... ) -- for N<=48: min in-degree >=24 (Cor 1) forces
 N >= 49.  Hence f(4) >= 51.

## Step 8 (08:30) regular N=51: t51_lp.out complete: 550/551 classes LP-INFEASIBLE (HiGHS); class 0 LP-feasible but
 MIP (integer x, tight51.py mode mip) INFEASIBLE in 69 s.  => (pending independent verification) a regular S_4
 tournament on 51 vertices has no tight pair, hence every pair has exactly 12 dominators: it is a DRT(51).
 Disjointness cut (tight51b.py) does not make class 0 LP-infeasible.
 Next: tightZ51.py (case 1<=|Z|<=5) over all classes.

## Step 9 (resumed after cut-off): coordinator checked hand proof of f(4)>=51 (now ROUND3_FINDINGS 0). Tasks: settle N=51 (|Z| in 1..5, and regular/DRT(51)); budget_lemmaT re-checked by coordinator (skip); write FINAL.md.
- (Step 9) restarted verify_reg51.py (exact Farkas certificates, independent builder) for the regular-case LP -> vreg51_a/b.out.
- DRT(51) thoughts: 4-set dominator counts in ANY DRT(51) have mean 2.58, variance 0.97 (2nd moment determined by DRT);
  triples: mean 5.63, var 0.84; delta = 6 + c/8 (cyclic), 5.5 + c/8 (transitive), c = sum_w S_wx S_wy S_wz, E[c^2]=50.9.
  No contradiction from 2nd moments.  DRT(51) looks out of reach (no classification of skew-Hadamard 52).
- Case (I) plan: MILP with integer j_r = d^-(r)-25 (sum <= z <= 5), x continuous, deg_O(r) = 18 - j_r, head in Z
  (nB=12), valid integer cuts: #{y->r: 7<=q_y<=10} <= 2 j_r, #{y->r: q_y=6} <= 1 + 3 j_r.  If infeasible for all
  classes => no tight pair with zero-excess head => case (I) impossible.
- (Step 10) verify_reg51.py done: 550/551 classes have EXACT Farkas certificates (independent builder, integer check)
  for infeasibility of the regular-N=51 tight-pair LP; class 0: no certificate (LP feasible); HiGHS MIP infeasible (69 s);
  CP-SAT integer re-check of class 0 running (cpsat_reg51.py).
- tightJ51.py (case I, head in Z, integer j_r, big-set x integer, 5-set x continuous): FEASIBLE for classes 1-5 with
  sum j = 3-4 (several dominators of in-degree 26).  So case (I) is not killed by a single tight pair; needs global work.
- (Step 11) SPECTRAL LEMMA for case (I) (hand): v in Z, D_z = D(v,z) subset N^-(v) (24-dim), Gram G=X^T X = 5J + M,
  M = diag(6+h) + E (E_zz' = |D(v,z,z')|-5 >= 0).  rank<=24 => M has >= 26 eigenvalues <= 0.  n_t = #non-tight z
  <= sum h = 626 - sum_{x in N^-(v)} d^-(x) <= 28 - W^-(v)  (Claim Q; W^-(v) = sum_{x in N^-(v)} (d^-(x)-25)^+).
  For tight z: row sum of E = S_z = 8 - J_z (J_z = sum_{r in D_z}(d^-(r)-25)).  B := {tight z: J_z <= 2};
  M on T\B strictly diag. dominant => PD; interlacing => 26 <= n_t + |B| => |B| >= W^-(v) - 2.
  => If every tight pair at a Z-vertex has J >= 3, then W^-(v) <= 2 < 3 <= J_a <= W^-(v) (a in L_v): CONTRADICTION.
  So case (I) reduces to the LOCAL claim J >= 3 (in-pairs with head in Z, out-pairs with tail in Z).
  Full-integer MILP (runJ.py, HiGHS): J<=2 infeasible for classes 0,1 so far (J2in.out). Relaxed x: J=2 feasible.
- DRT(51) at a vertex: spectrum of E forced {31, 6^24, (-7)^25} (X X^T = 13I+11J) -- 2nd-order tools give nothing.
- (Step 12) unit_identities.py: random planted tight pairs (N=51): all modelling identities (|D(U)|, |D(U+a)|, |D(U+b)|,
  deg_O, nA, nB, |Q_y|) hold: 101820 checks, 0 failures.
- runJ.py in-mode J<=2 (full integer, HiGHS): classes 0,1,3,4,5,6,7 infeasible; class 2 undecided at 120 s.
  ~40 s/class => too slow for all 551 x 2 modes in this session.
- (Step 13) FINAL.md written (draft; update after class-0 CP-SAT and J>=3 runs).
- (Step 14) CASE (R) FULLY CERTIFIED: CP-SAT on class 0 returned UNKNOWN (800 s), but class0_split.py splits class 0 on
  r* (valid: the two q=6 vertices beat disjoint 5-sets, so exactly one r* is beaten by neither and every other r by
  exactly one) and ALL 11 sub-LPs have EXACT Farkas certificates (class0_split.out).  Together with the 550 direct
  certificates: in a regular S_4 tournament on 51 vertices no pair is tight => it is a DRT(51).  [computer, exact certs]
- (Step 15) portfolio_J.py (J<=2 at N=51 tight pairs; type-free MILP 8 s, then typed in/out 45 s each) running in chunks
  (portJ_*.out).  First results: classes 2,4,5 type-free infeasible (<2 s); class 3 in+out infeasible; classes 0,1:
  in infeasible, out undecided at 45 s.  ~30 s/class => hours; out-mode is the hard one.
- Hand: z=1 impossible in case (I) if J>=1 for in-pairs at Z-heads (single heavy h would have to beat all of L_v,
  forcing h in L_v, whose own tight pair then needs a second heavy vertex).

- (Step 16) portfolio J<=2 so far (portJ_all.out): 35 classes; type-free infeasible 25; typed in+out infeasible 1; with an undecided mode 9 (time limits 8 s / 45 s).
