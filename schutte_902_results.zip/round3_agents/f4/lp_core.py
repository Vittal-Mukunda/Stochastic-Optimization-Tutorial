"""LP / MILP relaxation of the core of the tight-pair configuration (N=50 unless given):
x_S >= 0 for admissible S (|S|>=5, meets every N^-_R(z)), sum x_S = N-13,
triple/pair/4-set cover constraints inside R, deg_O(r) <= N-32.
Reports min E_R (= sum_r (N-32-deg_O(r))) over the LP (and optionally MILP without intersecting constraint)."""
import sys, itertools, time
import numpy as np
from scipy.optimize import linprog, milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix, csr_matrix
sys.path.insert(0, '/home/claude/f4/pkg/lower_bound')
from tour_util import parse_upper
def popc(x): return bin(x).count('1')

def core(A, N, maxsize=11):
    n = 11; Rng = range(n)
    inR = [sum(1 << i for i in Rng if A[i][j]) for j in Rng]
    outR = [sum(1 << j for j in Rng if A[i][j]) for i in Rng]
    adm = [S for S in range(1 << n) if 5 <= popc(S) <= maxsize and all(S & inR[z] for z in Rng)]
    def cR(Um): return sum(1 for y in Rng if not (Um >> y) & 1 and (outR[y] & Um) == Um)
    rows, lo, hi = [], [], []
    nu = {2: 11, 3: 5, 4: 1}
    for k in (2, 3, 4):
        for U in itertools.combinations(Rng, k):
            Um = sum(1 << i for i in U)
            rows.append([i for i, S in enumerate(adm) if not (S & Um)]); lo.append(nu[k] - cR(Um)); hi.append(np.inf)
    for r in Rng:
        rows.append([i for i, S in enumerate(adm) if (S >> r) & 1]); lo.append(-np.inf); hi.append(N - 32)
    rows.append(list(range(len(adm)))); lo.append(N - 13); hi.append(N - 13)
    M = lil_matrix((len(rows), len(adm)))
    for r, co in enumerate(rows):
        for j in co: M[r, j] = 1
    # objective: E_R = 11(N-32) - sum_S |S| x_S  -> minimise  -sum |S| x_S
    c = -np.array([popc(S) for S in adm], float)
    return adm, csr_matrix(M), np.array(lo, float), np.array(hi, float), c, 11 * (N - 32)

if __name__ == "__main__":
    N = int(sys.argv[1]); lo_, hi_ = int(sys.argv[2]), int(sys.argv[3]); integ = len(sys.argv) > 4 and sys.argv[4] == 'int'
    lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
    hist = {}
    for cl in range(lo_, min(hi_, len(lines))):
        A = parse_upper(lines[cl], 11)
        adm, M, l, h, c, const = core(A, N)
        res = milp(c=c, constraints=LinearConstraint(M, l, h), bounds=Bounds(0, N),
                   integrality=np.ones(len(adm)) if integ else np.zeros(len(adm)), options={'time_limit': 60})
        val = None if res.x is None else round(const + res.fun, 3)
        hist[val] = hist.get(val, 0) + 1
        print(cl, res.status, val, flush=True)
    print('hist minE_R:', sorted(hist.items(), key=lambda t: (t[0] is None, t[0])))
