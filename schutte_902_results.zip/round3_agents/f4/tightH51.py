"""Case N=51, 1<=|Z|<=5 (notes Step 5/9).  Tight pair P={a,b}, a->b, |D(P)|=11, head b in Z (d^-(b)=24).
Dominators: d^-(r) >= 25 (Lemma T); 'heavy' positions W subset R have d^-(r) in [26,30], others exactly 25;
sum_r (d^-(r)-25) <= 5.  deg_O(r) = 43 - d^-(r).  nB = 12, nA in [13,19].
Integrality-derived per-r constraints (refined Lemma T, exact): for r with d^-(r)=25,
  sum_{y in O, y->r} lambda(q_y) <= 5,  lambda(q)=10-C(10-q,2)  =>  no outside in-nbr of r with 7<=q<=10, at most one with q=6.
Usage: python3 tightH51.py lo hi k   (k = number of heavy positions; all subsets W of size k are tried)."""
import sys, itertools, time
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix, csr_matrix
sys.path.insert(0, '/home/claude/f4/pkg/lower_bound')
from tour_util import parse_upper
def popc(x): return bin(x).count('1')
O = 38

def base(A):
    n = 11; Rng = range(n)
    inR = [sum(1 << i for i in Rng if A[i][j]) for j in Rng]
    outR = [sum(1 << j for j in Rng if A[i][j]) for i in Rng]
    adm = [S for S in range(1 << n) if popc(S) >= 5 and all(S & inR[z] for z in Rng)]
    nS = len(adm); X = lambda i, t: 3 * i + t
    rows = []
    def cR(Um): return sum(1 for y in Rng if not (Um >> y) & 1 and (outR[y] & Um) == Um)
    rows.append(({X(i, t): 1 for i in range(nS) for t in range(3)}, O, O))
    nu = {2: 11, 3: 5, 4: 1}
    for k in (2, 3, 4):
        for U in itertools.combinations(Rng, k):
            Um = sum(1 << i for i in U); need = nu[k] - cR(Um)
            if need > 0: rows.append(({X(i, t): 1 for i, S in enumerate(adm) if not (S & Um) for t in range(3)}, need, np.inf))
    for t in (0, 1):
        for k, need0 in ((3, 1), (2, 5), (1, 11)):
            for U in itertools.combinations(Rng, k):
                Um = sum(1 << i for i in U); need = need0 - cR(Um)
                if need > 0: rows.append(({X(i, t): 1 for i, S in enumerate(adm) if not (S & Um)}, need, np.inf))
    rows.append(({X(i, 0): 1 for i in range(nS)}, 13, 19))
    rows.append(({X(i, 1): 1 for i in range(nS)}, 12, 12))
    rows.append(({X(i, t): 1 for i, S in enumerate(adm) if popc(S) >= 6 for t in range(3)}, 0, 4))
    return adm, rows

def with_profile(adm, rows, W):
    nS = len(adm); X = lambda i, t: 3 * i + t; rows = list(rows)
    deg = [{X(i, t): 1 for i, S in enumerate(adm) if (S >> r) & 1 for t in range(3)} for r in range(11)]
    for r in range(11):
        if r in W: rows.append((deg[r], 13, 17))
        else:
            rows.append((deg[r], 18, 18))
            rows.append(({X(i, t): 1 for i, S in enumerate(adm) if not (S >> r) & 1 and 7 <= popc(S) <= 10 for t in range(3)}, 0, 0))
            rows.append(({X(i, t): 1 for i, S in enumerate(adm) if not (S >> r) & 1 and popc(S) == 6 for t in range(3)}, 0, 1))
    tot = {}
    for r in range(11):
        for j, v in deg[r].items(): tot[j] = tot.get(j, 0) + v
    rows.append((tot, 11 * 18 - 5, 11 * 18))
    nv = 3 * nS
    M = lil_matrix((len(rows), nv))
    for r_, (co, l, h) in enumerate(rows):
        for j, v in co.items(): M[r_, j] = v
    l = np.array([r[1] for r in rows], float); h = np.array([r[2] for r in rows], float)
    res = milp(c=np.zeros(nv), constraints=LinearConstraint(csr_matrix(M), l, h), bounds=Bounds(0, O),
               integrality=np.zeros(nv), options={'time_limit': 60})
    return res.status

if __name__ == "__main__":
    lo_, hi_, k = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
    lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
    for cl in range(lo_, min(hi_, len(lines))):
        t0 = time.time(); adm, rows = base(parse_upper(lines[cl], 11)); feas = []
        for W in itertools.combinations(range(11), k):
            if with_profile(adm, rows, set(W)) != 2: feas.append(W)
        print(cl, 'k', k, 'feasible profiles', len(feas), feas[:6], round(time.time() - t0, 1), flush=True)
