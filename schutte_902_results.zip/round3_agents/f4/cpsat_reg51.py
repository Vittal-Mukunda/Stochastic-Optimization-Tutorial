"""Independent check (OR-tools CP-SAT, integer model, own builder) of the regular N=51 tight-pair model
(same constraints as tight51.py / verify_reg51.py, integer x).  Usage: python3 cpsat_reg51.py cl timelimit"""
import sys, itertools
from ortools.sat.python import cp_model

def parse(line):
    n = 11; B = [[False] * n for _ in range(n)]; k = 0
    for i in range(n):
        for j in range(i + 1, n):
            if line[k] == '1': B[i][j] = True
            else: B[j][i] = True
            k += 1
    return B

def run(B, tl):
    V = range(11); inn = [frozenset(i for i in V if B[i][j]) for j in V]
    adm = [frozenset(S) for size in (5, 6, 11) for S in itertools.combinations(V, size)
           if all(frozenset(S) & inn[z] for z in V)]
    m = cp_model.CpModel()
    x = {(S, t): m.NewIntVar(0, 38, '') for S in adm for t in range(3)}
    def domR(U): return sum(1 for y in V if y not in U and all(B[y][u] for u in U))
    m.Add(sum(x.values()) == 38)
    for k, nd in ((2, 11), (3, 5), (4, 1)):
        for U in itertools.combinations(V, k):
            need = nd - domR(U)
            if need > 0: m.Add(sum(v for (S, t), v in x.items() if not (S & set(U))) >= need)
    for tt in (0, 1):
        for k, nd in ((1, 11), (2, 5), (3, 1)):
            for U in itertools.combinations(V, k):
                need = nd - domR(U)
                if need > 0: m.Add(sum(v for (S, t), v in x.items() if t == tt and not (S & set(U))) >= need)
    for r in V: m.Add(sum(v for (S, t), v in x.items() if r in S) == 18)
    m.Add(sum(v for (S, t), v in x.items() if t == 0) == 14)
    m.Add(sum(v for (S, t), v in x.items() if t == 1) == 13)
    m.Add(sum(v for (S, t), v in x.items() if len(S) == 11) == 1)
    m.Add(sum(v for (S, t), v in x.items() if len(S) == 6) == 2)
    s = cp_model.CpSolver(); s.parameters.num_workers = 1; s.parameters.max_time_in_seconds = tl
    st = s.Solve(m)
    return s.StatusName(st), round(s.WallTime(), 1)

if __name__ == "__main__":
    cl, tl = int(sys.argv[1]), float(sys.argv[2])
    lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
    print(cl, *run(parse(lines[cl]), tl), flush=True)
