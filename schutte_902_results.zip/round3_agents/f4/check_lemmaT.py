"""Randomised sanity check of the counting inequality behind Lemma T (not a proof; Lemma T is proved by hand).
Plant P={a,b}, R=D(P) (|R|=11, T[R] a 5-regular class from reg11_S2.txt), outside vertices y beaten by >=5 of R,
random arcs elsewhere.  For r in R check  sum_{U: r in U subset R, |U|=3} |D(U)|  <=  10 d^-(r) - 20."""
import random, itertools, sys
sys.path.insert(0, '/home/claude/f4/pkg/lower_bound')
from tour_util import parse_upper
lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
random.seed(1); worst = -10**9; tests = 0
for trial in range(300):
    N = random.randint(30, 60)
    B = [[False]*N for _ in range(N)]
    for i in range(N):
        for j in range(i+1, N):
            if random.random() < 0.5: B[i][j] = True
            else: B[j][i] = True
    a, b = 0, 1; R = list(range(2, 13)); O = list(range(13, N))
    A = parse_upper(random.choice(lines), 11)
    for i in range(11):
        for j in range(11):
            if i != j: B[R[i]][R[j]] = bool(A[i][j])
    for r in R:                                   # R beats a, b
        for p in (a, b): B[r][p] = True; B[p][r] = False
    for y in O:                                   # y does not beat both a and b; beaten by >= 5 of R
        if B[y][a] and B[y][b]:
            p = random.choice((a, b)); B[y][p] = False; B[p][y] = True
        k = random.randint(5, 11); S = set(random.sample(R, k))
        for r in R:
            B[r][y] = r in S; B[y][r] = r not in S
    D = lambda X: [w for w in range(N) if w not in X and all(B[w][x] for x in X)]
    assert sorted(D([a, b])) == R
    for r in R:
        tot = sum(len(D([r, u, w])) for u, w in itertools.combinations([x for x in R if x != r], 2))
        din = sum(1 for w in range(N) if B[w][r])
        worst = max(worst, tot - (10*din - 20)); tests += 1
print('tests', tests, 'max of LHS - RHS (must be <= 0):', worst)
