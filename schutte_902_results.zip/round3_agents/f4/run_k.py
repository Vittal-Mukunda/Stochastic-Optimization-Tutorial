import sys, time
import kappa
from tour_util import parse_upper
K = int(sys.argv[1]); lo, hi = int(sys.argv[2]), int(sys.argv[3])
kappa.KMAX = K
lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
for cl in range(lo, min(hi, len(lines))):
    t0 = time.time()
    st, val = kappa.solve(parse_upper(lines[cl], 11), 'k8', tl=120)
    print(cl, st, val, round(time.time() - t0, 1), flush=True)
