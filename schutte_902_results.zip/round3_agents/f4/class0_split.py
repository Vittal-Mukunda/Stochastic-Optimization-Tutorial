"""Class 0 of the regular N=51 tight-pair model: split on r* (the vertex of R beaten by neither q=6 vertex).
Valid because the two q=6 vertices beat disjoint 5-subsets of R (notes Step 7), so every r != r* is beaten by exactly
one of them and r* by none:  for r != r*: sum_{|S|=6, r not in S} x_S = 1 ; for r*: = 0.
For each r* builds an exact Farkas certificate with verify_reg51.certify on the independently built system."""
import sys, itertools
sys.path.insert(0, '/home/claude/agents/f4')
import verify_reg51 as V
lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
cl = int(sys.argv[1]) if len(sys.argv) > 1 else 0
B = V.parse(lines[cl])
cols, rows = V.system(B)
res = []
for rs in range(11):
    extra = []
    for r in range(11):
        co = {j: 1 for j, (S, t) in enumerate(cols) if len(S) == 6 and r not in S}
        v = 0 if r == rs else 1
        extra.append((co, v)); extra.append(({j: -c for j, c in co.items()}, -v))
    val = V.certify(cols, rows + extra)
    res.append((rs, val)); print(cl, rs, 'CERT' if val is not None else 'NOCERT', val, flush=True)
print('class', cl, 'all r* certified:', all(v is not None for _, v in res))
