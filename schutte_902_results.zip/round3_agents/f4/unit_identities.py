"""Unit test of the identities used by the local tight-pair models (tight51.py, verify_reg51.py, kappa.py):
for a planted pair P={a,b}, a->b, R=D(P) (|R|=11, T[R] from reg11_S2.txt), random other arcs, N=51:
  |D(U)|       = cR(U) + #{y in O : Q_y n U = 0}
  |D(U+{a})|   = cR(U) + #{y in O, type 0 : Q_y n U = 0}
  |D(U+{b})|   = cR(U) + #{y in O, type 1 : Q_y n U = 0}
  deg_O(r) = d^+(r) - 2 - 5 ;  nA = d^-(a) - 11 ;  nB = d^-(b) - 12 ;  |Q_y| = |D(P+y)|."""
import random, itertools, sys
sys.path.insert(0, '/home/claude/f4/pkg/lower_bound')
from tour_util import parse_upper
lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
random.seed(7); bad = 0; checks = 0
for trial in range(60):
    N = 51; B = [[False] * N for _ in range(N)]
    for i in range(N):
        for j in range(i + 1, N):
            if random.random() < 0.5: B[i][j] = True
            else: B[j][i] = True
    a, b = 0, 1; R = list(range(2, 13)); O = list(range(13, N))
    B[a][b] = True; B[b][a] = False
    A = parse_upper(random.choice(lines), 11)
    for i in range(11):
        for j in range(11):
            if i != j: B[R[i]][R[j]] = bool(A[i][j])
    for r in R:
        for p in (a, b): B[r][p] = True; B[p][r] = False
    for y in O:
        if B[y][a] and B[y][b]:
            p = random.choice((a, b)); B[y][p] = False; B[p][y] = True
    D = lambda X: [w for w in range(N) if w not in X and all(B[w][x] for x in X)]
    assert sorted(D([a, b])) == R
    Q = {y: frozenset(i for i, r in enumerate(R) if B[r][y]) for y in O}
    typ = {y: (0 if B[y][a] else (1 if B[y][b] else 2)) for y in O}
    def cR(U): return sum(1 for i in range(11) if i not in U and all(A[i][u] for u in U))
    for k in (1, 2, 3, 4):
        for U in itertools.combinations(range(11), k):
            Ur = [R[i] for i in U]
            checks += 3
            bad += len(D(Ur)) != cR(U) + sum(1 for y in O if not (Q[y] & set(U)))
            bad += len(D(Ur + [a])) != cR(U) + sum(1 for y in O if typ[y] == 0 and not (Q[y] & set(U)))
            bad += len(D(Ur + [b])) != cR(U) + sum(1 for y in O if typ[y] == 1 and not (Q[y] & set(U)))
    dout = lambda w: sum(B[w][x] for x in range(N)); din = lambda w: sum(B[x][w] for x in range(N))
    for i, r in enumerate(R):
        checks += 1; bad += sum(1 for y in O if i in Q[y]) != dout(r) - 7
    checks += 3
    bad += sum(1 for y in O if typ[y] == 0) != din(a) - 11
    bad += sum(1 for y in O if typ[y] == 1) != din(b) - 12
    bad += any(len(Q[y]) != len(D([a, b, y])) for y in O)
print('checks', checks, 'failures', bad)
