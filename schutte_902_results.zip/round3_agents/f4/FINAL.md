# f4 agent: final write-up (Erdős #902, n = 4)

Status labels: **[hand]** = complete proof by hand, checked; **[computer]** = computer-assisted, with the scripts and
the independent cross-checks named; **[pending]** = evidence only, not yet a proof.

Notation. T is a tournament on N vertices with property S_4 (every 4-set has a common dominator). D(X) is the set of
dominators of X, d⁻ and d⁺ are in- and out-degree, A_v = T[N⁻(v)]. A pair P is *tight* if |D(P)| = 11.
Facts of Szekeres type **[hand]**: (F1) |D(triple)| ≥ 5; (F2) |D(pair)| ≥ 11; (F3) d⁻(v) ≥ 23.

## 1. Main result: f(4) ≥ 51 **[hand]**

**Lemma T.** If |D(P)| = 11, then every r ∈ D(P) has d⁻(r) ≥ 25. (Valid for every N.)

*Proof.* Let R = D(P). For y ∈ R, D(P ∪ {y}) = R ∩ N⁻(y) has ≥ 5 elements by (F1). These in-degrees of T[R] sum to
C(11,2) = 55, so T[R] is 5-regular. A vertex y ∉ P ∪ R is beaten by ≥ 5 vertices of R (again (F1)), so it beats ≤ 6 of
them. Fix r ∈ R. The 45 triples U ⊆ R through r have ≥ 225 dominator incidences in total. A dominator w of such a U
beats r, so w ∈ N⁻(r), and w ∉ P because r beats P. If w ∈ R (5 choices), it dominates at most C(4,2) = 6 of these
triples. If w ∉ R (d⁻(r) − 5 choices), it dominates at most C(5,2) = 10. So 30 + 10(d⁻(r) − 5) ≥ 225, and d⁻(r) ≥ 24.5. ∎

**Corollary 1.** If N ≤ 50, no vertex has in-degree 23.

*Proof.* If d⁻(v) = 23, then A = A_v is regular of in-degree 11 (by (F2) the in-degrees are ≥ 11, and they sum to
23·11). So every pair {a, v} with a ∈ A is tight, with D({a,v}) = N⁻_A(a). These sets cover A, so by Lemma T every
a ∈ A has d⁻(a) ≥ 25, and hence beats at most N − 38 vertices of B = N⁺(v). By (F2),
11(N − 24) ≤ Σ_{b∈B} |D({v,b})| = Σ_{a∈A} |N⁺(a) ∩ B| ≤ 23(N − 38), so 12N ≥ 610 and N ≥ 51. ∎

**Claim Q.** Suppose the minimum in-degree is ≥ 24, and let Z = {v : d⁻(v) = 24}. Every v ∈ Z has at most 2
in-neighbours in Z, so |Z| ≤ 5.

*Proof.* In A_v (24 vertices) write d⁻_{A_v}(x) = 11 + f_x with f_x ≥ 0 (by (F2)). Then Σ f_x = 276 − 264 = 12, so
L = {f = 0} has ℓ ≥ 12 elements. For a ∈ L the pair {a, v} is tight, so by Lemma T all in-neighbours of a inside A_v lie
outside Z. Hence a beats every other vertex of Z_v = N⁻(v) ∩ Z, and |L ∩ Z| ≤ 1. Let Q = Z_v \ L, with q = |Q|. Each
z′ ∈ Q is beaten by all of L, so f_{z′} ≥ ℓ − 11 + d⁻_{T[Q]}(z′). The remaining 24 − ℓ − q vertices outside L have f ≥ 1.
Summing, 12 ≥ q(ℓ − 11) + C(q,2) + 24 − ℓ − q, that is (q − 1)(ℓ − 12) + C(q,2) ≤ 0, which forces q ≤ 1. So |Z_v| ≤ 2.
Then T[Z] has all in-degrees ≤ 2, so C(|Z|,2) ≤ 2|Z| and |Z| ≤ 5. ∎

**Theorem.** No S_4 tournament has N ≤ 50 vertices. Hence **f(4) ≥ 51**.

*Proof.* By (F3) and Corollary 1, the minimum in-degree is ≥ 24, so C(N,2) ≥ 24N and N ≥ 49. Moreover
Σ(d⁻ − 24) = N(N − 49)/2, which is 0 for N = 49 and 25 for N = 50, so |Z| ≥ N − N(N − 49)/2 ≥ 25 > 5. This contradicts
Claim Q. ∎

This proof uses no computer at all. It also replaces the earlier computer-assisted proof of f(4) ≥ 50.

## 2. The in-degree-23 exclusion for larger N **[computer]**

With Lemma T the excess budget in RESULTS.md Lemma 3(ii) becomes Σ_b (|A_b| − 11) ≤ 12N − 610 (it was 12N − 564).
There are at most N − 24 vertices b. Take the per-excess coverage maxima best[e] from `lower_bound/local48b_out.txt`
(source-less undominated 4-sets in the complement of an admissible (11+e)-set). A knapsack over these
(`budget_lemmaT.py`) shows that **no vertex has in-degree 23 when N ≤ 64**. Both S_3 DRTs on 23 vertices pass up to
N = 64, and QR_23 first fails at N = 65.
Inputs: the classification of the two S_3 DRT(23) and the covering tables (RESULTS.md Lemmas 2 and 4, both
computer-verified twice). The coordinator re-checked this knapsack independently. For N ≤ 50 no computer is needed
(the budget is negative).

## 3. N = 51: reductions

Here Σ(d⁻ − 25) = 0, the minimum in-degree is ≥ 24 (§2), and by Claim Q **[hand]** either

* **(R)** T is regular (every in-degree is 25), or
* **(I)** 1 ≤ |Z| ≤ 5, and the excess over 25 sums to Σ_{x∈X}(d⁻(x) − 25) = |Z| ≤ 5, where X = V \ Z.

### 3.1 Rigid structure at a tight pair **[hand]**
Take a tight pair P = {a,b} with a → b and R = D(P), in a tournament with N = 51. Let O be the 38 vertices outside
P ∪ R, and for y ∈ O let q_y = |D(P ∪ {y})|. Then the total deficit is Σ_O (q_y − 5) = 283 − Σ_{r∈R} d⁻(r), which equals
8 − J with J = Σ_{r∈R}(d⁻(r) − 25) ≥ 0.

Write λ(q) = 10 − C(10 − q, 2). The count in Lemma T, done exactly, gives for each r ∈ R:
Σ over the outside in-neighbours y of r of λ(q_y) ≤ 5 + 10(d⁻(r) − 25).
When all 11 dominators have in-degree 25 (J = 0), this forces the following. There is exactly one 'shadow' y with
D(P ∪ {y}) = R. There are exactly two vertices with q = 6, and they beat disjoint 5-subsets of R. The other 35 outside
vertices have q = 5. The only triples of R with more than 5 dominators are the five triples {r*} ∪ π_i, each with
exactly 6.

### 3.2 Case (R) reduces to a DRT(51) **[computer, exact certificates]**
Local model at a tight pair in case (R) (`tight51.py`). The variables count the outside vertices by (Q_y, type). The
constraints are: every pair, triple and 4-set inside R, and every such set together with a or b, is dominated (F1, F2,
S_4); deg_O(r) = 18; n_A = 14, n_B = 13; and the structure of §3.1.

* LP-infeasible for 550 of the 551 classes of 5-regular S_2 tournaments T[R] (HiGHS, `t51_lp.out`). The verifier
  `verify_reg51.py` is a separate implementation (its own constraint builder). It found an **exact integer Farkas
  certificate** for every one of these 550 classes (`vreg51_a.out`, `vreg51_b.out`).
* Class 0: the LP is feasible, and the integer program is infeasible (HiGHS MILP, 69 s; CP-SAT timed out). A hand-valid
  split settles it: the two q = 6 vertices beat disjoint 5-sets, so exactly one vertex r* of R is beaten by neither and
  every other vertex by exactly one. Each of the 11 sub-LPs then has an **exact Farkas certificate**
  (`class0_split.py`, `class0_split.out`).
* The modelling identities were unit-tested on random planted configurations (`unit_identities.py`: 101,820 checks, 0
  failures).

The local model never uses the degrees of vertices outside P ∪ R. So the result holds in **every** S_4 tournament
on 51 vertices with minimum in-degree ≥ 24: no tight pair has both endpoints and all 11 dominators of in-degree 25.
Consequence: in case (R) no pair is tight. Every pair has ≥ 12 dominators, and the dominator counts
sum to 51·C(25,2) = 12·C(51,2). So **every pair has exactly 12 dominators, and T is a doubly regular tournament
DRT(51)** (a skew-Hadamard matrix of order 52).

### 3.3 Case (I) reduces to a local claim **[hand reduction; local claim pending]**
**Spectral lemma [hand].** Fix v ∈ Z. The 50 sets D_z = D({v,z}) lie in N⁻(v), which has 24 vertices. Their Gram
matrix is 5J + M, where M = diag(6 + h_z) + E, h_z = |D_z| − 11 and E_{zz′} = |D({v,z,z′})| − 5 ≥ 0. The Gram matrix has
rank ≤ 24, so M has ≥ 26 eigenvalues ≤ 0. The number of non-tight z is at most Σ h_z ≤ 28 − W⁻(v), where
W⁻(v) = Σ_{x∈N⁻(v)} (d⁻(x) − 25)⁺ (using Claim Q). For a tight z, the z-row of E sums to 8 − J_z. If every tight
pair at v has J_z ≥ 3, then M restricted to the tight z is strictly diagonally dominant. Interlacing then gives
26 ≤ 28 − W⁻(v), so W⁻(v) ≤ 2. But any a ∈ L_v has 3 ≤ J_a ≤ W⁻(v). Contradiction.

So case (I) is impossible as soon as the following holds.
**Local claim J≥3 [pending].** Let P be a tight pair at N = 51 whose head (if P is an in-pair) or tail (if P is an
out-pair) has in-degree 24, and whose dominators have in-degree 25 + j_r. Then Σ j_r ≥ 3.
Evidence so far: `portfolio_J.py` (output in `portJ_all.out`) runs two full-integer HiGHS MILPs. The first is a
type-free relaxation, valid for both modes, with an 8 s limit. The second is the typed model in each mode, with a 45 s
limit. It shows J ≤ 2 infeasible for 26 of the first 35 classes. Classes 0, 1, 7, 8, 17, 18, 21, 29 and 32 have a mode
that hit the time limit. The LP relaxation alone is **not** enough: J = 2 is LP-feasible for several classes. To
continue: `python3 portfolio_J.py <lo> <hi> 8 45` in chunks of about 20 classes per 10 minutes, then longer runs, or
splits in the style of `class0_split.py`, on the undecided classes. A second implementation (CP-SAT, or exact LP
certificates after splitting on the heavy positions and deficit patterns) is still needed.

### 3.4 DRT(51) **[open]**
Second-order tools cannot help here. In any DRT(51) the spectra are forced: at each vertex the matrix E above has
spectrum {31, 6^24, (−7)^25}. The 4-set dominator counts have mean 2.58 and variance 0.97, and the triple counts have
mean 5.63 and variance 0.84, in every DRT(51). With δ = 6 + c/8 for a cyclic triple and 5.5 + c/8 for a transitive one,
where c = Σ_w S_wx S_wy S_wz, S_4 needs c ≥ −8 (cyclic) and c ≥ −4 (transitive). This is a third-order condition. A
classification of skew-Hadamard matrices of order 52 is not available.

## 4. Scripts (all in /home/claude/agents/f4/)
* `check_lemmaT.py`: randomised check of the inequality behind Lemma T (3300 cases; tight, never violated).
* `kappa.py`, `run_k.py`, `k8_all.out`: an earlier N = 50 local MILP (κ ≤ 8 infeasible for all 551 classes). It is
  consistent with Lemma T and now superseded by it.
* `budget_lemmaT.py`: the knapsack of §2.
* `tight51.py`, `t51_lp.out`; `verify_reg51.py`, `vreg51_*.out`; `cpsat_reg51.py`: §3.2.
* `tightJ51.py`, `runJ.py`, `runJnt.py`, `J2in.out`: §3.3.
* `unit_identities.py`: unit test of the local-model identities.
* `notes.md`: the full log.

## 5. Dead ends
* Per-pair bounds like E(D(P)) ≥ c combined with averaging fail on their own (the averages allow c up to 12). The
  structural Lemma T was the key.
* For N = 51 case (I), the single-tight-pair LP (continuous x) is feasible. Integrality of the 5-sets matters (the
  near-exact triple cover).
* For DRT(51), every pair and triple count and every Gram/spectral identity at a vertex is automatically satisfied.

## 6. Next steps
1. Finish the local claim J ≥ 3 (both modes, all 551 classes). The likely route is to run `runJnt.py` (type-free, fast)
   first and then `runJ.py` on the classes left undecided, and to cross-check with CP-SAT. That would reduce N = 51 to
   DRT(51).
2. DRT(51) with S_4 needs third- or fourth-order information. One option: from a vertex v, A_v is a regular
   25-tournament with S_3 in which every pair has ≥ 5 common in-neighbours. A search seeded by the 12-vertex
   in-neighbourhoods (min in-degree 5, S_2), in the style of RESULTS.md Lemma 2, might be feasible with strong
   symmetry breaking. Its cost is unclear.
3. N ≥ 52: §2 covers the minimum in-degree up to N = 64. The rest of the argument would need new ideas beyond Claim Q:
   at N = 52 the excess is 52 and |Z| ≤ 5 still holds, but X may contain many vertices of in-degree 26.
