"""Portfolio check of the local claim J>=3 at N=51 (notes Step 11): for each class decide 'sum_r j_r <= 2 infeasible'
(1) type-free full-integer MILP (runJnt.build) with short limit -> valid for both modes at once;
(2) otherwise typed full-integer MILP (tightJ51.build), mode 'in' (head in Z) and mode 'out' (tail in Z).
Output per class: cl result details.  Usage: python3 portfolio_J.py lo hi t1 t2"""
import sys, time
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
sys.path.insert(0, '/home/claude/agents/f4')
import runJnt, tightJ51 as T
from tour_util import parse_upper
lo, hi, t1, t2 = int(sys.argv[1]), int(sys.argv[2]), float(sys.argv[3]), float(sys.argv[4])
T.JMAX = 2
lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
for cl in range(lo, min(hi, len(lines))):
    A = parse_upper(lines[cl], 11); t0 = time.time()
    M, l, h, ub, nv = runJnt.build(A, 2)
    r = milp(c=np.zeros(nv), constraints=LinearConstraint(M, l, h), bounds=Bounds(0, ub), integrality=np.ones(nv),
             options={'time_limit': t1})
    if r.status == 2:
        print(cl, 'TF-INF', round(time.time() - t0, 1), flush=True); continue
    out = []
    for mode, kw in (('in', dict(NB=(12, 12), NA=(13, 19))), ('out', dict(NA=(13, 13), NB=(12, 18)))):
        M2, l2, h2, lb2, ub2, integ, nv2 = T.build(A, **kw); integ[:] = 1
        r2 = milp(c=np.zeros(nv2), constraints=LinearConstraint(M2, l2, h2), bounds=Bounds(lb2, ub2),
                  integrality=integ, options={'time_limit': t2})
        out.append(f'{mode}:{r2.status}')
    print(cl, 'TF-' + str(r.status), ' '.join(out), round(time.time() - t0, 1), flush=True)
