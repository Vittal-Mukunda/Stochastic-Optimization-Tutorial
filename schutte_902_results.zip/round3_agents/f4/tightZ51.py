"""Case N=51 with a vertex of in-degree 24 (1<=|Z|<=5, sum_X (d^- - 25) = |Z| <= 5; notes Step 5).
Local relaxation at a forced tight pair P={a,b}, a->b, |D(P)|=11, d^-(b)=24 (head in Z).
By Lemma T every r in R=D(P) has d^-(r)>=25, so deg_O(r) = 43-d^-(r) <= 18 and sum_r (18-deg_O(r)) <= 5.
nB = d^-(b)-12 = 12 ; nA = d^-(a)-11 in [13,19].  At most 4 outside y with |Q_y|>=6 (triple count, 38 outside).
Refined Lemma-T per r (exact): sum_{y in O, y->r} lambda(q_y) <= 10 d^-(r) - 245 where lambda(q)=10-C(10-q,2), i.e.
 we impose it through the per-r triple sums (they are implied by the per-triple constraints already present).
Usage: python3 tightZ51.py lo hi"""
import sys, itertools, time
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix, csr_matrix
sys.path.insert(0, '/home/claude/f4/pkg/lower_bound')
from tour_util import parse_upper
def popc(x): return bin(x).count('1')
O = 38

def build(A):
    n = 11; Rng = range(n)
    inR = [sum(1 << i for i in Rng if A[i][j]) for j in Rng]
    outR = [sum(1 << j for j in Rng if A[i][j]) for i in Rng]
    adm = [S for S in range(1 << n) if popc(S) >= 5 and all(S & inR[z] for z in Rng)]
    nS = len(adm); nv = 3 * nS
    X = lambda i, t: 3 * i + t
    rows, lo, hi = [], [], []
    def add(co, l, h): rows.append(co); lo.append(l); hi.append(h)
    def cR(Um): return sum(1 for y in Rng if not (Um >> y) & 1 and (outR[y] & Um) == Um)
    add({X(i, t): 1 for i in range(nS) for t in range(3)}, O, O)
    nu = {2: 11, 3: 5, 4: 1}
    for k in (2, 3, 4):
        for U in itertools.combinations(Rng, k):
            Um = sum(1 << i for i in U); need = nu[k] - cR(Um)
            if need > 0: add({X(i, t): 1 for i, S in enumerate(adm) if not (S & Um) for t in range(3)}, need, np.inf)
    for t in (0, 1):
        for k, need0 in ((3, 1), (2, 5), (1, 11)):
            for U in itertools.combinations(Rng, k):
                Um = sum(1 << i for i in U); need = need0 - cR(Um)
                if need > 0: add({X(i, t): 1 for i, S in enumerate(adm) if not (S & Um)}, need, np.inf)
    deg = [{X(i, t): 1 for i, S in enumerate(adm) if (S >> r) & 1 for t in range(3)} for r in Rng]
    for r in Rng: add(deg[r], 13, 18)
    tot = {}
    for r in Rng:
        for j, v in deg[r].items(): tot[j] = tot.get(j, 0) + v
    add(tot, 11 * 18 - 5, 11 * 18)                                  # sum_r (18-deg_O(r)) <= 5
    add({X(i, 0): 1 for i in range(nS)}, 13, 19)
    add({X(i, 1): 1 for i in range(nS)}, 12, 12)
    add({X(i, t): 1 for i, S in enumerate(adm) if popc(S) >= 6 for t in range(3)}, 0, 4)
    M = lil_matrix((len(rows), nv))
    for r_, co in enumerate(rows):
        for j, v in co.items(): M[r_, j] = v
    return adm, csr_matrix(M), np.array(lo, float), np.array(hi, float), nv

if __name__ == "__main__":
    lo_, hi_ = int(sys.argv[1]), int(sys.argv[2])
    lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
    for cl in range(lo_, min(hi_, len(lines))):
        t0 = time.time(); adm, M, l, h, nv = build(parse_upper(lines[cl], 11))
        res = milp(c=np.zeros(nv), constraints=LinearConstraint(M, l, h), bounds=Bounds(0, O),
                   integrality=np.zeros(nv), options={'time_limit': 60})
        print(cl, res.status, round(time.time() - t0, 1), flush=True)
