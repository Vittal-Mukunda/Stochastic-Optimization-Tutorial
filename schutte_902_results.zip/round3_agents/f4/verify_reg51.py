"""Independent verifier (exact Farkas certificates) for the regular N=51 tight-pair LP of tight51.py.
System (rows 'coef.x >= rhs', x >= 0, sum x = 38 so x_j <= 38), built here from scratch:
  variables x[S,t]: S subset of R admissible (meets every in-nbhd N^-_R(z)) with |S| in {5,6,11}, t in {0,1,2};
  sum x = 38; per U subset R (|U|=2,3,4): dom_R(U) + sum_{S n U = 0} x >= 11,5,1;
  per U (|U|=1,2,3), t in {0,1}: dom_R(U) + sum_{S n U = 0} x[.,t] >= 11,5,1;
  deg_O(r) = 18 for all r; nA = 14; nB = 13; #{S = R} = 1; #{|S| = 6} = 2.
Certificate y >= 0 (scaled to integers) proves infeasibility iff  y.b - 38 * sum_j max(0,(A^T y)_j) > 0 (exact ints).
Usage: python3 verify_reg51.py lo hi"""
import sys, itertools
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix, csr_matrix

def parse(line):
    n = 11; B = [[False] * n for _ in range(n)]; k = 0
    for i in range(n):
        for j in range(i + 1, n):
            if line[k] == '1': B[i][j] = True
            else: B[j][i] = True
            k += 1
    return B

def system(B):
    V = range(11); inn = [frozenset(i for i in V if B[i][j]) for j in V]
    adm = [frozenset(S) for size in (5, 6, 11) for S in itertools.combinations(V, size)
           if all(frozenset(S) & inn[z] for z in V)]
    cols = [(S, t) for S in adm for t in range(3)]
    def domR(U): return sum(1 for y in V if y not in U and all(B[y][u] for u in U))
    rows = []
    def eq(co, v): rows.append((co, v)); rows.append(({j: -c for j, c in co.items()}, -v))
    eq({j: 1 for j in range(len(cols))}, 38)
    for k, nd in ((2, 11), (3, 5), (4, 1)):
        for U in itertools.combinations(V, k):
            need = nd - domR(U)
            if need > 0: rows.append(({j: 1 for j, (S, t) in enumerate(cols) if not (S & set(U))}, need))
    for tt in (0, 1):
        for k, nd in ((1, 11), (2, 5), (3, 1)):
            for U in itertools.combinations(V, k):
                need = nd - domR(U)
                if need > 0: rows.append(({j: 1 for j, (S, t) in enumerate(cols) if t == tt and not (S & set(U))}, need))
    for r in V: eq({j: 1 for j, (S, t) in enumerate(cols) if r in S}, 18)
    eq({j: 1 for j, (S, t) in enumerate(cols) if t == 0}, 14)
    eq({j: 1 for j, (S, t) in enumerate(cols) if t == 1}, 13)
    eq({j: 1 for j, (S, t) in enumerate(cols) if len(S) == 11}, 1)
    eq({j: 1 for j, (S, t) in enumerate(cols) if len(S) == 6}, 2)
    return cols, rows

def certify(cols, rows, UB=38, D=10 ** 6):
    m = len(rows); nc = len(cols)
    I, J, Vv = [], [], []
    for i, (co, b) in enumerate(rows):
        for j, a in co.items(): I.append(i); J.append(j); Vv.append(a)
    A = coo_matrix((Vv, (I, J)), shape=(m, nc)).tocsr()
    b = np.array([bb for _, bb in rows], dtype=np.int64)
    # search LP: max y.b - UB*sum t  s.t. A^T y - t <= 0, 0<=y<=1, t>=0
    from scipy.sparse import hstack, identity
    Aub = hstack([A.T, -identity(nc)]).tocsr()
    c = np.concatenate([-b.astype(float), UB * np.ones(nc)])
    res = linprog(c, A_ub=Aub, b_ub=np.zeros(nc), bounds=[(0, 1)] * m + [(0, None)] * nc, method='highs')
    if res.status != 0 or -res.fun <= 1e-7: return None
    y = np.floor(res.x[:m] * D).astype(np.int64)
    Ai = csr_matrix((A.data.astype(np.int64), A.indices, A.indptr), shape=A.shape)
    col = Ai.T.dot(y)                                  # exact int64
    val = int(y.dot(b)) - UB * int(col[col > 0].sum())
    return val if val > 0 else None

if __name__ == "__main__":
    lo, hi = int(sys.argv[1]), int(sys.argv[2])
    lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
    for cl in range(lo, min(hi, len(lines))):
        cols, rows = system(parse(lines[cl]))
        v = certify(cols, rows)
        print(cl, 'CERT' if v is not None else 'NOCERT', v, flush=True)
