"""Full-integer MILP feasibility at a tight pair incident to a Z-vertex (N=51, case I) with sum_r j_r <= JMAX.
mode 'in': head b in Z (nB=12, nA in [13,19]);  mode 'out': tail a in Z (nA=13, nB in [12,18]).
Usage: python3 runJ.py mode JMAX lo hi"""
import sys, time
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
import tightJ51 as T
from tour_util import parse_upper
mode, jm, lo, hi = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
T.JMAX = jm
lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
for cl in range(lo, min(hi, len(lines))):
    A = parse_upper(lines[cl], 11); t0 = time.time()
    kw = dict(NB=(12, 12), NA=(13, 19)) if mode == 'in' else dict(NA=(13, 13), NB=(12, 18))
    M, l, h, lb, ub, integ, nv = T.build(A, **kw); integ[:] = 1
    res = milp(c=np.zeros(nv), constraints=LinearConstraint(M, l, h), bounds=Bounds(lb, ub), integrality=integ,
               options={'time_limit': 120})
    j = None if res.x is None else [int(round(v)) for v in res.x[-11:]]
    print(cl, mode, jm, res.status, j, round(time.time() - t0, 1), flush=True)
