"""Local model at a tight pair P={a,b} (a->b, |D(P)|=11) of a hypothetical S_4 tournament on N vertices with
min in-degree >= 24 (N <= 51 by RESULTS.md theorem).  R = D(P): T[R] is a 5-regular S_2 11-tournament.
Outside vertices O (N-13): y has Q_y = R n N^-(y) = D(P+y) (admissible, |Q_y|>=5), pairwise intersecting,
and type t in {0: y->a, b->y ; 1: a->y, y->b ; 2: a->y, b->y}.
Variables x[S][t] = number of outside y with Q_y = S and type t.
Usage: python3 tight_pair.py N lo hi timelimit [mode]
mode 'feas' : feasibility;  'minER' : minimise E_R (sum of excesses of R)."""
import sys, itertools, time
sys.path.insert(0, '/home/claude/f4/pkg/lower_bound')
from tour_util import parse_upper
from ortools.sat.python import cp_model

def popc(x): return bin(x).count('1')

def build(A, N, mode='feas', fix_ER=None):
    n = 11; Rng = range(n); full = (1 << n) - 1
    inR = [sum(1 << i for i in Rng if A[i][j]) for j in Rng]
    outR = [sum(1 << j for j in Rng if A[i][j]) for i in Rng]
    assert all(popc(m) == 5 for m in inR)
    adm = [S for S in range(1 << n) if popc(S) >= 5 and all(S & inR[z] for z in Rng)]
    idx = {S: i for i, S in enumerate(adm)}
    O = N - 13
    m = cp_model.CpModel()
    x = [[m.NewIntVar(0, O, "") for t in range(3)] for S in adm]
    u = [m.NewBoolVar("") for S in adm]
    for i in range(len(adm)):
        m.Add(sum(x[i]) <= O * u[i]); m.Add(sum(x[i]) >= u[i])
    for i, S in enumerate(adm):                      # pairwise intersecting
        comp = full & ~S; sub = comp
        while sub:
            if sub > S and sub in idx: m.AddBoolOr([u[i].Not(), u[idx[sub]].Not()])
            sub = (sub - 1) & comp
    tot = [sum(x[i]) for i in range(len(adm))]
    m.Add(sum(tot) == O)
    def cR(Um): return sum(1 for y in Rng if not (Um >> y) & 1 and (outR[y] & Um) == Um)
    nu = {2: 11, 3: 5, 4: 1}
    for k in (2, 3, 4):
        for U in itertools.combinations(Rng, k):
            Um = sum(1 << i for i in U)
            need = nu[k] - cR(Um)
            if need > 0: m.Add(sum(tot[i] for i, S in enumerate(adm) if not (S & Um)) >= need)
    degO = [sum(tot[i] for i, S in enumerate(adm) if (S >> r) & 1) for r in Rng]
    for r in Rng: m.Add(degO[r] <= N - 32)          # d^-(r) = N-8-degO(r) >= 24
    nA = sum(x[i][0] for i in range(len(adm))); nB = sum(x[i][1] for i in range(len(adm)))
    m.Add(nA >= 13); m.Add(nB >= 12)                 # d^-(a)=11+nA, d^-(b)=12+nB
    ER = sum(N - 32 - degO[r] for r in Rng)
    exc_total = N * (N - 49) // 2
    m.Add(ER + (nA - 13) + (nB - 12) <= exc_total)
    for t in (0, 1):                                 # sets U+{a} (t=0), U+{b} (t=1), U subset of R
        for k, need0 in ((3, 1), (2, 5), (1, 11)):
            for U in itertools.combinations(Rng, k):
                Um = sum(1 << i for i in U)
                need = need0 - cR(Um)
                if need > 0: m.Add(sum(x[i][t] for i, S in enumerate(adm) if not (S & Um)) >= need)
    if fix_ER is not None: m.Add(ER == fix_ER)
    if mode == 'minER': m.Minimize(ER)
    return m, len(adm), ER

def solve(m, tl):
    s = cp_model.CpSolver(); s.parameters.num_workers = 1; s.parameters.max_time_in_seconds = tl
    st = s.Solve(m); return s, s.StatusName(st)

if __name__ == "__main__":
    N = int(sys.argv[1]); lo = int(sys.argv[2]); hi = int(sys.argv[3]); tl = float(sys.argv[4])
    mode = sys.argv[5] if len(sys.argv) > 5 else 'feas'
    lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
    for c in range(lo, min(hi, len(lines))):
        A = parse_upper(lines[c], 11)
        m, na, ER = build(A, N, mode)
        s, st = solve(m, tl)
        extra = ''
        if st in ('OPTIMAL', 'FEASIBLE'): extra = 'ER=%d bound=%.1f' % (s.Value(ER), s.BestObjectiveBound() if mode == 'minER' else -1)
        print(c, st, round(s.WallTime(), 1), na, extra, flush=True)
