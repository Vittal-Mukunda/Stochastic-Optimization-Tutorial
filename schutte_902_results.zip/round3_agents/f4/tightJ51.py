"""Case (I) at N=51 (1<=|Z|<=5, sum_{x in X}(d^-(x)-25) = |Z| <= 5).  Local MILP at a tight pair P={a,b}, a->b,
|D(P)|=11, head b in Z (d^-(b)=24 => nB=12), tail a with d^-(a)=11+nA in [24,30].
Dominators r in R=D(P): d^-(r) = 25 + j_r (Lemma T), j_r integer >= 0, sum_r j_r <= 5, deg_O(r) = 18 - j_r.
x[S,t] >= 0 continuous (relaxation).  Valid integer-rounding cuts from the refined Lemma-T count
  sum_{y->r} lambda(q_y) <= 5 + 10 j_r  (lambda(6)=4, lambda(7..10)>=7):
     #{y->r : 7<=q_y<=10} <= 2 j_r ,   #{y->r : q_y = 6} <= 1 + 2.5 j_r .
Also at most 4 outside y with |Q_y|>=6 (triple count with 38 outside vertices).
Usage: python3 tightJ51.py lo hi [tailmode]  (tailmode 'any' default)."""
import sys, itertools, time
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix, csr_matrix
sys.path.insert(0, '/home/claude/f4/pkg/lower_bound')
from tour_util import parse_upper
def popc(x): return bin(x).count('1')
O = 38; JMAX = 5; BIGINT = True

def build(A, NB=(12, 12), NA=(13, 19)):
    n = 11; Rng = range(n)
    inR = [sum(1 << i for i in Rng if A[i][j]) for j in Rng]
    outR = [sum(1 << j for j in Rng if A[i][j]) for i in Rng]
    adm = [S for S in range(1 << n) if popc(S) >= 5 and all(S & inR[z] for z in Rng)]
    nS = len(adm); nx = 3 * nS; nv = nx + 11
    X = lambda i, t: 3 * i + t; J = lambda r: nx + r
    rows = []
    def add(co, l, h): rows.append((co, l, h))
    def cR(Um): return sum(1 for y in Rng if not (Um >> y) & 1 and (outR[y] & Um) == Um)
    add({X(i, t): 1 for i in range(nS) for t in range(3)}, O, O)
    nu = {2: 11, 3: 5, 4: 1}
    for k in (2, 3, 4):
        for U in itertools.combinations(Rng, k):
            Um = sum(1 << i for i in U); need = nu[k] - cR(Um)
            if need > 0: add({X(i, t): 1 for i, S in enumerate(adm) if not (S & Um) for t in range(3)}, need, np.inf)
    for t in (0, 1):
        for k, need0 in ((3, 1), (2, 5), (1, 11)):
            for U in itertools.combinations(Rng, k):
                Um = sum(1 << i for i in U); need = need0 - cR(Um)
                if need > 0: add({X(i, t): 1 for i, S in enumerate(adm) if not (S & Um)}, need, np.inf)
    for r in Rng:
        co = {X(i, t): 1 for i, S in enumerate(adm) if (S >> r) & 1 for t in range(3)}; co[J(r)] = 1
        add(co, 18, 18)                                                        # deg_O(r) + j_r = 18
        co = {X(i, t): 1 for i, S in enumerate(adm) if not (S >> r) & 1 and 7 <= popc(S) <= 10 for t in range(3)}
        co[J(r)] = -2; add(co, -np.inf, 0)                                     # <= 2 j_r
        co = {X(i, t): 1 for i, S in enumerate(adm) if not (S >> r) & 1 and popc(S) == 6 for t in range(3)}
        co[J(r)] = -2.5; add(co, -np.inf, 1)                                   # <= 1 + 2.5 j_r
    add({J(r): 1 for r in Rng}, 0, JMAX)
    nA = {X(i, 0): 1 for i in range(nS)}
    add(nA, NA[0], NA[1])
    co = dict(nA); co.update({J(r): 1 for r in Rng}); add(co, -np.inf, 19)     # heavy budget incl. tail
    add({X(i, 1): 1 for i in range(nS)}, NB[0], NB[1])
    add({X(i, t): 1 for i, S in enumerate(adm) if popc(S) >= 6 for t in range(3)}, 0, 4)
    M = lil_matrix((len(rows), nv))
    for r_, (co, l, h) in enumerate(rows):
        for j, v in co.items(): M[r_, j] = v
    l = np.array([r[1] for r in rows], float); h = np.array([r[2] for r in rows], float)
    lb = np.zeros(nv); ub = np.full(nv, float(O)); ub[nx:] = JMAX
    integ = np.zeros(nv); integ[nx:] = 1
    if BIGINT:
        for i, S in enumerate(adm):
            if popc(S) >= 6:
                for t in range(3): integ[X(i, t)] = 1
    return csr_matrix(M), l, h, lb, ub, integ, nv

def solve(A, tl=120, **kw):
    M, l, h, lb, ub, integ, nv = build(A, **kw)
    res = milp(c=np.zeros(nv), constraints=LinearConstraint(M, l, h), bounds=Bounds(lb, ub), integrality=integ,
               options={'time_limit': tl})
    return res.status, (None if res.x is None else [int(round(v)) for v in res.x[-11:]])

if __name__ == "__main__":
    lo_, hi_ = int(sys.argv[1]), int(sys.argv[2])
    lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
    for cl in range(lo_, min(hi_, len(lines))):
        t0 = time.time(); st, j = solve(parse_upper(lines[cl], 11))
        print(cl, st, j, round(time.time() - t0, 1), flush=True)
