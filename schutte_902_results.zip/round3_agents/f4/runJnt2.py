"""Type-free full-integer MILP for 'sum_r j_r <= 2' at an N=51 tight pair, with the pattern cuts valid when J<=2
(notes Step 17): no outside y with |Q_y| in {7,8}; exactly one with |Q_y| >= 9; at most two with |Q_y| = 6.
Usage: python3 runJnt2.py lo hi tl [classlist comma-separated]"""
import sys, time
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import vstack, csr_matrix
sys.path.insert(0, '/home/claude/agents/f4')
import runJnt
from tour_util import parse_upper
def popc(x): return bin(x).count('1')
lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
lo, hi, tl = int(sys.argv[1]), int(sys.argv[2]), float(sys.argv[3])
cls = [int(c) for c in sys.argv[4].split(',')] if len(sys.argv) > 4 else range(lo, min(hi, len(lines)))
for cl in cls:
    A = parse_upper(lines[cl], 11); t0 = time.time()
    M, l, h, ub, nv = runJnt.build(A, 2)
    n = 11; inR = [sum(1 << i for i in range(n) if A[i][j]) for j in range(n)]
    adm = [S for S in range(1 << n) if popc(S) >= 5 and all(S & inR[z] for z in range(n))]
    nS = len(adm)
    rows = []; lo_ = []; hi_ = []
    for sizes, a, b in (((7, 8), 0, 0), ((9, 10, 11), 1, 1), ((6,), 0, 2)):
        r = np.zeros(nv); r[[i for i, S in enumerate(adm) if popc(S) in sizes]] = 1
        rows.append(r); lo_.append(a); hi_.append(b)
    M2 = vstack([M, csr_matrix(np.array(rows))]); l2 = np.concatenate([l, lo_]); h2 = np.concatenate([h, hi_])
    res = milp(c=np.zeros(nv), constraints=LinearConstraint(M2, l2, h2), bounds=Bounds(0, ub),
               integrality=np.ones(nv), options={'time_limit': tl})
    print(cl, res.status, round(time.time() - t0, 1), flush=True)
