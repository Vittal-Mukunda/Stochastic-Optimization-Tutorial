#!/usr/bin/env python3
"""Generate tournaments as adjacency matrices (adj[u][v]=1 iff u->v).
   gentour.py paley p
   gentour.py random N seed            (uniform random tournament)
   gentour.py randomS n N seed tries   (random tournament conditioned on S_n, by rejection)
"""
import sys, random
from itertools import combinations


def paley(p):
    qr = {(x * x) % p for x in range(1, p)}
    return [[1 if (v - u) % p in qr else 0 for v in range(p)] for u in range(p)]


def rand_t(N, rng):
    a = [[0] * N for _ in range(N)]
    for u in range(N):
        for v in range(u + 1, N):
            if rng.random() < 0.5:
                a[u][v] = 1
            else:
                a[v][u] = 1
    return a


def has_S(a, n):
    N = len(a)
    inn = [0] * N
    for u in range(N):
        for v in range(N):
            if a[u][v]:
                inn[v] |= 1 << u
    full = (1 << N) - 1
    for X in combinations(range(N), n):
        d = full
        for x in X:
            d &= inn[x]
            if not d:
                return False
        if not d:
            return False
    return True


def dump(a):
    print(len(a))
    for r in a:
        print("".join(map(str, r)))


if __name__ == "__main__":
    kind = sys.argv[1]
    if kind == "paley":
        a = paley(int(sys.argv[2]))
    elif kind == "random":
        a = rand_t(int(sys.argv[2]), random.Random(int(sys.argv[3])))
    elif kind == "randomS":
        n, N, seed, tries = map(int, sys.argv[2:6])
        rng = random.Random(seed)
        for t in range(tries):
            a = rand_t(N, rng)
            if has_S(a, n):
                break
        else:
            sys.exit("no S_%d tournament found" % n)
    dump(a)
