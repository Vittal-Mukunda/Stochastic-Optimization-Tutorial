#!/usr/bin/env python3
"""Purely definitional (no bitsets) check of the cross-level lemma on small random tournaments,
for ALL s in [0, N-1] and ALL k in [1, N]  (the lemma needs no S_n hypothesis at all:
nu_j is just the minimum of |D(X)| over j-sets).  Also counts pairs (U,y) literally."""
import random, sys
from itertools import combinations
from math import comb


def C(x, k):
    return comb(x, k) if 0 <= k <= x else 0


def D(adj, X, N):
    Xs = set(X)
    return [v for v in range(N) if v not in Xs and all(adj[v][x] for x in X)]


def run(N, seed):
    rng = random.Random(seed)
    adj = [[0] * N for _ in range(N)]
    for u in range(N):
        for v in range(u + 1, N):
            if rng.random() < 0.5:
                adj[u][v] = 1
            else:
                adj[v][u] = 1
    nu = [min(len(D(adj, X, N)) for X in combinations(range(N), j)) for j in range(N + 1)]
    checks = 0
    for s in range(0, N):
        for A in combinations(range(N), s):
            R = D(adj, A, N)
            m = len(R)
            for k in range(1, N + 1):
                # literal count of pairs (U, y): U k-subset of R, y in D(U)
                P = 0
                for U in combinations(R, k):
                    P += len(D(adj, U, N))
                lhs = (N - s) * C(m - nu[s + 1], k)
                rhs = nu[k] * C(m, k)
                assert rhs <= P <= lhs, (N, seed, s, A, k, m, P, lhs, rhs)
                checks += 1
    return nu, checks


if __name__ == "__main__":
    tot = 0
    for N in range(3, 10):
        for seed in range(6 if N < 9 else 2):
            nu, c = run(N, 1000 * N + seed)
            tot += c
    print("all definitional checks passed:", tot)
