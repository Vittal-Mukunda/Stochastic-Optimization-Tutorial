/* Verifier: brute-force check of the cross-level lemma on a given tournament.
 *
 * Input (stdin): N, then N rows of N chars '0'/'1'; adj[u][v]=1 iff u->v.
 * Args: smax kmax  -- check all s in [0, smax], all s-sets A, all k in [1,kmax].
 *       nu_s is computed exactly (min over all s-sets) for s = 0..max(smax+1,kmax).
 *
 * For each A (|A|=s), R=D(A), m=|R|:
 *   (i)   for every y not in A: Q_y := R ∩ N^-(y) equals D(A ∪ {y}) computed from the
 *         definition by adjacency loops; |Q_y| >= nu_{s+1}
 *   (ii)  for every y in A: R ∩ N^+(y) = empty
 *   (iii) for each k: P := sum over k-subsets U of R of |D(U)| (enumerated);
 *         P == sum_{y} C(|R ∩ N^+(y)|, k)   (exact identity)
 *         nu_k*C(m,k) <= P <= (N-s)*C(m-nu_{s+1},k)   (the lemma)
 * Prints counts of checks and failures; also the minimum slack ratio of the lemma.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define MAXN 512
#define MAXW 8
static int N, W;
static unsigned char adj[MAXN][MAXN];
static uint64_t inn[MAXN][MAXW], outb[MAXN][MAXW];
static long long nu[MAXN + 1];
static int smax, kmax, numax;

static int popc(const uint64_t *a) { int c = 0; for (int i = 0; i < W; i++) c += __builtin_popcountll(a[i]); return c; }
static void andw(uint64_t *r, const uint64_t *a, const uint64_t *b) { for (int i = 0; i < W; i++) r[i] = a[i] & b[i]; }
static int inset(const uint64_t *a, int v) { return (a[v >> 6] >> (v & 63)) & 1; }
static void setall(uint64_t *a) { memset(a, 0, sizeof(uint64_t) * MAXW); for (int v = 0; v < N; v++) a[v >> 6] |= 1ULL << (v & 63); }

static __int128 binom(long long x, int k) {
    if (k < 0 || x < k) return 0;
    __int128 r = 1;
    for (int i = 0; i < k; i++) { r = r * (x - i) / (i + 1); }
    return r;
}

/* ---- nu computation: DFS over combinations ---- */
static long long numin[MAXN + 1];
static void nu_dfs(int start, int depth, uint64_t *cur) {
    int c = popc(cur);
    if (c < numin[depth]) numin[depth] = c;
    if (depth == numax) return;
    uint64_t nxt[MAXW];
    for (int v = start; v < N; v++) { andw(nxt, cur, inn[v]); nu_dfs(v + 1, depth + 1, nxt); }
}

/* ---- lemma checks ---- */
static long long n_A = 0, n_y = 0, n_k = 0, fails = 0;
static double minslack = 1e300, minslack1 = 1e300; static int ms_s = -1, ms_k = -1, ms_m = -1;
static int Aset[MAXN], Asz;
static int Rlist[MAXN], Rsz;

static long long Psum; static int Kcur;
static void u_dfs(int start, int depth, uint64_t *cur) {
    if (depth == Kcur) { Psum += popc(cur); return; }
    uint64_t nxt[MAXW];
    for (int i = start; i < Rsz; i++) { andw(nxt, cur, inn[Rlist[i]]); u_dfs(i + 1, depth + 1, nxt); }
}

static void check_A(int s, uint64_t *R) {
    n_A++;
    int m = popc(R);
    Rsz = 0; for (int v = 0; v < N; v++) if (inset(R, v)) Rlist[Rsz++] = v;
    unsigned char inA[MAXN]; memset(inA, 0, N); for (int i = 0; i < Asz; i++) inA[Aset[i]] = 1;
    /* (i),(ii) */
    for (int y = 0; y < N; y++) {
        uint64_t q[MAXW];
        if (inA[y]) {
            andw(q, R, outb[y]);
            if (popc(q) != 0) { fails++; fprintf(stderr, "FAIL (ii) s=%d y=%d\n", s, y); }
            continue;
        }
        n_y++;
        andw(q, R, inn[y]);
        /* D(A ∪ {y}) from definition */
        int cnt = 0, mismatch = 0;
        for (int v = 0; v < N; v++) {
            int ok = (!inA[v]) && v != y && adj[v][y];
            for (int i = 0; ok && i < Asz; i++) if (!adj[v][Aset[i]]) ok = 0;
            if (ok) cnt++;
            if (ok != inset(q, v)) mismatch = 1;
        }
        if (mismatch) { fails++; fprintf(stderr, "FAIL (i) Q_y != D(A+y) s=%d y=%d\n", s, y); }
        if (cnt < nu[s + 1]) { fails++; fprintf(stderr, "FAIL (i) |Q_y|<nu_{s+1} s=%d\n", s); }
    }
    /* (iii) */
    for (int k = 1; k <= kmax; k++) {
        n_k++;
        uint64_t all[MAXW]; setall(all);
        Psum = 0; Kcur = k; u_dfs(0, 0, all);
        __int128 ident = 0;
        for (int y = 0; y < N; y++) { uint64_t q[MAXW]; andw(q, R, outb[y]); ident += binom(popc(q), k); }
        __int128 lower = (__int128)nu[k] * binom(m, k);
        __int128 upper = (__int128)(N - s) * binom(m - nu[s + 1], k);
        if ((__int128)Psum != ident) { fails++; fprintf(stderr, "FAIL identity s=%d k=%d\n", s, k); }
        if (lower > (__int128)Psum) { fails++; fprintf(stderr, "FAIL lower s=%d k=%d\n", s, k); }
        if ((__int128)Psum > upper) { fails++; fprintf(stderr, "FAIL upper s=%d k=%d m=%d P=%lld\n", s, k, m, Psum); }
        if (lower > upper) { fails++; fprintf(stderr, "FAIL LEMMA s=%d k=%d m=%d\n", s, k, m); }
        /* refinement R1: dominators inside R lose one more vertex */
        __int128 upper1 = (__int128)(N - s - m) * binom(m - nu[s + 1], k) + (__int128)m * binom(m - nu[s + 1] - 1, k);
        if ((__int128)Psum > upper1) { fails++; fprintf(stderr, "FAIL R1 s=%d k=%d m=%d\n", s, k, m); }
        if (lower > 0) { double sl1 = (double)upper1 / (double)lower; if (sl1 < minslack1) minslack1 = sl1; }
        if (lower > 0) {
            double sl = (double)upper / (double)lower;
            if (sl < minslack) { minslack = sl; ms_s = s; ms_k = k; ms_m = m; }
        }
    }
}

static void A_dfs(int start, int depth, int s, uint64_t *cur) {
    if (depth == s) { check_A(s, cur); return; }
    uint64_t nxt[MAXW];
    for (int v = start; v < N; v++) { andw(nxt, cur, inn[v]); Aset[Asz++] = v; A_dfs(v + 1, depth + 1, s, nxt); Asz--; }
}

int main(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr, "usage: lemcheck smax kmax < tournament\n"); return 1; }
    smax = atoi(argv[1]); kmax = atoi(argv[2]);
    if (scanf("%d", &N) != 1) return 1;
    W = (N + 63) / 64;
    char *row = malloc(N + 8);
    for (int u = 0; u < N; u++) { if (scanf("%s", row) != 1) return 1; for (int v = 0; v < N; v++) adj[u][v] = row[v] == '1'; }
    /* validate tournament */
    for (int u = 0; u < N; u++) { if (adj[u][u]) { fprintf(stderr, "loop\n"); return 1; } for (int v = u + 1; v < N; v++) if (adj[u][v] + adj[v][u] != 1) { fprintf(stderr, "not a tournament\n"); return 1; } }
    memset(inn, 0, sizeof inn); memset(outb, 0, sizeof outb);
    for (int u = 0; u < N; u++) for (int v = 0; v < N; v++) if (adj[u][v]) { outb[u][v >> 6] |= 1ULL << (v & 63); inn[v][u >> 6] |= 1ULL << (u & 63); }
    numax = smax + 1 > kmax ? smax + 1 : kmax; if (numax > N) numax = N;
    for (int i = 0; i <= numax; i++) numin[i] = 1LL << 60;
    uint64_t all[MAXW]; setall(all);
    nu_dfs(0, 0, all);
    for (int i = 0; i <= numax; i++) nu[i] = numin[i];
    printf("N=%d nu:", N); for (int i = 0; i <= numax; i++) printf(" %lld", nu[i]); printf("\n");
    for (int s = 0; s <= smax && s + 1 <= numax; s++) { Asz = 0; A_dfs(0, 0, s, all); }
    printf("checked A=%lld (A,y)=%lld (A,k)=%lld  fails=%lld  min upper/lower=%.6f at s=%d k=%d m=%d  (R1 min %.6f)\n",
           n_A, n_y, n_k, fails, minslack, ms_s, ms_k, ms_m, minslack1);
    return fails ? 2 : 0;
}
