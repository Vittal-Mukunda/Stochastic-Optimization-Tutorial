#!/usr/bin/env python3
"""Verifier: recompute a_j and c* = lim a_j/2^j where a_1 = 1 (or a given base) and
   Phi(a_j, a_{j-1}) = ln 2, a_j > a_{j-1} + 1,
   Phi(a,b) = int_0^1 ln((a-x)/(a-b-x)) dx.
Two independent evaluations of Phi: (1) stable closed form, (2) mpmath numerical quadrature.
"""
import sys
import mpmath as mp


def F(a):
    # a ln a - (a-1) ln(a-1), stable: = ln a - (a-1) log1p(-1/a); F(1) = 0
    if a == 1:
        return mp.mpf(0)
    return mp.log(a) - (a - 1) * mp.log1p(-1 / a)


def Phi(a, b):
    return F(a) - F(a - b)


def Phi_quad(a, b):
    return mp.quad(lambda x: mp.log((a - x) / (a - b - x)), [0, 1])


def solve(b, phi=Phi):
    """unique root a in (b+1, inf) of phi(a,b) = ln2 (phi decreasing in a)."""
    target = mp.log(2)
    lo = b + 1
    # value at the boundary a = b+1 is F(b+1) - F(1) = F(b+1) (avoid rounding of (b+1)-b)
    if F(lo) <= target:
        raise ValueError("no root above b+1 for b=%s" % b)
    hi = 2 * b + 2
    while phi(hi, b) > target:
        hi *= 2
    # bisection to moderate accuracy, then Newton via findroot
    for _ in range(60):
        mid = (lo + hi) / 2
        if phi(mid, b) > target:
            lo = mid
        else:
            hi = mid
    return mp.findroot(lambda a: phi(a, b) - target, (lo + hi) / 2)


def run(a1=1, J=200, dps=80, verbose=False):
    mp.mp.dps = dps
    a = [None, mp.mpf(a1)]
    for j in range(2, J + 1):
        a.append(solve(a[-1]))
    return a


if __name__ == "__main__":
    mp.mp.dps = 80
    a = run(1, 200, 80)
    for j in (1, 2, 3, 4, 5, 6, 10):
        print(j, mp.nstr(a[j], 10), mp.nstr(a[j] / 2 ** j, 10), "d_j=a_j-2a_{j-1}:", mp.nstr(a[j] - 2 * a[j - 1], 8) if j > 1 else "")
    # monotonicity of a_j/2^j and d_j
    r = [a[j] / 2 ** j for j in range(1, 201)]
    print("a_j/2^j increasing:", all(r[i] < r[i + 1] for i in range(len(r) - 1)))
    d = [a[j] - 2 * a[j - 1] for j in range(2, 201)]
    print("d_j decreasing:", all(d[i] > d[i + 1] for i in range(len(d) - 1)), "d_200 =", mp.nstr(d[-1], 20))
    # tail: c* = a_J/2^J + sum_{i>J} d_i/2^i, d_i -> 1/2 (+ 1/(16 a_{i-1}) + ...)
    for J in (100, 150, 200):
        print("J=%d  a_J/2^J + 2^-(J+1) =" % J, mp.nstr(a[J] / 2 ** J + mp.mpf(2) ** (-(J + 1)), 45))
    # independent check with quadrature for the first few levels
    mp.mp.dps = 30
    b = mp.mpf(1)
    aq = [None, b]
    for j in range(2, 12):
        aq.append(solve(aq[-1], phi=Phi_quad))
    mp.mp.dps = 80
    print("quadrature a_2..a_11 vs closed form max rel diff:",
          mp.nstr(max(abs(aq[j] - a[j]) / a[j] for j in range(2, 12)), 5))
    # sensitivity table for other bases a_1 (Section 4 of the write-up)
    mp.mp.dps = 40
    for a1 in (1, 1.1, 1.25, 1.5, 2, 3):
        aa = run(mp.mpf(a1), 120, 40)
        print("a_1=%s -> constant %s" % (a1, mp.nstr(aa[120] / 2 ** 120 + mp.mpf(2) ** -121, 12)))
