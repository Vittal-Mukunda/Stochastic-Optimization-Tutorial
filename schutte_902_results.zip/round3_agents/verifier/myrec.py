#!/usr/bin/env python3
"""
Independent implementation (verifier) of the cross-level recursion, written from the
statement of the lemma only.

Lemma: for an s-set A (0<=s<=n-1), m=|D(A)|, 1<=k<=n:
    (N-s)*C(m - nu_{s+1}, k) >= nu_k * C(m,k),  C(x,k)=0 for x<k (incl. negative x).

Given N, compute lower bounds L[s] <= nu_s top-down:
  L[n] = 1
  for s = n-1..0:
     h = L[s+1]
     lower bounds on nu_k: k>=s+1 -> L[k];  k<=s -> 2^(s+1-k)(h+1)-1  (M2 chain)
     L[s] = least m >= start satisfying the lemma for all k in 1..n, where
            start = 2h+1 (M2), and optionally max with n+1 at s=n-1 (M1)
  N infeasible if L[0] > N  (or no feasible m <= N-s at some level).

Two search modes for m: 'linear' (scan every m upward, no monotonicity assumption)
and 'bisect' (binary search, relies on monotonicity, which is then checked).
"""
import sys
from math import comb


def C(x, k):
    if k < 0 or x < k:
        return 0
    return comb(x, k)


def ok_m(n, N, s, m, h, Lk):
    for k in range(1, n + 1):
        if (N - s) * C(m - h, k) < Lk[k] * C(m, k):
            return False
    return True


def levels(n, N, mode="bisect", use_M1=True, use_M2_floor=True, ks=None):
    """Return list L[0..n] of forced lower bounds, or None if N is ruled out
    (some level needs more than N-s dominators, or L[0] > N)."""
    if ks is None:
        ks = range(1, n + 1)
    L = [None] * (n + 1)
    L[n] = 1
    for s in range(n - 1, -1, -1):
        h = L[s + 1]
        Lk = [0] * (n + 1)
        for k in range(1, n + 1):
            if k >= s + 1:
                Lk[k] = L[k]
            else:
                Lk[k] = 2 ** (s + 1 - k) * (h + 1) - 1
        # restrict to chosen ks (others set to 0 = no constraint)
        Lk2 = [0] * (n + 1)
        for k in ks:
            Lk2[k] = Lk[k]
        start = 1
        if use_M2_floor:
            start = max(start, 2 * h + 1)
        if use_M1 and s == n - 1:
            start = max(start, n + 1)
        hi = N - s  # |D(A)| <= N - s
        if start > hi:
            return None
        if mode == "linear":
            m = start
            while m <= hi and not ok_m(n, N, s, m, h, Lk2):
                m += 1
            if m > hi:
                return None
        else:
            if not ok_m(n, N, s, hi, h, Lk2):
                return None
            lo_, hi_ = start, hi  # invariant: hi_ feasible
            if ok_m(n, N, s, lo_, h, Lk2):
                hi_ = lo_
            else:
                while hi_ - lo_ > 1:  # lo_ infeasible, hi_ feasible
                    mid = (lo_ + hi_) // 2
                    if ok_m(n, N, s, mid, h, Lk2):
                        hi_ = mid
                    else:
                        lo_ = mid
            m = hi_
        L[s] = m
    if L[0] > N:
        return None
    return L


def szekeres(n):
    return (n + 2) * 2 ** (n - 1) - 1


def least_feasible_linear(n, **kw):
    N = 1
    while levels(n, N, **kw) is None:
        N += 1
    return N


def least_feasible_scan_from_szekeres(n, **kw):
    N = szekeres(n)
    while levels(n, N, **kw) is None:
        N += 1
    return N


def least_feasible_bisect(n, **kw):
    lo = szekeres(n) - 1
    # sanity: everything below Szekeres must be infeasible; check lo
    assert levels(n, lo, **kw) is None
    hi = max(2 * lo, 4)
    while levels(n, hi, **kw) is None:
        hi *= 2
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if levels(n, mid, **kw) is None:
            lo = mid
        else:
            hi = mid
    return hi


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "small"
    if which == "small":
        # fully assumption-free for tiny n: scan every N from 1 and every m linearly
        for n in range(1, 8):
            a = least_feasible_scan_from_szekeres(n, mode="linear")
            b = least_feasible_bisect(n)
            print(n, szekeres(n), a, b, flush=True)
    elif which == "table":
        for n in range(2, 27):
            b = least_feasible_bisect(n)
            print(n, szekeres(n), b, "%.4f" % (b / szekeres(n)), "%.4f" % (b / (n * 2 ** n)), flush=True)
