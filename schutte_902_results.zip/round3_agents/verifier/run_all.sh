#!/bin/sh
# Reproduce all verifier checks (single-threaded, < 1 min total)
cd "$(dirname "$0")"
gcc -O2 -o lemcheck lemcheck.c && gcc -O2 -o paleynu paleynu.c
echo "== definitional python lemma check (random tournaments N=3..9, all s,k)"; python3 lempy.py
echo "== C lemma check (+R1)"; 
python3 gentour.py paley 7 > qr7.txt; python3 gentour.py paley 19 > qr19.txt; python3 gentour.py paley 67 > qr67.txt
./lemcheck 5 7 < qr7.txt; ./lemcheck 5 6 < qr19.txt; ./lemcheck 3 4 < qr67.txt
for N in 8 10 12; do for seed in 1 2 3 4 5 6; do python3 gentour.py random $N $seed > r.txt; ./lemcheck $((N-2)) $N < r.txt | tail -1; done; done
for N in 15 20 25; do for seed in 3 11 12; do python3 gentour.py randomS 2 $N $seed 5000 > rs2.txt && ./lemcheck 4 5 < rs2.txt; done; done
python3 gentour.py randomS 3 100 7 50 > rs3.txt && ./lemcheck 2 4 < rs3.txt
echo "== Paley nu"; ./paleynu 67 4 | head -1; ./paleynu 331 5 | head -1
echo "== recursion tables"; python3 myrec.py small; python3 myrec.py table
echo "== R1 refinement"; python3 -c "
import refine
for n in range(2,12): print(n, refine.least_R1_bisect(n), refine.least(n, R1=True))"
echo "== c*"; python3 cstar.py
