#!/usr/bin/env python3
"""Optional: two VALID strengthenings of the recursion (not claimed in the write-up), to see
whether the explicit table can be improved cheaply.  Linear scans only (no monotonicity assumed):
the least m satisfying all constraints is a valid lower bound for nu_s whether or not the
feasible set is an up-set, and the least N not ruled out (scanning every N upward from the
Szekeres value) is a valid lower bound for f(n).

R1: dominators y inside R=D(A) lose one more vertex (y itself is not in U):
      pairs <= (N-s-m) C(m-h,k) + m C(m-h-1,k)
R2: apply the lemma to a MINIMISING s-set A, so m = nu_s and, for k <= s,
      nu_k >= 2^(s-k)(m+1)-1   (M2 chain from level s itself, instead of from level s+1)
"""
import sys
from math import comb


def C(x, k):
    return comb(x, k) if 0 <= k <= x else 0


def levels(n, N, R1=False, R2=False):
    L = [None] * (n + 1)
    L[n] = 1
    for s in range(n - 1, -1, -1):
        h = L[s + 1]
        m = max(2 * h + 1, n + 1 if s == n - 1 else 0)
        while True:
            if m > N - s:
                return None
            good = True
            for k in range(1, n + 1):
                if k >= s + 1:
                    lk = L[k]
                elif R2:
                    lk = 2 ** (s - k) * (m + 1) - 1
                else:
                    lk = 2 ** (s + 1 - k) * (h + 1) - 1
                if R1:
                    up = (N - s - m) * C(m - h, k) + m * C(m - h - 1, k)
                else:
                    up = (N - s) * C(m - h, k)
                if up < lk * C(m, k):
                    good = False
                    break
            if good:
                break
            m += 1
        L[s] = m
    return L if L[0] <= N else None


def least(n, **kw):
    N = (n + 2) * 2 ** (n - 1) - 1
    while levels(n, N, **kw) is None:
        N += 1
    return N


if __name__ == "__main__":
    nmax = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    for n in range(2, nmax + 1):
        print(n, "base", least(n), "R1", least(n, R1=True), "R2", least(n, R2=True),
              "R1+R2", least(n, R1=True, R2=True), flush=True)


# ---- R1 in closed form, bisection version (R1 is equivalent to replacing (N-s) by
#      (N - s - k*m/(m-h)); both factors increase with m, so feasibility is an up-set in m,
#      and it is monotone in N) ----
from fractions import Fraction


def ok_R1(n, N, s, m, h, Lk):
    for k in range(1, n + 1):
        up = (N - s - m) * C(m - h, k) + m * C(m - h - 1, k)
        if up < Lk[k] * C(m, k):
            return False
    return True


def levels_R1_bisect(n, N):
    L = [None] * (n + 1)
    L[n] = 1
    for s in range(n - 1, -1, -1):
        h = L[s + 1]
        Lk = [0] + [L[k] if k >= s + 1 else 2 ** (s + 1 - k) * (h + 1) - 1 for k in range(1, n + 1)]
        lo = max(2 * h + 1, n + 1 if s == n - 1 else 0)
        hi = N - s
        if lo > hi or not ok_R1(n, N, s, hi, h, Lk):
            return None
        if ok_R1(n, N, s, lo, h, Lk):
            L[s] = lo
            continue
        while hi - lo > 1:
            mid = (lo + hi) // 2
            if ok_R1(n, N, s, mid, h, Lk):
                hi = mid
            else:
                lo = mid
        L[s] = hi
    return L if L[0] <= N else None


def least_R1_bisect(n):
    lo = (n + 2) * 2 ** (n - 1) - 2
    assert levels_R1_bisect(n, lo) is None
    hi = 2 * lo
    while levels_R1_bisect(n, hi) is None:
        hi *= 2
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if levels_R1_bisect(n, mid) is None:
            lo = mid
        else:
            hi = mid
    return hi
