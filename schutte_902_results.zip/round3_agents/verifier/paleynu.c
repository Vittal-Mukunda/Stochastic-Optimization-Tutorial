/* nu_s = min |D(X)| over s-sets X of the Paley tournament QR_p (p = 3 mod 4), s <= smax.
 * Uses arc-transitivity of QR_p (z -> a z + b, a a nonzero square): every s-set (s>=2)
 * is equivalent to one containing 0 and 1.  Also records the histogram of |D(X)| values
 * (over representatives) so the lemma inequality can be checked for every m that occurs. */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#define MAXW 32
static int p, W, smax;
static uint64_t inn[4096][MAXW];
static long long best[16];
static long long hist[16][4096];
static int popc(const uint64_t *a) { int c = 0; for (int i = 0; i < W; i++) c += __builtin_popcountll(a[i]); return c; }
static void dfs(int start, int depth, const uint64_t *cur) {
    int c = popc(cur);
    if (c < best[depth]) best[depth] = c;
    hist[depth][c]++;
    if (depth == smax) return;
    uint64_t nxt[MAXW];
    for (int v = start; v < p; v++) {
        for (int i = 0; i < W; i++) nxt[i] = cur[i] & inn[v][i];
        dfs(v + 1, depth + 1, nxt);
    }
}
int main(int argc, char **argv) {
    p = atoi(argv[1]); smax = atoi(argv[2]);
    W = (p + 63) / 64;
    char *qr = calloc(p, 1);
    for (long x = 1; x < p; x++) qr[(x * x) % p] = 1;
    /* u -> v iff v-u is a square; inn[v] = {u : v-u square} */
    for (int v = 0; v < p; v++) { memset(inn[v], 0, sizeof inn[v]); for (int u = 0; u < p; u++) if (qr[((v - u) % p + p) % p]) inn[v][u >> 6] |= 1ULL << (u & 63); }
    for (int i = 0; i < 16; i++) best[i] = 1LL << 60;
    /* depth counts |X|; start from X = {0,1} (0->1 since 1 is a square) */
    uint64_t cur[MAXW];
    for (int i = 0; i < W; i++) cur[i] = inn[0][i] & inn[1][i];
    dfs(2, 2, cur);
    /* nu_0 = p, nu_1 = (p-1)/2 by vertex-transitivity */
    printf("p=%d nu: %d %d", p, p, (p - 1) / 2);
    for (int s = 2; s <= smax; s++) printf(" %lld", best[s]);
    printf("\n");
    for (int s = 2; s <= smax; s++) {
        printf("s=%d values of |D(X)|:", s);
        for (int c = 0; c < p; c++) if (hist[s][c]) printf(" %d", c);
        printf("\n");
    }
    return 0;
}
