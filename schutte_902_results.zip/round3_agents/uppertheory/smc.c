// Sequential Monte Carlo (Feynman-Kac particle system) estimate of
//   frac = P(a uniformly random n-set of a Cayley tournament on Z_p has no dominator)
// for very small values (deep lower tail).  Same conventions as mc.c:
//   mode 0: Paley QR_p (fix {0,1});  mode 1: random Cayley (fix {0});  mode 2: random cyclotomic (h).
// Path: A_k (k = nfix .. n-1) built by adding uniform random new elements; D_k = D(A_k).
// Potentials G_t = exp(-beta_k |D_k| + beta_{k-1} |D_{k-1}|), beta_k = kappa * 2^{-(n-k)}; multinomial resampling.
// Final test function f(A_{n-1}) = c(A_{n-1})/(p-n+1), corrected by exp(beta_{n-2}|D_{n-2}| - beta_{nfix}|D_nfix|).
// Unbiased (standard Feynman-Kac particle estimate).  Repeats R independent runs and reports mean and spread.
// Also writes any dominating n-set found (certificate that the tournament fails S_n) to stdout.
// usage: smc mode p n M R kappa seed [h]
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
typedef uint64_t u64;
static int p, n, W;
static u64 *S2, *T2, lastmask;
static u64 rs;
static inline u64 rnd(void){ u64 z = (rs += 0x9E3779B97F4A7C15ULL); z = (z ^ (z>>30))*0xBF58476D1CE4E5B9ULL; z = (z ^ (z>>27))*0x94D049BB133111EBULL; return z ^ (z>>31); }
static inline double urand(void){ return (rnd() >> 11) * (1.0/9007199254740992.0); }
static inline u64 getwin(const u64 *B2, long off, int w){ long b = off + 64L*w; long k = b >> 6; int sh = b & 63; return sh ? (B2[k] >> sh) | (B2[k+1] << (64-sh)) : B2[k]; }
static void setbit(u64 *B, long i){ B[i>>6] |= 1ULL << (i&63); }
static long modpow(long a, long e, long m){ long r = 1; a %= m; while (e) { if (e&1) r = r*a%m; a = a*a%m; e >>= 1; } return r; }
static int popc(const u64 *D){ int c = 0; for (int w = 0; w < W; w++) c += __builtin_popcountll(D[w]); return c; }
// count z notin A with A+z dominating, given D = D(A)
static long completions(const int *A, int na, const u64 *D, u64 *Wm, int *zout){
  memset(Wm, 0, 8*W); for (int i = 0; i < na; i++) setbit(Wm, A[i]);
  int cnt = 0;
  for (int w = 0; w < W; w++) { u64 x = D[w]; while (x) { int b = __builtin_ctzll(x); x &= x-1; int y = w*64 + b; long off = p - y;
      for (int k = 0; k < W; k++) Wm[k] |= getwin(S2, off, k);
      if (++cnt % 4 == 0) { int f = 1; for (int k = 0; k < W-1; k++) if (~Wm[k]) { f = 0; break; } if (f && ((Wm[W-1] & lastmask) == lastmask)) return 0; } } }
  long c = 0; *zout = -1;
  for (int k = 0; k < W; k++) { u64 m = ~Wm[k]; if (k == W-1) m &= lastmask; if (m && *zout < 0) *zout = k*64 + __builtin_ctzll(m); c += __builtin_popcountll(m); }
  return c;
}
int main(int argc, char **argv){
  if (argc < 8) { fprintf(stderr, "usage: smc mode p n M R kappa seed [h]\n"); return 1; }
  int mode = atoi(argv[1]); p = atoi(argv[2]); n = atoi(argv[3]); long M = atol(argv[4]); int R = atoi(argv[5]);
  double kappa = atof(argv[6]); u64 seed = strtoull(argv[7],0,10); long h = argc > 8 ? atol(argv[8]) : 1;
  rs = seed * 0x2545F4914F6CDD1DULL + 11;
  W = (p + 63) / 64; long L2 = (2L*p + 192) / 64 + 2;
  S2 = calloc(L2, 8); T2 = calloc(L2, 8);
  char *S = calloc(p, 1);
  if (mode == 0) { for (long x = 1; x < p; x++) S[x*x % p] = 1; }
  else if (mode == 1) { for (int g = 1; g <= (p-1)/2; g++) { if (rnd() & 1) S[g] = 1; else S[p-g] = 1; } }
  else {
    long pm = p - 1, fac[64]; int nf = 0; long t = pm; for (long q = 2; q*q <= t; q++) if (t % q == 0) { fac[nf++] = q; while (t % q == 0) t /= q; } if (t > 1) fac[nf++] = t;
    long g = 2; for (;; g++) { int ok = 1; for (int i = 0; i < nf; i++) if (modpow(g, pm/fac[i], p) == 1) { ok = 0; break; } if (ok) break; }
    long e = (p-1)/(2*h); int *dl = malloc(sizeof(int)*p); long x = 1; for (long i = 0; i < pm; i++) { dl[x] = (int)i; x = x*g % p; }
    char *choice = malloc(e); for (long i = 0; i < e; i++) choice[i] = rnd() & 1;
    for (long y = 1; y < p; y++) { long c = dl[y] % (2*e); if (choice[c % e] ^ (c >= e)) S[y] = 1; }
  }
  for (long y = 1; y < p; y++) if (S[y] == S[p-y]) { fprintf(stderr, "not a tournament\n"); return 1; }
  for (long i = 0; i < 2L*p; i++) { long r = i % p; if (S[r]) setbit(S2, i); if (r && S[p - r]) setbit(T2, i); }
  lastmask = (p & 63) ? ((1ULL << (p & 63)) - 1) : ~0ULL;
  int nfix = (mode == 0) ? 2 : 1, L = n - 1;           // levels nfix..L
  int AW = 16;                                        // max set size stored
  u64 *D = malloc(8L*W*M), *D2 = malloc(8L*W*M);
  int *A = malloc(sizeof(int)*AW*M), *A2 = malloc(sizeof(int)*AW*M);
  int *dpar = malloc(sizeof(int)*M), *dcur = malloc(sizeof(int)*M), *dpar2 = malloc(sizeof(int)*M);
  double *G = malloc(sizeof(double)*M), *cum = malloc(sizeof(double)*M);
  u64 *Wm = malloc(8*W);
  double beta[64]; for (int k = 0; k <= L; k++) beta[k] = kappa * ldexp(1.0, -(n-k));
  // D0 = D(fixed)
  u64 *D0 = malloc(8*W); for (int w = 0; w < W; w++) D0[w] = ~0ULL; D0[W-1] &= lastmask;
  int fixedv[2] = {0, 1};
  for (int i = 0; i < nfix; i++) { long off = p - fixedv[i]; for (int w = 0; w < W; w++) D0[w] &= getwin(T2, off, w); }
  int d0 = popc(D0);
  double sumest = 0, sumlog = 0, sumlog2 = 0; int nz = 0; long certs = 0;
  double ests[4096];
  for (int r = 0; r < R; r++) {
    for (long i = 0; i < M; i++) { memcpy(D + i*W, D0, 8*W); for (int j = 0; j < nfix; j++) A[i*AW + j] = fixedv[j]; dcur[i] = d0; }
    double logZ = 0;    // log of product of mean potentials
    for (int k = nfix + 1; k <= L; k++) {
      // mutation: add random new element
      for (long i = 0; i < M; i++) {
        int *Ai = A + i*AW; int v, ok; do { v = (int)(rnd() % p); ok = 1; for (int j = 0; j < k-1; j++) if (Ai[j] == v) { ok = 0; break; } } while (!ok);
        Ai[k-1] = v; u64 *Di = D + i*W; long off = p - v; for (int w = 0; w < W; w++) Di[w] &= getwin(T2, off, w);
        dpar[i] = dcur[i]; dcur[i] = popc(Di);
      }
      if (k == L) break;
      // potentials and resampling
      double mx = -1e300;
      for (long i = 0; i < M; i++) { G[i] = -beta[k]*dcur[i] + beta[k-1]*dpar[i]; if (G[i] > mx) mx = G[i]; }
      double s = 0; for (long i = 0; i < M; i++) { G[i] = exp(G[i] - mx); s += G[i]; }
      logZ += mx + log(s / M);
      // systematic resampling
      cum[0] = G[0]; for (long i = 1; i < M; i++) cum[i] = cum[i-1] + G[i];
      double u = urand() * s / M; long j = 0;
      for (long i = 0; i < M; i++) { double target = u + i * (s / M); while (j < M-1 && cum[j] < target) j++;
        memcpy(D2 + i*W, D + j*W, 8*W); memcpy(A2 + i*AW, A + j*AW, sizeof(int)*k); dpar2[i] = dcur[j]; }
      u64 *tD = D; D = D2; D2 = tD; int *tA = A; A = A2; A2 = tA; memcpy(dcur, dpar2, sizeof(int)*M);
    }
    // final level L = n-1: particles hold A_{n-1}, D_{n-1}; dpar = |D_{n-2}|
    double fsum = 0;
    for (long i = 0; i < M; i++) {
      int z; long c = completions(A + i*AW, L, D + i*W, Wm, &z);
      if (c) { fsum += (double)c / (p - n + 1) * exp(beta[L-1]*dpar[i] - beta[nfix]*d0);
        if (certs < 3) { printf("CERT dominating %d-set:", n); for (int j = 0; j < L; j++) printf(" %d", A[i*AW+j]); printf(" %d\n", z); }
        certs++; }
    }
    // note: for L-1 == nfix (no resampling steps) the correction is exp(beta[nfix]*d0 - beta[nfix]*d0) = 1
    double est = exp(logZ) * fsum / M;
    ests[r % 4096] = est; sumest += est; if (est > 0) { sumlog += log(est); sumlog2 += log(est)*log(est); nz++; }
  }
  double mean = sumest / R, var = 0; for (int r = 0; r < R && r < 4096; r++) var += (ests[r]-mean)*(ests[r]-mean); var /= (R > 1 ? R-1 : 1);
  double l1 = -log1p(-ldexp(1.0, -n)), lam = (p - n) * l1;
  printf("SMC mode=%d p=%d n=%d h=%ld M=%ld R=%d kappa=%.2f  frac=%.4e +- %.2e (rel %.3f)  nonzero runs=%d  lam'=%.3f psi=%.4f  certs=%ld\n",
         mode, p, n, h, M, R, kappa, mean, sqrt(var/R), sqrt(var/R)/mean, nz, lam, mean > 0 ? -log(mean)/lam : -1, certs);
  return 0;
}
