# uppertheory — running notes (Erdős #902, upper side)

Status legend: [PROVEN] full proof written/checked here; [HEUR] heuristic; [NUM] numerical; [TODO].

## 0. Reformulations used
- X is an n-set with no dominator  <=>  X is a dominating set (every y outside X has an in-neighbour in X).
  So S_n <=> γ(T) > n.
- Cayley tournament Cay(G,S) (|G| odd, S ⊔ S^{-1} = G\{e}), convention y→x iff y^{-1}x ∈ S:
  y dominates X iff y^{-1}X ⊆ S. So X is dominating iff NO left translate y^{-1}X lies inside S,
  iff X·(S∪{e})^{-1}... (abelian: X + (S ∪ {0}) = G, i.e. γ = translational covering number of G by S∪{0}).
- Paley QR_p: X dominating iff no translate X+t lies inside the set of quadratic residues.

## 1. [PROVEN] Theorem A (random symmetric tournaments do not beat ln2·n²2^n)
G any group of odd order acting freely on V, |V| = N. Random G-invariant tournament = independent fair
coin for each G-orbit of unordered pairs (free action => no g reverses an arc, all orbits size |G|).
Claim: for every ε>0, n ≥ n0(ε), N ≤ (ln2 − ε) n² 2^n  =>  P(S_n) → 0 (uniformly in G).
Covers: random tournaments (G trivial; known: Lee 2001 two-point concentration), random Cayley
tournaments on ANY odd-order group (G regular), random k-orbit G-invariant families (like the f(4) searches).
Proof outline (details in THEOREMS.md):
- A_y^X = {y beats X}: P ∈ {0, 2^{-n}}; P=0 for ≤ n(n−1) "conflicted" y (some g with gy=x', gx=y).
- Dependencies: A_y^X ~ A_{y'}^{X'} only via g with gy=y' (shared orbits = |gX ∩ X'|, same orientation)
  or "second type" (opposite orientation => joint prob 0). Each event has ≤ 2n² neighbours per family.
- LLL (x = 2^{-n}(1+8n²2^{-n})): P(X dom) ≥ exp(−μ_X − O(n⁴2^{-n})), μ_X = 2^{-n}(#non-conflicted y) = λ − O(n²2^{-n}), λ = N2^{-n}.
- Suen (Janson 1998): P(X dom ∧ X' dom) ≤ exp(−μ_X − μ_X' + Δ e^{2δ}),
  Δ ≤ λn²(2^{R0(X)−n} + 2^{R0(X')−n} + 2^{R(X,X')−n}), δ ≤ 4n²2^{-n},
  R0(X)=max_{g≠e}|gX∩X|, R(X,X')=max_g |gX∩X'|.
- Good X: R0 ≤ n/2 (all but o(1) fraction: chain-counting gives ≤ n²2^n N^{2n/3+1} bad sets).
- #{X': R(X,X') ≥ r} ≤ N C(n,r) C(N,n−r); fraction ≤ N(n²/(N−n))^r/r!.
  r ≤ n − 3log2 n − 3: Suen gives ρ ≤ e^{O(n)/8}·e^{o(1)}, killed by N^{1−r}; r near n: trivial ρ ≤ e^{λ+o(1)}, killed since λ ≤ (ln2−ε)n².
- Hence E Z² ≤ (1+o(1))(EZ)², EZ ≥ C(N,n)e^{−λ−o(1)} → ∞. ∎
Extension [sketch]: non-free actions with max stabiliser s ≤ 2^n/n^C (e.g. random cyclotomic tournaments
with ≥ n^7 classes) — dependency degree × s. Paley itself (s ≈ p/2) is far outside.

## 2. [PROVEN] Theorem B (F_3^m Cayley: strictly WORSE than random, by a log factor)
n = 3^d. If n2^{n−1} ≤ 3^m ≤ (1−ε)(ln2)·d·n²·2^n (d = log3 n), a uniformly random Cayley tournament
on F_3^m has w.h.p. a dominating d-dim LINEAR SUBSPACE U; so it fails S_n.
- U dominating iff no coset U+c (c∉U) lies in S. Cosets pair up as U+c, U−c = −(U+c) (mutually exclusive),
  so EXACTLY P(U dom) = (1 − 2^{1−n})^{(3^{m−d}−1)/2}.
- #subspaces ≥ 3^{d(m−d)}; E Z_sub → ∞ iff 3^{m−d}2^{-n} < (1−ε)d(m−d)ln3 ⟸ N < (1−ε)ln2·d·n²2^n.
- Distinct U,U' (dim U∩U' = e ≤ d−1): Δ ≤ 3^{m−e}2^{−2n+3^e} ≤ N2^{−5n/3} → 0, δ ≤ (2n+1)2^{-n}; Suen ⇒ ρ → 1 uniformly.
Analogue of Green's theorem (clique number of random Cayley graphs on F_2^n). Group structure matters:
on Z_p the most structured sets (APs) have P(dom) ≈ e^{−λ/2} but only ~p² of them: harmless.

## 3. Structured alternatives
- [PROVEN] Lexicographic composition: γ(T1[T2]) ≤ γ(T1)+1 (T[U] has ≤ 1 source; add an in-neighbour),
  so N multiplies by |T2| ≥ 3 while γ grows ≤ 1: never helps.
- arXiv:2604.08790 Prop 2.3 / Thm 2.2: combines an S_{k1} m1-SET and S_{k2} m2-SET into an S_{k1+k2+1}
  (m1+m2)-set (V1 beats V2 in the first family, V2 beats V1 in the second). For a single tournament (m=1)
  it is vacuous; the single-tournament join with all V1→V2 forces V1 itself to be S_n. With free cross arcs,
  the cross bipartite graph must do all the work (dominator count = Bin-thinned sums: Poisson-like again).
- Relaxation check: covering all n-subsets of a v-set by half-size blocks, WITHOUT tournament skew-symmetry,
  is trivial: affine hyperplanes of F_2^d (2v−2 blocks of size v/2) contain every d points. So the tournament
  duality (dual S_n) is essential to any lower bound; random-like order needs both S_n and dual S_n.
- Exact n-wise uniformity impossible: N×N tournament matrix as an orthogonal array of strength t needs
  N ≥ C(N, ⌊t/2⌋) (Rao) ⇒ t ≤ 3. (Strength 2 = doubly regular.)

## 4. Necessary conditions
- [PROVEN] Variance identity: for a REGULAR tournament and any s,
  Var_{|X|=s} d(X) ≥ λ_s + N(N−1)C((N−3)/4, s)/C(N,s) − λ_s², λ_s = N C((N−1)/2,s)/C(N,s),
  equality iff doubly regular; asymptotically Var ≥ (1 − O(s²2^{−s}))λ_s. So dominator counts can never be
  sub-Poisson in variance at high levels; any concentration must be a LOWER-TAIL-only phenomenon.
- [HEUR] Max-entropy model: for an n-set X let c_v (v ∈ {±1}^n) be the dominance-type counts. If the only
  structure is that m' Fourier coefficients ĉ(S) vanish (DRT: m' = 1+n+C(n,2)), Sanov gives
  P(d(X)=0) ≈ exp(−(N−n)·KL*), KL* ≈ 2^{−n}(1 + m'/(2(2^n−m'))) (quadratic approx; exact for n=4: ψ = KL*/ln(16/15) = 1.91).
  ψ_n → 1 for DRT/Paley ⇒ Paley threshold (ln2+o(1))n²2^n. o(n²2^n) needs ψ → ∞ i.e. all but o(2^n) modes frozen
  for most X, which forces Var(d) = o(λ): contradicts the variance identity ⇒ an o(n²2^n) construction must be
  strongly non-max-entropy (its Poisson-size variance carried by a few systematic modes).

## 5. Paley data (literature + mine)
- Smallest S_n Paley: 3,7,19,67,331,1163 (n=1..6). Brouwer table (q<2048): γ=5 for q∈67–83,107–311,343,379;
  γ=6 for 331,347–367,383–1151; γ=7 from 1163 ⇒ non-monotone (QR_103, QR_343, QR_379 fail).
- p_n/(n²2^n) = 0.44, 0.26, 0.26, 0.41, 0.50 (n=2..6), p_n/(n2^n) = 0.875,0.79,1.05,2.07,3.03 (growing ~linearly).
- Symmetry-adjusted first moment (C(p,n)(1−2^{−n})^{p−n} = p(p−1)/2): 110, 455, 1480 for n=4,5,6;
  actual/heuristic = 0.61, 0.73, 0.79 → trending to 1.
- Literature: Lee 2001 random tournaments γ ∈ {⌊k*⌋+1,⌊k*⌋+2}, k* = lg N − 2lglgN + lglg e; Paley γ > (1/2+o(1))lg p
  (Graham–Spencer); Lu–Wang–Wong 2000: γ(T) ≤ lgN − lglgN + 2.

## 6. TODO
- [NUM] count undominated n-sets in QR_p vs random Cayley Z_p (n=4,5,6) → empirical ψ; compare with max-ent model.
- [NUM] max-ent KL* exact for n up to ~30, predicted Paley thresholds.
- [NUM] Theorem B demo: random Cayley on F_3^10 (N=59049), n=9: find dominating 2-dim subspace.

## 7. [NUM] Lower-tail exponents (done, files scan45.txt, scan6.txt, maxent_out.txt)
psi := -ln(fraction of undominated n-sets)/lam', lam' = -(p-n)ln(1-2^-n). Random model psi≈1.
- Paley QR_p: n=4: psi≈1.2–1.6 (p=31..59); n=5: psi≈1.23–1.50, typically 1.30 (p=127..311);
  n=6: psi = 1.19–1.22 for p=571..1151 (very stable).
- Random Cayley on Z_p: psi≈0.85–0.97 (slightly <1 from midpoint conflicts κ_X ≈ C(n,2)).
- Max-ent model with frozen orders ≤2 (doubly regular): psi = 1.913 (n=4), 1.434 (5), 1.238 (6), 1.137 (7),
  1.081 (8), 1.028 (10); psi−1 ~ n²/2^{n+2}. Model vs Paley at n=6: 1.238 vs 1.20–1.22 (≈2% agreement);
  so Paley ≈ "random subject to double regularity" ⇒ psi_n → 1 ⇒ Paley threshold (ln2+o(1)) n²2^n [HEUR].
- psi(n,k) table (k frozen orders): blows up only when k ≈ n (n=14: k=7 → 1.73, k=10 → 5.97, k=13 → 1.1e4).
- [PROVEN, Welch/frame-potential] for any N×N ±1 matrix (rows y), ĉ(U)=Σ_y Π_{x∈U} M_{yx}: for j ≥ 2, the
  mean of ĉ(SΔS')² over ordered pairs of distinct j-sets is ≥ N(1 − (N−1)/(C(N,j)−1)) ≈ N — random level.
  So orders ≥ 4 cannot be frozen on average ⇒ in the max-ent world no construction beats ln2·n²2^n.
