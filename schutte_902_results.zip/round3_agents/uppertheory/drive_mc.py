# Driver: run mc for given mode/n over a grid of lambda' targets; adaptively choose sample counts.
# usage: python3 drive_mc.py mode n "lam1,lam2,..." target_hits max_seconds_per_point [h] [seed]
import sys, subprocess, time, math, re
def isprime(m):
    if m < 2: return False
    i = 2
    while i*i <= m:
        if m % i == 0: return False
        i += 1
    return True
def prime_near(x, cond):
    m = int(x)
    for d in range(0, 100000):
        for c in (m+d, m-d):
            if c > 5 and isprime(c) and cond(c): return c
mode = int(sys.argv[1]); n = int(sys.argv[2]); lams = [float(t) for t in sys.argv[3].split(',')]
target = int(sys.argv[4]); tmax = float(sys.argv[5]); h = int(sys.argv[6]) if len(sys.argv) > 6 else 1
seed = int(sys.argv[7]) if len(sys.argv) > 7 else 1
l1 = -math.log1p(-2.0**-n)
for lam in lams:
    x = lam / l1 + n
    if mode == 0: p = prime_near(x, lambda c: c % 4 == 3)
    elif mode == 2: p = prime_near(x, lambda c: ((c-1) % (2*h) == 0))
    else: p = prime_near(x, lambda c: True)
    M = 20000; total_hits = 0; t0 = time.time()
    while True:
        t1 = time.time()
        out = subprocess.run(["./mc", str(mode), str(p), str(n), str(M), str(seed)] + ([str(h)] if mode == 2 else []), capture_output=True, text=True).stdout
        dt = time.time() - t1
        hits = int(re.search(r"hits=(\d+)", out).group(1))
        if hits >= target or time.time() - t0 + 4*dt > tmax: break
        # scale M
        if hits == 0: M *= 8
        else: M = int(M * min(8.0, 1.2*target/hits))
        if dt * (M / max(1, int(re.search(r"samples=(\d+)", out).group(1)))) > tmax: M = int(M * tmax / (dt*M/int(re.search(r"samples=(\d+)", out).group(1))+1e-9)*0.5)
    print(out.strip(), " time=%.1fs" % dt, flush=True)
