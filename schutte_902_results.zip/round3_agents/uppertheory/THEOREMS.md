# uppertheory — rigorous statements and proofs

Notation. T a tournament on V, |V| = N. D(X) = {y ∉ X : y → x for all x ∈ X}. X is *dominating* (every vertex
outside X has an in-neighbour in X) iff D(X) = ∅. So S_n ⟺ no n-set is dominating ⟺ γ(T) > n. λ := N·2^(−n).
By Szekeres, S_n is impossible for N < (n+2)2^(n−1) − 1, so all statements below may assume N ≥ n·2^(n−1).

Tools (events are cylinder events of independent fair coins; i ∼ j iff their coin sets meet — a dependency graph).
* **LLL** (asymmetric): if P(B_i) ≤ x_i ∏_{j∼i}(1 − x_j) with x_i ∈ [0,1), then P(∩ B̄_i) ≥ ∏(1 − x_i).
* **Suen–Janson** (S. Janson, *New versions of Suen's correlation inequality*, Random Struct. Alg. 13 (1998)):
  with μ = Σ P(B_i), Δ = Σ_{{i,j}: i∼j} P(B_i ∩ B_j), δ = max_i Σ_{j∼i} P(B_j): P(∩ B̄_i) ≤ exp(−μ + Δ e^{2δ}).
  (No monotonicity needed.)

---------------------------------------------------------------------------------------------------------------
## Theorem A (symmetrising the random construction never beats the constant ln 2)

Let G be a group of odd order acting freely on V, |V| = N, and let T be a uniformly random G-invariant tournament.
For every ε > 0 there is n₀(ε) such that for n ≥ n₀ and N ≤ (ln 2 − ε)·n²·2^n,
  P(T has S_n) ≤ ε_n → 0,   with ε_n depending only on n, ε (not on G).

Special cases: G = {e} (random tournaments; two-point concentration of γ is Lee 2001); G acting regularly
(**random Cayley tournaments on any group of odd order**, e.g. Z_N, Z_p, F_3^m, non-abelian); G with k orbits
(random members of the "k-orbit G-invariant" families searched for f(4)).

**Lemma A0 (model).** (a) No g maps an ordered pair (u,v), u ≠ v, to (v,u): g(u,v) = (v,u) ⇒ g²u = u ⇒ g² = e
(free) ⇒ g = e (odd order). (b) Hence G acts freely on unordered pairs; each orbit O of unordered pairs splits into
two ordered orbits O⁺, O⁻ = reverse(O⁺); a G-invariant tournament takes all of O⁺ or all of O⁻; the uniform measure
is one independent fair coin per orbit. (c) For y, y' ∈ V at most one g has gy = y'. (d) Squaring is a bijection of
G (g = (g²)^{(|G|+1)/2}).

Fix an n-set X. For y ∉ X, A_y^X := {y → x ∀ x ∈ X}: the conjunction of n literals, the literal for x being
"the coin of orbit{y,x} points y → x".

**Lemma A1.** (a) If {y,x}, {y,x'} (x ≠ x') lie in one orbit, then g(y,x) = (x',y) for some g (g(y,x) = (y,x')
would force gy = y, g = e); the literals conflict and P(A_y^X) = 0 ("y conflicted"). Then gy = x', gx = y, so
g²x = x', which (A0 c,d) determines g, hence y = gx: at most n(n−1) conflicted y. Otherwise P(A_y^X) = 2^(−n).
Thus μ_X := Σ_{y∉X} P(A_y^X) ∈ [λ − n²2^(−n), λ].
(b) Let X, X' be n-sets, y ∉ X, y' ∉ X', (y,X) ≠ (y',X'). If A_y^X, A_{y'}^{X'} share a coin, the sharing is via
g(y,x) = (y',x') (type i; then g is the unique element with gy = y', and the coins shared with *equal* orientation
are those of x ∈ X with gx ∈ X', r_g := |gX ∩ X'| of them) or via g(y,x) = (x',y') (type ii; opposite orientation,
forcing P(A ∩ A') = 0). Hence P(A_y^X ∩ A_{y'}^{X'}) ≤ 2^(−2n + r_g) if y' = gy, and = 0 if only type ii occurs.
(c) Each A_y^X is adjacent to ≤ 2n² events A_{y'}^{X'} (fixed X'): type i needs gX ∩ X' ≠ ∅ (≤ n² such g, one per
(x,x') ∈ X × X'), type ii is fixed by (x,x') via gy = x', y' = gx (≤ n²).

Put R₀(X) := max_{g≠e} |gX ∩ X|, R(X,X') := max_{g∈G} |gX ∩ X'|. Note Σ_g |gX ∩ X'| ≤ n².

**Lemma A2 (lower bound, LLL).** For n ≥ n₀ and every X: P(X dom) ≥ exp(−μ_X − 10n⁴2^(−n)).
*Proof.* Use only non-conflicted y; degrees ≤ 2n². Take x = 2^(−n)(1+η), η = 8n²2^(−n) (≤ 1/2). Then
2n²x ≤ 3n²2^(−n) ≤ η/2 and x(1−x)^{2n²} ≥ x(1 − 2n²x) ≥ 2^(−n)(1+η)(1−η/2) ≥ 2^(−n). LLL gives
P ≥ (1−x)^{2^n μ_X} ≥ exp(−2^n μ_X (x + x²)) ≥ exp(−μ_X(1 + η)(1 + x)) ≥ exp(−μ_X − 10 n² 2^(−n) μ_X), and μ_X ≤ λ ≤ n². ∎

**Lemma A3 (upper bounds, Suen).** For n ≥ n₀ (so δ ≤ 4n²2^(−n) and e^{2δ} ≤ 2):
P(X dom) ≤ exp(−μ_X + 2Δ_X) and, for X ≠ X', P(X dom ∧ X' dom) ≤ exp(−μ_X − μ_{X'} + 2(Δ_X + Δ_{X'} + Δ_{XX'})), where
  Δ_X ≤ (λ/2)·n²·2^{R₀(X) − n},   Δ_{XX'} ≤ λ·n²·2^{R(X,X') − n}.
*Proof.* By A1(b), Δ_{XX'} ≤ Σ_{y∈V} Σ_{g: r_g ≥ 1} 2^{−2n + r_g} ≤ N 2^(−2n) Σ_g r_g 2^{r_g} ≤ N2^(−2n) n² 2^{R}.
Same for Δ_X with g ≠ e and unordered pairs. ∎

**Lemma A4 (few self-overlapping sets).** #{X : R₀(X) > n/2} ≤ n²·2^n·N^{2n/3 + 1} = o(C(N,n)) for N ≥ 2^(n−1).
*Proof.* Fix g ≠ e, of order o ≥ 3; V is a union of ⟨g⟩-cycles of length o. X ∩ (cycle) is a union of maximal runs
{x, gx, …, g^{ℓ−1}x}; a non-full run contributes ℓ−1 to |{x ∈ X : gx ∈ X}| = |gX ∩ X|, a full cycle contributes o.
With a non-full runs and b full cycles, |gX ∩ X| = n − a and a + 3b ≤ n; X is fixed by the a run starts, the lengths
(≤ 2^n compositions) and the b cycles: ≤ 2^n N^{a+b} sets. If n − a > n/2 then a + b ≤ a + (n−a)/3 < 2n/3. Sum over
(a,b) and g. Finally C(N,n) ≥ (N/n)^n. ∎

**Proof of Theorem A.** Assume n2^(n−1) ≤ N ≤ (ln2 − ε)n²2^n. Let 𝒢 = {X : R₀(X) ≤ n/2}, Z = Σ_{X∈𝒢} 1[X dom].
For X ∈ 𝒢, Δ_X ≤ n⁴2^(−n/2), so by A1–A3, P(X dom) = e^{−λ + θ_X} with |θ_X| ≤ η₀ := 3n⁴2^(−n/2) = o(1).
*First moment.* EZ ≥ |𝒢| e^{−λ−η₀}, |𝒢| = (1−o(1))C(N,n), ln C(N,n) ≥ n ln(N/n) ≥ n(n−1) ln 2, so
ln EZ ≥ εn² − n ln2 − 1 → ∞.
*Second moment.* For X ≠ X' in 𝒢 with R = R(X,X'): A3 gives P(both) ≤ e^{−2λ + 4η₀ + 2λn²2^{R−n}}, and trivially
P(both) ≤ P(X dom) ≤ e^{−λ+η₀}. So P(both) ≤ P(X dom)P(X' dom)·e^{6η₀}·min(e^{λ}, e^{2λn²2^{R−n}}).
Pairs with R ≤ 1 contribute ≤ e^{6η₀ + 4λn²2^(−n)}(EZ)² = (1+o(1))(EZ)². For r ≥ 2, given X,
#{X' : R(X,X') ≥ r} ≤ |G|·C(n,r)·C(N,n−r) ≤ C(N,n)·N(n²/(N−n))^r / r!. With L := ln((N−n)/n²) ≥ (n−1)ln2 − ln n − 1:
  E Z²/(EZ)² ≤ 1/EZ + 1 + o(1) + (1+o(1)) Σ_{r=2}^{n} exp(ln N − rL + min{λ, 2λn²2^{r−n}}).
– 2 ≤ r ≤ n − k₀, k₀ = ⌈3 log₂ n⌉ + 3: 2λn²2^{r−n} ≤ 2ln2·n⁴2^{−k₀} ≤ (ln2/4)n and ln N − 2L ≤ −(n−1)ln2 + 3ln n + O(1);
  the sum is ≤ exp(−(3/4 − o(1)) n ln 2) → 0.
– r > n − k₀: ln N − rL + λ ≤ −(n − k₀)L + ln N + (ln2 − ε)n² ≤ −εn² + O(n log² n) → −∞ (n terms).
So Var Z = o((EZ)²) and P(S_n) ≤ P(Z = 0) ≤ Var Z/(EZ)² → 0. ∎

*Remarks.* (1) It is a statement about typical members: a measure-zero special member (an "algebraic" one) is not
excluded. (2) Non-free actions with all stabilisers of size ≤ s: every degree bound gets a factor s; the proof goes
through for s ≤ 2^n/n^C (e.g. random cyclotomic tournaments on Z_p with ≥ n^C classes). Paley (s = (p−1)/2) is far
outside. (3) The matching upper half (S_n w.h.p. for N ≥ (ln2+ε)n²2^n) is FALSE for some groups — Theorem B.

---------------------------------------------------------------------------------------------------------------
## Theorem B (random Cayley tournaments on F_3^m are worse than random, by a factor log₃ n)

Let n = 3^d and let T be a uniformly random Cayley tournament on (F_3^m, +) (S ⊔ −S = F_3^m∖{0}; y → x iff x−y ∈ S).
For every ε > 0, if n ≥ n₀(ε) and n2^(n−1) ≤ 3^m ≤ (1−ε)·ln2·d·n²·2^n, then with probability 1 − o(1) some
d-dimensional linear subspace U is a dominating set; in particular T fails S_n.
(For comparison, random tournaments and random Cayley tournaments in general are S_n only above (ln 2 + o(1))n²2^n
by Theorem A / first moment, and random tournaments ARE S_n w.h.p. above (ln2 + ε)n²2^n.)

*Proof.* y dominates U iff U − y ⊆ S; for y ∈ U, U − y = U ∋ 0 ∉ S. So U is dominating iff no coset U + c (c ∉ U)
is contained in S. The 3^{m−d} − 1 cosets ≠ U pair up as {U+c, U−c} with U−c = −(U+c) ≠ U+c; the two events are
mutually exclusive (S contains exactly one of ±g) and each has probability 2^(−n) (the n elements of U+c lie in n
distinct pairs {±g}); distinct pairs of cosets use disjoint coins. Hence exactly
  P(U dom) = (1 − 2^{1−n})^{(3^{m−d} − 1)/2}.
Let Z = #dominating d-subspaces. EZ = [m,d]_3 P(U dom) ≥ 3^{d(m−d)} exp(−μ(1+2^{1−n})), μ := (3^{m−d}−1)2^(−n) ≤ (N/n)2^(−n).
Under the hypothesis μ ≤ (1−ε)·d·n·ln2 while d(m−d)ln3 = d ln(N/n) ≥ d(n−1)ln2, so ln EZ ≥ d(εn − 2)ln 2 → ∞.
For U ≠ U' with e = dim(U ∩ U') ≤ d − 1, apply Suen to the family {U+c ⊆ S} ∪ {U'+c' ⊆ S}: within a family the
only adjacencies are exclusive pairs (contribute 0 to Δ); a coset U+c meets ±(U'+c') for ≤ 2·3^{d−e} cosets c' and a
consistent overlap is a coset of U ∩ U' (size 3^e), so
  Δ ≤ 3^{m−d}·3^{d−e}·2^{−2n+3^e} ≤ N·2^{−2n + n/3} → 0,   δ ≤ (2n+1)2^(−n) → 0.
So P(U dom ∧ U' dom) ≤ exp(−2μ + 2Δ) ≤ P(U dom)P(U' dom)·exp(2Δ + 4μ2^(−n)) = (1+o(1))P(U dom)P(U' dom), uniformly.
Hence Var Z ≤ EZ + o(1)(EZ)² and P(Z = 0) → 0. ∎

*Numerical certificate* (thmB_demo.c, thmB_demo_out.txt): m = 10 (N = 59049), n = 9: E Z = 193.1; a random
Cayley tournament on F_3^10 was sampled and three dominating 2-dim subspaces were found (and verified vertex by
vertex) among ~9·10^5 random subspaces (rate 3.4·10^(−6) vs predicted 2.66·10^(−6)). For a uniformly random tournament
on 59049 vertices, E #dominating 9-sets = 1.8·10^(−13), so it has S_9 with probability > 1 − 10^(−12).
This is the tournament analogue of Green's theorem on clique numbers of random Cayley graphs on F_2^n.

---------------------------------------------------------------------------------------------------------------
## Proposition C (lexicographic compositions are useless)

If T₁ has minimum in-degree ≥ 1 and T₂ is arbitrary (or different T₂'s are substituted into different vertices),
then γ(T₁) ≤ γ(T₁[T₂]) ≤ γ(T₁) + 1, while |V| is multiplied by ≥ 3 (if T₂ is to have no source).
*Proof.* Lower: the projection of a dominating set dominates T₁. Upper: let U be a minimum dominating set of T₁. The
subtournament T₁[U] has at most one source u₀; add an in-neighbour w of u₀ (w ∉ U). Then every vertex of T₁ has an
in-neighbour in U' = U ∪ {w}, so U' × {v₀} dominates T₁[T₂]. ∎  So an S_n composition needs T₁ to be S_{n−1} and
costs a factor ≥ 3 per level, versus f(n) ≥ 2f(n−1) + 1 achievable growth ≈ 2(1 + O(1/n)).

---------------------------------------------------------------------------------------------------------------
## Proposition D (dominator counts are never sub-Poisson: variance identity)

Let T be regular (r = (N−1)/2) and X a uniformly random s-set, d(X) = |D(X)|. Then
  E d = λ_s := N C(r,s)/C(N,s),   Var d ≥ λ_s + N(N−1)·C((N−3)/4, s)/C(N,s) − λ_s²,
with equality iff T is doubly regular. Numerically the right side equals λ_s(1 − (1 + s + C(s,2))2^(−s) + O(sλ_s/N)),
e.g. ratio 0.661 (N=1163,s=6), 0.9457 (N=7383,s=10), 0.9998 (s=20) (computed exactly).
*Proof.* E d(d−1) = Σ_{y≠z} C(c_yz, s)/C(N,s), c_yz = |N⁺(y) ∩ N⁺(z)|, Σ_{y≠z} c_yz = Σ_x d⁻(x)(d⁻(x)−1) = N r(r−1),
mean (N−3)/4. t ↦ C(t,s) (piecewise-linear between integers) is convex and lies above the polynomial for
t ≥ s−1; Jensen. ∎  Interpretation: in Fourier language a doubly regular tournament freezes exactly the 1 + s + C(s,2)
modes of order ≤ 2 of the 2^s dominance-pattern modes; no regular tournament can reduce the variance further.

## Proposition E (higher-order dominance correlations are at least random on average — Welch bound)

Let M be any N×N ±1 matrix (tournament: M_yx = +1 iff y → x, M_yy = +1) and ĉ(U) := Σ_y ∏_{x∈U} M_yx. For j ≥ 1,
  (1/(C(N,j)(C(N,j)−1))) Σ_{S≠S', |S|=|S'|=j} ĉ(S Δ S')² ≥ N·(1 − (N−1)/(C(N,j) − 1)).
*Proof.* Vectors w_S = (∏_{x∈S}M_yx)_y have ⟨w_S, w_{S'}⟩ = ĉ(S Δ S'), ‖w_S‖² = N; the Gram matrix has rank ≤ N, and
(tr G)² ≤ rank·tr(G²). ∎  For j = 2 and a doubly regular T (order-2 modes ≈ 0) this says the order-4 modes have mean
square ≥ (1 − O(1/N))N — exactly the value for a random tournament. So "design-like" freezing of dominance correlations
is impossible beyond order 2, even approximately (Rao's bound gives the exact version: strength ≤ 3).
