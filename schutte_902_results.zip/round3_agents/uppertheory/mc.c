// Monte Carlo estimate of the fraction of DOMINATING n-sets (= n-sets with no dominator) in a
// Cayley tournament on Z_p (rows generated on the fly by rotating one bitset, memory O(p)).
//   mode 0: Paley QR_p (p = 3 mod 4 prime).  Affine group transitive on unordered pairs => fix {0,1} in A.
//   mode 1: uniformly random Cayley tournament on Z_p (one fair coin per pair {g,-g}).  Fix {0}.
//   mode 2: random cyclotomic tournament: H = subgroup of F_p^* of odd order h (h | (p-1)/2), one coin per
//           coset pair {aH, -aH}; e = (p-1)/(2h) coins.  Fix {0}.   (argument 'h')
// Estimator: A = random (n-1)-set containing the fixed points; c(A) = #{z notin A : A+z dominating}.
//   frac = E[c(A)]/(p-n+1)  exactly (unbiased), by transitivity (see notes.md).
// Convention: y -> x iff x - y in S.  A+z dominating iff no y in D(A) beats z (y != z).
// usage: mc mode p n samples seed [h]
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
typedef uint64_t u64;
static int p, n, W;
static u64 *S2, *T2;   // doubled bitsets of S and T = -S, length 2p (+pad)
static u64 rs;
static inline u64 rnd(void){ u64 z = (rs += 0x9E3779B97F4A7C15ULL); z = (z ^ (z>>30))*0xBF58476D1CE4E5B9ULL; z = (z ^ (z>>27))*0x94D049BB133111EBULL; return z ^ (z>>31); }
static inline u64 getwin(const u64 *B2, long off, int w){ long b = off + 64L*w; long k = b >> 6; int sh = b & 63; return sh ? (B2[k] >> sh) | (B2[k+1] << (64-sh)) : B2[k]; }
static void setbit(u64 *B, long i){ B[i>>6] |= 1ULL << (i&63); }
static int getbit(const u64 *B, long i){ return (B[i>>6] >> (i&63)) & 1; }
static long modpow(long a, long e, long m){ long r = 1; a %= m; while (e) { if (e&1) r = r*a%m; a = a*a%m; e >>= 1; } return r; }
int main(int argc, char **argv){
  if (argc < 6) { fprintf(stderr, "usage: mc mode p n samples seed [h]\n"); return 1; }
  int mode = atoi(argv[1]); p = atoi(argv[2]); n = atoi(argv[3]); long M = atol(argv[4]); u64 seed = strtoull(argv[5],0,10);
  long h = argc > 6 ? atol(argv[6]) : 1;
  rs = seed * 0x2545F4914F6CDD1DULL + 7;
  W = (p + 63) / 64;
  long L2 = (2L*p + 192) / 64 + 2;
  S2 = calloc(L2, 8); T2 = calloc(L2, 8);
  char *S = calloc(p, 1);
  if (mode == 0) { if (p % 4 != 3) { fprintf(stderr, "p must be 3 mod 4\n"); return 1; } for (long x = 1; x < p; x++) S[x*x % p] = 1; }
  else if (mode == 1) { for (int g = 1; g <= (p-1)/2; g++) { if (rnd() & 1) S[g] = 1; else S[p-g] = 1; } }
  else if (mode == 2) {
    if ((p-1) % (2*h) || h % 2 == 0) { fprintf(stderr, "need h odd, h | (p-1)/2\n"); return 1; }
    // find generator g of F_p^*
    long pm = p - 1, fac[64]; int nf = 0; long t = pm; for (long q = 2; q*q <= t; q++) if (t % q == 0) { fac[nf++] = q; while (t % q == 0) t /= q; } if (t > 1) fac[nf++] = t;
    long g = 2; for (;; g++) { int ok = 1; for (int i = 0; i < nf; i++) if (modpow(g, pm/fac[i], p) == 1) { ok = 0; break; } if (ok) break; }
    long e = (p-1)/(2*h);           // classes: index of x = dlog(x) mod 2e ; coset pair {i, i+e}
    // build dlog table
    int *dl = malloc(sizeof(int)*p); long x = 1; for (long i = 0; i < pm; i++) { dl[x] = (int)i; x = x*g % p; }
    char *choice = malloc(e); for (long i = 0; i < e; i++) choice[i] = rnd() & 1;
    for (long y = 1; y < p; y++) { long c = dl[y] % (2*e); long base = c % e; int upper = c >= e; if (choice[base] ^ upper) S[y] = 1; }
    // sanity: S and -S partition
    for (long y = 1; y < p; y++) if (S[y] == S[p-y]) { fprintf(stderr, "not a tournament (h even?)\n"); return 1; }
    free(dl); free(choice);
  }
  for (long i = 0; i < 2L*p; i++) { long r = i % p; if (S[r]) setbit(S2, i); if (r && S[p - r]) setbit(T2, i); }
  u64 lastmask = (p & 63) ? ((1ULL << (p & 63)) - 1) : ~0ULL;
  int nfix = (mode == 0) ? 2 : 1;
  int A[64]; u64 *D = malloc(8*W), *Wm = malloc(8*W), *Ab = calloc(W, 8);
  double sum = 0, sum2 = 0; long hits = 0;
  for (long it = 0; it < M; it++) {
    A[0] = 0; if (nfix == 2) A[1] = 1;
    for (int i = nfix; i < n-1; i++) { int v, ok; do { v = (int)(rnd() % p); ok = 1; for (int j = 0; j < i; j++) if (A[j] == v) { ok = 0; break; } } while (!ok); A[i] = v; }
    for (int w = 0; w < W; w++) D[w] = ~0ULL; D[W-1] &= lastmask;
    for (int i = 0; i < n-1; i++) { long off = p - A[i]; for (int w = 0; w < W; w++) D[w] &= getwin(T2, off, w); }
    memset(Ab, 0, 8*W); for (int i = 0; i < n-1; i++) setbit(Ab, A[i]);
    for (int w = 0; w < W; w++) Wm[w] = Ab[w];
    int full = 0, cnt = 0;
    for (int w = 0; w < W && !full; w++) { u64 x = D[w]; while (x) { int b = __builtin_ctzll(x); x &= x-1; int y = w*64 + b; long off = p - y;
        for (int k = 0; k < W; k++) Wm[k] |= getwin(S2, off, k);
        if (++cnt % 4 == 0) { int f = 1; for (int k = 0; k < W-1; k++) if (~Wm[k]) { f = 0; break; } if (f && ((Wm[W-1] & lastmask) == lastmask)) { full = 1; break; } } } }
    long c = 0;
    if (!full) { for (int k = 0; k < W-1; k++) c += __builtin_popcountll(~Wm[k]); c += __builtin_popcountll(~Wm[W-1] & lastmask); }
    sum += c; sum2 += (double)c*c; if (c) hits++;
  }
  double mean = sum / M, var = sum2 / M - mean*mean, se = sqrt(var / M);
  double frac = mean / (p - n + 1), fse = se / (p - n + 1);
  double l1 = -log1p(-ldexp(1.0, -n));
  double lam = (p - n) * l1, lam2 = (p - n - n*(n-1)/2.0) * l1;
  printf("mode=%d p=%d n=%d h=%ld samples=%ld hits=%ld frac=%.5e +- %.2e  lam'=%.4f psi=%.4f (+-%.4f)  lam''=%.4f psi''=%.4f\n",
         mode, p, n, h, M, hits, frac, fse, lam, frac > 0 ? -log(frac)/lam : -1, frac > 0 ? (fse/frac)/lam : 0, lam2, frac > 0 ? -log(frac)/lam2 : -1);
  return 0;
}
