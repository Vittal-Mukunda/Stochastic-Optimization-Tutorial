# uppertheory — notes.md (run of 2026-10-17)

Status legend: [PROVEN] full proof checked; [HEUR] heuristic; [NUM] numerical; [TODO].

## 0. Starting point
An earlier run of this agent DID write files (despite the coordinator's note): NOTES.md and THEOREMS.md in this
directory (dated 2026-10-16 19:06-19:10), plus undom.c, maxent.py, thmB_demo.c and outputs. This file continues them.

Re-verification (this run, line by line):
- THEOREMS.md Theorem A (random G-invariant tournaments, G odd order acting freely; covers random Cayley
  tournaments on ANY odd-order group): proof re-checked step by step (Lemmas A0-A4, first and second moment). [PROVEN]
  Constants are loose but every inequality holds for n >= n0(eps).
- Theorem B (random Cayley tournaments on F_3^m have a dominating d-dim subspace up to (1-eps) ln2 * d * n^2 2^n,
  n = 3^d): re-checked (exact formula P(U dom) = (1-2^{1-n})^{(3^{m-d}-1)/2}; Suen with Delta <= N 2^{-5n/3}). [PROVEN]
- Prop C (lexicographic composition), Prop D (variance identity for regular tournaments), Prop E (Welch bound): re-checked. [PROVEN]

## 1. Plan for this run
(a) [NUM] Paley lower-tail exponent psi_n for n = 7..12 by Monte Carlo (exhaustive counts only reach n = 6),
    compared with the max-entropy doubly-regular prediction psi(n,2) and with random Cayley tournaments.
(b) [NUM] Random cyclotomic tournaments with e classes (interpolating Paley e=1 and random Cayley e=(p-1)/2).
(c) [PROVEN?] Extend Theorem A to non-free actions: G acting freely on unordered pairs with point stabilisers of
    order <= s (random cyclotomic tournaments). Goal: symmetry groups of order up to N*2^n/poly(n).
(d) [NUM] Prime-power Paley anomalies (gamma(QR_343)=5, gamma(QR_1331)=6 are below their neighbours).

## 2. [NUM] Paley lower-tail exponents for n = 7..14 (Monte Carlo; mc.c + drive_mc.py)
Estimator: A = random (n-1)-set through {0,1} (affine group of QR_p is transitive on unordered pairs),
c(A) = #{z : A+z dominating}; frac := P(random n-set has no dominator) = E[c(A)]/(p-n+1) exactly (unbiased).
Validated against the exhaustive counts of the previous run: p=311,n=6: MC 3.810e-3 +- 2.5e-5 vs exact 3.786e-3;
p=571,n=6: 2.019e-5 +- 1.8e-7 vs 2.030e-5; p=127,n=5: 7.325e-3 vs 7.333e-3.
psi := -ln(frac)/lam', lam' = -(p-n) ln(1-2^-n)  (psi = 1 exactly in expectation for a uniformly random tournament);
psi'' uses p-n-C(n,2) (the C(n,2) midpoints of pairs of X can never dominate X in a Cayley tournament on Z_p).
Raw output: mc_paley_7.txt (below), mc_paley_8_10.txt, mc_paley_11_14.txt.

 n | p (lam')                         | psi (+-se)                                   | max-ent DRT psi(n,2)
 7 | 1031(8) 1283(10) 1531(12) 1787(14) 2039(16) | 1.111 1.118 1.122 1.131 1.126 (+-0.002-0.004) | 1.137
 8 | 2063(8) 3079(12) 4099(16)        | 1.081 1.074 1.077 (+-0.002-0.005)            | 1.081
 9 | 4099(8) 6143(12) 8191(16)        | 1.047 1.044 1.043 (+-0.002-0.005)            | 1.048
10 | 8191(8) 12263(12) 16363(16)      | 1.022 1.025 1.022 (+-0.002-0.006)            | 1.028
11 | 16411(8) 32771(16)               | 1.016 1.017 (+-0.003-0.006)                  | 1.017
12 | 32779(8) 65539(16)               | 1.007 1.006 (+-0.006-0.008)                  | 1.010
13 | 65543(8) 114691(14)              | 1.002 0.995 (+-0.006-0.011)                  | 1.006
14 | 131071(8) 229399(14)             | 1.007 0.991 (+-0.005-0.015)                  | 1.003
(n=7 low-lam' points: 263(2) 1.036, 523(4) 1.084, 787(6) 1.110: psi rises with lam' and saturates by lam' ~ 8.)
CONCLUSION [NUM]: for 7 <= n <= 14 the Paley lower-tail exponent agrees with the max-entropy "random subject to
double regularity" prediction to within the statistical error, and psi_n -> 1 (psi_n - 1 ~ 0.27 n^2 2^-n).
If psi stays at this value up to the threshold (it is flat in lam' from lam' ~ 8 to 16 for every n tested), the
smallest S_n Paley prime is p_n ~ (ln2/psi_n + o(1)) n^2 2^n -> (ln 2 + o(1)) n^2 2^n, i.e. Paley is asymptotically
no better than a uniformly random tournament, even in the constant. [HEUR extrapolation from lam' <= 16 to the
threshold lam' ~ n^2 ln 2.]
