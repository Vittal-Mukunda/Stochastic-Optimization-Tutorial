// Count undominated n-sets (= dominating n-sets) in a Cayley tournament on Z_p.
// mode 0: Paley QR_p (p = 3 mod 4), uses affine symmetry: count n-sets containing {0,1}.
// mode 1: random Cayley tournament on Z_p (seeded), uses translations: count n-sets containing {0}.
// Convention: y -> x iff x - y in S.  X undominated (no vertex beats all of X) iff X dominating.
// Output: total count U, fraction U/C(p,n), lambda' = -(p-n) ln(1-2^-n), psi = -ln(frac)/lambda'.
// Optional histogram (hist=1) of d(X) for small d over n-sets through the fixed set (n<=5 sensible).
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <string.h>
#define MAXW 40
typedef uint64_t u64;
static int p, n, W, mode, hist;
static u64 outb[2600][MAXW], inb[2600][MAXW];
static int fixedset[2], nf;
static long double U0 = 0;            // count of undominated n-sets containing the fixed set
static long double H[64];             // histogram of d over n-sets containing the fixed set
static int B[16];
static u64 D[16][MAXW];
static u64 rng_state;
static u64 rnd(void){ rng_state ^= rng_state << 13; rng_state ^= rng_state >> 7; rng_state ^= rng_state << 17; return rng_state; }

static void leaf(int depth) {
  // A = fixed ∪ B[0..depth-1], |A| = n-1; D[depth] = D(A).
  u64 *d = D[depth];
  int last = depth ? B[depth-1] : (nf==2 ? 1 : 0);
  if (!hist) {
    u64 Wm[MAXW]; memset(Wm, 0, sizeof(u64)*W);
    for (int w = 0; w < W; w++) { u64 x = d[w]; while (x) { int b = __builtin_ctzll(x); x &= x-1; int y = w*64+b; for (int k = 0; k < W; k++) Wm[k] |= outb[y][k]; } }
    // bad z: z > last, z < p, z not in Wm
    long cnt = 0;
    for (int z = last+1; z < p; z++) if (!((Wm[z>>6] >> (z&63)) & 1)) cnt++;
    U0 += cnt;
  } else {
    for (int z = last+1; z < p; z++) {
      int c = 0; for (int k = 0; k < W; k++) c += __builtin_popcountll(d[k] & inb[z][k]);
      if (c < 64) H[c] += 1;
      if (c == 0) U0 += 1;
    }
  }
}
static void dfs(int depth, int start) {
  int need = n - 1 - nf;               // size of B
  if (depth == need) { leaf(depth); return; }
  for (int b = start; b <= p - 1 - (need - depth); b++) {   // leave room for z
    B[depth] = b;
    for (int k = 0; k < W; k++) D[depth+1][k] = D[depth][k] & inb[b][k];
    dfs(depth+1, b+1);
  }
}
int main(int argc, char **argv) {
  if (argc < 4) { fprintf(stderr, "usage: undom p n mode [seed] [hist]\n"); return 1; }
  p = atoi(argv[1]); n = atoi(argv[2]); mode = atoi(argv[3]);
  u64 seed = argc > 4 ? strtoull(argv[4],0,10) : 1; hist = argc > 5 ? atoi(argv[5]) : 0;
  rng_state = seed*0x9E3779B97F4A7C15ULL + 12345;
  W = (p + 63) / 64;
  char *S = calloc(p, 1);
  if (mode == 0) { for (long x = 1; x < p; x++) S[(x*x) % p] = 1; }
  else { for (int g = 1; g <= (p-1)/2; g++) { if (rnd() & 1) S[g] = 1; else S[p-g] = 1; } }
  for (int y = 0; y < p; y++) for (int x = 0; x < p; x++) if (S[((x - y) % p + p) % p]) { outb[y][x>>6] |= 1ULL << (x&63); inb[x][y>>6] |= 1ULL << (y&63); }
  if (mode == 0) { nf = 2; fixedset[0] = 0; fixedset[1] = 1; if (!S[1]) { fprintf(stderr,"1 not in S\n"); return 1; } }
  else { nf = 1; fixedset[0] = 0; }
  for (int k = 0; k < W; k++) D[0][k] = ~0ULL;
  // clear bits >= p
  for (int x = p; x < W*64; x++) D[0][x>>6] &= ~(1ULL << (x&63));
  for (int i = 0; i < nf; i++) for (int k = 0; k < W; k++) D[0][k] &= inb[fixedset[i]][k];
  dfs(0, nf == 2 ? 2 : 1);
  long double total = (mode == 0) ? U0 * (long double)p * (p-1) / ((long double)n*(n-1)) : U0 * (long double)p / n;
  long double lc = lgammal(p+1) - lgammal(n+1) - lgammal(p-n+1);
  long double lam = -(p - n) * log1pl(-ldexpl(1.0L, -n));
  long double frac = total / expl(lc);
  printf("p=%d n=%d mode=%d seed=%llu  U_fixed=%.0Lf  U=%.6Le  frac=%.6Le  lam'=%.4Lf  psi=%.4Lf\n",
         p, n, mode, (unsigned long long)seed, U0, total, frac, lam, total > 0 ? -logl(frac)/lam : -1.0L);
  if (hist) {
    long double tot = 0; for (int c = 0; c < 64; c++) tot += H[c];
    printf("  hist(d) over n-sets through fixed set (first 16):");
    for (int c = 0; c < 16; c++) printf(" %.4Le", H[c]/tot);
    printf("\n");
  }
  return 0;
}
