// Theorem B demo: random Cayley tournament on F_3^m (m=10, N=59049); search random 2-dim subspaces U (|U|=9)
// for a dominating one (no coset U+c, c notin U, inside S), then verify domination directly vertex by vertex.
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#define M 10
#define N 59049
static int add5[243][243], neg5[243];
static unsigned char S[N];
static uint64_t st=88172645463325252ULL; static uint64_t rnd(){st^=st<<13;st^=st>>7;st^=st<<17;return st;}
static int add(int a,int b){return add5[a/243][b/243]*243+add5[a%243][b%243];}
static int neg(int a){return neg5[a/243]*243+neg5[a%243];}
static int smul(int s,int a){return s==0?0:(s==1?a:neg(a));}
int main(int argc,char**argv){
  long maxtries = argc>1?atol(argv[1]):2000000; if(argc>2) st ^= strtoull(argv[2],0,10)*0x9E3779B97F4A7C15ULL;
  for(int a=0;a<243;a++){int da[5],x=a;for(int i=0;i<5;i++){da[i]=x%3;x/=3;}
    int ng=0,pw=1;for(int i=0;i<5;i++){ng+=((3-da[i])%3)*pw;pw*=3;} neg5[a]=ng;
    for(int b=0;b<243;b++){int db[5],y=b;for(int i=0;i<5;i++){db[i]=y%3;y/=3;}int s=0;pw=1;for(int i=0;i<5;i++){s+=((da[i]+db[i])%3)*pw;pw*=3;}add5[a][b]=s;}}
  for(int g=1;g<N;g++){int h=neg(g); if(g<h){ if(rnd()&1) S[g]=1; else S[h]=1; }}
  long found=0;
  for(long t=0;t<maxtries;t++){
    int u1=1+rnd()%(N-1), u2; do{u2=1+rnd()%(N-1);}while(u2==u1||u2==neg(u1));
    int U[9],k=0; for(int a=0;a<3;a++)for(int b=0;b<3;b++)U[k++]=add(smul(a,u1),smul(b,u2));
    int dom=1;
    for(int c=0;c<N && dom;c++){ int all=1; for(int i=0;i<9;i++) if(!S[add(c,U[i])]){all=0;break;} if(all) dom=0; } // c in U gives 0 not in S
    if(dom){
      // direct verification: every y outside U is beaten by some x in U (x->y iff y-x in S)
      int ok=1; for(int y=0;y<N;y++){int inU=0;for(int i=0;i<9;i++)if(U[i]==y)inU=1; if(inU)continue;
        int beaten=0; for(int i=0;i<9;i++) if(S[add(y,neg(U[i]))]){beaten=1;break;} if(!beaten){ok=0;break;}}
      printf("try %ld: dominating 2-dim subspace span(%d,%d) found; direct check %s\n",t,u1,u2,ok?"PASSED":"FAILED");
      if(++found>=3) break;
    }
  }
  printf("found=%ld\n",found); return 0;
}
