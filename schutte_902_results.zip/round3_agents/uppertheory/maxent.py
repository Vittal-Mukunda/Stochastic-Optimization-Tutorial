# Max-entropy model for the dominance-type distribution of an n-set X.
# q on {±1}^n, exchangeable, q(all-ones)=0, Fourier modes of order 1..k frozen (E chi_S = 0, |S|<=k).
# KL* = n ln2 - min_theta log Z(theta);  psi(n,k) = KL*/(-ln(1-2^-n)).  (Sanov: P(d(X)=0) ~ exp(-(N-n) KL*).)
import numpy as np
from math import comb, log
def kraw(n,j,w): return sum((-1)**i*comb(w,i)*comb(n-w,j-i) for i in range(0,j+1))
def kl_star(n,k):
    W = np.arange(1,n+1)
    lc = np.array([log(comb(n,w)) for w in W])
    K = np.array([[kraw(n,j,w)/comb(n,j) for w in W] for j in range(1,k+1)])  # k x n
    th = np.zeros(k)
    for it in range(200):
        a = lc + th@K; m = a.max(); e = np.exp(a-m); Z = e.sum(); Q = e/Z
        g = K@Q; H = (K*Q)@K.T - np.outer(g,g)
        if np.max(np.abs(g)) < 1e-13: break
        step = np.linalg.solve(H + 1e-15*np.eye(k), g)
        # damped Newton on f(th)=logZ
        f0 = m + np.log(Z); t = 1.0
        while True:
            th2 = th - t*step; a2 = lc + th2@K; m2 = a2.max(); f2 = m2 + np.log(np.exp(a2-m2).sum())
            if f2 <= f0 - 0.25*t*g@step or t < 1e-12: break
            t *= 0.5
        th = th2
    a = lc + th@K; m = a.max(); logZ = m + np.log(np.exp(a-m).sum())
    return n*log(2) - logZ, np.max(np.abs(g))
if __name__ == "__main__":
    print("psi(n,k): k = number of frozen Fourier orders (k=2 <-> doubly regular / Paley)")
    for n in range(3,15):
        base = -log(1-2.0**-n)
        row = []
        for k in range(1,n):
            kl, err = kl_star(n,k)
            row.append(f"{kl/base:8.3f}")
        print(f"n={n:2d}", " ".join(row))
    print("\nDRT model psi(n,2)-1 vs n^2/2^n, and quadratic approx m'/(2(2^n-m')), m'=1+n+C(n,2):")
    for n in range(4,31):
        kl,err = kl_star(n,2); base = -log(1-2.0**-n); mp = 1+n+comb(n,2)
        print(f"n={n:2d} psi-1={kl/base-1:.5f}  (psi-1)*2^n/n^2={(kl/base-1)*2**n/n**2:.4f}  quad={mp/(2*(2**n-mp)):.5f}  err={err:.1e}")
