# literature agent - running notes (2026-10-16)

## erdosproblems.com/902 (fetched 2026-10-16)
- Status OPEN. Bounds: Er63c 2^{n+1}-1 <= f(n) << n^2 2^n; SzSz65 f(3)=19, n2^n << f(n).
- Forum thread: 3 comments, only Graham-Spencer [GrSp71] mentioned. "no solutions, partial or complete, claimed".
- History: single dated revision 2025-10-20; no changes to bounds.
- OEIS A362137 linked.

## arXiv:2604.08790 Joel Jeffries (v1 2026-04-09) "Schuttes property for sets of tournaments and an application to dice games"
- "The bounds in Theorem 1.1 remain the best known bounds for f(k)"; Section 4: "The bounds on f(k) have remained un-improved for 60 years." "It is likely that modern extremal techniques could be used to improve these bounds."
- "For instance, f(5) >= 111" (= Szekeres bound).
- "According to Bozoki, Fisher showed computationally that P67, P331, and P1163 are the smallest S4, S5, and S6 Paley tournaments respectively [3]."
- Refs of interest: [3] Bozoki 2014 Miskolc Math Notes 15; [8] Jeffries PhD thesis Iowa State 2024; [9] Lu-Wang-Wong 2000 DM 220; [10] Borowiecki-Grytczuk-(Haluszczak)-Tuza CPC 12(4) 2003; [13] Simon 2022 strong S_k; [15] Tyszkiewicz AMM 2000.

## Borowiecki, Grytczuk, Haluszczak, Tuza, CPC 12(4) (2003) 359-364, DOI 10.1017/S0963548303005674
- bipartite version S_{k,l}; intersecting families reformulation.

## Bozoki, Miskolc Math. Notes 15(1) (2014) 39-50, "Nontransitive dice sets realizing the Paley tournaments for solving Schutte's tournament problem"
- PDF https://eprints.sztaki.hu/8154/1/Bozoki_39_2390862_ny.pdf
- Prop 1 (attributed to Fisher 1996 computations, as private comm. reported in Reid et al.): smallest Paley tournaments with S4, S5, S6 are P67, P331, P1163. Bozoki confirmed S4,S5; for S6 only that P_p lacks S6 for p=4m+3 prime < 1163.
- (unverified wording from WebFetch summary:) claims Graham-Spencer "conjectured f(4)=67" -- need source check.
- Mentions Alon-Brightwell-Kierstead-Kostochka-Winkler JCTB 96 (2006) geometric proof of finiteness of f(k).

## Reid, McRae, S.M. Hedetniemi, S.T. Hedetniemi, AJC 29 (2004) 157-172 https://ajc-new.maths.uq.edu.au/pdf/29/ajc_v29_p157.pdf
- Prop 14: "If gamma(T) >= 5, then |V(T)| >= 47." Corollary 7: "If gamma(T) >= 5, then |V(T)| >= 48."
- States Moser (via Moon's monograph): "log n - 2 log(log n) <= gamma(n) <= log(n+1)".
- Fisher: "the smallest rotational tournament with domination number 5 is QRT67", "the smallest QRTp with domination number k has p = 331 if k = 6, and has p = 1163 if k = 7", "the smallest QRTp with domination number 8 has p >= 3079."
  => f restricted to ROTATIONAL (circulant) tournaments, n=4, is 67 (per Fisher, unpublished).
- Theorem 5: every tournament with <19 vertices has gamma<=3; Prop 5: <7 vertices gamma<=2.
- Prop 8: "a smallest tournament W with gamma(W)=k+1 must have at least 2n+1 vertices" (garbled; Erdos 2^{k+1}-1).
- Tyszkiewicz Thm 2 (V x V x V construction S_{3k/2}), Duncan-Jacobson Thm 3.

## Bonato survey "The search for n-e.c. graphs", Contrib. Discrete Math. 4 (2009) 40-53; https://www.mscs.dal.ca/~abonato/necsurvey.pdf
- "For n > 1, by Theorem 2 (5) we have that mec(n) >= 2mec(n-1) + 1. In particular, mec(n) = Omega(2^n). The proof of Theorem 1 shows that mec(n) = O(2^n n^2)." (exponents garbled in extraction; context implies Omega(2^n))
- Thm 2(2): order >= n + 2^n; >= n 2^{n-1} edges.
- m_ec(1)=4, m_ec(2)=9 (CEV85), 22 <= m_ec(3) <= 28 (Pralat comp.; Gordinowicz-Pralat JCMCC 74 (2010) 129-142).
- Thm 4: Paley P_q n-e.c. if q > n^2 2^{2n-2}.
- open: lim m_ec(n)/... (garbled)

## Bonato-Cameron, DM 306 (2006) 2327-2335 "On an adjacency property of almost all tournaments": 2-e.c. tournament on k vertices iff k>=7, k!=8; unique minimal = Paley D7. Lemma 1: G n-e.c. => G-v, N_in(v), N_out(v) are (n-1)-e.c.

## Bonato-Gordinowicz-Pralat, "Bounds and constructions for n-e.c. tournaments", Contrib. Discrete Math. 5(2) (2010) 52-66. Abstract (sharcnet): "With aid of a computer search, we demonstrate that there is a unique minimum order 3-e.c. tournament of order 19, and there are no 3-e.c. tournaments of orders 20, 21, and 22. We show that there are no 4-e.c. tournaments of orders 47 and 48 improving the lower bound for the minimum order of such a tournament."
- Preprint version (https://www.mathstat.dal.ca/~pralat/papers/tournament.pdf): t_P(n) >= (n+2)2^{n-1}-1 (Szekeres), so same for t_ec(n); random gives t_ec(n)=O(n^2 2^n); lim t_ec(n)^{1/n}=2; open: lim t_ec(n)/(n^2 2^n), lim t_ec(n)/t_P(n). "T67 is the first Paley tournament that has property P4, and it is also 4-e.c."; "T359 is the first Paley tournament that is 5-e.c." T331 first with P5. Preprint states 47 <= t_ec(4) <= 67.
- published PDF https://cdm.ucalgary.ca/article/view/62061/46708 (binary; WebFetch could not parse). METHOD FOR 47/48 NOT VERIFIED.
- NOTE: 4-e.c. is STRONGER than S_4, so t_ec(4) >= 49 is weaker than our f(4) >= 49.

## Javier, Llano, Zuazua, "2- and 3-existentially closed tournaments", Contrib. Discrete Math. 21(1) (2026) 73-90, DOI 10.55016/0sre1423; https://cdm.ucalgary.ca/article/view/78881
- Cor 4.2: vertex-transitive doubly regular T has P3 iff S3. Cor 4.3 QR_p has P3 for all p=3 mod 4, p>=19.
- Prop 4.8/Cor 4.9: QR_p[N+(v)] has S3 iff QR_p has S4. Cor 4.11 QR67 has S4. Prop 4.10: C_33(K) has S3.
- Thm 5.3/5.5: Szekeres-type doubly regular tournaments S_p (p = 5 mod 8, p>=13) and converses have P3.
- Problems 5.6, 5.7. No f(4) lower bound beyond citing BGP.

## Lu, Wang, Wong, "On the bounded domination number of tournaments", Discrete Math 220 (2000) 257-?? (pages unverified)
- abstract: "We also give a short direct proof of the result of E. Szekeres and G. Szekeres that every n-vertex tournament is dominated by at most lg n - lg lg n + 2 vertices."  => Szekeres in gamma-form: gamma <= lg n - lg lg n + 2 (i.e. constant 2 for gamma, 1 for gamma-1 = max S_k index).

## El Zein, "About kings and dominating sets in tournaments", AJC 91(2) (2025) 282-300, https://ajc.maths.uq.edu.au/download/91/ajc_v91_p282.pdf
- Cor 2.4: gamma(T) <= log2(k) - log2(log2(k)) + 2, k = |K^{xi(T)}(T)| (iterated kings subtournament). Constant 2 unchanged; no improvement when all vertices are kings (k=n). Does not touch f(k).

## OEIS A362137 (Rouyer 2023): smallest n-paradoxical Paley tournament: 1,3,7,19,67,331,1163. a(4..6) not proven minimal among all tournaments.

## Moon, Topics on Tournaments (1968), Section 11 "An Extremal Problem" (Gutenberg #42833 PDF https://www.gutenberg.org/files/42833/42833-pdf.pdf) [WebFetch summary; quotes partial]
- S(k,m): every k-set has >= m common dominators.
- Thm 16 (Szekeres): "If the tournament Tn has property S(k, m), then" n >= 2^k(m+1) - 1. Proof: dominators of p induce S(k-1,m); induct; in-degree >= 2^{k-1}(m+1)-1; count arcs n(2^{k-1}(m+1)-1) <= C(n,2).
- Cor: S(k,1) => S(k-1,k+1) => n >= 2^{k-1}(k+2)-1. Best possible for k=2,3, unknown for k>3.
- Exercise 5 (Moser): floor(log2 n - 2 log2 log2 n) <= h(n) <= log2(n+1) (h = max domination number).
- Exercise 4: generalize Thm 16 to T(a,b;m) (e.c.-type) property.

## Erdos 1985 "Welcoming address", Ann. Discrete Math 28 (1985) 1-5 (https://old.renyi.hu/~p_erdos/1985-38.pdf): "An asymptotic formula for nk is nowhere in sight at the moment and the value of n4 is also unknown."
## Erdos-Moser, Canad. Math. Bull. 7 (1964) 351-356 "A problem on tournaments" (https://old.renyi.hu/~p_erdos/1964-03.pdf)

## Caccetta-Erdos-Vijayan, "A property of random graphs", Ars Combin. 19A (1985) 287-294 (https://static.renyi.hu/~p_erdos/1985-04.pdf): P(k) = k-e.c. for graphs; Thm 4 smallest 2-e.c. graph has 9 vertices; Thm 1: max k for n-vertex graph between log2 n - (2+o(1)) log log n and ~log2 n; lower bound on h(n) only 2^n + n (counting).

## Changwoo Lee, "The Domination Number of a Tournament", Kangweon-Kyungki Math. J. 9(1) (2001) 21-28, https://koreascience.kr/article/JAKO200134041280735.pdf
- Thm 1: 1 <= alpha(T) <= floor(lg(n+1)); Thm 2: random tournament domination number is floor(k*)+1 or +2, k* = lg n - 2 lg lg n + lg lg e.
- Thm 3: Paley alpha(Q_p) > (1+o(1)) (1/2) lg p (via Graham-Spencer S_k lemma). alpha(Q_31) <= 4.
- open: sharpen upper bound floor(lg(n+1)).

## Nguyen-Scott-Seymour(?) "Some results and problems on tournament structure", arXiv 2306.02364 -- Sec 9 domination: Paley Omega(log q) (Graham-Spencer); k-majority Omega(k/log k). Conjectures 9.1-9.6 on domination; nothing on constants.

## McKay digraph data (https://users.cecs.anu.edu.au/~bdm/data/digraphs.html): doubly regular tournaments: 3:1, 7:1, 11:1, 15:2, 19:2, 23:37, 27:722 (Spence first; McKay recomputed); 31+: incomplete (from Koukouvinos skew Hadamard catalogue).

## Graham-Spencer, Canad. Math. Bull. 14 (1971) 45-48 (Cambridge PDF): Theorem: if p > k^2 2^{2k-2} then T_p has P_k (=S_k). Uses Burgess/Weil character sum bound. "Also, it is true that T67 has property P4."; notes f(4) >= 47 and "it is possible that T67 is also minimal". (not a formal conjecture)

## Brouwer Paley page https://aeb.win.tue.nl/graphs/Paley.html : domination numbers of Paley tournaments q<2048 (citing C. Lee 2001):
 2: q=3; 3: 7-11; 4: 19-59, 103; 5: 67-83, 107-311, 343, 379; 6: 331, 347-367, 383-1151, 1171, 1223, 1331, 1723; 7: 1163, 1187, 1231-1327, 1367-1699, 1747-2039.
 Paley graphs: greedy gamma < 1 + log q; >= ~(0.5-eps) log q.
 => smallest Paley with S_4,S_5,S_6 = 67, 331, 1163 (consistent with Fisher). Non-monotone (103 has gamma 4; 379 gamma 5; 1171.. etc).

## Covering arrays / k-independent families analog
- Kleitman-Spencer 1973 (Discrete Math 6, 255-262): 2^k d2 log n <= g_k(n) <= k 2^k d1 log n (as quoted in Johnson-Wickes arXiv 2112.01946 Thm 1.1). g_k(n) = min rows of binary covering array of strength k with n columns.
- Lawrence-Kacker-Lei-Kuhn-Forbes, "A survey of binary covering arrays", EJC 18 (2011) P84 (NIST pdf): "These lower bounds on the ct's from Kleitman-Spencer [50] haven't been improved upon." "it is not known whether or not ct and dt are equal."
- Sarkar-Colbourn (arXiv 1605.02131): CAN(t,k,v) = Omega(v^{t-1} log k) via CAN(t,k,v) >= v CAN(t-1,k-1,v) + Gargano-Korner-Vaccaro; upper (t-1) v^t log k (1+o(1)).
- OBSERVATION (mine): an n-e.c. graph/tournament on N vertices yields an N x N binary covering array of strength n (diagonal arbitrary), so N >= g_n(N) >= d2 2^n log N => m_ec(n), t_ec(n) = Omega(n 2^n). (Bonato's survey only states Omega(2^n) for graphs.)

## !!! Jared Wilder, GitHub jaredwilder/erdos902 (Lean 4 + computation), cloned to /home/claude/jaredwilder/erdos902 (HEAD 959d09a, 2026-09-17)
- commit history: initial 2026-08-26; "Formalize the analytic reduction for a 48-vertex S_4 tournament" 2026-08-27 (e2ad793); "Encode the two S_3 doubly regular tournaments of order 23 and kernel-check their counts" 2026-08-27 (b2066f4); "Release serious computer-assisted candidate proof f(4) >= 49" 2026-09-11 (f556134); "Publish compact layerwise f4>=49 contradiction architecture" 2026-09-13 (b9ec939); catalogue replay 2026-09-11/13.
- f4-ge49-candidate/README.md: "Source date: 2026-08-27 / Public release: 2026-09-11 / Status: SERIOUS COMPUTER-ASSISTED PROOF CANDIDATE — NOT YET PROMOTED TO CANONICAL THEOREM". Argument: 48-vertex S4 => S(3,5), pairs >= 11 common dominators, indegree >= 23; some v has indegree 23; H=N^-(v) has S3 and is DRT(23,11,5); McKay's 37 DRT(23): exactly two have S3 (catalogue lines 35, 36); bad 4-sets 2475 / 2530; outside masks W_x: |W_x|<=12 and |W_x cap N_H^-(h)|<=6; exhaustive max bad-4-sets per admissible mask 65 / 66; 24*66=1584 < 2475 => contradiction => f(4)>=49. "No priority claim is made here." Novelty boundary: "The 2026-08-27 source search found the published lower bound f(4)>=48 and the known QR_67 upper construction, but no ordinary-S_4 statement f(4)>=49."
- F4-LAYERWISE...md: alternative budget sum R(W_x) <= 2448 < 2475.
- Row 36 identified as QR_23 (Erdos902QR23.lean); 2-(23,4,60) design of bad 4-sets for row 36.
- Order-49 Cayley tournaments on Z_49 and F_7^2: no S4 (SAT, DRAT-verified). General order 49 undecided.
- README Status: "The general factor-n gap between the lower and upper asymptotic bounds remains open." Only classical sandwich (n+2)2^{n-1}-1 <= f(n) <= n + 3n^2 2^n. NO improved asymptotic constant; NO f(5..10) bounds (grep). Many "closure" files documenting failed routes (Cover: N^-(v) covers all k-sets avoiding v -> only 2^{k+1}; Reach; Order/Bonferroni; Coupling).
- Erdos902Reid.lean formalizes f(4) >= 48.

## Reid et al. Cor 7 proof (via WebFetch summary): Prop 14 is Szekeres at k=4 (indegree >= 23 => n >= 47); equality forces "triply regular (5,11,23)-tournament", contradicting Reid-Brown (1972) nonexistence of nontrivial triply regular tournaments => n >= 48. Only k=4 stated. Open Problem 5: smallest order with gamma = 5.
  => our (c) "Szekeres never attained for n>=4" is the natural generalization of this tightness argument (k=4 case = Reid et al. Cor 7).
