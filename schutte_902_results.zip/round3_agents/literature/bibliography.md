# Erdős #902 (Schütte's tournament problem) — annotated bibliography

Compiled by the "literature" agent, 2026-10-16. Conventions: f(n) = least N such that some N-vertex
tournament has S_n (every n-set has a dominator outside it); S_n iff γ(T) > n.
"[verified]" = I read the statement in the source itself (via WebFetch text extraction or a local clone).
"[summary]" = the WebFetch tool returned a paraphrase; wording may not be exact.
"[unverified]" = known only from a secondary source or a title.
Note: WebFetch hit a session limit at ~19:50 IST on 2026-10-16; items after that point are from WebSearch titles only.

---------------------------------------------------------------------------------------------------
## A. Core sources on f(n) and its bounds

1. **P. Erdős, "On a problem in graph theory", Math. Gazette 47 (1963) 220–223.**
   Random tournaments: S_k exists on N > (ln 2 + ε) k² 2^k vertices; lower bound f(k) ≥ 2^{k+1} − 1.
   Erdős later (Ann. Discrete Math. 28 (1985) 1–5, "Welcoming address",
   https://old.renyi.hu/~p_erdos/1985-38.pdf) [verified]: "An asymptotic formula for nk is nowhere in
   sight at the moment and the value of n4 is also unknown."

2. **E. Szekeres, G. Szekeres, "On a problem of Schütte and Erdős", Math. Gazette 49 (1965) 290–293,
   DOI 10.2307/3612854.** f(3) = 19 and f(k) ≥ (k+2)2^{k−1} − 1. Proof as reproduced in Moon's book
   (item 3): S(k,m) ⇒ N ≥ 2^k(m+1) − 1 (dominators of a vertex induce S(k−1,m); induct; count arcs),
   and S(k,1) ⇒ S(k−1,k+1). Original not accessed.

3. **J. W. Moon, Topics on Tournaments (1968), §11 "An Extremal Problem"** (Gutenberg #42833,
   https://www.gutenberg.org/files/42833/42833-pdf.pdf) [summary]. Thm 16 (Szekeres): "If the
   tournament Tn has property S(k, m), then" n ≥ 2^k(m+1) − 1. Corollary: S(k,1) ⇒ n ≥ 2^{k−1}(k+2) − 1,
   "best possible for k = 2, 3 but unknown for k > 3". Exercise 5 (L. Moser):
   ⌊log₂n − 2log₂log₂n⌋ ≤ h(n) ≤ log₂(n+1), h = max domination number. Exercise 4: extend Thm 16 to
   the e.c.-type property T(a,b;m).

4. **P. Erdős, L. Moser, "A problem on tournaments", Canad. Math. Bull. 7 (1964) 351–356**
   (https://old.renyi.hu/~p_erdos/1964-03.pdf) [summary]. Restates Schütte's question and the bounds
   2^{k+1}−1 and (ln2+ε)k²2^k; asks monotonicity in N.

5. **R. L. Graham, J. H. Spencer, "A constructive solution to a tournament problem", Canad. Math.
   Bull. 14 (1971) 45–48** [verified, OCR]. "If p > k² 2^{2k−2} then T_p has property P_k"
   (QR tournament; Weil/Burgess character-sum bound). "T7 has property P2 and T19 has property P3",
   "Also, it is true that T67 has property P4"; notes f(4) ≥ 47 and "it is possible that T67 is also
   minimal" (a remark, not a formal conjecture).

6. **K. B. Reid, A. A. McRae, S. M. Hedetniemi, S. T. Hedetniemi, "Domination and irredundance in
   tournaments", Australas. J. Combin. 29 (2004) 157–172**
   (https://ajc-new.maths.uq.edu.au/pdf/29/ajc_v29_p157.pdf) [verified].
   Prop. 14 "If γ(T) ≥ 5, then |V(T)| ≥ 47." Cor. 7 "If γ(T) ≥ 5, then |V(T)| ≥ 48."
   Proof of Cor. 7 [summary]: equality in Prop. 14 forces a triply regular (5,11,23)-tournament,
   impossible by Reid–Brown (1972) (no nontrivial triply regular tournaments). Only k = 4 is stated —
   no general-k version. Reports D. C. Fisher's (1996, unpublished) computations: "the smallest
   rotational tournament with domination number 5 is QRT67", "the smallest QRTp with domination
   number k has p = 331 if k = 6, and has p = 1163 if k = 7", "the smallest QRTp with domination
   number 8 has p ≥ 3079." Open Problem 5: smallest order with γ = 5.

7. **X. Lu, D.-W. Wang, C. K. Wong, "On the bounded domination number of tournaments", Discrete Math.
   220 (2000) 257–261** [abstract verified]: "We also give a short direct proof of the result of
   E. Szekeres and G. Szekeres that every n-vertex tournament is dominated by at most lg n − lg lg n + 2
   vertices." (So Szekeres in γ-form has constant +2; in the S_n-index form n = γ−1 it is +1.)

8. **A. El Zein, "About kings and dominating sets in tournaments", Australas. J. Combin. 91(2) (2025)
   282–300** (https://ajc.maths.uq.edu.au/download/91/ajc_v91_p282.pdf) [verified via extraction].
   Cor. 2.4: γ(T) ≤ log₂k − log₂log₂k + 2 with k = |K^{ξ(T)}(T)| (iterated-kings subtournament).
   Constant 2 unchanged; no gain when every vertex is a king. Does not touch f(k).

9. **Changwoo Lee, "The domination number of a tournament", Kangweon-Kyungki Math. J. 9(1) (2001)
   21–28** (https://koreascience.kr/article/JAKO200134041280735.pdf) [summary]. γ(T) ≤ ⌊lg(n+1)⌋;
   random tournament: γ ∈ {⌊k*⌋+1, ⌊k*⌋+2}, k* = lg n − 2 lg lg n + lg lg e; Paley:
   "α(Qp) > (1 + o(1)) 1/2 lg p"; α(Q_31) ≤ 4.

10. **J. Tyszkiewicz, "A simple construction for tournaments with every k players beaten by a single
    player", Amer. Math. Monthly 107(1) (2000) 53–54** [unverified]: product construction (V×V×V gives
    S_{3k/2}, per Reid et al. Thm 2).

11. **S. Bozóki, "Nontransitive dice sets realizing the Paley tournaments for solving Schütte's
    tournament problem", Miskolc Math. Notes 15(1) (2014) 39–50**
    (https://eprints.sztaki.hu/8154/1/Bozoki_39_2390862_ny.pdf) [summary]. Prop. 1: smallest Paley
    tournaments with S4, S5, S6 are P67, P331, P1163 (Fisher 1996, via Reid et al.); Bozóki re-verified
    S4, S5; for S6 only that no P_p, p < 1163, has S6.

12. **J. Jeffries, "Schütte's property for sets of tournaments and an application to dice games",
    arXiv:2604.08790 (2026-04-09)** [verified]. "The bounds in Theorem 1.1 remain the best known bounds
    for f(k)"; §4: "The bounds on f(k) have remained un-improved for 60 years." "It is likely that
    modern extremal techniques could be used to improve these bounds." Gives "f(5) ≥ 111" (= Szekeres).
    Theorems 2.2–2.3 are upper bounds for f(m,k) (sets of m tournaments); "no non-trivial lower bound
    for f(m,k)". Thesis: J. A. Jeffries, "Generalizations of Schütte's property with applications to
    dice games", PhD, Iowa State 2024, DOI 10.31274/td-20250502-307 [not accessed].

13. **M. Borowiecki, J. Grytczuk, M. Hałuszczak, Zs. Tuza, "Schütte's tournament problem and
    intersecting families of sets", Combin. Probab. Comput. 12(4) (2003) 359–364,
    DOI 10.1017/S0963548303005674** [abstract only]. Bipartite version S_{k,l}; reformulated via
    intersecting set families (set-pair method); bounds not seen.

14. **OEIS A362137** (J. Rouyer 2023; a(6) corrected by N. S. Georgescu 2024) [verified]: smallest
    n-paradoxical Paley tournament: 1, 3, 7, 19, 67, 331, 1163 (n = 0..6). "a(4), a(5), and a(6) are
    the smallest known solutions" — not proven minimal over all tournaments.

15. **erdosproblems.com/902** (fetched 2026-10-16) [verified]: status OPEN; lists Er63c
    (2^{n+1}−1 ≤ f(n) ≪ n²2^n) and SzSz65 (f(3)=19, n2^n ≪ f(n)); forum thread has 3 comments, only
    Graham–Spencer mentioned; "There are no solutions, partial or complete, claimed in the comments."
    History: one dated revision (2025-10-20), no change in bounds.

16. **N. Y. Javier, B. Llano, R. Zuazua, "2- and 3-existentially closed tournaments", Contrib.
    Discrete Math. 21(1) (2026) 73–90, DOI 10.55016/0sre1423** (https://cdm.ucalgary.ca/article/view/78881)
    [verified via extraction]. Cor. 4.2: a vertex-transitive doubly regular tournament has P3 iff S3;
    Cor. 4.3: QR_p has P3 for all p ≡ 3 (mod 4), p ≥ 19; Prop. 4.8/Cor. 4.9: QR_p[N^+(v)] has S3 iff
    QR_p has S4; Cor. 4.11: QR67 has S4; Szekeres-type DRTs S_p (p ≡ 5 mod 8) have P3. Problems 5.6
    (DRT: P_k ⇔ S_k?) and 5.7. No new f(4) lower bound.

17. **!!! J. Wilder, GitHub `jaredwilder/erdos902` (Lean 4 + computation; first commit 2026-08-26;
    HEAD 959d09a 2026-09-17)** [verified from local clone at /home/claude/jaredwilder/erdos902].
    - `classical_sandwich`: (n+2)2^{n−1} − 1 ≤ f(n) ≤ n + 3n²2^n (Lean); f(1)=3, f(2)=7, f(3) ≥ 19,
      48 ≤ f(4) ≤ 67 (QR67 certificate; `Erdos902Reid.lean` = Reid et al. Cor. 7).
    - `f4-ge49-candidate/README.md` — "Candidate theorem: f(4) >= 49", "Source date: 2026-08-27",
      "Public release: 2026-09-11", "Status: SERIOUS COMPUTER-ASSISTED PROOF CANDIDATE — NOT YET
      PROMOTED TO CANONICAL THEOREM". Route: a 48-vertex S4 tournament has S(3,5), pair codegree ≥ 11,
      all in-degrees ≥ 23, so some v has in-degree 23; H = N^-(v) has S3 and is DRT(23,11,5);
      McKay's catalogue of 37 DRT(23): "exactly two have S_3" (lines 35, 36; line 36 = QR_23);
      2475 resp. 2530 undominated 4-sets in H; each outside x ∈ N^+(v) has mask W_x with
      |W_x| ≤ 12 and |W_x ∩ N_H^-(h)| ≤ 6; exhaustive maximum of bad 4-sets inside an admissible
      mask = 65 resp. 66; 24·66 = 1584 < 2475 ⇒ contradiction. Commit f556134 (2026-09-11)
      "Release serious computer-assisted candidate proof f(4) >= 49". Its own novelty note: "The
      2026-08-27 source search found the published lower bound f(4)>=48 and the known QR_67 upper
      construction, but no ordinary-S_4 statement f(4)>=49. That is promising evidence, not a
      priority certificate."
    - `F4-LAYERWISE-CAPACITY-CONTRADICTION-2026-09-13.md`: sharper budget Σ R(W_x) ≤ 2448 < 2475.
    - `DRT23-MCKAY-CATALOGUE-REPLAY-2026-09-13.md`: catalogue SHA-256 20dbad06…; survivors rows 35
      (2475) and 36 (2530).
    - `ORDER49-CAYLEY-ELIMINATIONS.md`: no Cayley tournament on Z/49 or F_7² has S4 (SAT, DRAT-checked);
      unrestricted order 49 undecided.
    - README status: "The general factor-n gap between the lower and upper asymptotic bounds remains
      open." No improved asymptotic constant and no bounds for f(5), f(6), … anywhere in the repo
      (grep). Many files document failed routes ("closures"): e.g. `Erdos902Cover.lean` (N^-(v)
      covers every k-set avoiding v; as a count gives only ~2^{k+1}), `Erdos902Reach.lean`,
      `Erdos902Order.lean` (Bonferroni at every order), `Erdos902Coupling.lean`.

18. **TheJustinSunPrize/awards PR #262** (GitHub), "JSP-000750: submit Lean formalization of Schütte's
    tournament values f(1)=3, f(2)=7 and Erdős's lower bound (Erdős #902, scoped component)" by
    CollinYuanjieRen [title only, unverified]. Indicates a prize repository where #902 components are
    being submitted.

---------------------------------------------------------------------------------------------------
## B. Paley / circulant tournaments

19. **A. E. Brouwer, Paley graph page** (https://aeb.win.tue.nl/graphs/Paley.html) [verified]:
    domination numbers of Paley tournaments for q < 2048 (citing Lee 2001):
    γ=2: 3; γ=3: 7–11; γ=4: 19–59, 103; γ=5: 67–83, 107–311, 343, 379; γ=6: 331, 347–367, 383–1151,
    1171, 1223, 1331, 1723; γ=7: 1163, 1187, 1231–1327, 1367–1699, 1747–2039. (Non-monotone in q.)
    Paley graphs: greedy dominating set "less than 1 + log q", lower ~(0.5 − ε) log q.
20. **Fisher (1996), unpublished**, as reported in item 6: smallest rotational (circulant) tournament
    with γ = 5 is QR_67 — i.e. f restricted to circulant tournaments equals 67 for n = 4.
21. **S. Satake, "On explicit random-like tournaments", arXiv:1901.10733** [summary]: generalized
    Paley tournaments T_p^m(S_i) have S_k for large p (Prop. 5.2), spectral method limit √(n+1)/2.
22. Bollobás–Thomason, "Graphs which contain all small graphs", European J. Combin. 2 (1981) 13–15;
    Blass–Exoo–Harary, J. Graph Theory 5 (1981) 435–439 [unverified here]: Paley graphs n-e.c. for
    q > n²4^n (Bonato survey Thm 4: q > n²2^{2n−2}).
23. **BGP 2010 preprint** (item 26): "T67 is the first Paley tournament that has property P4, and it is
    also 4-e.c."; "T359 is the first Paley tournament that is 5-e.c."; T331 first with P5.

---------------------------------------------------------------------------------------------------
## C. Analogous problems

### n-e.c. graphs
24. **A. Bonato, "The search for n-e.c. graphs", Contrib. Discrete Math. 4 (2009) 40–53**
    (https://www.mscs.dal.ca/~abonato/necsurvey.pdf) [verified, some exponents garbled]:
    Thm 2(2): order ≥ n + 2^n and ≥ n2^{n−1} edges; m_ec(n) ≥ 2m_ec(n−1)+1, "In particular,
    mec(n) = Ω(2^n)"; random graphs give O(n²2^n); m_ec(1)=4, m_ec(2)=9, 22 ≤ m_ec(3) ≤ 28.
    "The exact determination of mec(n) where n ≥ 3 is a difficult open problem."
25. **L. Caccetta, P. Erdős, K. Vijayan, "A property of random graphs", Ars Combin. 19A (1985)
    287–294** (https://static.renyi.hu/~p_erdos/1985-04.pdf) [summary]: smallest 2-e.c. graph has 9
    vertices; only counting lower bound 2^n + n.
    Also: W. Ananchuen, L. Caccetta, AJC 6 (1992) 155–175 and AJC 8 (1993) 153–168 (adjacency
    properties; abstracts not seen); P. Gordinowicz, P. Prałat, "The search for the smallest 3-e.c.
    graphs", JCMCC 74 (2010) 129–142 [title]; A. Costea, MSc thesis WLU 2010 (3-e.c. graph of order 30).
    Hypergraph analogue: Burgess–Luther–Pike 2024 (arXiv 2407.06054), counting lower bounds only.

### n-e.c. tournaments
26. **A. Bonato, P. Gordinowicz, P. Prałat, "Bounds and constructions for n-e.c. tournaments",
    Contrib. Discrete Math. 5(2) (2010) 52–66** (published PDF https://cdm.ucalgary.ca/article/view/62061/46708
    could not be text-extracted; preprint https://www.mathstat.dal.ca/~pralat/papers/tournament.pdf).
    Abstract [verified]: "there is a unique minimum order 3-e.c. tournament of order 19, and there are
    no 3-e.c. tournaments of orders 20, 21, and 22." "We show that there are no 4-e.c. tournaments of
    orders 47 and 48 improving the lower bound for the minimum order of such a tournament."
    (4-e.c. is strictly stronger than S4, so this is weaker than f(4) ≥ 49; method not seen.)
    Preprint [summary]: t_ec(n) ≥ (n+2)2^{n−1}−1 via Szekeres; random O(n²2^n); lim t_ec(n)^{1/n} = 2;
    open: existence of lim t_ec(n)/(n²2^n) and lim t_ec(n)/t_P(n).
27. **A. Bonato, K. Cameron, "On an adjacency property of almost all tournaments", Discrete Math. 306
    (2006) 2327–2335** (https://www.mscs.dal.ca/~abonato/nectour.pdf) [verified]: 2-e.c. tournament
    on k vertices iff k ≥ 7, k ≠ 8; unique minimum = Paley D7; Lemma 1: N^+(v), N^-(v), T−v of an n-e.c.
    tournament are (n−1)-e.c.

### Covering arrays / k-independent families / (n,k)-universal sets
28. **D. Kleitman, J. Spencer, "Families of k-independent sets", Discrete Math. 6 (1973) 255–262.**
    As quoted in Johnson–Wickes, arXiv:2112.01946, Thm 1.1 [verified]: "2^k d_2 log n ≤ g_k(n) ≤
    k 2^k d_1 log n" (g_k(n) = min size of a family shattering every k-subset of [n]) — the same
    factor-k (≈ factor-n) gap as Schütte's problem.
29. **J. Lawrence, R. N. Kacker, Y. Lei, D. R. Kuhn, M. Forbes, "A survey of binary covering arrays",
    Electron. J. Combin. 18 (2011) #P84** (NIST PDF) [summary + quotes]: "These lower bounds on the
    ct's from Kleitman-Spencer [50] haven't been improved upon." "it is not known whether or not ct
    and dt are equal." Roux improved the upper bound for t = 3; Godbole–Skipper–Sunley for t > 3.
30. K. Sarkar, C. J. Colbourn, arXiv:1605.02131 [summary]: CAN(t,k,v) = Ω(v^{t−1} log k) (via
    CAN(t,k,v) ≥ v·CAN(t−1,k−1,v) + Gargano–Körner–Vaccaro); CAN ≤ (t−1) v^t log k (1+o(1)).
31. Choi–Kim–Oh, arXiv:1111.0587 — improves Roux's lower bound for t = 3, q = 2 (small cases).
32. Saharoy–Vaya, "Universal sets and cover-free families" (arXiv:1606.01376): lower bound
    "Ω(2^d log n)" for (n,d)-universal sets; constructions d·2^{d+o(d)}·log n.
    OBSERVATION (mine, not in the literature I saw): an n-e.c. graph or tournament on N vertices gives
    an N×N binary covering array of strength n, so m_ec(n), t_ec(n) ≥ c·n·2^n by item 28/30 — better
    than the Ω(2^n) stated in item 24 for graphs.

### Domination in k-majority tournaments and hypergraph tournaments
33. **N. Alon, G. Brightwell, H. A. Kierstead, A. V. Kostochka, P. Winkler, "Dominating sets in
    k-majority tournaments", J. Combin. Theory Ser. B 96(3) (2006) 374–387**
    (https://math.dartmouth.edu/~pw/papers/dice.pdf) [verified]: "F(2) = 3 and in general C1k/log k ≤
    F(k) ≤ C2k log k"; upper bound via fractional transversals + VC-dimension (ε-nets); lower bound by an
    explicit construction ("a 3t⌈log₂t⌉-majority tournament that satisfies property S_t").
34. D. Fidler, "A recurrence for bounds on dominating sets in k-majority tournaments", Electron. J.
    Combin. 18(1) (2011) #P166 [summary]: F(3) ≤ 12.
35. **J. Ai, X. Yi, "A linear lower bound for dominating sets in k-majority tournaments",
    arXiv:2607.23148 (2026-07-25)** [verified abstract]: F(k) ≥ ⌊(k+1)/2⌋ for k ≥ 3.
36. **Y. Caro, A. Hansberg, "Directed domination in oriented hypergraphs", arXiv:1904.02351 (2019)**
    [verified abstract]: upper directed (r−1)-domination number of H(n,r) between c(ln n)^{1/(r−1)}
    and C ln n.

### Other
37. Nguyen–Scott–Seymour, "Some results and problems on tournament structure", arXiv:2306.02364
    [summary]: §9 domination (Paley Ω(log q), k-majority), Conjectures 9.1–9.6; nothing on constants.
38. B. D. McKay, digraph data (https://users.cecs.anu.edu.au/~bdm/data/digraphs.html) [verified]:
    doubly regular tournaments 3:1, 7:1, 11:1, 15:2, 19:2, 23:37, 27:722 ("Ted Spence was the first to
    find them up to 27 vertices but I have recomputed them"); 31+ incomplete.
