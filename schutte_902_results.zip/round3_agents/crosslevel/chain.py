# Sharpened cross-level recursion (copy of /home/claude/asym/cross/sharpened_small.py logic) that also prints the chain.
from math import comb
def chain(n, N, sharp=True):
    nu = {n: 1}
    for s in range(n-1, -1, -1):
        h = nu[s+1]
        lowk = lambda k: nu[k] if k > s else 2**(s+1-k)*(h+1) - 1
        def ok(m):
            for k in range(1, min(m, n)+1):
                lhs = ((N-s-m)*comb(m-h, k) + m*comb(m-h-1, k)) if sharp else (N-s)*comb(m-h, k)
                if lhs < lowk(k)*comb(m, k): return False
            return True
        m = 2*h + 1
        while not ok(m):
            m += 1
            if m > N - s: return None
        nu[s] = m
    return nu
if __name__ == "__main__":
    for n in range(4, 9):
        N = (n+2)*2**(n-1) - 1
        while True:
            nu = chain(n, N)
            if nu is not None and nu[0] <= N: break
            N += 1
        print(n, "f(n) >=", N, "chain at threshold:", [nu[s] for s in range(n+1)], "(N-1)/2 =", (N-1)/2)
        for NN in range(N, N+4):
            nu = chain(n, NN); print("   N =", NN, [nu[s] for s in range(n+1)] if nu else None)
