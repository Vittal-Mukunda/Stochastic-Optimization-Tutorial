# crosslevel agent notes (run 2, started 2026-10-17)

Task: improve c* = 0.7695 (cross-level lemma + M2) rigorously, or show the method cannot; local configurations at an
(n-2)-set A; second moments / three-level counts / LP; n = 4, N = 49 regular case.

Resources: scipy (HiGHS linprog/milp), ortools (CP-SAT), pysat. 2 cores shared, single-threaded runs < 10 min.

## Log

### Step 1 (2026-10-17): f(4) >= 50  [RIGOROUS modulo the computer-assisted RESULTS.md theorem]
Claim A. A regular S_4 tournament on 49 vertices does not exist.
Proof. In-/out-degrees are 24. Let A={a,b} be a pair, R=D(A), m=|R| >= 11 (F2). Suppose m = 11. T[R] has min
in-degree >= 5 (D(A+y) = N^-_R(y) has >= 5 elements, F1), so T[R] is regular, every y in R has q_y := |N^-_R(y)| = 5.
For the 36 vertices y outside A u R put q_y = |R n N^-(y)| = |D(A+y)| >= 5.
 (i) Exact pair count, U over 3-subsets of R:  sum_U |D(U)| = 11*C(5,3) + sum_{y outside} C(11-q_y,3)  (a beats no
     vertex of R).  F1 gives sum_U |D(U)| >= 5*C(11,3) = 825, so sum_{outside} C(11-q_y,3) >= 715.
 (ii) Exact degree count: arcs from R to V\A: each r in R has out-degree 24 and beats a,b, so 11*22 = 242 arcs;
     55 of them inside R; so sum_{outside} q_y = 187 = 36*5 + 7.
 With e_y = q_y - 5 >= 0, sum e_y = 7, the loss 20 - C(6-e,3) is 0,10,16,19,20,20,... (concave in e), so
 sum_{outside} C(11-q_y,3) <= 36*20 - 20 = 700 < 715. Contradiction. Hence every pair has >= 12 dominators.
 Then for any v, T[N^-(v)] has min in-degree >= 12 (N^-(a) n N^-(v) = D({a,v})), so d^-(v) >= 25 > 24. Contradiction.
Combined with RESULTS.md Theorem (S_4 on <= 51 vertices => min in-degree >= 24; at N=49 this forces regularity):
  **f(4) >= 50.**   (the argument is the "degree-sum + convexity" refinement; only constants, so no asymptotic gain)
