from math import comb
def chain_dbg(n, N):
    nu = {n: 1}; info = {}
    for s in range(n-1, -1, -1):
        h = nu[s+1]
        lowk = lambda k: nu[k] if k > s else 2**(s+1-k)*(h+1) - 1
        def bad(m):
            for k in range(1, min(m, n)+1):
                lhs = (N-s-m)*comb(m-h, k) + m*comb(m-h-1, k)
                rhs = lowk(k)*comb(m, k)
                if lhs < rhs: return (k, lhs, rhs)
            return None
        m = 2*h + 1; fails = []
        while True:
            b = bad(m)
            if b is None: break
            fails.append((m, b)); m += 1
            if m > N - s: return None, None
        nu[s] = m
        # slack at accepted m
        sl = []
        for k in range(1, min(m, n)+1):
            lhs = (N-s-m)*comb(m-h, k) + m*comb(m-h-1, k); rhs = lowk(k)*comb(m, k)
            sl.append((k, lhs - rhs, round(lhs/rhs, 4)))
        info[s] = (m, h, fails, sl)
    return nu, info
import sys
n = int(sys.argv[1])
for N in map(int, sys.argv[2:]):
    nu, info = chain_dbg(n, N)
    print("N =", N, "nu =", [nu[s] for s in range(n+1)] if nu else None)
    if info:
        for s in sorted(info, reverse=True):
            m, h, fails, sl = info[s]
            print(f"  s={s} m={m} h={h} rejected={[(mm, b[0]) for mm, b in fails][-3:]} slack(k,abs,ratio)={sl[-3:]}")
