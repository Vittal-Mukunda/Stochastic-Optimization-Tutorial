import sys, itertools, time
import numpy as np
from scipy.optimize import linprog, milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix, csr_matrix
sys.path.insert(0, '/home/claude/f4/pkg/lower_bound')
from tour_util import parse_upper

def model(A, N, sizes_max=11):
    n = 11; Rng = range(n); full = (1 << n) - 1
    inR = [sum(1 << i for i in Rng if A[i][j]) for j in Rng]
    outR = [sum(1 << j for j in Rng if A[i][j]) for i in Rng]
    adm = [S for S in range(1 << n) if 5 <= bin(S).count('1') <= sizes_max and all(S & inR[z] for z in Rng)]
    nv = 3 * len(adm)
    rows = []; lo = []; hi = []
    def add(coefs, l, h):
        rows.append(coefs); lo.append(l); hi.append(h)
    def cR(Um): return sum(1 for y in Rng if not (Um >> y) & 1 and (outR[y] & Um) == Um)
    O = N - 13
    add({j: 1 for j in range(nv)}, O, O)
    nu = {2: 11, 3: 5, 4: 1}
    for k in (2, 3, 4):
        for U in itertools.combinations(Rng, k):
            Um = sum(1 << i for i in U)
            add({3*i+t: 1 for i, S in enumerate(adm) if not (S & Um) for t in range(3)}, nu[k] - cR(Um), np.inf)
    for r in Rng:
        add({3*i+t: 1 for i, S in enumerate(adm) if (S >> r) & 1 for t in range(3)}, -np.inf, N - 32)
    add({3*i: 1 for i in range(len(adm))}, 13, np.inf)
    add({3*i+1: 1 for i in range(len(adm))}, 12, np.inf)
    exc_total = N * (N - 49) // 2
    # sum_r (N-32 - degO(r)) + nA - 13 + nB - 12 <= exc_total
    c = {}
    for i, S in enumerate(adm):
        for t in range(3):
            c[3*i+t] = -bin(S).count('1') + (1 if t == 0 else 0) + (1 if t == 1 else 0)
    add(c, -np.inf, exc_total - 11*(N-32) + 25)
    for w, t in (('a', 0), ('b', 1)):
        for k, need in ((3, 1), (2, 5), (1, 11)):
            for U in itertools.combinations(Rng, k):
                Um = sum(1 << i for i in U)
                add({3*i+t: 1 for i, S in enumerate(adm) if not (S & Um)}, need - cR(Um), np.inf)
    M = lil_matrix((len(rows), nv))
    for r, co in enumerate(rows):
        for j, v in co.items(): M[r, j] = v
    return adm, csr_matrix(M), np.array(lo, float), np.array(hi, float)

if __name__ == "__main__":
    N = int(sys.argv[1]); lo_, hi_ = int(sys.argv[2]), int(sys.argv[3])
    lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
    for c in range(lo_, hi_):
        A = parse_upper(lines[c], 11)
        t0 = time.time()
        adm, M, l, h = model(A, N)
        nv = M.shape[1]
        res = milp(c=np.zeros(nv), constraints=LinearConstraint(M, l, h), bounds=Bounds(0, N), integrality=np.zeros(nv))
        print(c, "LP status", res.status, res.message[:40], round(time.time()-t0, 1), flush=True)
