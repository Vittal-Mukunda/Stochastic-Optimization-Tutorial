import sys, itertools, time
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix, csr_matrix, vstack, hstack
sys.path.insert(0, '/home/claude/agents/crosslevel/n4')
from lp_pair import model
sys.path.insert(0, '/home/claude/f4/pkg/lower_bound')
from tour_util import parse_upper

def solve(A, N, tl=120):
    adm, M, l, h = model(A, N)
    na = len(adm); nv = 3*na
    full = (1 << 11) - 1
    idx = {S: i for i, S in enumerate(adm)}
    O = N - 13
    # binary u_i: sum_t x_{i,t} <= O u_i ; disjoint pairs u_i + u_j <= 1
    rows = []
    for i, S in enumerate(adm):
        comp = full & ~S
        if bin(comp).count('1') < 5: continue
        sub = comp
        while sub:
            if sub > S and sub in idx: rows.append((i, idx[sub]))
            sub = (sub - 1) & comp
    # aggregate k=3 constraint (redundant)
    from math import comb
    agg = np.zeros(nv + na)
    for i, S in enumerate(adm):
        for t in range(3): agg[3*i+t] = comb(11 - bin(S).count('1'), 3)
    Mx = hstack([M, csr_matrix((M.shape[0], na))])
    L = lil_matrix((na + len(rows) + 1, nv + na))
    lo = []; hi = []
    for i in range(na):
        for t in range(3): L[i, 3*i+t] = 1
        L[i, nv+i] = -O; lo.append(-np.inf); hi.append(0)
    for r, (i, j) in enumerate(rows):
        L[na+r, nv+i] = 1; L[na+r, nv+j] = 1; lo.append(-np.inf); hi.append(1)
    for j in range(nv): L[na+len(rows), j] = agg[j]
    lo.append(715 - 0); hi.append(np.inf)   # placeholder, cR part handled below
    # compute the R-internal contribution for k=3: 11*C(5,3)=110 ; need 5*165 = 825
    lo[-1] = 5*165 - 110
    Mall = vstack([Mx, csr_matrix(L)])
    lall = np.concatenate([l, lo]); hall = np.concatenate([h, hi])
    integ = np.ones(nv + na)
    ub = np.concatenate([np.full(nv, O), np.ones(na)])
    t0 = time.time()
    res = milp(c=np.zeros(nv+na), constraints=LinearConstraint(Mall, lall, hall), bounds=Bounds(0, ub),
               integrality=integ, options={"time_limit": tl, "disp": False})
    return res.status, res.message, time.time() - t0, len(rows)

if __name__ == "__main__":
    N = int(sys.argv[1]); a, b = int(sys.argv[2]), int(sys.argv[3]); tl = float(sys.argv[4])
    lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
    for c in range(a, b):
        st, msg, wt, nd = solve(parse_upper(lines[c], 11), N, tl)
        print(c, st, msg[:60], round(wt, 1), nd, flush=True)
