"""Local configuration at a tight pair A={a,b} (|D(A)|=11) in a hypothetical S_4 tournament on N vertices
(N = 50 or 51), assuming (RESULTS.md theorem) min in-degree >= 24 and nu_2 >= 11, nu_3 >= 5.
R = D(A), T[R] regular 11-tournament with S_2 (551 classes), O = outside vertices (N-13 of them).
Variables x[S][t] = #outside y with Q_y = R n N^-(y) = S and A-type t (0: y->a only, 1: y->b only, 2: neither).
WLOG a -> b.  All constraints below are necessary conditions (see notes.md)."""
import sys, itertools, time
sys.path.insert(0, '/home/claude/f4/pkg/lower_bound')
from tour_util import parse_upper
from ortools.sat.python import cp_model

def build(A, N, extra=True, time_limit=60.0):
    n = 11; Rng = range(n)
    full = (1 << n) - 1
    inR = [sum(1 << i for i in Rng if A[i][j]) for j in Rng]    # in-neighbours of j within R
    outR = [sum(1 << j for j in Rng if A[i][j]) for i in Rng]   # out-neighbours of i within R
    assert all(bin(m).count('1') == 5 for m in inR)
    # admissible Q: |S| >= 5, meets every N^-_R(z)
    adm = [S for S in range(1 << n) if bin(S).count('1') >= 5 and all(S & inR[z] for z in Rng)]
    idx = {S: i for i, S in enumerate(adm)}
    O = N - 13
    m = cp_model.CpModel()
    x = [[m.NewIntVar(0, O, f"x{S}_{t}") for t in range(3)] for S in adm]
    u = [m.NewBoolVar(f"u{S}") for S in adm]
    for i, S in enumerate(adm):
        m.Add(sum(x[i]) <= O * u[i])
        m.Add(sum(x[i]) >= u[i])
    # intersecting: disjoint admissible sets cannot both be used
    for i, S in enumerate(adm):
        comp = full & ~S
        if bin(comp).count('1') < 5: continue
        # enumerate subsets of comp that are admissible
        sub = comp
        while sub:
            if sub > S and sub in idx: m.AddBoolOr([u[i].Not(), u[idx[sub]].Not()])
            sub = (sub - 1) & comp
    m.Add(sum(x[i][t] for i in range(len(adm)) for t in range(3)) == O)
    def cR(Umask):   # dominators of U inside R
        return sum(1 for y in Rng if not (Umask >> y) & 1 and (outR[y] & Umask) == Umask)
    nu = {1: 24, 2: 11, 3: 5, 4: 1}
    for k in (2, 3, 4):
        for U in itertools.combinations(Rng, k):
            Um = sum(1 << i for i in U)
            terms = [x[i][t] for i, S in enumerate(adm) if not (S & Um) for t in range(3)]
            m.Add(cR(Um) + sum(terms) >= nu[k])
    # in-degree of r in R: d^-(r) = N - 8 - deg_O(r) >= 24
    degO = [sum(x[i][t] for i, S in enumerate(adm) if (S >> r) & 1 for t in range(3)) for r in Rng]
    for r in Rng: m.Add(degO[r] <= N - 32)
    nA = sum(x[i][0] for i in range(len(adm))); nB = sum(x[i][1] for i in range(len(adm)))
    m.Add(nA >= 13); m.Add(nB >= 12)       # a->b: d^-(a) = 11 + nA, d^-(b) = 12 + nB, both >= 24
    exc_total = N * (N - 49) // 2
    m.Add(sum(N - 8 - degO[r] - 24 for r in Rng) + (11 + nA - 24) + (12 + nB - 24) <= exc_total)
    if extra:
        # sets containing w in A plus subsets of R: dominators are y in R (beat w) or outside y beating w
        for w, t in (('a', 0), ('b', 1)):
            for k, need in ((3, 1), (2, 5), (1, 11)):
                for U in itertools.combinations(Rng, k):
                    Um = sum(1 << i for i in U)
                    terms = [x[i][t] for i, S in enumerate(adm) if not (S & Um)]
                    m.Add(cR(Um) + sum(terms) >= need)
    solver = cp_model.CpSolver()
    solver.parameters.num_workers = 1
    solver.parameters.max_time_in_seconds = time_limit
    st = solver.Solve(m)
    return solver.StatusName(st), solver.WallTime(), len(adm)

if __name__ == "__main__":
    N = int(sys.argv[1]); lo = int(sys.argv[2]); hi = int(sys.argv[3]); tl = float(sys.argv[4]) if len(sys.argv) > 4 else 60
    lines = open('/home/claude/f4/pkg/lower_bound/reg11_S2.txt').read().split()
    for c in range(lo, min(hi, len(lines))):
        A = parse_upper(lines[c], 11)
        st, wt, na = build(A, N, time_limit=tl)
        print(c, st, round(wt, 2), na, flush=True)
