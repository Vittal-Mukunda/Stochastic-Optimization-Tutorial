# U-driven greedy covering of n-subsets of [m] by complements of h-sets (h=n+1); variant with intersecting constraint.
import sys, itertools, random
from math import comb
def run(m,n,inter,seed):
    rnd=random.Random(seed); h=n+1; full=(1<<m)-1
    U=[sum(1<<i for i in c) for c in itertools.combinations(range(m),n)]
    idx={u:k for k,u in enumerate(U)}; unc=set(range(len(U)))
    sub={}  # cache: mask -> list of n-subset indices
    def nsubs(mask):
        if mask not in sub:
            el=[i for i in range(m) if mask>>i&1]
            sub[mask]=[idx[sum(1<<i for i in c)] for c in itertools.combinations(el,n)]
        return sub[mask]
    chosen=[]; stuck=0
    order=list(range(len(U))); rnd.shuffle(order)
    for u in order:
        if u not in unc: continue
        comp=full^U[u]; el=[i for i in range(m) if comp>>i&1]
        best=None;bv=-1
        for c in itertools.combinations(el,h):
            F=sum(1<<i for i in c)
            if inter and any(F&G==0 for G in chosen): continue
            v=sum(1 for k in nsubs(full^F) if k in unc)
            if v>bv: bv=v;best=F
        if best is None: stuck+=1; unc.discard(u); continue
        chosen.append(best)
        for k in nsubs(full^best): unc.discard(k)
    return len(chosen),stuck
if __name__=="__main__":
    m,n=int(sys.argv[1]),int(sys.argv[2]); seeds=int(sys.argv[3]) if len(sys.argv)>3 else 3
    cb=comb(m,n)/comb(m-n-1,n)
    P=[run(m,n,False,s)[0] for s in range(seeds)]
    Q=[run(m,n,True,s) for s in range(seeds)]
    print(f"m={m} n={n} countbd={cb:.1f} plain={min(P)} inter={min(q[0] for q in Q)} stuckU={[q[1] for q in Q]} ratio={min(q[0] for q in Q)/min(P):.2f}",flush=True)
