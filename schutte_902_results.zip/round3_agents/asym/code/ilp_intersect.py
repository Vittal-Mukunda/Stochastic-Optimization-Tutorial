# I(m,n): min |F|, F intersecting family of subsets of [m] with sizes in [n+1, m-n], every n-set misses a member.
# Also Cov(m,n): same without intersecting.  Uses scipy milp (HiGHS). single-threaded.
import itertools, sys, time, numpy as np
from math import comb
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix, csr_matrix
def solve(m,n,intersect=True,sizes=None,tl=300):
    if sizes is None: sizes=range(n+1,m-n+1)
    S=[frozenset(c) for k in sizes for c in itertools.combinations(range(m),k)]
    masks=[sum(1<<i for i in s) for s in S]
    U=[sum(1<<i for i in c) for c in itertools.combinations(range(m),n)]
    rows=[];cols=[]
    for r,u in enumerate(U):
        for c,f in enumerate(masks):
            if u&f==0: rows.append(r);cols.append(c)
    A=csr_matrix((np.ones(len(rows)),(rows,cols)),shape=(len(U),len(S)))
    cons=[LinearConstraint(A,lb=np.ones(len(U)),ub=np.inf)]
    if intersect:
        pr=[];pc=[];k=0
        for i in range(len(S)):
            for j in range(i+1,len(S)):
                if masks[i]&masks[j]==0:
                    pr+= [k,k]; pc+=[i,j]; k+=1
        if k:
            B=csr_matrix((np.ones(2*k),(pr,pc)),shape=(k,len(S)))
            cons.append(LinearConstraint(B,lb=-np.inf,ub=np.ones(k)))
    res=milp(c=np.ones(len(S)),constraints=cons,integrality=np.ones(len(S)),bounds=Bounds(0,1),
             options={"time_limit":tl,"disp":False,"threads":1} if False else {"time_limit":tl,"disp":False})
    return res
if __name__=="__main__":
    m,n=int(sys.argv[1]),int(sys.argv[2]); tl=float(sys.argv[3]) if len(sys.argv)>3 else 120
    cb=comb(m,n)/comb(m-n-1,n)
    t=time.time(); r1=solve(m,n,True,tl=tl); t1=time.time()-t
    t=time.time(); r0=solve(m,n,False,tl=tl); t0=time.time()-t
    def st(r): return f"{r.fun:.0f}(bd {getattr(r,'mip_dual_bound',float('nan')):.1f},{r.status})"
    print(f"m={m} n={n} countbd={cb:.2f} Cov={st(r0)} [{t0:.0f}s] I={st(r1)} [{t1:.0f}s]")
