# Exponent test: F0 member of size n, U uniform n-set with |U∩F0| = theta*n.
# Member F with |F∩F0| = iota*n >= 0+, |F\F0| = (1-iota)*n (minimal size n).
# E(iota,theta) = ln P(U∩F=∅)/n. Compare min_theta max_iota E with -Phi(a,1).
import numpy as np
def H(p):
    p=np.clip(p,1e-300,1-1e-16); return -p*np.log(p)-(1-p)*np.log(1-p)
def g(x,y):  # ln C(xn,yn)/n
    if y<0 or y>x+1e-12: return -np.inf
    if x<=0: return 0.0
    return x*H(min(max(y/x,0),1))
def Phi(a,b):
    f=lambda t: t*np.log(t) if t>0 else 0.0
    return f(a)-f(a-1)-f(a-b)+f(a-b-1)
def E(io,th,a):
    return g(1-io,th)-g(1,th)+g(a-2+io,1-th)-g(a-1,1-th)
for a in [2.3,2.45,2.5622,2.7,3.0]:
    best=(1e9,None,None)
    for th in np.linspace(0.001,0.999,999):
        ios=np.linspace(0,1-th,400)
        vals=[E(io,th,a) for io in ios]
        k=int(np.argmax(vals)); M=vals[k]
        if M<best[0]: best=(M,th,ios[k])
    print(f"a={a}: min_th max_io E = {best[0]:.4f} at th={best[1]:.3f}, io*={best[2]:.3f};  -Phi(a,1) = {-Phi(a,1):.4f}")
