# High-precision solve of the level-2 relaxation via its dual (max b.y, A^T y <= 1, y>=0): primal simplex (Bland), mpmath.
import sys, math, mpmath as mp
from math import comb
mp.mp.dps=int(sys.argv[2]) if len(sys.argv)>2 else 60
def eber(m,h,d,k): return sum((-1)**l*comb(k,l)*comb(h-k,d-l)*comb(m-h-k,d-l) for l in range(0,d+1))
def solve(m,h,t,n,copies=False):
    I=list(range(t,h+1 if copies else h)); v={i:comb(h,i)*comb(m-h,h-i) for i in I}
    cols=[]; b=[]          # each dual var r has column a_r (over i) and objective b_r
    for k in range(1,h+1): cols.append([mp.mpf(eber(m,h,h-i,k))/v[i] for i in I]); b.append(mp.mpf(-1))
    for j in range(1,n+1): cols.append([mp.mpf(comb(h-j,i)*comb(m-h-n+j,h-i))/v[i] for i in I]); b.append(mp.mpf(1))
    cb=mp.mpf(comb(m,h))/comb(m-n,h); cols.append([mp.mpf(1)]*len(I)); b.append(cb-1)
    R=len(I); Cn=len(cols)
    # tableau rows: for each i: sum_r a_{r,i} y_r + u_i = 1
    T=[[cols[r][i] for r in range(Cn)]+[mp.mpf(1) if q==i else mp.mpf(0) for q in range(R)]+[mp.mpf(1)] for i in range(R)]
    obj=[-x for x in b]+[mp.mpf(0)]*R+[mp.mpf(0)]   # minimise -b.y
    basis=[Cn+i for i in range(R)]; eps=mp.mpf(10)**(-(mp.mp.dps//2))
    for it in range(5000):
        # reduced costs = obj row (kept updated)
        enter=next((c for c in range(Cn+R) if obj[c]< -eps),None)
        if enter is None: break
        ratios=[(T[r][-1]/T[r][enter],basis[r],r) for r in range(R) if T[r][enter]>eps]
        if not ratios: return None,cb,'unbounded'
        mn=min(x[0] for x in ratios); r=min((x for x in ratios if x[0]<=mn*(1+eps)+eps),key=lambda x:x[1])[2]
        pv=T[r][enter]; T[r]=[x/pv for x in T[r]]
        for q in range(R):
            if q!=r and T[q][enter]!=0:
                f=T[q][enter]; T[q]=[a-f*bb for a,bb in zip(T[q],T[r])]
        f=obj[enter]; obj=[a-f*bb for a,bb in zip(obj,T[r])]; basis[r]=enter
    val=abs(obj[-1])   # max b.y (sign convention of tableau)
    return val+1, cb, it
if __name__=="__main__":
    n=int(sys.argv[1]); al,be=5.648740750254475,2.5621833827060674
    m=round(al*n); h=math.ceil(be*n); t=n+1
    K,cb,it=solve(m,h,t,n)
    print(f"n={n} m={m} h={h} t={t}: K_LP={mp.nstr(K,6)} countbd={mp.nstr(cb,6)} ratio={mp.nstr(K/cb,5)} ln(ratio)/n={mp.nstr(mp.log(K/cb)/n,4)} iters={it}",flush=True)
