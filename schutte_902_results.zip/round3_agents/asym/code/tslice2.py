# exact a_j and single-member t-slice exponent at threshold params (al,be,ta)=(a_j,a_{j-1},a_{j-2})
import numpy as np, mpmath as mp
mp.mp.dps=30
f=lambda t: t*mp.log(t) if t>0 else mp.mpf(0)
Phi=lambda a,b: f(a)-f(a-1)-f(a-b)+f(a-b-1)
a=[None,mp.mpf(1)]
for j in range(2,9):
    a.append(mp.findroot(lambda x: Phi(x,a[-1])-mp.log(2), 2*a[-1]+0.6))
print("a_j:",[float(x) for x in a[1:]])
import sys; sys.path.insert(0,'/home/claude/agents/asym/code')
from tslice import E
def scan(al,be,ta,nth=2000,nio=300):
    out=[]
    for th in np.linspace(1e-4,min(1.0,be)-1e-6,nth):
        lo,hi=ta,be-th
        if lo>hi: out.append((th,-np.inf)); continue
        ios=np.linspace(lo,hi,nio); out.append((th,max(E(i,th,al,be) for i in ios)))
    return out
for j in range(3,7):
    al,be,ta=float(a[j]),float(a[j-1]),float(a[j-2])
    s=scan(al,be,ta); th,v=min(s,key=lambda x:x[1])
    print(f"j={j}: min_th max_io E = {v:.6f} at th={th:.3f}; -ln2={-np.log(2):.6f}; typical overlap be^2/al={be*be/al:.4f} vs ta={ta:.4f}")
