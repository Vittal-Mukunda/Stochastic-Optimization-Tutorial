import sys, itertools, numpy as np
sys.path.insert(0,'/home/claude/agents/asym/code')
from ilp_intersect import *
m,n=int(sys.argv[1]),int(sys.argv[2])
sizes=range(n+1,m-n+1)
S=[frozenset(c) for k in sizes for c in itertools.combinations(range(m),k)]
r=solve(m,n,True,tl=float(sys.argv[3]) if len(sys.argv)>3 else 60)
F=[sorted(S[i]) for i in range(len(S)) if r.x[i]>0.5]
print(len(F),"members; sizes",[len(f) for f in F])
for f in F: print(f)
I=np.array([[len(set(a)&set(b)) for b in F] for a in F]); print("intersection sizes multiset:",sorted(np.bincount(I[np.triu_indices(len(F),1)])))
print("point degrees:",np.bincount([x for f in F for x in f],minlength=m))
