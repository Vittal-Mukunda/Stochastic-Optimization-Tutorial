# t-intersecting slice conditioning exponent. units of n. m=al, h=be (|M0|=be), t=ta.
# E(io,th) = g(be-io,th)-g(be,th) + g(al-be-ph,1-th)-g(al-be,1-th), ph=max(be-io,0), io in [ta, be-th]
import numpy as np
def H(p):
    p=min(max(p,1e-300),1-1e-16); return -p*np.log(p)-(1-p)*np.log(1-p)
def g(x,y):
    if y<-1e-12 or y>x+1e-12: return -np.inf
    if x<=1e-15 or y<=1e-15 or x-y<=1e-15: return 0.0
    return x*H(y/x)
def Phi(a,b):
    f=lambda t: t*np.log(t) if t>0 else 0.0
    return f(a)-f(a-1)-f(a-b)+f(a-b-1)
def E(io,th,al,be):
    ph=max(be-io,0.0)
    return g(be-io,th)-g(be,th)+g(al-be-ph,1-th)-g(al-be,1-th)
def best(al,be,ta,nth=400,nio=400):
    bestv=(np.inf,None,None)
    for th in np.linspace(1e-4,min(1,be)-1e-4,nth):
        lo,hi=ta,be-th
        if lo>hi: return (-np.inf,th,None)   # some slice uncoverable -> contradiction
        ios=np.linspace(lo,hi,nio); v=[E(i,th,al,be) for i in ios]; k=int(np.argmax(v))
        if v[k]<bestv[0]: bestv=(v[k],th,ios[k])
    return bestv
if __name__=="__main__":
    import sys
    a1,a2,a3=1.0,2.5622,5.6487
    for (al,be,ta) in [(a3,a2,a1),(a3,a2,0.0),(6.0,a2,a1),(6.5,a2,a1)]:
        v,th,io=best(al,be,ta)
        print(f"al={al} be={be} ta={ta}: slice exp={-v:.4f} (th={th:.3f},io={io}) vs Phi={Phi(al,be):.4f}  ln2={np.log(2):.4f}")
