# Level-2 relaxation of the local problem at a level with (m,h,t,n): uniform h-sets, pairwise |F∩F'|>=t,
# every n-set missed.  Variables d_i (i=t..h) = avg # other members at intersection i.  Minimise K=1+sum d_i.
# (D_k) 1+sum_i d_i E_{h-i}(k)/v_i >= 0, k=1..h ; (C_j) sum_i d_i N(i,j)/v_i >= 1, j=1..n ; (Cov1) K >= C(m,h)/C(m-n,h).
import sys, numpy as np
from math import comb
from fractions import Fraction
from scipy.optimize import linprog
def eber(m,h,d,k):
    return sum((-1)**l*comb(k,l)*comb(h-k,d-l)*comb(m-h-k,d-l) for l in range(0,d+1))
def build(m,h,t,n):
    I=list(range(t,h+1))
    v={i:comb(h,i)*comb(m-h,h-i) for i in I}
    A=[];b=[]
    for k in range(1,h+1):          # -(sum d_i E/v) <= 1
        A.append([-float(Fraction(eber(m,h,h-i,k),v[i])) for i in I]); b.append(1.0)
    for j in range(1,n+1):          # -(sum d_i N/v) <= -1
        A.append([-float(Fraction(comb(h-j,i)*comb(m-h-n+j,h-i),v[i])) for i in I]); b.append(-1.0)
    cb=comb(m,h)/comb(m-n,h)
    A.append([-1.0]*len(I)); b.append(-(cb-1))
    return I,np.array(A),np.array(b),cb
if __name__=="__main__":
    m,h,t,n=map(int,sys.argv[1:5])
    I,A,b,cb=build(m,h,t,n)
    r=linprog(np.ones(len(I)),A_ub=A,b_ub=b,bounds=[(0,None)]*len(I),method="highs")
    K=1+r.fun if r.status==0 else float('nan')
    print(f"m={m} h={h} t={t} n={n}: status={r.status} K_LP={K:.4g} countbd={cb:.4g} ratio={K/cb:.4g} ln(ratio)/n={np.log(K/cb)/n:.4f}")
