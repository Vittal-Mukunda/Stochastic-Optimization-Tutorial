# Same LP as delsarte_lp.py, column-scaled; dual certificate verified EXACTLY (Fractions) -> rigorous lower bound
import sys, numpy as np
from math import comb
from fractions import Fraction as Fr
from scipy.optimize import linprog
def eber(m,h,d,k): return sum((-1)**l*comb(k,l)*comb(h-k,d-l)*comb(m-h-k,d-l) for l in range(0,d+1))
def run(m,h,t,n):
    I=list(range(t,h+1)); v={i:comb(h,i)*comb(m-h,h-i) for i in I}
    rows=[]; rhs=[]   # constraints in form  sum_i a_i d_i >= r
    for k in range(1,h+1): rows.append([Fr(eber(m,h,h-i,k),v[i]) for i in I]); rhs.append(Fr(-1))
    for j in range(1,n+1): rows.append([Fr(comb(h-j,i)*comb(m-h-n+j,h-i),v[i]) for i in I]); rhs.append(Fr(1))
    cb=Fr(comb(m,h),comb(m-n,h)); rows.append([Fr(1)]*len(I)); rhs.append(cb-1)
    tot=comb(m,h); s=[float(cb*v[i]/tot)+1e-300 for i in I]   # column scale
    A=np.array([[float(a)*s[c] for c,a in enumerate(r)] for r in rows]); b=np.array([float(x) for x in rhs])
    res=linprog(np.array(s),A_ub=-A,b_ub=-b,bounds=[(0,None)]*len(I),method="highs")
    if res.status!=0: return None, float(cb), res.status
    y=np.maximum(-res.ineqlin.marginals,0)       # duals for A z >= b
    # exact check of dual feasibility: sum_r y_r a_{r,i} <= 1 for each column i (unscaled)
    yF=[Fr(float(x)) for x in y]
    worst=max(sum(yF[r]*rows[r][c] for r in range(len(rows))) for c in range(len(I)))
    lb=sum(yF[r]*rhs[r] for r in range(len(rows)))
    if worst>1: lb=lb/worst
    return float(lb)+1, float(cb), 0
if __name__=="__main__":
    import math
    for n in map(int,sys.argv[1:]):
        m=round(5.648740750254475*n); h=math.ceil(2.5621833827060674*n); t=n+1
        lb,cb,st=run(m,h,t,n)
        if lb: print(f"n={n} m={m} h={h} t={t}: rigorous LB K>={lb:.4g}, countbd={cb:.4g}, ratio={lb/cb:.3f}, ln/n={math.log(lb/cb)/n:.4f}",flush=True)
        else: print(f"n={n}: LP status {st}",flush=True)
