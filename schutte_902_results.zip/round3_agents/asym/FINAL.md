# asym: final summary (Erdős #902, can the constant c* = 0.7695 be beaten?)

**Bottom line.** I have no rigorous improvement of c*. What I do have:
* a confirmation that the localized count is vacuous asymptotically;
* four barrier results, which show that every convex or averaging refinement of the cross-level lemma that I could set up gains only a factor of 1 + o(1), a constant, or poly(n);
* one structural, non-convex lead. At level n−3 the local constraint system is rigid, unlike at level n−2. This is stated as Conjecture L3, which would imply a constant better than c*.

Code is in `code/`. The step-by-step log is in `notes.md`.

## 0. Local structure at level s (used throughout)
Let A be an s-set, R = D(A) and m = |R|. For y ∉ A put M_y = D(A∪{y}) = (R∩N⁻(y))∖{y}, and P_y = M_y ∪ ({y}∩R). Then:
* **(F1)** |M_y| ≥ ν_{s+1}.
* **(F2)** For distinct y_1,…,y_j ∉ A with j ≤ n−s, D(A∪{y_1..y_j}) equals the intersection of the M_{y_i}. So **|M_{y_1}∩…∩M_{y_j}| ≥ ν_{s+j}**.
* **(F3)** Every n-subset of R is disjoint from some P_y.

The lemma uses only (F1) and (F3). At level n−2, (F2) says the family is *intersecting*. At level s ≤ n−3, (F2) says it is **ν_{s+2}-intersecting, which is linear in n**.

## 1. Localized count: confirmed vacuous
Write L_r for the localized inequality at r ∈ R:

  Σ_{w∈N⁻(r)∖A} C(m−|P_w|−1, k−1) ≥ ν_k·C(m−1, k−1).

The pairs {(r,w): r ∈ R, w ∈ N⁻(r)∖A} are exactly the pairs {(r,w): w ∉ A, r ∈ R∖P_w}. Hence **Σ_r L_r = k·(global lemma)**, as an exact identity.

The per-vertex bound d⁻(r) ≥ ((m−h)/m)·ν_k·C(m,k)/C(m−h,k) is matched by the arc identity Σ_r |N⁻(r)∖A| = Σ_{w∉A}(m−|P_w|) ≤ (m−h)(N−s). Moreover, the bound falls by a factor e^{−Ω(δn)} once m exceeds the lemma threshold by δn. So it can help only through integrality, as in the n = 4 case.

## 2. Barriers
In this section p = C(m−h,n)/C(m,n), so 1/p is the lemma's counting bound.

* **(B1) Bounded configurations.** This is a theorem, with proof in the report. Fix k. Suppose E|M∩M'| ≥ (1+ε)t for independent uniform h-sets M ⊆ U^c and M' ⊆ U'^c, for every pair of n-sets U, U'. This holds when h²(m−2n)/(m−n)² ≥ (1+ε)t. Then for **every** distribution μ on k-tuples of n-sets,
  max over t-intersecting configurations (M_1..M_k) of P_μ(U_i∩M_i = ∅ for all i) ≥ p^k·(1 − C(k,2)·e^{−cn}).
  So every "N^k·max ≥ 1" averaging argument gives at most N ≥ (1+o(1))/p.
  At the recursion threshold the margin h²(m−2n)/(m−n)² − t equals 0.230n, 0.108n, 0.117n, 0.121n, … for levels j = 2, 3, 4, 5, …, tending to n/8. This covers pairs of disjoint n-sets, k-tuples, and so on.
* **(B1b) Conditioning on a fixed member M_0, with a t-intersecting constraint.** Symmetrizing μ is without loss of generality, and mixtures cost only a factor n+1. The optimal exponent min_θ max_ι E equals −ln 2 to six digits for j = 2, …, 6 (`code/slice_exp.py`, `code/tslice2.py`). The reason is that the typical overlap h²/m (1.162n at level n−3) exceeds t.
* **(B2) Level-2 Sherali–Adams plus PSD at level n−2.** This is a theorem for large n. The explicit symmetric point X = x²(J − A_Kneser) + (x − x²)I, with x = λ/C(m−n,h) and λ ∈ [(m−n)/h, C(m−n,h)/(1 + C(m−h,h))] (that is, [1.56, 2.79] at a_2), satisfies:
  * moment-matrix PSD;
  * X = 0 on disjoint pairs;
  * covering;
  * all products x_F·cov_U, (1−x_F)·cov_U and cov_U·cov_U'.
  So the value of this relaxation is at most 1.56/p.
* **(B3) Level-2 Delsarte LP at level n−3** (uniform member size, t = n+1, Johnson-scheme eigenvalues, covering conditioned on a member). This is numerical, solved with an mpmath simplex (`code/delsarte_mp.py`). The ratio K_LP/(1/p) is 2.07, 2.36, 1.46, 1.86, 2.18, 1.51, 2.38, 1.71 for n = 12, 16, 20, 24, 30, 36, 44, 52. It stays bounded; the variation tracks the rounding of m and h. Forbidding duplicate members changes the values by less than 1%.
* **(B4) Small exact and heuristic data at level n−2.** "I" is the minimum size of an intersecting covering family (`code/ilp_intersect.py`).
  * I/Cov: (7,2) 6/5, (8,2) 6/4, (8,3) 17/14, (9,3) 12/12, (10,3) ≤10/10, (10,4) [50,53]/[50,51].
  * I bounds only: (12,5) I ∈ [134,183], (13,5) I ∈ [62,143].
  * Greedy algorithm, intersecting vs plain at a ≈ 2.5, n = 4..7: 57/57, 116/114, 372/356, 732/701. The overhead is at most 4%, and the greedy never got stuck (`code/greedy_int.py`).
* **(B5) Heuristic obstruction at level n−2.** A random greedy intersecting process should reach the counting exponent, because (a−2)/(a−1)·aH(1/a) = 0.617 < (a−1)H(1/(a−1)) = 1.020 at a = a_2. So the intersecting property alone very likely **cannot** move c*.

## 3. Global non-convex lead: rigidity at level n−3
In the tight scenario, the level-(n−3) minimizer A_3 has m_3 ≈ 5.649n. Its family satisfies (F1)–(F3), with sizes ≥ 2.562n, all pairwise intersections ≥ n+1, and all triple intersections ≥ 1. About 2^n·e^{o(n)} of its members are near-minimal.
* **Random families fail.** Random pairs violate the "≥ n+1" condition with probability e^{−0.0380n}. So random-like families of size e^{0.69n} fail super-exponentially, which is unlike level n−2. The corresponding rates at levels 4, 5, 6 are 0.0133, 0.0058, 0.0027.
* **Junta families fail too.** Ahlswede–Khachatrian families {F : |F∩S| ≥ (|S|+t)/2} need at least e^{1.265n} members to cover.
* **Fisher-type bound (rigorous).** Take s members, each of size h, pairwise meeting in at most w < h²/m elements. Then s ≤ 1 + h(1−h/m)/(h²/m − w), which is about 9.6 at level n−3. Covering, however, forces every near-minimal member to have at least e^{(ln2−o(1))n} partners at intersection about n, namely its near-thin extensions. So the minimum-intersection graph is K_10-free but dense. This is a constraint on actual families that the averaged relaxations in (B3) cannot see.

**Conjecture L3.** There are ε, δ > 0 such that the following holds for all large n. Let m ≤ (a_3+ε)n, and let 𝓜 be a family of subsets of [m] with:
* every member of size ≥ (a_2−δ)n;
* every two distinct members meeting in ≥ n elements;
* every n-subset of [m] disjoint from some member.

Then |𝓜| ≥ e^{(ln 2+δ)n}.

L3 implies ν_{n−3} ≥ (a_3+ε)n whenever N ≤ e^{(ln2+δ)n}, and hence **f(n) ≥ (c* + ε/8 − o(1))·n·2^n**, to first order in ε.

**Most promising next step.** Prove a stability statement in this dense regime (m ≈ 2.2h, t ≈ 0.39h): spread, n-covering, t-intersecting families must be close to juntas, at which point the junta bound above applies. Spread approximations (Kupavskii–Zakharov) or shifting are candidate tools. Delsarte and level-2 relaxations are provably or numerically too weak.
