# asym notes (started 05:51)

## Step 0 (05:55) read context files
Key reformulation (level n-2): A (n-2)-set, R=D(A), m=|R|. Members P_y = Q_y ∪ ({y}∩R), y∉A.
 (i) every n-subset U of R misses some P_y  (covering; gives the lemma)
 (ii) {Q_y} pairwise INTERSECTING (S_n on A∪{y,z})  -- all y, not just near-thin.
Idea: pick a near-thin member F0 (|F0|=n+1); sample U uniformly with |U∩F0|=j fixed.
 Every member meets F0 => P(U misses F) ≤ max_{i>=1} P(i) ; maybe < uniform bound p. Testing numerically.
## Step 1 (06:05) single-member slice conditioning: NO gain
 code/slice_exp.py: min_theta max_iota exponent == -Phi(a,1) exactly (optimum at typical slice).
 Reason (rigorous-ish): conditioning on O(1) fixed members only changes the fractional cover number by poly(n).
 Any exponential gain from "intersecting" must use the non-convex (independent-set-in-Kneser) structure.
 Next: exact ILP for I(m,n)= min |F|, F intersecting, members >= n+1, every n-set misses a member; compare
 with covering number (no intersecting) and counting bound C(m,n)/C(m-n-1,n).
## Step 2 (06:20) ILP small data  (code/ilp_intersect.py)  I = intersecting min, Cov = plain covering min
 n=2: m=5:10/10, m=6:6/6, m=7: I=6 Cov=5, m=8: I=6 Cov=4
 n=3: m=7:35/35, m=8: I=17 Cov=14, m=9: 12/12, m=10: I<=10 (bd 9) Cov=10
Theory notes:
 - averaging over random disjoint (U,U') pairs: violations of intersecting are exp. rare -> invisible to LP/averaging.
 - block construction (majority in k of 2k-1 blocks) gives tau=h families with a=m/h in {2,3,10/3,..->4}; none in (2,3).
   3-block (a=3) needs e^{0.6365 n} members vs counting e^{0.5232 n}. For a in (2,3) only C([2n+1],n+1) (4^n) known so far.
 n=4,m=10 (a=2.5): countbd 42, Cov in [50,51], I in [50,53] (240s limits) -- inconclusive.
## Step 3 (06:40) theory: LP/SDP (Lasserre level 2, Johnson scheme) relaxations give only poly gains;
 any exponential gain from intersecting must be a global (non-convex) argument. Looking at optimal small families.
## Step 4 (resumed after cut-off) theory recap (no rigorous gain)
 - tight scenario: if N<=(c*+eps)n2^n then nu_{n-j} in [a_j n,(a_j+2^j eps)n]; minimiser at level n-2 MUST have
   >= N e^{-o(n)} near-thin extensions (coordinator's framing confirmed).
 - local problem at level n-2 == I(m,n) (intersecting, sizes>=n+1, every n-set missed). Constructions: only C([2n+1],n+1)
   for a in (2,3); block/wreath constructions give a in {2}∪[3,4].
 - idea (a): #{X: D(X)={r}} = #dominating n-sets of T-r; no usable upper bound -> dead end as stated.
 - deeper levels: Q-family nu_{s+2}-intersecting; slack ~0.13-0.16n over typical; random-like violates at e^{-0.038n} (j=3).
## Step 5: coordinator msg: (1) check localized count (2) barrier write-up (3) one global idea. FINAL.md at end.
## Step 6: task (1) localized count -- CONFIRMED vacuous asymptotically
 L_r: sum_{w in N^-(r)\A} C(m-|P_w|-1,k-1) >= nu_k C(m-1,k-1). Identity: sum_r L_r = k*(global lemma) exactly
 (pairs (r,w): r in R\P_w <=> w in N^-(r)\A). Uniform/balanced model satisfies all L_r whenever global holds;
 bound d^-(r) >= ((m-h)/m) C(m,n)/C(m-h,n) decays like e^{-kappa*delta*n} N once m exceeds threshold by delta*n.
## Step 7: NEW IDEA (promising): t-intersecting slice conditioning at levels s<=n-3.
 At level s: members M_y=D(A∪{y}) satisfy |M_y ∩ M_z| >= t := nu_{s+2} (LINEAR in n for s<=n-3!).
 Fix M0 = M_{y0} of min size h0; sample U uniformly in slice |U∩M0|=j. Every other member has |M∩M0|>=t and
 M∩M0 ⊆ M0\U -> constraint iota>=tau can bind (exponentially rare), unlike t=1 at level n-2.
 Rigorous: N-s-1 >= 1/max_{|M|>=h0,|M∩M0|>=t} P_slice(U∩M=∅). Computing exponent now.
## Step 8: barriers established
 (B1) single-member t-slice at threshold params j=3..6: min_th max_io E = -ln2 exactly (code/tslice2.py; exact a_j).
 (B1+) bounded-configuration barrier (theorem): if h^2(m-2n)/(m-n)^2 >= (1+eps)t, any k-tuple averaging bound
   N^k max_{feasible} P_mu >= 1 gives N <= (1+o(1))/p. Hypothesis holds at all threshold levels (margin -> n/8).
 (B2) level-2 SA+PSD at level n-2 (t=1): ansatz c_i=x^2 (1<=i<h) feasible with ratio lambda in [(m-n)/h, ~2.8].
   At level n-3 (t=n+1) the same ansatz FAILS PSD (row mass x^2 * #pairs with |∩|<t ~ K e^{-0.038n} >> 1).
## Step 9: NEW: level-2 relaxation = Delsarte LP (anticode, |F∩F'|>=t) + member-conditioned covering. Computing it.
## Step 10: level-2 Delsarte LP at level n-3 (uniform sizes h, t=n+1): code/delsarte_mp.py (mpmath dual simplex)
 K_LP/countbd: n=12 2.07, 16 2.36, 20 1.46, 24 1.86, 30 2.18, 36 1.51, 44 2.38, 52 1.71  -> BOUNDED (no exp gain).
 distinct-sets version (no copies): n=12 2.08, 16 2.38, 24 1.87, 30 2.20 -> same. Active: D1 (first eigenvalue), C_j (j=4,n).
 => level-2 spectral relaxation at level n-3: O(1) gain only (numerical, n<=52).
## Step 11 (global idea notes): tight scenario => deep levels (2^j >> n/ln n) nearly regular along transitive chains;
 top levels: minimisers atypical by ~n/2 (nu_{n-j}~a_j n vs typical N/2^{n-j}~(a_j+1/2)n). No contradiction found.
 ILP n=5: m=12: I in [134,183] (countbd 132); m=13: I in [62,143] (countbd 61.3); C(11,6)=462. inconclusive.
## Step 12: heuristic test of the non-convex local problem: U-driven greedy, intersecting vs plain (code/greedy_int.py)
 greedy (U-driven) intersecting vs plain at a~2.5: n=4 57/57, n=5 116/114, n=6 372/356, n=7 732/701 (ratio<=1.04), never stuck.
 => level n-2 intersecting is "soft": heuristic random-greedy succeeds since (a-2)/(a-1)*aH(1/a)=0.617 < (a-1)H(1/(a-1))=1.020.
 Level n-3 is "rigid": random pairs violate |M∩M'|>=n+1 at rate e^{-0.038n} -> random-like K=e^{0.69n} families impossible;
 AK-type t-intersecting families need >= e^{1.265n}; but level-2 Delsarte LP sees only O(1). -> Conjecture L3 (FINAL.md).
## Step 13 (final): FINAL.md written. Margins (B1) by level j=2..10: .230 .108 .117 .121 .123 .124 .1245 .1248 .1249 (·n);
 Fisher clique bound s_j: 9.63, 22.05, 46.7, ...; pair-violation rates r_j: .0380 .0133 .0058 .0027 ...
 Conjecture L3 stated (level n-3 rigidity) => c*+eps/8. No rigorous improvement of c* obtained.
