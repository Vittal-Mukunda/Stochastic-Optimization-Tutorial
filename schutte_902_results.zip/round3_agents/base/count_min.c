// count_min.c: histogram of |D(X)| over all s-sets X of a tournament (line v = out-neighbours of v, '#' comments)
// usage: ./count_min file s maxprint
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#define MAXN 1300
#define MW ((MAXN+63)/64)
static uint64_t inn[MAXN][MW]; static int N,W,s; static long long hist[MAXN+1];
static inline int popc(const uint64_t*a){int c=0;for(int i=0;i<W;i++)c+=__builtin_popcountll(a[i]);return c;}
static void rec(int lo,int r,const uint64_t*cur){
  if(r==0){hist[popc(cur)]++;return;}
  uint64_t nx[MW];
  for(int v=lo;v<=N-r;v++){for(int i=0;i<W;i++)nx[i]=cur[i]&inn[v][i];rec(v+1,r-1,nx);}
}
int main(int argc,char**argv){
  FILE*f=fopen(argv[1],"r"); s=atoi(argv[2]); int mp=argc>3?atoi(argv[3]):10;
  static char line[1<<18]; int v=0;
  while(fgets(line,sizeof line,f)){ if(line[0]=='#')continue; char*q=line;int x,off;
    while(sscanf(q,"%d%n",&x,&off)==1){q+=off; inn[x][v>>6]|=1ULL<<(v&63);} v++; }
  N=v; W=(N+63)/64; uint64_t full[MW]; memset(full,0,sizeof full); for(int a=0;a<N;a++) full[a>>6]|=1ULL<<(a&63);
  rec(0,s,full);
  printf("%s: N=%d, histogram of |D(X)| over %d-sets (smallest values):",argv[1],N,s);
  int k=0; for(int i=0;i<=N&&k<mp;i++) if(hist[i]){printf(" %d:%lld",i,hist[i]);k++;} printf("\n");
  return 0;
}
