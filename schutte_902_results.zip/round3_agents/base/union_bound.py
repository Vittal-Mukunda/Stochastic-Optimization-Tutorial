"""Union bound for the planted random construction L(n, M)   (run 2, step 2).

V = W u U u B, |W| = n+1, |U| = M, |B| = n-1.  T[W] contains a directed Hamiltonian cycle, W -> B,
T[B] arbitrary; each u in U: colour beta(u) uniform in B (beta(u) -> u, u -> rest of B), in-set
P(u) = N^-(u) cap W uniform among the 2^{n+1}-1 NONEMPTY subsets of W; T[U] uniformly random.
For an n-set X with |X cap W| = j, |X cap U| = s, |X cap B| = k <= n-2, a vertex u in U \\ X dominates X with prob
    q(j,s,k) = (n-1-k)/(n-1) * (2^{n+1-j}-1)/(2^{n+1}-1) * 2^{-s},   independently over u in U \\ X,
so P(no dominator) <= (1-q)^{M-s}.  Sets with k = n-1 are always dominated (by W).  Hence
    P(not S_n) <= F(n,M) = sum_{k<=n-2} C(n-1,k) sum_j C(n+1,j) C(M,s) (1-q)^{M-s},  s = n-k-j.
We print log F (natural log) for M = ceil(c n^2 2^n), the explicit analytic bounds E0, E1, E2 used in the
proof (c = 2), and the least c (to 3 digits) with F < 1, which should tend to ln 2 = 0.693.
"""
import math
from mpmath import mp, mpf, binomial, log, exp, log1p, ceil
mp.dps = 50

def logF(n, M):
    M = mpf(M); terms = []
    for k in range(0, n - 1):
        for j in range(0, n - k + 1):
            if j > n + 1: continue
            s = n - k - j
            q = mpf(n - 1 - k) / (n - 1) * (mpf(2) ** (n + 1 - j) - 1) / (mpf(2) ** (n + 1) - 1) / mpf(2) ** s
            t = log(binomial(n - 1, k)) + log(binomial(n + 1, j)) + log(binomial(M, s)) + (M - s) * log1p(-q)
            terms.append(t)
    mx = max(terms)
    return mx + log(sum(exp(t - mx) for t in terms))

def analytic(n, c=2):
    """ln E0, ln E1, ln E2 exactly as in the written proof (M = ceil(c n^2 2^n), c = 2)."""
    M = math.ceil(c * n * n * 2 ** n)
    lnfact = math.lgamma(n + 1)
    lE0 = n * math.log(M + n + 1) - lnfact - (1 - 2 ** (-n / 2 - 1)) * (c * n * n - 1)
    lE1 = (n + 1) * math.log(2) + (n / 2) * math.log(M) - (c * n * n - 1) / 2
    lE2 = math.log(max(n - 2, 1)) + (n - 1) * math.log(2) + (n - 1) * math.log(M + n + 1) \
        - (2 * (n - 2) / (n - 1)) * (c * n * n - 1) / 2
    return lE0, lE1, lE2

def minc(n):
    lo, hi = 0.3, 6.0
    for _ in range(40):
        mid = (lo + hi) / 2
        if logF(n, math.ceil(mid * n * n * 2 ** n)) < 0: hi = mid
        else: lo = mid
    return hi

if __name__ == "__main__":
    print(" n |  ln F(n, ceil(2 n^2 2^n))  | ln E0, ln E1, ln E2 (analytic, c=2) | sum E < 1 ? | least c with F<1")
    for n in list(range(2, 31)) + [40, 50, 60, 80, 100]:
        lF = logF(n, math.ceil(2 * n * n * 2 ** n))
        e = analytic(n)
        sE = sum(math.exp(x) for x in e)
        mc = minc(n) if n <= 60 else float('nan')
        print(f"{n:3d} | {float(lF):14.3f} | {e[0]:9.2f} {e[1]:9.2f} {e[2]:9.2f} | {sE < 1!s:5} | {mc:.4f}", flush=True)
