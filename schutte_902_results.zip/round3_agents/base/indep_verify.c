// indep_verify.c  (run 2, written from scratch; does not reuse run-1 code)
// Independent verifier for a tournament file of the form "QR_p on 0..p-1 plus B = p..N-1".
//   usage: ./indep_verify file p n [full_nu_max_sets]
// Checks:
//  (1) tournament axioms from the out-neighbour lists (no loops, no duplicate entries, exactly one arc per pair);
//  (2) T[0..p-1] is exactly the Paley tournament QR_p (u->v iff v-u is a nonzero square mod p);
//  (3) D(B) for B = {p,...,N-1};
//  (4) QR_p has S_n, by checking all n-sets containing {0,1} (valid because x -> a x + b, a a nonzero
//      square, are automorphisms acting transitively on arcs, hence on unordered pairs);
//  (5) every n-set meeting B has a dominator in T -- by DIRECT enumeration of all such n-sets
//      (B' = X cap B nonempty, X0 = X \ B subset of V0), dominators sought in all of V;
//  (6) nu_s(T) for s = 1..n: exact over all s-sets if C(N,s) <= full_nu_max_sets, otherwise
//      min( min over s-sets meeting B , lower bound nu_s(QR_p) for s-sets inside V0 ).
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#define MAXN 1300
#define MW ((MAXN+63)/64)
static unsigned char A[MAXN][MAXN];
static uint64_t inn[MAXN][MW];   // inn[v] = set of vertices beating v
static int N, p, n, W, nb;
static inline int popc(const uint64_t *a){ int s=0; for(int i=0;i<W;i++) s+=__builtin_popcountll(a[i]); return s; }
static inline int nonzero(const uint64_t *a){ for(int i=0;i<W;i++) if(a[i]) return 1; return 0; }
static void setbit(uint64_t *a,int v){ a[v>>6]|=1ULL<<(v&63); }

// generic enumerator: all subsets of {lo..hi-1} of size r, intersected into cur; at leaf call cb
static long long viol; static int minD; static long long cnt;
static void enum_rec(int lo,int hi,int r,const uint64_t *cur){
  if(r==0){ int c=popc(cur); cnt++; if(c==0) viol++; if(c<minD) minD=c; return; }
  uint64_t nx[MW];
  for(int v=lo; v<=hi-r; v++){ for(int i=0;i<W;i++) nx[i]=cur[i]&inn[v][i]; enum_rec(v+1,hi,r-1,nx); }
}
// same, but restricted to vertex set mask (for QR_p alone, dominators must lie in V0)
int main(int argc,char**argv){
  if(argc<4){ fprintf(stderr,"usage\n"); return 1; }
  FILE*f=fopen(argv[1],"r"); p=atoi(argv[2]); n=atoi(argv[3]);
  double fullmax = argc>4 ? atof(argv[4]) : 1e9;
  static char line[1<<18]; int v=0; long long dup=0, oor=0;
  while(fgets(line,sizeof line,f)){
    if(line[0]=='#') continue;
    char *q=line; int x, off;
    while(sscanf(q,"%d%n",&x,&off)==1){ q+=off; if(x<0||x>=MAXN){oor++;continue;} if(A[v][x]) dup++; A[v][x]=1; }
    v++;
  }
  N=v; W=(N+63)/64; nb=N-p;
  long long loops=0, badpair=0;
  for(int a=0;a<N;a++){ if(A[a][a]) loops++; for(int b=0;b<N;b++){ if(b>=N) continue; } }
  for(int a=0;a<N;a++) for(int b=a+1;b<N;b++) if(A[a][b]+A[b][a]!=1) badpair++;
  for(int a=0;a<MAXN;a++) for(int b=N;b<MAXN;b++) if(A[a][b]) oor++;
  printf("file %s: N=%d (p=%d, |B|=%d), n=%d\n",argv[1],N,p,nb,n);
  printf("(1) loops=%lld duplicate-entries=%lld out-of-range=%lld bad-pairs=%lld => %s\n",loops,dup,oor,badpair,
         (loops||dup||oor||badpair)?"NOT A TOURNAMENT":"tournament OK");
  // (2) Paley check
  char *sq=calloc(p,1); for(long t=1;t<p;t++) sq[(t*t)%p]=1;
  long long pal=0;
  for(int a=0;a<p;a++) for(int b=0;b<p;b++) if(a!=b){ int want=sq[((b-a)%p+p)%p]; if(A[a][b]!=want) pal++; }
  printf("(2) arcs inside 0..%d disagreeing with QR_%d: %lld => %s\n",p-1,p,pal,pal?"NOT Paley":"T[V0] = QR_p");
  for(int a=0;a<N;a++) for(int b=0;b<N;b++) if(A[a][b]) setbit(inn[b],a);
  // (3) D(B)
  uint64_t d[MW]; memset(d,0,sizeof d); for(int a=0;a<N;a++) setbit(d,a);
  for(int b=p;b<N;b++) for(int i=0;i<W;i++) d[i]&=inn[b][i];
  printf("(3) D(B) = {"); for(int a=0;a<N;a++) if(d[a>>6]>>(a&63)&1) printf(" %d",a); printf(" }, |D(B)| = %d\n",popc(d));
  // in-degrees inside T[D(B)]
  printf("    in-degrees inside T[D(B)]:"); for(int a=0;a<N;a++) if(d[a>>6]>>(a&63)&1){ int c=0; for(int b=0;b<N;b++) if((d[b>>6]>>(b&63)&1) && A[b][a]) c++; printf(" %d",c);} printf("\n");
  // T[B]
  printf("    arcs inside B:"); for(int a=p;a<N;a++) for(int b=p;b<N;b++) if(A[a][b]) printf(" %d->%d",a,b); printf("\n");
  // (4) QR_p S_n and nu_s(QR_p) via sets containing {0,1}
  // Need inn restricted to V0: build separately
  static uint64_t inn0[MAXN][MW];
  for(int a=0;a<p;a++) for(int b=0;b<p;b++) if(A[a][b]) setbit(inn0[b],a);
  int nuQR[20]; nuQR[0]=p; nuQR[1]=(p-1)/2;
  for(int s=2;s<=n;s++){
    // enumerate s-sets {0,1} + (s-2) from 2..p-1 with inn0
    uint64_t cur[MW]; for(int i=0;i<W;i++) cur[i]=inn0[0][i]&inn0[1][i];
    // temporarily swap inn with inn0 via a local recursion
    long long vv=0; int mn=1<<30; long long c=0;
    // iterative recursion with explicit stack
    int idx[20]; uint64_t st[20][MW]; int depth=0; int r=s-2;
    if(r==0){ int cc=popc(cur); mn=cc; c=1; if(cc==0) vv++; }
    else {
      memcpy(st[0],cur,sizeof cur); idx[0]=1;
      while(depth>=0){
        idx[depth]++;
        if(idx[depth] > p-(r-depth)){ depth--; continue; }
        int u=idx[depth];
        for(int i=0;i<W;i++) st[depth+1][i]=st[depth][i]&inn0[u][i];
        if(depth+1==r){ int cc=popc(st[depth+1]); c++; if(cc==0) vv++; if(cc<mn) mn=cc; }
        else { idx[depth+1]=u; depth++; }
      }
    }
    nuQR[s]=mn;
    printf("(4) QR_%d: %d-sets containing {0,1}: %lld checked, undominated %lld, min |D| = %d\n",p,s,c,vv,mn);
  }
  printf("    => nu_s(QR_%d), s=0..%d:",p,n); for(int s=0;s<=n;s++) printf(" %d",nuQR[s]); printf("\n");
  // (5) all n-sets meeting B, dominators in all of V
  long long totviol=0; int minmeet[20]; for(int s=0;s<=n;s++) minmeet[s]=1<<30;
  for(int s=1;s<=n;s++){
    // s-sets meeting B: B' nonempty subset of B with |B'|=k<=s, X0 subset of V0 of size s-k
    long long sv=0, sc=0; int smin=1<<30;
    for(int m=1;m<(1<<nb);m++){ int k=__builtin_popcount(m); if(k>s) continue;
      uint64_t cur[MW]; memset(cur,0,sizeof cur); for(int a=0;a<N;a++) setbit(cur,a);
      for(int b=0;b<nb;b++) if(m>>b&1) for(int i=0;i<W;i++) cur[i]&=inn[p+b][i];
      viol=0; minD=1<<30; cnt=0;
      enum_rec(0,p,s-k,cur);
      sv+=viol; sc+=cnt; if(minD<smin) smin=minD;
    }
    minmeet[s]=smin;
    printf("(5) s=%d: s-sets meeting B: %lld, with no dominator: %lld, min |D| = %d\n",s,sc,sv,smin);
    if(s==n) totviol=sv;
    fflush(stdout);
  }
  printf("    => n-sets meeting B without dominator: %lld\n",totviol);
  // (6) nu_s(T)
  printf("(6) nu_s(T):");
  for(int s=1;s<=n;s++){
    double cs=1; for(int t=0;t<s;t++) cs=cs*(N-t)/(t+1);
    if(cs<=fullmax){
      uint64_t cur[MW]; memset(cur,0,sizeof cur); for(int a=0;a<N;a++) setbit(cur,a);
      viol=0; minD=1<<30; cnt=0; enum_rec(0,N,s,cur);
      printf(" s=%d:%d(exact)",s,minD);
    } else {
      int lb = nuQR[s]; int val = minmeet[s] < lb ? minmeet[s] : -1;
      if(val>=0) printf(" s=%d:%d(exact: attained by a set meeting B, and sets in V0 have >= %d)",s,val,lb);
      else printf(" s=%d:>=%d(meeting B min %d; inside V0 >= nu_s(QR)=%d)",s,minmeet[s]<lb?minmeet[s]:lb,minmeet[s],lb);
    }
    fflush(stdout);
  }
  printf("\n");
  return 0;
}
