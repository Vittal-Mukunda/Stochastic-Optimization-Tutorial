"""Try to make QR_67 thin (nu_3 = 5) by reversing ONE arc y->b with B a 3-set, |D(B)| = 6, y in D(B), b in B.
After reversing, D(B) loses y.  The only n-sets that can lose a dominator are 4-sets X containing b
with y in D(X) (y not in X); X becomes undominated iff D(X) = {y}.  (b gains the out-arc b->y, which can only
create new dominators.)  We test this exactly and then re-verify the resulting tournament exhaustively."""
import itertools, sys
sys.path.insert(0, '.')
from tlib import paley_out, inn_from_out, D, pc, bits, check_Sn, nu_profile
p, n = 67, 4
out = paley_out(p); inn = inn_from_out(out); full = (1 << p) - 1
# 3-sets through {0,1} with |D| = 6 (every 3-set is equivalent to one of these)
cands = [ (0, 1, c) for c in range(2, p) if pc(D(inn, p, (0, 1, c))) == 6 ]
print("3-sets {0,1,c} with |D|=6:", len(cands))
good = []
for Bset in cands:
    dB = D(inn, p, Bset)
    for y in bits(dB):
        for b in Bset:
            ok = True
            others = [v for v in range(p) if v != b and v != y]
            for Z in itertools.combinations(others, 3):
                d = inn[b]
                for z in Z: d &= inn[z]
                if d == (1 << y): ok = False; break
            if ok: good.append((Bset, y, b))
    if good: break
print("successful single flips found (first B):", good[:10], "count", len(good))
if good:
    Bset, y, b = good[0]
    out2 = list(out); out2[y] &= ~(1 << b); out2[b] |= (1 << y)
    bad = check_Sn(out2, n)
    print("exhaustive S_4 check of modified QR_67: undominated 4-sets =", len(bad))
    inn2 = inn_from_out(out2)
    print("D(B) after flip:", sorted(bits(D(inn2, p, Bset))), " nu profile:", nu_profile(out2, n))
    with open("thin_S4_N67.txt", "w") as f:
        f.write(f"# S_4 tournament on 67 vertices: QR_67 with the single arc {y}->{b} reversed; B={list(Bset)}, D(B) has 5 elements\n")
        f.write("# line v: out-neighbours of v\n")
        for v in range(p): f.write(" ".join(map(str, bits(out2[v]))) + "\n")
    print("saved thin_S4_N67.txt")
