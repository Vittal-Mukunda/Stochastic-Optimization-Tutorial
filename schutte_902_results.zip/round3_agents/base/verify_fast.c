// Fast exhaustive S_n verifier.  T has S_n  <=>  for every (n-1)-set X, the set S = D(X) "dominates"
// V \ X, i.e. (a) no vertex outside X ∪ S beats all of S, and (b) T[S] has no source (and S nonempty).
// Enumerates all (n-1)-sets.  Also reports nu_{n-1} and the number of (n-1)-sets attaining it.
// Input: line v = out-neighbours of v ('#' lines ignored).   usage: ./verify_fast file n
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#define MAXN 1280
#define MW (MAXN/64)
int N=0,n,W; uint64_t inn[MAXN][MW], outm[MAXN][MW], full[MW];
long long nbad=0, nsets=0; int numin=1<<30; long long nmin=0; int X[16];
static inline int pc(const uint64_t*a){int s=0;for(int i=0;i<W;i++)s+=__builtin_popcountll(a[i]);return s;}
void leaf(uint64_t*S){
  nsets++;
  int c=pc(S); if(c<numin){numin=c;nmin=0;} if(c==numin) nmin++;
  uint64_t C[MW]; memcpy(C,full,sizeof(uint64_t)*W);
  for(int i=0;i<W;i++){ uint64_t m=S[i]; while(m){ int u=i*64+__builtin_ctzll(m); m&=m-1;
      for(int j=0;j<W;j++) C[j]&=inn[u][j];   // C = vertices beating every u in S
      // source check: u beats all of S\{u}  <=>  inn[u] ∩ S = 0
      int src=1; for(int j=0;j<W;j++) if(inn[u][j]&S[j]){src=0;break;}
      if(src){ nbad++; if(nbad<5){printf("bad: X=");for(int t=0;t<n-1;t++)printf("%d ",X[t]);printf("+source %d of D(X)\n",u);} }
  } }
  for(int t=0;t<n-1;t++) C[X[t]>>6]&=~(1ULL<<(X[t]&63));
  for(int j=0;j<W;j++) if(C[j]){ nbad++; if(nbad<5){printf("bad: X=");for(int t=0;t<n-1;t++)printf("%d ",X[t]);printf("+ a vertex beating D(X)\n");} break; }
  if(c==0){ nbad++; }
}
void rec(int start,int depth,uint64_t*cur){
  if(depth==n-1){ leaf(cur); return; }
  uint64_t nx[MW];
  for(int v=start;v<N;v++){ for(int i=0;i<W;i++) nx[i]=cur[i]&inn[v][i]; X[depth]=v; rec(v+1,depth+1,nx); }
}
int main(int argc,char**argv){
  FILE*f=fopen(argv[1],"r"); n=atoi(argv[2]);
  static char line[1<<17]; int v=0;
  while(fgets(line,sizeof line,f)){ if(line[0]=='#') continue;
    char*p=line; int x,off; while(sscanf(p,"%d%n",&x,&off)==1){ outm[v][x>>6]|=1ULL<<(x&63); p+=off; } v++; }
  N=v; W=(N+63)/64;
  for(int a=0;a<N;a++) for(int b=0;b<N;b++){ int ab=(outm[a][b>>6]>>(b&63))&1, ba=(outm[b][a>>6]>>(a&63))&1;
     if(a==b && ab){printf("loop\n");return 1;} if(a!=b && ab+ba!=1){printf("not a tournament %d %d\n",a,b);return 1;}
     if(ab) inn[b][a>>6]|=1ULL<<(a&63); }
  for(int a=0;a<N;a++) full[a>>6]|=1ULL<<(a&63);
  rec(0,0,full);
  printf("%s: N=%d n=%d, (n-1)-sets checked %lld, violations %lld => %s ; nu_{n-1}=%d attained by %lld sets\n",
     argv[1],N,n,nsets,nbad,nbad?"NOT S_n":"S_n holds",numin,nmin);
  return 0;
}
