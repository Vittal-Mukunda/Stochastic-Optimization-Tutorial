"""Monte Carlo sanity check of the first-moment formula used in union_bound.py (run 2, step 2).
Builds L(n,M) at random, counts n-sets without a dominator exactly, compares the average with
F(n,M) = expected number of n-sets having no dominator in U (an upper bound for the true expectation)."""
import random, itertools, sys, math
from union_bound import logF

def build(n, M, rng):
    W = list(range(n + 1)); U = list(range(n + 1, n + 1 + M)); B = list(range(n + 1 + M, n + 1 + M + n - 1))
    N = 2 * n + M; out = [0] * N
    def arc(a, b): out[a] |= 1 << b
    for i in range(n + 1):                       # T[W]: Hamiltonian cycle i -> i+1, other pairs random
        for j in range(i + 1, n + 1):
            if j == i + 1 or (i == 0 and j == n): (arc(i, j) if j == i + 1 else arc(j, i))
            else: (arc(i, j) if rng.random() < 0.5 else arc(j, i))
    for w in W:
        for b in B: arc(w, b)
    for i in range(len(B)):
        for j in range(i + 1, len(B)): arc(B[i], B[j])
    for u in U:
        c = rng.choice(B)
        for b in B: (arc(b, u) if b == c else arc(u, b))
        while True:
            P = [w for w in W if rng.random() < 0.5]
            if P: break
        for w in W: (arc(w, u) if w in P else arc(u, w))
    for a in range(len(U)):
        for b in range(a + 1, len(U)):
            (arc(U[a], U[b]) if rng.random() < 0.5 else arc(U[b], U[a]))
    return out, B

def count_undominated(out, n):
    N = len(out); inn = [0] * N
    for u in range(N):
        m = out[u]
        while m:
            b = m & -m; inn[b.bit_length() - 1] |= 1 << u; m ^= b
    bad = 0
    full = (1 << N) - 1
    def rec(start, depth, cur):
        nonlocal bad
        if depth == n:
            if cur == 0: bad += 1
            return
        for v in range(start, N): rec(v + 1, depth + 1, cur & inn[v])
    rec(0, 0, full)
    return bad, inn

rng = random.Random(12345)
for n, M, reps in [(3, 40, 30), (3, 60, 30), (3, 144, 5), (4, 120, 4)]:
    tot = 0; dB_ok = True
    for r in range(reps):
        out, B = build(n, M, rng)
        bad, inn = count_undominated(out, n)
        d = (1 << len(out)) - 1
        for b in B: d &= inn[b]
        dB_ok &= (bin(d).count('1') == n + 1)
        tot += bad
    print(f"n={n} M={M}: mean #undominated n-sets = {tot/reps:.3f}   first-moment bound F = {float(math.e**logF(n, M)):.3f}   |D(B)|=n+1 always: {dB_ok}", flush=True)
