// Independent verifier: reads a tournament (line v = out-neighbours of v, '#' comments),
// checks it is a tournament, checks S_n exhaustively (all n-sets), prints nu_0..nu_n,
// and for a given list of vertices B (argv[3..]) prints D(B).
// usage: ./verify_tour file n [B...]
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#define MAXN 1280
#define MW (MAXN/64)
int N=0, n, W;
uint64_t inn[MAXN][MW], outm[MAXN][MW];
long long nbad=0; int nu[16];
static inline int pc(const uint64_t*a){int s=0;for(int i=0;i<W;i++)s+=__builtin_popcountll(a[i]);return s;}
void rec(int start,int depth,uint64_t*cur){
  int c=pc(cur); if(c<nu[depth]) nu[depth]=c;
  if(depth==n){ if(c==0) nbad++; return; }
  uint64_t nx[MW];
  for(int v=start;v<N;v++){ for(int i=0;i<W;i++) nx[i]=cur[i]&inn[v][i]; rec(v+1,depth+1,nx); }
}
int main(int argc,char**argv){
  FILE*f=fopen(argv[1],"r"); n=atoi(argv[2]);
  static char line[1<<16]; int v=0;
  while(fgets(line,sizeof line,f)){ if(line[0]=='#') continue;
    char*p=line; int x,off; while(sscanf(p,"%d%n",&x,&off)==1){ outm[v][x>>6]|=1ULL<<(x&63); p+=off; } v++; }
  N=v; W=(N+63)/64;
  for(int a=0;a<N;a++) for(int b=0;b<N;b++){ int ab=(outm[a][b>>6]>>(b&63))&1, ba=(outm[b][a>>6]>>(a&63))&1;
     if(a==b && ab){printf("loop at %d\n",a);return 1;} if(a!=b && ab+ba!=1){printf("not a tournament at %d %d\n",a,b);return 1;}
     if(ab) inn[b][a>>6]|=1ULL<<(a&63); }
  uint64_t full[MW]; memset(full,0,sizeof full); for(int a=0;a<N;a++) full[a>>6]|=1ULL<<(a&63);
  for(int i=0;i<16;i++) nu[i]=1<<30;
  rec(0,0,full);
  printf("N=%d n=%d : tournament OK; undominated n-sets = %lld ; nu_0..nu_n =",N,n,nbad);
  for(int i=0;i<=n;i++) printf(" %d",nu[i]); printf("\n");
  if(argc>3){ uint64_t d[MW]; memcpy(d,full,sizeof d);
    for(int i=3;i<argc;i++){int b=atoi(argv[i]); for(int j=0;j<W;j++) d[j]&=inn[b][j];}
    printf("D(B) = {"); for(int a=0;a<N;a++) if((d[a>>6]>>(a&63))&1) printf(" %d",a); printf(" }  size %d\n",pc(d)); }
  return 0;
}
