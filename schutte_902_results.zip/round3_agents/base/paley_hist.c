// Histogram of |D(X)| over k-sets X of the Paley tournament QR_p, using the fact that
// G = {x -> a x + b : a nonzero square} acts regularly on unordered pairs, so the
// distribution over k-sets containing {0,1} equals the distribution over all k-sets.
// usage: ./paley_hist p k
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#define MAXW 32
int p, W, k;
uint64_t inn[4096][MAXW];
long long hist[4096];
static inline int pc(const uint64_t *a){int s=0;for(int i=0;i<W;i++)s+=__builtin_popcountll(a[i]);return s;}
void rec(int start, int depth, uint64_t *cur){
  if(depth==k){ hist[pc(cur)]++; return; }
  uint64_t nxt[MAXW];
  for(int v=start; v<p; v++){
    for(int i=0;i<W;i++) nxt[i]=cur[i]&inn[v][i];
    rec(v+1, depth+1, nxt);
  }
}
int main(int argc,char**argv){
  p=atoi(argv[1]); k=atoi(argv[2]); W=(p+63)/64;
  char *sq=calloc(p,1); for(int x=1;x<p;x++) sq[(long)x*x%p]=1;
  for(int v=0;v<p;v++){ memset(inn[v],0,sizeof(inn[v]));
    for(int u=0;u<p;u++) if(u!=v && sq[((v-u)%p+p)%p]) inn[v][u>>6]|=1ULL<<(u&63); }
  uint64_t cur[MAXW]; for(int i=0;i<W;i++) cur[i]=inn[0][i]&inn[1][i];
  if(k==1){ hist[pc(inn[0])]++; }
  else rec(2,2,cur);
  long long tot=0; for(int i=0;i<=p;i++) tot+=hist[i];
  printf("QR_%d k=%d : histogram of |D(X)| over %lld k-sets containing {0,1} (= distribution over all k-sets)\n",p,k,tot);
  for(int i=0;i<=p;i++) if(hist[i]) printf("  |D|=%d : %lld  (%.6f)\n",i,hist[i],(double)hist[i]/tot);
  return 0;
}
