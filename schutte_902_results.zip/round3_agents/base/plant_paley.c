// Plant a thin (n-1)-set into QR_p (p = 3 mod 4):
//   W = (n+1)-subset of V0 that dominates every vertex of V0 (incl. itself: no source in T[W]);
//   B = n-1 new vertices p..p+n-2, W -> B, T[B] transitive (b_i -> b_j for i<j);
//   each v in V0\W gets a colour beta(v) in B: beta(v) -> v, and v -> every other b  ("max type").
// Then D(B) = W.  Checks S_n for every n-set meeting B (n-sets inside V0 are dominated since QR_p is S_n,
// which is checked separately).  Tries several seeds; writes the first good tournament.
// usage: ./plant_paley p n seeds
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#define MW 20
int p,n,N,W,nb; uint64_t inn[1300][MW]; int Wset[16]; int beta[1300];
unsigned long long rng=88172645463325252ULL; unsigned long long xr(){rng^=rng<<13;rng^=rng>>7;rng^=rng<<17;return rng;}
static inline int pc(const uint64_t*a){int s=0;for(int i=0;i<W;i++)s+=__builtin_popcountll(a[i]);return s;}
static inline int isz(const uint64_t*a){for(int i=0;i<W;i++) if(a[i]) return 0; return 1;}
long long bad;
// enumerate X0 subsets of V0 of size s (s = n - k), and for each, every k-subset of B
int s_target; int X0[16];
void rec(int start,int depth,uint64_t*cur){
  if(depth==s_target){
    int k=n-s_target;
    // for every k-subset of B (bitmask over nb bits) check that cur ∩ (inn of all b in B') != 0
    for(int m=0;m<(1<<nb);m++){ if(__builtin_popcount(m)!=k) continue;
      uint64_t t[MW]; memcpy(t,cur,sizeof(uint64_t)*W);
      for(int b=0;b<nb;b++) if(m>>b&1) for(int i=0;i<W;i++) t[i]&=inn[p+b][i];
      if(isz(t)) bad++;
    }
    return;
  }
  uint64_t nx[MW];
  for(int v=start;v<p;v++){ for(int i=0;i<W;i++) nx[i]=cur[i]&inn[v][i]; X0[depth]=v; rec(v+1,depth+1,nx); }
}
int main(int argc,char**argv){
  p=atoi(argv[1]); n=atoi(argv[2]); int seeds=atoi(argv[3]); nb=n-1; N=p+nb; W=(N+63)/64;
  char*sq=calloc(p,1); for(long x=1;x<p;x++) sq[x*x%p]=1;
  for(int seed=1; seed<=seeds; seed++){
    rng=88172645463325252ULL ^ (seed*0x9E3779B97F4A7C15ULL); for(int i=0;i<10;i++) xr();
    // choose W: random (n+1)-sets until dominating with no source
    int tries=0;
    while(1){ tries++;
      for(int i=0;i<=n;i++){ int ok; do{ Wset[i]=xr()%p; ok=1; for(int j=0;j<i;j++) if(Wset[j]==Wset[i]) ok=0; }while(!ok); }
      int good=1;
      for(int v=0;v<p && good;v++){ int has=0; for(int i=0;i<=n;i++){int w=Wset[i]; if(w!=v && sq[((v-w)%p+p)%p]) has=1;} if(!has) good=0; }
      if(good) break;
    }
    memset(inn,0,sizeof inn);
    for(int v=0;v<p;v++) for(int u=0;u<p;u++) if(u!=v && sq[((v-u)%p+p)%p]) inn[v][u>>6]|=1ULL<<(u&63);
    char inW[1300]; memset(inW,0,sizeof inW); for(int i=0;i<=n;i++) inW[Wset[i]]=1;
    for(int v=0;v<p;v++){ if(inW[v]){ for(int b=0;b<nb;b++) inn[p+b][v>>6]|=1ULL<<(v&63); continue; }
      beta[v]=xr()%nb;
      for(int b=0;b<nb;b++){ if(b==beta[v]) inn[v][(p+b)>>6]|=1ULL<<((p+b)&63); else inn[p+b][v>>6]|=1ULL<<(v&63); } }
    for(int i=0;i<nb;i++) for(int j=i+1;j<nb;j++) inn[p+j][(p+i)>>6]|=1ULL<<((p+i)&63);   // b_i -> b_j
    // D(B)
    uint64_t d[MW]; for(int i=0;i<W;i++) d[i]=~0ULL; 
    for(int i=0;i<W;i++){ if(i==W-1 && (N&63)) d[i]=(1ULL<<(N&63))-1; }
    for(int b=0;b<nb;b++) for(int i=0;i<W;i++) d[i]&=inn[p+b][i];
    bad=0;
    for(s_target=1; s_target<=n-1; s_target++){
      uint64_t full[MW]; for(int i=0;i<W;i++) full[i]=d[i]|~d[i]; // all ones
      for(int i=0;i<W;i++){ full[i]=~0ULL; if(i==W-1 && (N&63)) full[i]=(1ULL<<(N&63))-1; }
      rec(0,0,full);
    }
    // also X0 empty: the subsets of B of size n -- impossible since |B|=n-1.  (n-sets inside B∪W∪... are covered above
    // because the enumeration of X0 ranges over all of V0, which contains W.)
    printf("seed %d: W={",seed); for(int i=0;i<=n;i++) printf(" %d",Wset[i]); printf(" } (after %d tries), |D(B)|=%d, undominated n-sets meeting B: %lld\n",tries,pc(d),bad); fflush(stdout);
    if(bad==0){
      char fn[64]; sprintf(fn,"thin_S%d_N%d.txt",n,N); FILE*f=fopen(fn,"w");
      fprintf(f,"# S_%d tournament on %d vertices: QR_%d (0..%d) plus B = %d..%d ; D(B) = W =",n,N,p,p-1,p,p+nb-1);
      for(int i=0;i<=n;i++) fprintf(f," %d",Wset[i]); fprintf(f,"\n# line v: out-neighbours of v\n");
      for(int v=0;v<N;v++){ for(int u=0;u<N;u++) if((inn[u][v>>6]>>(v&63))&1) fprintf(f,"%d ",u); fprintf(f,"\n"); }
      fclose(f); printf("saved %s\n",fn); return 0;
    }
  }
  return 1;
}
