"""Plant a thin (n-1)-set into an S_n background T0 = QR_p:
   new vertices B = {b_0..b_{n-2}}, R := W (an (n+1)-subset of V0 that dominates V0 and has no source),
   W -> B, every v outside W must lose to some b (so D(B) = W exactly).
   Unknowns: arcs v -> b_i (v in V0 \\ W) and arcs inside B.  Every n-set meeting B must have a dominator.
   usage: python3 plant_sat.py p n [seed] [tries]"""
import sys, itertools, random, time
from pysat.solvers import Cadical153
from tlib import *

p = int(sys.argv[1]); n = int(sys.argv[2]); seed = int(sys.argv[3]) if len(sys.argv) > 3 else 1
tries = int(sys.argv[4]) if len(sys.argv) > 4 else 20
random.seed(seed)
out0 = paley_out(p); inn0 = inn_from_out(out0); N0 = p; full = (1 << N0) - 1
nb = n - 1

def is_dom_nosource(W):
    Wm = sum(1 << w for w in W)
    for v in range(N0):
        if inn0[v] & Wm == 0: return False   # v (in W or not) has no in-neighbour in W
    return True

# find candidate W
cands = []
for _ in range(200000):
    W = tuple(sorted(random.sample(range(N0), n+1)))
    if is_dom_nosource(W): cands.append(W)
    if len(cands) >= tries: break
print(f"QR_{p}, n={n}: found {len(cands)} dominating (n+1)-sets W without source", flush=True)

def solve(W):
    Wm = sum(1 << w for w in W)
    rest = [v for v in range(N0) if not (Wm >> v & 1)]
    var = {}
    def V(key):
        if key not in var: var[key] = len(var) + 1
        return var[key]
    # x(v,i): v -> b_i ; e(i,j) (i<j): b_i -> b_j
    x = lambda v, i: V(('x', v, i))
    def barc(i, j):  # literal "b_i -> b_j"
        return V(('e', i, j)) if i < j else -V(('e', j, i))
    cls = []
    for v in rest: cls.append([-x(v, i) for i in range(nb)])
    # aux a(v,S) <-> AND_{i in S} x(v,i), for subsets S of B of size >= 2
    def aux_and(v, S):
        key = ('a', v, S)
        if key in var: return var[key]
        a = V(key)
        for i in S: cls.append([-a, x(v, i)])
        return a
    # B-internal option: b_k dominates B' u X0: b_k -> B' and b_k -> each x in X0 (x not in W)
    def aux_bint(k, Bp, X0):
        if any(Wm >> u & 1 for u in X0): return None
        key = ('g', k, Bp, X0)
        a = V(key)
        for i in Bp: cls.append([-a, barc(k, i)])
        for u in X0: cls.append([-a, -x(u, k)])
        return a
    nclauses = 0
    for k in range(1, nb):           # |B'| = k  (k = nb handled by W dominating)
        size0 = n - k
        for X0 in itertools.combinations(range(N0), size0):
            d = full
            for u in X0: d &= inn0[u]
            if d & Wm: continue
            dl = list(bits(d))
            for Bp in itertools.combinations(range(nb), k):
                if k == 1: lits = [x(v, Bp[0]) for v in dl]
                else: lits = [aux_and(v, Bp) for v in dl]
                for kk in range(nb):
                    if kk in Bp: continue
                    g = aux_bint(kk, Bp, X0)
                    if g is not None: lits.append(g)
                cls.append(lits); nclauses += 1
    s = Cadical153(bootstrap_with=cls)
    t = time.time(); ok = s.solve(); dt = time.time() - t
    model = s.get_model() if ok else None
    s.delete()
    return ok, model, var, nclauses, dt, rest

for W in cands:
    ok, model, var, nc, dt, rest = solve(W)
    print(f"W={W}: {nc} clauses, vars={len(var)}, SAT={ok}, {dt:.1f}s", flush=True)
    if ok:
        ms = set(l for l in model if l > 0)
        # build full tournament: vertices 0..p-1 = QR_p, p..p+nb-1 = B
        N = p + nb
        out = [o for o in out0] + [0]*nb
        for b in range(nb): 
            for w in W: out[w] |= 1 << (p + b)
        for v in rest:
            for i in range(nb):
                if var[('x', v, i)] in ms: out[v] |= 1 << (p+i)
                else: out[p+i] |= 1 << v
        for i in range(nb):
            for j in range(i+1, nb):
                key = ('e', i, j)
                if key in var and var[key] in ms: out[p+i] |= 1 << (p+j)
                else: out[p+j] |= 1 << (p+i)
        inn = inn_from_out(out)
        Bset = list(range(p, p+nb))
        dB = D(inn, N, Bset)
        print("  D(B) =", sorted(bits(dB)), " size", pc(dB), flush=True)
        bad = check_Sn(out, n, must_contain=set(Bset))
        print("  undominated n-sets meeting B:", len(bad), flush=True)
        if not bad:
            fn = f"thin_S{n}_N{N}.txt"
            with open(fn, "w") as f:
                f.write(f"# S_{n} tournament on {N} vertices: QR_{p} (0..{p-1}) plus B={Bset}; D(B)=W={list(W)}\n")
                f.write("# line v: out-neighbours of v\n")
                for v in range(N): f.write(" ".join(map(str, bits(out[v]))) + "\n")
            print("  saved", fn, flush=True)
        break
