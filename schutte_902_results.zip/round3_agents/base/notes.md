# Agent "base" -- notes (run 2)

Run 1 left files but no notes; this file is (re)started in run 2 and appended after every step.

## Step 0 (context checks, run 2)
Paley histograms (paley_hist.c, uses arc-transitivity of x -> a x + b, a a nonzero square):
- QR_7:   nu_1 = 3  = n+1 for n=2  (thin already)
- QR_19:  nu_2 = 4  = n+1 for n=3  (thin already; doubly regular: every pair has exactly (p-3)/4 = 4 common in-nbrs)
- QR_67:  nu_3 = 6  = n+2 for n=4  (|D| over 3-sets: 6:15.4%, 7:32.3%, 8:27.7%, 9:23.1%, 10:1.5%)
- QR_331: nu_4 = 12 = 2n+2 for n=5 (|D| over 4-sets ranges 12..; mean ~ 20.7)
So the Paley upper-bound tournaments are NOT thin for n = 4, 5; the thin examples of run 1 are obtained by planting.

## Step 1 (DONE): independent verification of thin_S5_N335.txt (and re-check of thin_S4_N70.txt)
New code written from scratch: indep_verify.c (C) + a numpy cross-check (scratch). Output: indep_verify_S5_N335.out.
Results for thin_S5_N335.txt (N = 335, V0 = 0..330, B = {331,332,333,334}):
 (1) tournament axioms OK (no loops, no duplicate list entries, exactly one arc per pair).
 (2) T[V0] is exactly QR_331 (all 331*330 ordered pairs checked against the residue rule).
 (3) D(B) = {5, 87, 218, 266, 279, 312}, |D(B)| = 6 = n+1. T[D(B)] in-degrees 3 2 3 2 1 4 (no source).
     T[B] transitive 331->332->333->334. Every v in V0 \ D(B) loses to exactly ONE b ("max type"):
     colour classes 74, 81, 85, 85.
 (4) QR_331 has S_5: all 5,881,204 5-sets containing {0,1} have a dominator (min 1).  Reduction is rigorous:
     maps x -> a x + b (a a nonzero square) are automorphisms; the map x -> (x-u)/(v-u) sends an arc u->v
     to 0->1, so the group is transitive on arcs = on unordered pairs, and every 5-set is equivalent to one
     containing {0,1}.  nu_s(QR_331) = 331 165 82 36 12 1.
 (5) all 2,000,693,421 5-sets meeting B enumerated directly (dominators searched in all of V): none undominated.
 Argument that this suffices: if X is a 5-set inside V0, QR_331 = T[V0] gives y in V0 \ X beating X in T[V0];
 arcs inside V0 are unchanged in T, so y dominates X in T as well (adding vertices never destroys a dominator).
 => T is S_5 on 335 vertices with |D(B)| = 6.  nu_s(T), s=0..5: 335 165 82 36 6 1 (nu_4 exact by full
 enumeration of all C(335,4) 4-sets; nu_5 = 1 attained by a set meeting B).
 Cost of planting: +4 = n-1 new vertices, 0 arcs of QR_331 modified; only nu_4 changes (12 -> 6).
thin_S4_N70.txt (from run 1's plant_sat.py): re-verified with the same program: tournament, T[0..66] = QR_67,
 D(B) = {13,24,37,49,63} (size 5 = n+1, in-degrees in T[D(B)] 2 1 2 2 3), QR_67 S_4 (all 2080 4-sets
 through {0,1}), all 150,415 4-sets meeting B dominated.  nu_s(T) = 70 33 16 5 1 (exact, full enumeration)
 vs QR_67: 67 33 16 6 1.  Cost: +3 = n-1 vertices, 0 arcs modified; also max type (classes 17, 21, 24).

## Step 2 (DONE): thin S_n tournaments exist for every n >= 2  (rigorous)
Construction L(n,M): V = W u U u B, |W| = n+1, |U| = M, |B| = n-1.
 T[W] contains a directed Hamiltonian cycle (so no source); W -> B; T[B] arbitrary;
 each u in U: colour beta(u) in B uniform, beta(u) -> u, u -> B \ {beta(u)}  ("max type");
 P(u) := N^-(u) cap W uniform among the 2^{n+1}-1 NONEMPTY subsets of W; T[U] uniformly random; all independent.
Deterministic: D(B) = W (each u loses to beta(u)); n-sets B u {x} are dominated by W (x in W: cycle
 predecessor; x in U: any w in P(x)).  For an n-set X with |X cap W| = j, |X cap U| = s, |X cap B| = k <= n-2:
 u in U \ X dominates X with prob q = (n-1-k)/(n-1) * (2^{n+1-j}-1)/(2^{n+1}-1) * 2^{-s}, independently in u
 (disjoint sets of random choices) => P(T not S_n) <= F(n,M) = sum C(n-1,k)C(n+1,j)C(M,s)(1-q)^{M-s}.
Analytic bounds (M = ceil(2 n^2 2^n)):  F <= E0+E1+E2 with
 E0 = (M+n+1)^n/n! * exp(-(1-2^{-n/2-1})(2n^2-1))    [k=0, j<=n/2, Vandermonde, rho_j >= 1-2^{j-n-1}]
 E1 = 2^{n+1} M^{n/2} exp(-(2n^2-1)/2)                [k=0, j>n/2, rho_j >= 1/2]
 E2 = (n-2) 2^{n-1} (M+n+1)^{n-1} exp(-((n-2)/(n-1))(2n^2-1))  [k>=1: min_k (n-1-k)2^k/(n-1) at k=1]
 For n >= 5: ln E0 <= -1.3068n^2 + n ln(2n) + n + 5.5 <= -10.6, ln E1 <= -0.6534n^2 + (n/2)ln(2n^2) + 0.6931n
 + 1.6931 <= -1.40, ln E2 <= -1.3068n^2 + (n-1)ln(2n^2) + ln n + 2n + 3.31 + 2/(n-1) <= -1.6 (all decreasing in
 n >= 5), so F < 0.45.  n = 2,3,4: exact F computed (50 digits): ln F = -1.80, -5.35, -10.89 (union_bound.out).
 Also explicit small examples: QR_7, QR_19, thin_S4_N70, thin_S5_N335.
=> THEOREM: for every n >= 2 there is an S_n tournament on ceil(2n^2 2^n)+2n vertices with nu_{n-1} = n+1
 ((M1) gives >= n+1, B gives <= n+1).  With M = (1+eps) ln2 n^2 2^n the same three bounds -> 0, so
 f_thin(n) <= (ln 2 + o(1)) n^2 2^n  = the classical random upper bound for f(n): thinness costs nothing at
 the scale of the best known general construction.  Least c with F(n, c n^2 2^n) < 1: 1.44 (n=2), 1.17 (n=5),
 1.00 (n=10), 0.88 (n=20), 0.80 (n=40), 0.77 (n=60) -> ln 2.
 Monte Carlo (mc_planted.py): exact counts of undominated n-sets in random L(n,M) are below F, |D(B)| = n+1 always.
 Other nu_s in L(n,M): only nu_{n-1} is affected (D(B \ {b}) contains W u beta^{-1}(b), ~ M/(n-1) vertices).

## Step 3 (in progress) -- evidence collected so far
- Thin sets are RARE in the planted examples (count_min.c, full enumeration):
  thin_S4_N70:  3-sets by |D|: 5:2, 6:6785, 7:14860, ...   (only 2 of 54740 3-sets are thin)
  thin_S5_N335: 4-sets by |D|: 6:1 (= B only), 12:233335, 13:1026491, ...  (next value after 6 is 12)
  => a single thin set is invisible to every averaging argument; what the cross-level recursion actually
  needs at level n-2 is that near-thin extensions A u {y} are exponentially rare (see report).
