"""Small tournament utilities (bitmask based).  A tournament on N vertices is given by
out[v] = bitmask of out-neighbours of v.  inn[v] = bitmask of in-neighbours (vertices beating v)."""
import itertools, random

def paley_out(p):
    Q = {(x*x) % p for x in range(1, p)}
    return [sum(1 << j for j in range(p) if j != i and (j - i) % p in Q) for i in range(p)]

def inn_from_out(out):
    N = len(out)
    inn = [0]*N
    for u in range(N):
        m = out[u]
        while m:
            b = m & -m; v = b.bit_length()-1; inn[v] |= 1 << u; m ^= b
    return inn

def D(inn, N, X):
    m = (1 << N) - 1
    for x in X: m &= inn[x]
    return m

def pc(x): return bin(x).count('1')

def bits(m):
    while m:
        b = m & -m; yield b.bit_length()-1; m ^= b

def check_Sn(out, n, must_contain=None):
    """Return list of undominated n-sets (only those meeting must_contain if given). Exhaustive."""
    N = len(out); inn = inn_from_out(out); full = (1 << N) - 1
    bad = []
    # recursive enumeration with running intersection
    def rec(start, depth, cur, X, hit):
        if depth == n:
            if cur == 0 and (must_contain is None or hit): bad.append(tuple(X))
            return
        for v in range(start, N):
            X.append(v)
            rec(v+1, depth+1, cur & inn[v], X, hit or (must_contain is not None and v in must_contain))
            X.pop()
    rec(0, 0, full, [], False)
    return bad

def nu_profile(out, n):
    N = len(out); inn = inn_from_out(out); full = (1 << N) - 1
    nu = [N] + [10**9]*n
    def rec(start, depth, cur):
        c = pc(cur)
        if c < nu[depth]: nu[depth] = c
        if depth == n: return
        for v in range(start, N):
            rec(v+1, depth+1, cur & inn[v])
    rec(0, 0, full)
    return nu
