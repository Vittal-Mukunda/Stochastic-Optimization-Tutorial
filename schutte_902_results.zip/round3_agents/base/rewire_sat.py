"""Experiment A (run 2): can QR_67 be made thin (some 3-set with exactly 5 dominators) WITHOUT adding vertices,
by re-choosing only the arcs incident to a 3-set B of its own vertices?   S_4 must hold for ALL 4-sets.
usage: python3 rewire_sat.py c1 c2 ...   (B = {0,1,c}); prints SAT/UNSAT per B, saves a solution if found."""
import sys, itertools, time
from pysat.solvers import Cadical153
from pysat.card import CardEnc, EncType
from tlib import paley_out, inn_from_out, bits, check_Sn, nu_profile, D, pc
p, n = 67, 4
out0 = paley_out(p); inn0 = inn_from_out(out0)
def run(Bset):
    Bset = tuple(sorted(Bset)); Bm = sum(1 << b for b in Bset); rest = [v for v in range(p) if not Bm >> v & 1]
    var = {}
    def V(k):
        if k not in var: var[k] = len(var) + 1
        return var[k]
    def arc(a, b):   # literal for "a -> b" (None if fixed: returns True/False)
        if (a in Bset) and (b in Bset):
            i, j = sorted((a, b)); l = V(('e', i, j)); return l if a == i else -l
        if a in Bset: return V(('x', a, b))
        if b in Bset: return -V(('x', b, a))
        return bool(out0[a] >> b & 1)
    cls = []
    def AND(lits):
        lits = [l for l in lits if l is not True]
        if any(l is False for l in lits): return False
        if not lits: return True
        if len(lits) == 1: return lits[0]
        key = ('and',) + tuple(sorted(lits))
        if key in var: return var[key]
        a = V(key)
        for l in lits: cls.append([-a, l])
        return a
    nX = 0
    for X in itertools.combinations(range(p), n):
        Xs = set(X); XB = [x for x in X if x in Bset]
        # fixed dominators: y not in B, all of X \ B fixed arcs, and y -> b for b in XB variable
        clause = []; satisfied = False
        cand = full = (1 << p) - 1
        for x in X:
            if x not in Bset: cand &= inn0[x]
        cand &= ~Bm
        for y in bits(cand):
            if y in Xs: continue
            lit = AND([arc(y, b) for b in XB])
            if lit is True: satisfied = True; break
            if lit is not False: clause.append(lit)
        if satisfied: continue
        for b in Bset:
            if b in Xs: continue
            lit = AND([arc(b, x) for x in X])
            if lit is True: satisfied = True; break
            if lit is not False: clause.append(lit)
        if satisfied: continue
        nX += 1
        cls.append(clause)   # may be empty => UNSAT
    # thinness: at most 5 vertices v outside B with v -> all of B
    dl = []
    for v in rest:
        lits = [arc(v, b) for b in Bset]          # all variable literals (v not in B)
        a = V(('thin', v))
        for l in lits: cls.append([-a, l])
        cls.append([a] + [-l for l in lits])        # full equivalence a <-> AND(lits)
        dl.append(a)
    top = len(var)
    enc = CardEnc.atmost(lits=dl, bound=5, top_id=top + 10, encoding=EncType.seqcounter)
    s = Cadical153(bootstrap_with=cls + enc.clauses)
    t = time.time(); ok = s.solve(); dt = time.time() - t
    res = None
    if ok:
        ms = set(l for l in s.get_model() if l > 0)
        out = list(out0)
        for b in Bset:
            for v in rest:
                k = ('x', b, v)
                if var[k] in ms: out[b] |= 1 << v; out[v] &= ~(1 << b)
                else: out[v] |= 1 << b; out[b] &= ~(1 << v)
        for i, j in itertools.combinations(Bset, 2):
            k = ('e', i, j)
            if k in var and var[k] in ms: out[i] |= 1 << j; out[j] &= ~(1 << i)
            else: out[j] |= 1 << i; out[i] &= ~(1 << j)
        res = out
    s.delete()
    return ok, nX, len(var), dt, res
for c in map(int, sys.argv[1:]):
    ok, nX, nv, dt, out = run((0, 1, c))
    print(f"B={{0,1,{c}}}: clauses-for-4-sets={nX}, vars={nv}, SAT={ok}  ({dt:.1f}s)", flush=True)
    if ok:
        bad = check_Sn(out, n); inn = inn_from_out(out)
        print("   exhaustive check: undominated 4-sets =", len(bad), " D(B) =", sorted(bits(D(inn, p, (0, 1, c)))),
              " nu =", nu_profile(out, n), flush=True)
        if not bad and pc(D(inn, p, (0, 1, c))) == 5:
            fn = "thin_S4_N67.txt"
            with open(fn, "w") as f:
                f.write(f"# S_4 tournament on 67 vertices: QR_67 with the arcs at B={{0,1,{c}}} re-chosen; |D(B)| = 5\n# line v: out-neighbours of v\n")
                for v in range(p): f.write(" ".join(map(str, bits(out[v]))) + "\n")
            print("   saved", fn); break
