// verify_sn: independent verifier of property S_n for a tournament given by its full adjacency matrix.
// Method (independent of sncore.h): X is undominated  <=>  X is an out-dominating set, i.e. X u N+(X) = V.
// DFS over (n-1)-sets keeping the covered set C = union of closed out-neighbourhoods; the last element x
// completes an undominated set iff V \ C is contained in N+[x]. Only sets containing vertex 0 (and, if a
// stabiliser group is given, an orbit representative r of it) are enumerated; this is valid because the
// program itself checks that all supplied permutations are automorphisms, that the T-permutations generate a
// transitive group and that the M-permutations fix vertex 0.
// input: "N n", N rows of '0'/'1' (row i col j = 1 iff i->j), "T k" + k permutations, "M k" + k permutations.
// usage: verify_sn file [full]   ("full": ignore symmetry, enumerate all n-sets of V; only for small cases)
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int N, n, WD;
static uint64_t *OUTC; // closed out-neighbourhoods N+[x], WD words each
static uint64_t *INC;  // closed in-neighbourhoods  N-[x]
static unsigned char *A;
static long long found_cnt; static int found_X[32]; static int have_X;
static int cur[32];
static void dfs(int start,int depth,const uint64_t*cov,int k,int fixed0,int fixedr,int full){
  // cur[0..depth-1] chosen; need k elements total
  uint64_t nc[40];
  if(depth==k-1){
    // uncovered U = V \ cov; need x > cur[depth-1] (or any x not chosen, for the fixed-prefix scheme) with U subset N+[x]
    // candidates: x in intersection over u in U of N-[u]  (x covers u  <=>  x==u or x->u  <=>  x in N-[u] closed)
    uint64_t *cand=nc; for(int t=0;t<WD;t++) cand[t]=~0ULL;
    // mask to valid vertices
    for(int v=N;v<64*WD;v++) cand[v>>6]&=~(1ULL<<(v&63));
    int any=1;
    for(int t=0;t<WD && any;t++){ uint64_t u=~cov[t]; if(t==WD-1 && (N&63)) u&=(1ULL<<(N&63))-1;
      while(u){ int b=__builtin_ctzll(u); u&=u-1; int uu=t*64+b; uint64_t o=0;
        for(int s=0;s<WD;s++){ cand[s]&=INC[(long long)uu*WD+s]; o|=cand[s]; }
        if(!o){ any=0; break; } } }
    if(any){
      for(int t=0;t<WD;t++){ uint64_t cw=cand[t]; while(cw){ int x=t*64+__builtin_ctzll(cw); cw&=cw-1;
        // x must be a new element respecting the enumeration order
        int ok=1; for(int i=0;i<depth;i++) if(cur[i]==x) ok=0;
        if(!ok) continue;
        if(x<start) continue;
        found_cnt++; if(!have_X){ memcpy(found_X,cur,sizeof(int)*depth); found_X[depth]=x; have_X=1; }
      } }
    }
    return;
  }
  for(int x=start;x<N;x++){
    if(x==fixedr || x==fixed0) continue;
    for(int t=0;t<WD;t++) nc[t]=cov[t]|OUTC[(long long)x*WD+t];
    cur[depth]=x; dfs(x+1,depth+1,nc,k,fixed0,fixedr,full);
  }
}
static int read_perms(FILE*f,char want,int***P){
  char c[8]; int k; if(fscanf(f,"%7s %d",c,&k)!=2 || c[0]!=want){ fprintf(stderr,"expected %c section\n",want); exit(1); }
  *P=malloc(sizeof(int*)*(k+1));
  for(int i=0;i<k;i++){ (*P)[i]=malloc(sizeof(int)*N); for(int v=0;v<N;v++) if(fscanf(f,"%d",&(*P)[i][v])!=1){ fprintf(stderr,"bad perm\n"); exit(1);} }
  return k;
}
static int is_aut(const int*p){
  char*seen=calloc(N,1); for(int v=0;v<N;v++){ if(p[v]<0||p[v]>=N||seen[p[v]]){ free(seen); return 0;} seen[p[v]]=1; } free(seen);
  for(int i=0;i<N;i++) for(int j=0;j<N;j++) if(A[(long long)i*N+j]!=A[(long long)p[i]*N+p[j]]) return 0;
  return 1;
}
int main(int argc,char**argv){
  FILE*f=fopen(argv[1],"r"); if(!f){ perror(argv[1]); return 1; }
  int full= argc>2 && !strcmp(argv[2],"full");
  if(fscanf(f,"%d %d",&N,&n)!=2) return 1;
  WD=(N+63)/64; if(WD>40){ fprintf(stderr,"N too large\n"); return 1; } A=malloc((long long)N*N);
  char*row=malloc(N+8);
  for(int i=0;i<N;i++){ if(fscanf(f,"%s",row)!=1 || (int)strlen(row)!=N){ fprintf(stderr,"bad row %d\n",i); return 1; } for(int j=0;j<N;j++) A[(long long)i*N+j]=row[j]=='1'; }
  // tournament check
  for(int i=0;i<N;i++){ if(A[(long long)i*N+i]){ fprintf(stderr,"loop at %d\n",i); return 1; } for(int j=i+1;j<N;j++) if(A[(long long)i*N+j]+A[(long long)j*N+i]!=1){ fprintf(stderr,"not a tournament at (%d,%d)\n",i,j); return 1; } }
  int **T,**M; int kT=read_perms(f,'T',&T), kM=read_perms(f,'M',&M); fclose(f);
  for(int i=0;i<kT;i++) if(!is_aut(T[i])){ fprintf(stderr,"T-permutation %d is not an automorphism\n",i); return 1; }
  for(int i=0;i<kM;i++){ if(!is_aut(M[i])){ fprintf(stderr,"M-permutation %d is not an automorphism\n",i); return 1; } if(M[i][0]!=0){ fprintf(stderr,"M-permutation %d moves 0\n",i); return 1; } }
  // transitivity of <T>
  int*orb=calloc(N,sizeof(int)); int*q=malloc(sizeof(int)*N); int qh=0,qt=0; orb[0]=1; q[qt++]=0;
  while(qh<qt){ int v=q[qh++]; for(int i=0;i<kT;i++){ int w=T[i][v]; if(!orb[w]){ orb[w]=1; q[qt++]=w; } } }
  int transitive=(qt==N);
  if(!full && !transitive){ fprintf(stderr,"T does not act transitively (%d of %d); use 'full'\n",qt,N); return 1; }
  // orbits of <M> on V\{0}
  int*morb=malloc(sizeof(int)*N); for(int v=0;v<N;v++) morb[v]=-1; int nreps=0; int*reps=malloc(sizeof(int)*N);
  for(int v=1;v<N;v++) if(morb[v]<0){ reps[nreps]=v; qh=qt=0; q[qt++]=v; morb[v]=nreps; while(qh<qt){ int x=q[qh++]; for(int i=0;i<kM;i++){ int w=M[i][x]; if(morb[w]<0){ morb[w]=nreps; q[qt++]=w; } } } nreps++; }
  OUTC=calloc((long long)N*WD,8); INC=calloc((long long)N*WD,8);
  for(int i=0;i<N;i++){ OUTC[(long long)i*WD+(i>>6)]|=1ULL<<(i&63); INC[(long long)i*WD+(i>>6)]|=1ULL<<(i&63); }
  for(int i=0;i<N;i++) for(int j=0;j<N;j++) if(A[(long long)i*N+j]){ OUTC[(long long)i*WD+(j>>6)]|=1ULL<<(j&63); INC[(long long)j*WD+(i>>6)]|=1ULL<<(i&63); }
  found_cnt=0; have_X=0;
  uint64_t*cov=calloc(WD,8);
  if(full){
    // all n-sets of V
    for(int t=0;t<WD;t++) cov[t]=0;
    dfs(0,0,cov,n,-1,-1,1);
    printf("verify_sn: N=%d n=%d FULL enumeration of all %d-sets: undominated=%lld\n",N,n,n,found_cnt);
  } else {
    // sets containing 0 and an orbit rep r (for every r): existence check only
    for(int i=0;i<nreps;i++){ int r=reps[i];
      for(int t=0;t<WD;t++) cov[t]=OUTC[t]|OUTC[(long long)r*WD+t];
      cur[0]=0; cur[1]=r; dfs(1,2,cov,n,0,r,0);
    }
    printf("verify_sn: N=%d n=%d transitive=%d |M-orbit reps|=%d : undominated %d-sets through {0,r} (summed over reps) = %lld\n",N,n,transitive,nreps,n,found_cnt);
  }
  if(have_X){ printf("  example undominated set:"); for(int i=0;i<n;i++) printf(" %d",found_X[i]); printf("\n");
    // brute-force confirm
    int dom=0; for(int v=0;v<N && !dom;v++){ int ok=1; for(int i=0;i<n;i++) if(v==found_X[i] || !A[(long long)v*N+found_X[i]]) ok=0; if(ok) dom=1; }
    printf("  brute-force: example is %s\n", dom? "DOMINATED (BUG)" : "undominated (confirmed)"); }
  printf("%s\n", found_cnt==0? "S_n HOLDS" : "S_n FAILS");
  return 0;
}
