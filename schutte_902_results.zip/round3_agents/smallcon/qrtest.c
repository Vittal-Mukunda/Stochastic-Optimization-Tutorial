// qrtest: U0 (#undominated n-sets through 0) of Paley tournaments QR_p, by the orbit method and (optionally) directly.
// usage: qrtest n pmin pmax [direct]
#include "sncore.h"
#include <time.h>
static int isprime(int x){ if(x<2) return 0; for(int d=2;d*d<=x;d++) if(x%d==0) return 0; return 1; }
int main(int argc,char**argv){
  NK=atoi(argv[1]); int pmin=atoi(argv[2]), pmax=atoi(argv[3]); int direct= argc>4;
  init_binom();
  static unsigned char S[1<<14];
  for(int p=pmin;p<=pmax;p++){ if(!isprime(p) || p%4!=3) continue; if(p>MAXV) break;
    memset(S,0,p); for(long long y=1;y<p;y++) S[(y*y)%p]=1;
    build_circulant(p,S);
    int g=2; // find a non-residue for the second orbit rep
    while(S[g]) g++;
    int rep[2]={1,g}, wt[2]={(p-1)/2,(p-1)/2};
    clock_t t0=clock();
    long long u=count_v0_orbits(2,rep,wt,1LL<<60);
    double t1=(double)(clock()-t0)/CLOCKS_PER_SEC;
    printf("QR_%d n=%d U0=%lld (orbit method %.2fs)",p,NK,u,t1);
    if(direct){ t0=clock(); long long d=count_v0_direct(1LL<<60); printf("  direct=%lld (%.2fs)%s",d,(double)(clock()-t0)/CLOCKS_PER_SEC, d==u?"":"  MISMATCH"); }
    printf("\n"); fflush(stdout);
  }
  return 0;
}
