// afam2: exhaustive check of property S_n (mode exist) or exact minimum of U0 (mode min) over a multiplier-
// invariant circulant family on Z_N (family file from mkfam2.py). Members b in {0,1}^P: S = U_j (b_j? O_j : -O_j).
// Symmetry: the unit group Z_N^* acts on the family by isomorphisms (signed permutations of the pairs, read from
// the file, identity first; -1 is among them, so canonical members have b_{P-1} = 0). A member is processed only if
// it is the integer-minimum of its orbit (byte-table images). Enumeration: Gray code over b in [0,2^(P-1)),
// doubled bitset DN2 of -S updated by XOR; IN[x] = window of DN2 at N-x.
// exist: cache of n-sets found undominated earlier (word-by-word window test), full bitset DFS on cache miss.
// min:   build the tournament for every canonical member, U0 by the orbit-weighted DFS with cutoff best+1.
// usage: afam2 famfile exist|min [lo hi]   (Gray ranks in [lo,hi) of [0,2^(P-1)))
#include "sncore.h"
#include <time.h>

#define MAXP 48
#define MAXG 1024
#define DW (2*W+4)
static int N_, P_, G_, OSZ_[MAXP], *OEL_[MAXP], MSZ_, MEL_[2048];
static int PK_[MAXG][MAXP], PS_[MAXG][MAXP];
static uint64_t (*TAB_)[6][256];
static int NB_;
static int gorder_[MAXG];
static uint64_t DN2_[DW], NEGP_[MAXP][DW], NEGN_[MAXP][DW]; // NEGP: -k in O_j ; NEGN: -k in -O_j
static uint64_t LASTMASK_;
static int rep_[2*MAXP], wt_[2*MAXP], nrep_;
static unsigned char S_[1<<14];
static long long ncand=0, nfull=0, nsn=0, hitsum=0, best=1LL<<60, nbest=0;

#define MAXCACHE 4096
static int cx_[MAXCACHE][16], cidx_[MAXCACHE], ncache=0;

static inline uint64_t win(const uint64_t*D,int off,int t){ int ws=(off>>6)+t, bsh=off&63; return bsh? ((D[ws]>>bsh)|(D[ws+1]<<(64-bsh))) : D[ws]; }
static inline int undominated_in(const uint64_t*D,const int*X){
  for(int t=0;t<W;t++){ uint64_t acc=(t==W-1)? LASTMASK_ : ~0ULL;
    for(int j=0;j<NK && acc;j++) acc&=win(D,N_-X[j],t);
    if(acc) return 0; }
  return 1;
}
static inline uint64_t image(int g,uint64_t b){ uint64_t r=0; for(int q=0;q<NB_;q++) r|=TAB_[g][q][(b>>(8*q))&255]; return r; }
static int canonical(uint64_t b){
  for(int i=1;i<G_;i++){ int g=gorder_[i]; if(image(g,b)<b){ // move g towards the front
      if(i>1){ int t=gorder_[i]; gorder_[i]=gorder_[i-1]; gorder_[i-1]=t; } return 0; } }
  return 1;
}
static void member_S(uint64_t b){
  memset(S_,0,N_);
  for(int j=0;j<P_;j++){ int bj=(b>>j)&1; for(int t=0;t<OSZ_[j];t++){ int s=OEL_[j][t]; if(bj) S_[s]=1; else S_[(N_-s)%N_]=1; } }
}
static void print_member(const char*tag,uint64_t b,long long u){
  member_S(b); printf("%s N=%d n=%d b=%llx U0=%lld S=",tag,N_,NK,(unsigned long long)b,u); for(int y=1;y<N_;y++) if(S_[y]) printf("%d,",y); printf("\n"); fflush(stdout);
}

int main(int argc,char**argv){
  if(argc<3){ fprintf(stderr,"usage: afam2 famfile exist|min [lo hi]\n"); return 1; }
  FILE*f=fopen(argv[1],"r"); if(!f){ perror(argv[1]); return 1; }
  int minmode=!strcmp(argv[2],"min");
  char tok[16];
  if(fscanf(f,"%d %d",&N_,&NK)!=2) return 1;
  if(fscanf(f,"%d",&P_)!=1) return 1;
  if(P_>MAXP||P_>63){ fprintf(stderr,"P too large\n"); return 1; }
  if(N_>MAXV || N_<=64*(W-1)){ fprintf(stderr,"N=%d needs W=%d\n",N_,(N_+63)/64); return 1; }
  static int seen[1<<14];
  for(int j=0;j<P_;j++){ if(fscanf(f,"%d",&OSZ_[j])!=1) return 1; OEL_[j]=malloc(sizeof(int)*OSZ_[j]);
    for(int t=0;t<OSZ_[j];t++){ if(fscanf(f,"%d",&OEL_[j][t])!=1) return 1; int s=OEL_[j][t]; int ns=(N_-s)%N_;
      if(s<=0||s>=N_||seen[s]||seen[ns]){ fprintf(stderr,"bad orbit data\n"); return 1; } seen[s]=seen[ns]=1; } }
  for(int s=1;s<N_;s++) if(!seen[s]){ fprintf(stderr,"element %d not covered\n",s); return 1; }
  if(fscanf(f,"%15s %d",tok,&G_)!=2 || tok[0]!='G' || G_>MAXG){ fprintf(stderr,"bad G\n"); return 1; }
  for(int g=0;g<G_;g++) for(int j=0;j<P_;j++) if(fscanf(f,"%d %d",&PK_[g][j],&PS_[g][j])!=2) return 1;
  if(fscanf(f,"%15s %d",tok,&MSZ_)!=2 || tok[0]!='M'){ fprintf(stderr,"bad M\n"); return 1; }
  for(int i=0;i<MSZ_;i++) if(fscanf(f,"%d",&MEL_[i])!=1) return 1;
  fclose(f);
  // sanity: every orbit is M-invariant, and the perms are consistent with multiplication (checked on reps)
  for(int j=0;j<P_;j++){ for(int t=0;t<OSZ_[j];t++) for(int i=0;i<MSZ_;i++){ int y=(int)((long long)MEL_[i]*OEL_[j][t]%N_); int ok=0; for(int s=0;s<OSZ_[j];s++) if(OEL_[j][s]==y) ok=1; if(!ok){ fprintf(stderr,"orbit %d not M-invariant\n",j); return 1; } } }
  for(int g=0;g<G_;g++){ int isid=1; for(int j=0;j<P_;j++) if(PK_[g][j]!=j||PS_[g][j]) isid=0; if(g==0 && !isid){ fprintf(stderr,"first perm must be identity\n"); return 1; } }
  init_binom();
  NB_=(P_+7)/8; TAB_=calloc(G_,sizeof *TAB_);
  for(int g=0;g<G_;g++) for(int q=0;q<NB_;q++) for(int v=0;v<256;v++){ uint64_t r=0;
      for(int i=0;i<8;i++){ int j=8*q+i; if(j>=P_) break; uint64_t bit=((v>>i)&1)^PS_[g][j]; r|=bit<<PK_[g][j]; }
      TAB_[g][q][v]=r; }
  for(int i=0;i<G_;i++) gorder_[i]=i;
  for(int k=0;k<2*N_;k++){ int s=k%N_; if(!s) continue; int ns=(N_-s)%N_;
    for(int j=0;j<P_;j++) for(int t=0;t<OSZ_[j];t++){ if(OEL_[j][t]==ns) NEGP_[j][k>>6]|=1ULL<<(k&63); if(OEL_[j][t]==s) NEGN_[j][k>>6]|=1ULL<<(k&63); } }
  LASTMASK_= (N_-64*(W-1))>=64? ~0ULL : ((1ULL<<(N_-64*(W-1)))-1);
  nrep_=0; for(int j=0;j<P_;j++){ rep_[nrep_]=OEL_[j][0]; wt_[nrep_++]=OSZ_[j]; rep_[nrep_]=(N_-OEL_[j][0])%N_; wt_[nrep_++]=OSZ_[j]; }
  uint64_t total=1ULL<<(P_-1), lo=0, hi=total;
  if(argc>4){ lo=strtoull(argv[3],0,0); hi=strtoull(argv[4],0,0); if(hi>total) hi=total; }
  // initial DN2 for Gray(lo)
  uint64_t gcur=lo^(lo>>1);
  memset(DN2_,0,sizeof DN2_);
  for(int j=0;j<P_;j++){ const uint64_t*m= ((gcur>>j)&1)? NEGP_[j] : NEGN_[j]; for(int w=0;w<DW;w++) DN2_[w]|=m[w]; }
  clock_t t0=clock();
  for(uint64_t r=lo;r<hi;r++){
    if(r>lo){ uint64_t g=r^(r>>1); int j=__builtin_ctzll(g^gcur); for(int w=0;w<DW;w++) DN2_[w]^=NEGP_[j][w]^NEGN_[j][w]; gcur=g; }
    if(!canonical(gcur)) continue;
    ncand++;
    if(minmode){
      member_S(gcur); build_circulant_fast(N_,S_);
      long long u=count_v0_orbits(nrep_,rep_,wt_,best+1);
      if(u<best){ best=u; nbest=1; print_member("BEST",gcur,u); } else if(u==best) nbest++;
      if(u==0){ nsn++; print_member("SN",gcur,0); }
      continue;
    }
    int hit=0;
    for(int c=0;c<ncache;c++) if(undominated_in(DN2_,cx_[cidx_[c]])){ hitsum+=c; if(c>0){ int t=cidx_[c]; memmove(&cidx_[1],&cidx_[0],sizeof(int)*c); cidx_[0]=t; } hit=1; break; }
    if(hit) continue;
    nfull++;
    member_S(gcur); build_circulant_fast(N_,S_);
    int X[16]; int found=0;
    for(int i=0;i<nrep_ && !found;i++) if(find_undominated_pair(rep_[i],X)) found=1;
    if(found){
      if(is_dominated(X,NK)){ fprintf(stderr,"internal error: dominated\n"); return 3; }
      if(!undominated_in(DN2_,X)){ fprintf(stderr,"internal error: window test disagrees\n"); return 3; }
      int slot; if(ncache<MAXCACHE){ slot=ncache++; memmove(&cidx_[1],&cidx_[0],sizeof(int)*(ncache-1)); } else { slot=cidx_[MAXCACHE-1]; memmove(&cidx_[1],&cidx_[0],sizeof(int)*(MAXCACHE-1)); }
      memcpy(cx_[slot],X,sizeof(int)*NK); cidx_[0]=slot; continue; }
    nsn++; print_member("SN",gcur,0);
  }
  double secs=(double)(clock()-t0)/CLOCKS_PER_SEC;
  if(minmode) printf("RESULTF %s N=%d n=%d P=%d G=%d |M|=%d range=[%llu,%llu) ncanon=%lld minU0=%lld nmin=%lld #SN=%lld time=%.1fs\n",argv[1],N_,NK,P_,G_,MSZ_,(unsigned long long)lo,(unsigned long long)hi,ncand,best,nbest,nsn,secs);
  else printf("RESULTF %s N=%d n=%d P=%d G=%d |M|=%d range=[%llu,%llu) ncanon=%lld #SN=%lld fullchecks=%lld avghit=%.1f time=%.1fs\n",argv[1],N_,NK,P_,G_,MSZ_,(unsigned long long)lo,(unsigned long long)hi,ncand,nsn,nfull,ncand>nfull?(double)hitsum/(ncand-nfull):0.0,secs);
  return 0;
}
