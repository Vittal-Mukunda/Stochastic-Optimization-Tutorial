#!/bin/bash
# exhaustive S_n existence over every family in an index (mkfam2 format) with Pmin <= P <= Pmax
# usage: run_afam2.sh index Pmin Pmax mode outfile
IDX=$1; PMIN=$2; PMAX=$3; MODE=$4; OUT=$5
sort -k3,3n -k1,1n $IDX | while read N m P G fn; do
  if [ $P -lt $PMIN ] || [ $P -gt $PMAX ]; then continue; fi
  W=$(( (N+63)/64 ))
  ./afam2_w$W $fn $MODE | grep -E "^(RESULTF|SN)" | cut -c1-400 >> $OUT
done
echo DONE >> $OUT
