import sys
p=int(sys.argv[1])
S=sorted({(y*y)%p for y in range(1,p)})
# generator of the squares: g^2 for a primitive root g
def isprim(g):
    q=p-1; f=2; fs=set()
    while f*f<=q:
        while q%f==0: fs.add(f); q//=f
        f+=1
    if q>1: fs.add(q)
    return all(pow(g,(p-1)//r,p)!=1 for r in fs)
g=next(x for x in range(2,p) if isprim(x))
print(','.join(map(str,S)), (g*g)%p)
