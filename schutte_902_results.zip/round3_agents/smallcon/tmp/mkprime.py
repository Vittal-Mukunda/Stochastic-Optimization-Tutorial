import sys, os
sys.path.insert(0, '/home/claude/agents/smallcon')
import mkfam2
N, m, n = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
U, subs = mkfam2.families(N)
M = [H for H in subs if len(H) == m][0]
pairs, perms = mkfam2.build(N, M, U)
fn = sys.argv[4]
with open(fn, 'w') as f:
    f.write(f"{N} {n}\n{len(pairs)}\n")
    for o in pairs: f.write(f"{len(o)} {' '.join(map(str, o))}\n")
    f.write(f"G {len(perms)}\n")
    for row in perms: f.write(' '.join(f"{k} {s}" for k, s in row) + "\n")
    f.write(f"M {len(M)} {' '.join(map(str, sorted(M)))}\n")
print(fn, len(pairs), len(perms))
