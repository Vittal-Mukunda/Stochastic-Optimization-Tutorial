import re,sys
def isprime(x): return x>1 and all(x%d for d in range(2,int(x**.5)+1))
done_exist=set(); done_min={}
for f in ['cyclo5_exist.txt','cyclo5_e1_12.txt','cyclo5_e13_20.txt']:
    for line in open(f):
        m=re.match(r'RESULT n=5 p=(\d+) m=(\d+) e=(\d+) ncand=(\d+) (.*)',line)
        if not m: continue
        p,mm,e=int(m[1]),int(m[2]),int(m[3])
        if 'exist-mode' in line:
            assert '#SN=0' in line; done_exist.add((p,mm))
        else:
            done_min[(p,mm)]=int(re.search(r'minU0=(\d+)',line)[1])
jobs=[]
for p in range(113,331):
    if not isprime(p): continue
    for m in range(3,p,2):
        if (p-1)%(2*m)==0: jobs.append(((p-1)//(2*m),p,m))
jobs.sort()
missing=[(e,p,m) for e,p,m in jobs if (p,m) not in done_exist]
print("total jobs (113<=p<=330, H nontrivial odd order):",len(jobs))
print("exist-mode done:",len(done_exist), " min-mode done:",len(done_min))
print("missing exist-mode:",missing)
print("primes with no nontrivial odd-order H:",[p for p in range(113,331) if isprime(p) and all((p-1)%(2*m) for m in range(3,p,2))])
