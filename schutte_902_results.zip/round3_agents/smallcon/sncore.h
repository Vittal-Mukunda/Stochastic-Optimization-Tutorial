// sncore.h -- fast counting of undominated n-sets through vertex 0 in a vertex-transitive tournament.
// Bitset width W (64-bit words) is a compile-time constant: compile with -DW=<words>, N <= 64*W.
// Conventions: OUT_[a] = out-neighbours of a, IN_[x] = in-neighbours of x (vertices beating x).
// An n-set X is undominated iff no vertex beats all of X  <=>  X u N+(X) = V.
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifndef W
#define W 6
#endif
#define MAXV (64*W)
typedef struct { uint64_t w[W]; } bs_t;

static int NV;                 // number of vertices
static int NK;                 // n (size of sets)
static bs_t IN_[MAXV], OUT_[MAXV];
static long long BINOM[MAXV+2][16];

static inline void bs_clear(bs_t*a){ memset(a,0,sizeof *a); }
static inline void bs_set(bs_t*a,int i){ a->w[i>>6] |= 1ULL<<(i&63); }
static inline int  bs_get(const bs_t*a,int i){ return (int)((a->w[i>>6]>>(i&63))&1ULL); }
static inline int  bs_popc(const bs_t*a){ int c=0; for(int k=0;k<W;k++) c+=__builtin_popcountll(a->w[k]); return c; }
static inline int  bs_and_nz(bs_t*r,const bs_t*a,const bs_t*b){ uint64_t o=0; for(int k=0;k<W;k++){ r->w[k]=a->w[k]&b->w[k]; o|=r->w[k]; } return o!=0; }

static void init_binom(void){
  for(int a=0;a<=MAXV+1;a++){ BINOM[a][0]=1; for(int b=1;b<16;b++) BINOM[a][b]= a? BINOM[a-1][b-1]+BINOM[a-1][b] : 0; }
}

// ---- candidate list for the DFS (sorted vertex ids) and suffix masks ----
static int L_[MAXV], nL_;
static bs_t SUF_[MAXV+1];
static long long g_cnt, g_limit;

static void build_suffix(void){
  bs_clear(&SUF_[nL_]);
  for(int i=nL_-1;i>=0;i--){ SUF_[i]=SUF_[i+1]; bs_set(&SUF_[i],L_[i]); }
}

// A = common dominators of the current partial set; choose `rem` more elements from L_[idx..].
static void rec_(const bs_t*A,int idx,int rem){
  if(rem==1){
    // undominated completions = suffix vertices beaten by no a in A (early exit when empty)
    bs_t R=SUF_[idx];
    for(int k=0;k<W;k++){ uint64_t x=A->w[k];
      while(x){ int b=__builtin_ctzll(x); x&=x-1; const bs_t*o=&OUT_[(k<<6)+b]; uint64_t any=0;
        for(int t=0;t<W;t++){ R.w[t]&=~o->w[t]; any|=R.w[t]; }
        if(!any) return; } }
    g_cnt+=bs_popc(&R); return;
  }
  for(int i=idx;i<=nL_-rem;i++){
    bs_t A2;
    if(!bs_and_nz(&A2,A,&IN_[L_[i]])) g_cnt+=BINOM[nL_-1-i][rem-1];
    else rec_(&A2,i+1,rem-1);
    if(g_cnt>=g_limit) return;
  }
}

// number of undominated NK-sets containing 0 (direct enumeration, no symmetry), stop when >= limit
static long long count_v0_direct(long long limit){
  nL_=0; for(int v=1;v<NV;v++) L_[nL_++]=v; build_suffix();
  g_cnt=0; g_limit=limit; rec_(&IN_[0],0,NK-1); return g_cnt;
}
// number of undominated NK-sets containing {0,r}, stop when >= limit
static long long count_pair(int r,long long limit){
  nL_=0; for(int v=1;v<NV;v++) if(v!=r) L_[nL_++]=v; build_suffix();
  g_cnt=0; g_limit=limit;
  bs_t A; if(!bs_and_nz(&A,&IN_[0],&IN_[r])) return BINOM[nL_][NK-2];
  if(NK==2) return 0;
  rec_(&A,0,NK-2); return g_cnt;
}
// weighted count: U0 = (1/(NK-1)) sum_r w_r c(r), where reps r (with orbit sizes w_r) are orbit representatives of a
// group of automorphisms fixing 0. Returns exact U0 if < limit, otherwise some value >= limit.
static long long count_v0_orbits(int nrep,const int*rep,const int*wt,long long limit){
  long long acc=0; long long lim2 = (limit>=(1LL<<55))? (1LL<<60) : limit*(NK-1);
  for(int i=0;i<nrep;i++){
    long long rem_budget = lim2-acc; long long lr = (rem_budget + wt[i]-1)/wt[i]; if(lr<1) lr=1;
    long long c=count_pair(rep[i],lr); acc+=c*wt[i];
    if(acc>=lim2) return (acc+(NK-2))/(NK-1) > limit ? (acc+(NK-2))/(NK-1) : limit;
  }
  if(acc%(NK-1)){ fprintf(stderr,"internal error: weighted sum %lld not divisible by %d\n",acc,NK-1); exit(3); }
  return acc/(NK-1);
}
// find (some) undominated set through {0,r}: returns 1 and fills X if found
static int fx_found; static int fx_set[16], fx_cur[16];
static void rec_find_(const bs_t*A,int idx,int rem,int depth){
  if(fx_found) return;
  if(rem==0){ if(!A){ } return; }
  for(int i=idx;i<=nL_-rem && !fx_found;i++){
    bs_t A2; int nz=bs_and_nz(&A2,A,&IN_[L_[i]]); fx_cur[depth]=L_[i];
    if(!nz){ // complete arbitrarily with following elements
      for(int j=1;j<rem;j++) fx_cur[depth+j]=L_[i+j];
      memcpy(fx_set,fx_cur,sizeof fx_cur); fx_found=1; return; }
    if(rem>1) rec_find_(&A2,i+1,rem-1,depth+1);
  }
}
static int find_undominated_pair(int r,int*X){
  nL_=0; for(int v=1;v<NV;v++) if(v!=r) L_[nL_++]=v;
  fx_found=0; fx_cur[0]=0; fx_cur[1]=r;
  bs_t A; if(!bs_and_nz(&A,&IN_[0],&IN_[r])){ for(int j=0;j<NK-2;j++) fx_cur[2+j]=L_[j]; memcpy(X,fx_cur,sizeof(int)*NK); return 1; }
  rec_find_(&A,0,NK-2,2);
  if(fx_found){ memcpy(X,fx_set,sizeof(int)*NK); return 1; } return 0;
}
// brute-force domination test of a given set (independent of the DFS)
static int is_dominated(const int*X,int k){
  for(int v=0;v<NV;v++){ int ok=1; for(int j=0;j<k;j++){ if(X[j]==v || !bs_get(&OUT_[v],X[j])){ ok=0; break; } } if(ok) return 1; }
  return 0;
}


// ---- fast circulant build via shifts of a doubled bitset (no O(N|S|) loop) ----
// D2[k] = T[k mod N] for k in [0,2N); returns bits j in [0,N): D2[j+off]
static inline void bs_extract(bs_t*r,const uint64_t*D2,int off){
  int ws=off>>6, bsh=off&63;
  for(int t=0;t<W;t++){ uint64_t lo=D2[ws+t], hi=D2[ws+t+1]; r->w[t]= bsh? ((lo>>bsh)|(hi<<(64-bsh))) : lo; }
}
static uint64_t DS2_[2*W+4], DN2_[2*W+4];
static bs_t VALID_;
static void build_circulant_fast(int N,const unsigned char*S){
  NV=N; if(N>MAXV){ fprintf(stderr,"N=%d exceeds MAXV\n",N); exit(2); }
  memset(DS2_,0,sizeof DS2_); memset(DN2_,0,sizeof DN2_);
  for(int k=0;k<2*N;k++){ int s=k%N; if(s && S[s]) DS2_[k>>6]|=1ULL<<(k&63); if(s && S[N-s]) DN2_[k>>6]|=1ULL<<(k&63); }
  bs_clear(&VALID_); for(int j=0;j<N;j++) bs_set(&VALID_,j);
  // OUT[a] = {a+s}: bit j set iff (j-a) mod N in S  -> D2S[j - a + N]
  // IN[x]  = {x-s}: bit j set iff (j-x) mod N in -S -> D2N[j - x + N]
  for(int a=0;a<N;a++){ bs_extract(&OUT_[a],DS2_,N-a); bs_extract(&IN_[a],DN2_,N-a);
    for(int t=0;t<W;t++){ OUT_[a].w[t]&=VALID_.w[t]; IN_[a].w[t]&=VALID_.w[t]; } }
}

// ---- build a circulant on Z_N from a connection set given as a 0/1 array S[1..N-1] ----
static int build_circulant(int N,const unsigned char*S){
  NV=N; if(N>MAXV){ fprintf(stderr,"N=%d exceeds MAXV=%d (W=%d)\n",N,MAXV,W); exit(2); }
  for(int s=1;s<N;s++){ if(S[s]+S[N-s]!=1) return 0; }
  for(int v=0;v<N;v++){ bs_clear(&IN_[v]); bs_clear(&OUT_[v]); }
  for(int a=0;a<N;a++) for(int s=1;s<N;s++) if(S[s]){ int b=(a+s)%N; bs_set(&OUT_[a],b); bs_set(&IN_[b],a); }
  return 1;
}
