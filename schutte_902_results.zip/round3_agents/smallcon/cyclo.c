// cyclo: exhaustive search of cyclotomic tournaments on Z_p for property S_n.
// H = subgroup of Z_p^* of odd order m, index 2e. Cosets C_i = g^i H (i mod 2e), -C_i = C_{i+e}.
// A tournament chooses one coset from each pair {C_i, C_{i+e}}: bit vector b in {0,1}^e
// (b_i=1: C_i in S, else C_{i+e} in S). Multiplication by g acts as the negacyclic shift; we
// enumerate one representative per orbit (multiplier-equivalence = isomorphism for Z_p, Z_p is DCI).
// usage: cyclo n p m [min|exist|hist] [cap]
//   min  : exact minimum of U0 (#undominated n-sets through 0) over the family, with all minimizers
//   exist: only decide S_n for every member (cache of undominated sets as a fast filter)
//   hist : histogram of min(U0,cap)
// Output: "RESULT ..." and "SN ..." for every S_n member found.
#include "sncore.h"
#include <time.h>

static int powmod(long long a,long long e,long long p){ long long r=1; a%=p; while(e){ if(e&1) r=r*a%p; a=a*a%p; e>>=1; } return (int)r; }
static int is_prim_root(int g,int p){ int q=p-1; for(int f=2;(long long)f*f<=q;f++){ if(q%f==0){ if(powmod(g,(p-1)/f,p)==1) return 0; while(q%f==0) q/=f; } } if(q>1 && powmod(g,(p-1)/q,p)==1) return 0; return 1; }

#define MAXCACHE 4096
static int cacheX[MAXCACHE][16]; static int ncache=0;
static int cache_hit(void){ // returns index of an undominated cached set, or -1
  for(int c=0;c<ncache;c++){ bs_t A=IN_[cacheX[c][0]]; int nz=1;
    for(int j=1;j<NK && nz;j++) nz=bs_and_nz(&A,&A,&IN_[cacheX[c][j]]);
    if(!nz) return c; }
  return -1;
}

int main(int argc,char**argv){
  if(argc<4){ fprintf(stderr,"usage: cyclo n p m [min|exist|hist] [cap]\n"); return 1; }
  NK=atoi(argv[1]); int p=atoi(argv[2]); int m=atoi(argv[3]);
  const char*mode= argc>4? argv[4] : "min"; long long cap= argc>5? atoll(argv[5]) : (1LL<<60);
  int exist=!strcmp(mode,"exist"), hist_mode=!strcmp(mode,"hist"), min_mode=!strcmp(mode,"min");
  init_binom();
  if((p-1)%(2*m) || m%2==0){ fprintf(stderr,"m must be an odd divisor of p-1\n"); return 1; }
  int e=(p-1)/(2*m); if(e>31){ fprintf(stderr,"e=%d too large\n",e); return 1; }
  int g=2; while(!is_prim_root(g,p)) g++;
  static int ind[1<<14]; long long x=1; for(int k=0;k<p-1;k++){ ind[x]=k%(2*e); x=x*g%p; }
  int nrep=2*e; int rep[64],wt[64]; x=1; for(int k=0;k<nrep;k++){ rep[k]=(int)x; wt[k]=m; x=x*g%p; }
  uint32_t mask=(uint32_t)((1ULL<<e)-1);
  long long ncand=0, best=cap, nbest=0, nfull=0, nsn=0; long long hist[64]={0};
  static unsigned char S[1<<14];
  clock_t t0=clock();
  uint64_t blo=0, bhi=(uint64_t)mask+1;
  if(getenv("BLO")) blo=strtoull(getenv("BLO"),0,0);
  if(getenv("BHI")) bhi=strtoull(getenv("BHI"),0,0);
  if(bhi>(uint64_t)mask+1) bhi=(uint64_t)mask+1;
  for(uint64_t b=blo;b<bhi;b++){
    uint32_t c=(uint32_t)b; int canon=1;
    for(int k=1;k<2*e;k++){ c=((c<<1)&mask)|(((c>>(e-1))&1u)^1u); if(c<(uint32_t)b){ canon=0; break; } }
    if(!canon) continue;
    ncand++;
    for(int y=1;y<p;y++){ int i=ind[y]; S[y]=(unsigned char)((i<e)? ((b>>i)&1) : (((b>>(i-e))&1)^1)); }
    build_circulant_fast(p,S);
    long long u;
    if(exist){
      int h=cache_hit();
      if(h>=0){ if(h>0){ int tmp[16]; memcpy(tmp,cacheX[h],sizeof tmp); memmove(cacheX[1],cacheX[0],sizeof(cacheX[0])*h); memcpy(cacheX[0],tmp,sizeof tmp); } continue; }
      nfull++;
      int X[16]; int found=0;
      for(int i=0;i<nrep && !found;i++) if(find_undominated_pair(rep[i],X)) found=1;
      if(found){
        if(is_dominated(X,NK)){ fprintf(stderr,"internal error: reported set is dominated\n"); return 3; }
        int slot = ncache<MAXCACHE? ncache++ : MAXCACHE-1;
        memmove(cacheX[1],cacheX[0],sizeof(cacheX[0])*slot); memcpy(cacheX[0],X,sizeof(int)*NK);
        continue; }
      u=0;
    } else {
      long long lim = min_mode? best+1 : cap; if(lim>cap) lim=cap;
      u=count_v0_orbits(nrep,rep,wt,lim);
      if(hist_mode){ int bucket = (u>=cap)? 63 : (u==0?0: 1+ (63-__builtin_clzll((unsigned long long)u))); if(bucket>63) bucket=63; hist[bucket]++; }
      if(u<best){ best=u; nbest=1; } else if(u==best) nbest++;
      if(u>0 && u<=best && min_mode){ printf("BEST n=%d p=%d m=%d e=%d b=%llx U0=%lld\n",NK,p,m,e,(unsigned long long)b,u); fflush(stdout); }
    }
    if(u==0){ nsn++; printf("SN n=%d p=%d m=%d e=%d b=%llx S=",NK,p,m,e,(unsigned long long)b); for(int y=1;y<p;y++) if(S[y]) printf("%d,",y); printf("\n"); fflush(stdout); }
  }
  double secs=(double)(clock()-t0)/CLOCKS_PER_SEC;
  if(exist) printf("RESULT n=%d p=%d m=%d e=%d ncand=%lld exist-mode #SN=%lld fullchecks=%lld cache=%d time=%.1fs\n",NK,p,m,e,ncand,nsn,nfull,ncache,secs);
  else printf("RESULT n=%d p=%d m=%d e=%d ncand=%lld minU0=%lld nmin=%lld time=%.1fs\n",NK,p,m,e,ncand,best,nbest,secs);
  if(blo||bhi!=(uint64_t)mask+1) printf("RESULT-RANGE p=%d m=%d [%llx,%llx)\n",p,m,(unsigned long long)blo,(unsigned long long)bhi);
  if(hist_mode){ printf("HIST(log2 buckets; 0 => U0=0, k => 2^(k-1)<=U0<2^k, 63 => >=cap):"); for(int k=0;k<64;k++) if(hist[k]) printf(" %d:%lld",k,hist[k]); printf("\n"); }
  return 0;
}
