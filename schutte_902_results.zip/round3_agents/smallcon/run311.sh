#!/bin/bash
for k in 0 1 2 3; do
  lo=$(( k * (1<<28) )); hi=$(( (k+1) * (1<<28) ))
  BLO=$lo BHI=$hi ./cyclo_w6 5 311 5 exist | grep -E "^(RESULT|SN)" | cut -c1-300 >> cyclo5_exist.txt
done
echo "DONE311" >> cyclo5_exist.txt
