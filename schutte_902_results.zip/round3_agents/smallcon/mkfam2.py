#!/usr/bin/env python3
"""Multiplier-invariant circulant tournament families on Z_N (N odd composite).
For every subgroup M != 1 of odd order of Z_N^* (odd order is forced: an element of even order would give an
element u of order 2, u = -1 mod some prime power q^a || N, making the M-orbit of x = N/q^a self-paired), the
family consists of S = union_j (b_j ? O_j : -O_j) over the P orbit pairs {O_j,-O_j} of M on Z_N\\{0}.
The whole unit group Z_N^* (including -1, x->-x maps Cay(Z_N,S) to Cay(Z_N,-S)) acts on the family by
isomorphisms; we write the induced signed permutations of the pairs for one unit per coset of M.
For N <= 330 every subgroup of the odd part of Z_N^* is 2-generated (all r-ranks <= 2), so subgroups generated
by <= 2 elements are all subgroups.
usage: mkfam2.py outdir n Nmin Nmax            (writes every family; index.txt lists P for each)
File format (read by afam2.c):
  N n
  P
  P lines: size e1 .. e_size           (orbit O_j; -O_j is implicit)
  G g                                  (g = |Z_N^*/M| signed permutations, identity first)
  g lines: k_0 s_0 k_1 s_1 ... k_{P-1} s_{P-1}   (u*O_j = O_{k_j} if s_j=0, = -O_{k_j} if s_j=1)
  M m u_1 .. u_m                       (the elements of M)
"""
import sys, os
from math import gcd

def isprime(x): return x > 1 and all(x % d for d in range(2, int(x**.5) + 1))

def subgroup(gens, N):
    H = {1}; fr = [1]
    while fr:
        nf = []
        for h in fr:
            for g in gens:
                z = h * g % N
                if z not in H: H.add(z); nf.append(z)
        fr = nf
    return frozenset(H)

def order(u, N):
    k, x = 1, u
    while x != 1: x = x * u % N; k += 1
    return k

def families(N):
    U = [u for u in range(1, N) if gcd(u, N) == 1]
    odd = [u for u in U if order(u, N) % 2 == 1]
    cyc = {subgroup([u], N) for u in odd}
    subs = set(cyc)
    cl = list(cyc)
    for a in cl:
        for b in cl:
            subs.add(subgroup(list(a | b), N))
    subs.discard(frozenset({1}))
    return U, sorted(subs, key=lambda H: (len(H), sorted(H)))

def build(N, M, U):
    seen = [-1] * N; orbs = []
    for x in range(1, N):
        if seen[x] >= 0: continue
        o = sorted({(u * x) % N for u in M})
        for y in o: seen[y] = len(orbs)
        orbs.append(o)
    # pair up
    pairs = []; pid = {}; sgn = {}
    for i, o in enumerate(orbs):
        if i in pid: continue
        j = seen[(N - o[0]) % N]
        assert j != i
        pid[i] = len(pairs); sgn[i] = 0; pid[j] = len(pairs); sgn[j] = 1
        pairs.append(o)
    # transversal of M in U
    rem = set(U); trans = []
    for u in U:
        if u not in rem: continue
        trans.append(u)
        for m in M: rem.discard(u * m % N)
    trans.sort()  # 1 first
    perms = []
    for u in trans:
        row = []
        for j, o in enumerate(pairs):
            img = (u * o[0]) % N
            oi = seen[img]
            row.append((pid[oi], sgn[oi]))
        perms.append(row)
    return pairs, perms

if __name__ == '__main__':
    outdir, n, Nmin, Nmax = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
    os.makedirs(outdir, exist_ok=True)
    idx = []
    for N in range(Nmin, Nmax + 1):
        if N % 2 == 0 or isprime(N): continue
        U, subs = families(N)
        for t, M in enumerate(subs):
            pairs, perms = build(N, M, U)
            P = len(pairs)
            fn = os.path.join(outdir, f"z{N}_m{len(M)}_{t}.fam")
            with open(fn, 'w') as f:
                f.write(f"{N} {n}\n{P}\n")
                for o in pairs: f.write(f"{len(o)} {' '.join(map(str, o))}\n")
                f.write(f"G {len(perms)}\n")
                for row in perms: f.write(' '.join(f"{k} {s}" for k, s in row) + "\n")
                f.write(f"M {len(M)} {' '.join(map(str, sorted(M)))}\n")
            gens_desc = sorted(M)[:6]
            idx.append((N, len(M), P, len(perms), fn))
    with open(os.path.join(outdir, 'index.txt'), 'w') as f:
        for N, m, P, g, fn in idx: f.write(f"{N} {m} {P} {g} {fn}\n")
    print(len(idx), 'families')
    from collections import Counter
    c = Counter(min(P, 31) for _, _, P, _, _ in idx)
    print('P<=30:', sum(v for k, v in c.items() if k <= 30), ' P>30:', c.get(31, 0))
    Ns = sorted({N for N, *_ in idx})
    print('N with a family:', len(Ns))
