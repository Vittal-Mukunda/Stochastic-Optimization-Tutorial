# smallcon notes (run 2, started 2026-10-17)

Agent "smallcon", compute-heavy agent for Erdős #902 (Schütte). U0 = number of undominated n-sets containing
vertex 0 (for a vertex-transitive tournament, total undominated n-sets = N*U0/n; S_n holds iff U0 = 0).

## Step 0. Reconstruction of run 1 (cut off by usage limit)

Files of run 1 (all in this directory):
- `sncore.h` — bitset core: build circulant, count U0 by DFS over sets through 0 with closed-form completion
  when the common-dominator set empties; orbit-weighted count U0 = (1/(n-1)) sum_r w_r c(r) where c(r) = #undominated
  n-sets through {0,r} and r runs over orbit reps of a group of automorphisms fixing 0 (here: multiplication by H).
- `cyclo.c` — cyclotomic families on Z_p: H <= F_p^* of odd order m, index 2e, cosets C_i = g^i H, -C_i = C_{i+e};
  member = bit vector b in {0,1}^e (b_i=1: C_i in S, else C_{i+e} in S); one representative per orbit of the
  negacyclic shift (= multiplication by g; Z_p is a CI-group so these are exactly the isomorphisms).
  Modes: `min` (exact min U0 over the family), `exist` (decide S_n for every member; cache of undominated sets
  found in earlier members used as a filter, brute-force re-check of every reported set).
- `qrtest.c` — U0 of QR_p by orbit method (+ optional direct enumeration without symmetry).
- `afam.c` + `mkfam.py` — M-invariant Cayley tournament families on abelian groups (Z_N with multiplier group M,
  and (F_q,+) with multiplicative subgroups, optionally + Frobenius). Gray-code enumeration of 2^(P-1) members.
  `fams5/` has 161 family files generated for 119 <= N <= 330 (index in fams5/index.txt); `famtest/` = 3 test
  families (Z_271, m=5,9,27) used to cross-check afam against cyclo.
- `verify_sn.c` + `mkverify.py` — independent verifier (closed out-neighbourhood covering formulation, own
  adjacency matrix input, checks that the supplied permutations are automorphisms / transitive / fix 0).
- Results: `cyclo5_e1_12.txt` (min mode, e<=12, 119<=p<=330), `cyclo5_e13_20.txt` (min mode, only p=131,151,181
  finished), `cyclo5_exist.txt` (exist mode for every job of `jobs_753.txt` = all (p,m) with e<=30, all #SN=0).
  `run311.sh` (p=311, m=5, e=31, split in 4 chunks) never wrote output: that job was missing.
  (The canonical rep of a negacyclic orbit always has top bit 0 since the orbit contains b and ~b, so
  b in [0,2^(e-1)) suffices; run311.sh uses this.)

Code review (run 2): coset indexing, -C_i = C_{i+e} (m odd), negacyclic shift b' = (b<<1 & mask) | !b_{e-1},
orbit weights (H-orbits on F_p^* are the 2e cosets, size m), and the verifier's symmetry reduction all checked by
hand — correct. All binaries recompiled from source (gcc -O3 -march=native, -DW=words).

Job accounting (primes 113 <= p <= 330, nontrivial H of odd order): 100 jobs. Done in run 1 (exist mode): 87.
Missing: (p,m,e) = (113,7,8) [below 121, trivial], (311,5,31), and the eleven m=3 families with e >= 32:
(193,3,32) (199,3,33) (211,3,35) (223,3,37) (229,3,38) (241,3,40) (271,3,45) (277,3,46) (283,3,47) (307,3,51)
(313,3,52). p=257 has no nontrivial odd-order subgroup (p-1 = 2^8): its only family is all circulants.

## Step 1a. Checker validation (run 2)

- `qrtest n=4`, p <= 127 (logs/qr_n4.txt): orbit method == direct enumeration for all p. U0(QR_p) = 0 exactly for
  p in {67,71,79,83,107,127} and U0 > 0 for all p < 67 (QR_59: 232) and for p = 103 (U0 = 68). Matches literature.
- `qrtest n=5`, p <= 383 (logs/qr_n5.txt): U0(QR_331) = 0; U0(QR_p) > 0 for every prime p = 3 mod 4 below 331
  (smallest: QR_271 675, QR_283 705, QR_307 765, QR_311 2325); also QR_347,359,367,383 = 0, QR_379 = 945 > 0.
  Direct enumeration agrees for p = 127, 271, 311, 331 (logs/qr_n5_direct.txt).
- Independent verifier `verify_sn` (verified/QR*_n*.{in,out}): QR_67 S_4 HOLDS (also with `full`, no symmetry:
  0 undominated 4-sets among all C(67,4)); QR_71 S_4 HOLDS; QR_331 S_5 HOLDS; QR_103 S_4 FAILS (full enumeration
  gives 1751 undominated 4-sets = 103*68/4, consistent with U0=68); QR_311 S_5 FAILS (example set 0 1 4 113 141,
  brute-force confirmed).

## Step 1b. New fast exhaustive checker `cyclo3.c` (run 2)

`cyclo2.c` (pattern lists per cached set) was memory-bound (3.8 us/member) and is superseded. `cyclo3.c`:
FKM necklace generation adapted to the forced tail a_{t+e} = !a_t (one member per isomorphism class: Z_p is CI, so
the 2e rotations = multipliers are all isomorphisms in the family); the doubled bitset of -S is OR-built along the DFS;
cache test of a stored 5-set X = AND of five 64-bit windows (IN[x] = window at p-x), early exit at the first nonzero
word; cache miss -> full bitset DFS (sncore.h) + brute-force re-check + window re-check of the found set.
Validation: candidate counts identical to run 1's `cyclo.c` (p=181 m=5: 7286; p=127 m=3: 49940; p=241 m=5: 349536),
and identical #SN=0. Speed ~0.8 us/member for p~200.

Results (exist mode, exhaustive over all necklaces, logs/cyclo3_e32plus.txt):
| p | m | e | members (iso classes) | #S_5 | full checks | time |
|---|---|---|---|---|---|---|
| 193 | 3 | 32 | 67,108,864 | 0 | 113,950 | 52 s |
| 199 | 3 | 33 | 130,150,588 | 0 | 297,923 | 113 s |
