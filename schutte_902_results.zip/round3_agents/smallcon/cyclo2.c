// cyclo2: fast exhaustive existence check of property S_n over a cyclotomic family on Z_p.
// H = subgroup of F_p^* of odd order m, index 2e; cosets C_i = g^i H (i mod 2e), -C_i = C_{i+e}.
// Member <-> word w_0..w_{2e-1}, w_i = [C_i in S], with w_{i+e} = !w_i. Multiplication by g^-1 rotates w, and
// (Z_p is a CI-group) the rotations are exactly the isomorphisms inside the family, so we enumerate one
// necklace (lexicographically least rotation) per orbit with the FKM algorithm adapted to the forced tail.
// Filter: cache of n-sets X found undominated in earlier members, tested directly on the bit vector
// b (bit i = w_i, i<e): vertex v dominates X iff all x-v in S iff (b & care_v) == val_v (no tournament build).
// Members passing the filter get a full check (bitset DFS from sncore.h); a found set is brute-force re-checked.
// usage: cyclo2 n p m [K k [cdepth]]  -- only the subtrees with (prefix rank at depth cdepth) % K == k
#include "sncore.h"
#include <time.h>

static int powmod(long long a,long long e,long long p){ long long r=1; a%=p; while(e){ if(e&1) r=r*a%p; a=a*a%p; e>>=1; } return (int)r; }
static int is_prim_root(int g,int p){ int q=p-1; for(int f=2;(long long)f*f<=q;f++){ if(q%f==0){ if(powmod(g,(p-1)/f,p)==1) return 0; while(q%f==0) q/=f; } } if(q>1 && powmod(g,(p-1)/q,p)==1) return 0; return 1; }

static int P_, E_, M_, G_;
static int CI_[1<<14];          // coset index of y in [0,2e)
static int a_[160];              // FKM word, 1-based, length 2e
static long long ncand=0, nfull=0, nsn=0, nhit_pos_sum=0;
static int K_=1, k_=0, cdepth_=0; static long long prefix_rank=0;

// ---- cache of undominated sets as pattern lists ----
#define MAXCACHE 2048
#define MAXPAT 1200
typedef struct { int npat; uint64_t care[MAXPAT], val[MAXPAT]; int X[16]; } centry;
static centry *cache_[MAXCACHE]; static int ncache=0;
static centry pool_[MAXCACHE+1];

static void make_entry(centry*c,const int*X){
  memcpy(c->X,X,sizeof(int)*NK); c->npat=0;
  for(int v=0;v<P_;v++){
    int inX=0; for(int j=0;j<NK;j++) if(X[j]==v) inX=1; if(inX) continue;
    uint64_t care=0,val=0; int conflict=0;
    for(int j=0;j<NK;j++){ int y=((X[j]-v)%P_+P_)%P_; int ci=CI_[y]; int bit= ci<E_? ci : ci-E_; uint64_t req= ci<E_? 1:0; // need y in S
      uint64_t bm=1ULL<<bit;
      if(care&bm){ if(((val>>bit)&1ULL)!=req){ conflict=1; break; } }
      else { care|=bm; if(req) val|=bm; } }
    if(conflict) continue;
    if(c->npat>=MAXPAT){ fprintf(stderr,"too many patterns\n"); exit(3); }
    c->care[c->npat]=care; c->val[c->npat]=val; c->npat++;
  }
}
static inline int entry_undominated(const centry*c,uint64_t b){
  for(int i=0;i<c->npat;i++) if((b&c->care[i])==c->val[i]) return 0;
  return 1;
}

static int rep_[128], wt_[128], nrep_;
static unsigned char S_[1<<14];

static void process(uint64_t b){
  ncand++;
  for(int ci=0;ci<ncache;ci++){
    if(entry_undominated(cache_[ci],b)){
      nhit_pos_sum+=ci;
      if(ci>0){ centry*t=cache_[ci]; memmove(&cache_[1],&cache_[0],sizeof(centry*)*ci); cache_[0]=t; }
      return; }
  }
  // full check
  nfull++;
  for(int y=1;y<P_;y++){ int ci=CI_[y]; S_[y]=(unsigned char)(ci<E_? ((b>>ci)&1) : (((b>>(ci-E_))&1)^1)); }
  build_circulant_fast(P_,S_);
  int X[16]; int found=0;
  for(int i=0;i<nrep_ && !found;i++) if(find_undominated_pair(rep_[i],X)) found=1;
  if(found){
    if(is_dominated(X,NK)){ fprintf(stderr,"internal error: reported set is dominated\n"); exit(3); }
    centry*slot;
    if(ncache<MAXCACHE){ slot=&pool_[ncache]; ncache++; memmove(&cache_[1],&cache_[0],sizeof(centry*)*(ncache-1)); }
    else { slot=cache_[MAXCACHE-1]; memmove(&cache_[1],&cache_[0],sizeof(centry*)*(MAXCACHE-1)); }
    make_entry(slot,X); cache_[0]=slot;
    if(!entry_undominated(slot,b)){ fprintf(stderr,"internal error: pattern test disagrees with DFS\n"); exit(3); }
    return;
  }
  nsn++;
  printf("SN n=%d p=%d m=%d e=%d b=%llx S=",NK,P_,M_,E_,(unsigned long long)b);
  for(int y=1;y<P_;y++) if(S_[y]) printf("%d,",y); printf("\n"); fflush(stdout);
}

// FKM over a_1..a_{2e}, free for t<=e, forced a_t = !a_{t-e} for t>e; necklaces = lexicographically least rotations.
static void gen(int t,int p){
  if(t==cdepth_+1 && cdepth_>0){ long long r=prefix_rank++; if(r%K_!=k_) return; }
  if(t>E_){
    // forced tail
    int pp=p;
    for(int s=t;s<=2*E_;s++){ int v=1-a_[s-E_]; a_[s]=v; if(v<a_[s-pp]) return; if(v>a_[s-pp]) pp=s; }
    if((2*E_)%pp) return;
    uint64_t b=0; for(int i=0;i<E_;i++) if(a_[i+1]) b|=1ULL<<i;
    process(b); return;
  }
  a_[t]=a_[t-p]; gen(t+1,p);
  if(a_[t-p]==0){ a_[t]=1; gen(t+1,t); }
}

int main(int argc,char**argv){
  if(argc<4){ fprintf(stderr,"usage: cyclo2 n p m [K k [cdepth]]\n"); return 1; }
  NK=atoi(argv[1]); P_=atoi(argv[2]); M_=atoi(argv[3]);
  if(argc>5){ K_=atoi(argv[4]); k_=atoi(argv[5]); cdepth_= argc>6? atoi(argv[6]) : 0; }
  init_binom();
  if((P_-1)%(2*M_) || M_%2==0){ fprintf(stderr,"m must be an odd divisor of p-1\n"); return 1; }
  E_=(P_-1)/(2*M_); if(E_>63){ fprintf(stderr,"e too large\n"); return 1; }
  if(K_>1 && cdepth_==0){ cdepth_= E_<16? E_ : 16; }
  if(cdepth_>E_) cdepth_=E_;
  G_=2; while(!is_prim_root(G_,P_)) G_++;
  long long x=1; for(int k=0;k<P_-1;k++){ CI_[x]=k%(2*E_); x=x*G_%P_; }
  nrep_=2*E_; x=1; for(int k=0;k<nrep_;k++){ rep_[k]=(int)x; wt_[k]=M_; x=x*G_%P_; }
  clock_t t0=clock();
  a_[0]=0; gen(1,1);
  double secs=(double)(clock()-t0)/CLOCKS_PER_SEC;
  printf("RESULT2 n=%d p=%d m=%d e=%d chunk=%d/%d cdepth=%d ncand=%lld #SN=%lld fullchecks=%lld cache=%d avghitpos=%.2f time=%.1fs\n",
    NK,P_,M_,E_,k_,K_,cdepth_,ncand,nsn,nfull,ncache, ncand>nfull? (double)nhit_pos_sum/(ncand-nfull):0.0, secs);
  return 0;
}
