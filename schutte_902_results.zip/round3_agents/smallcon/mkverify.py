#!/usr/bin/env python3
"""Write a verify_sn input file for a Cayley tournament.
usage:
  mkverify.py circ N n S_csv [mult_csv]          circulant on Z_N, connection set S, optional multipliers u (x -> u x)
  mkverify.py abel moduli_csv n S_csv            Cayley tournament on Z_n1 x ... x Z_nk (elements in mixed radix, last coord fastest)
Output to stdout. The verifier itself checks that every listed permutation is an automorphism.
"""
import sys

def main():
    kind = sys.argv[1]
    if kind == 'circ':
        N, n = int(sys.argv[2]), int(sys.argv[3])
        S = set(int(x) for x in sys.argv[4].strip(',').split(',') if x)
        mult = [int(x) for x in sys.argv[5].split(',')] if len(sys.argv) > 5 else []
        add = lambda a, b: (a + b) % N
        sub = lambda a, b: (a - b) % N
        T = [[(x + 1) % N for x in range(N)]]
        M = [[(u * x) % N for x in range(N)] for u in mult]
    else:
        mods = [int(x) for x in sys.argv[2].split(',')]
        n = int(sys.argv[3])
        S = set(int(x) for x in sys.argv[4].strip(',').split(',') if x)
        N = 1
        for m in mods: N *= m
        strides = []
        s = 1
        for m in reversed(mods): strides.append(s); s *= m
        strides = list(reversed(strides))
        def dec(a): return [(a // st) % m for st, m in zip(strides, mods)]
        def enc(v): return sum(c * st for c, st in zip(v, strides))
        def sub(a, b): return enc([(x - y) % m for x, y, m in zip(dec(a), dec(b), mods)])
        T = []
        for i in range(len(mods)):
            g = [0] * len(mods); g[i] = 1; ge = enc(g)
            T.append([enc([(x + y) % m for x, y, m in zip(dec(a), dec(ge), mods)]) for a in range(N)])
        M = []
    out = [f"{N} {n}"]
    for i in range(N):
        out.append(''.join('1' if (i != j and sub(j, i) in S) else '0' for j in range(N)))
    out.append(f"T {len(T)}")
    for p in T: out.append(' '.join(map(str, p)))
    out.append(f"M {len(M)}")
    for p in M: out.append(' '.join(map(str, p)))
    print('\n'.join(out))

main()
