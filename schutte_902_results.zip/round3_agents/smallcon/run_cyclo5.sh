#!/bin/bash
# exhaustive cyclotomic families on Z_p, 119 <= p <= 330, for S_5, e in [EMIN,EMAX]
EMIN=$1; EMAX=$2; OUT=$3
python3 - "$EMIN" "$EMAX" << 'PY' > /tmp/claude-0/cyclo_jobs_$$.txt
import sys
emin,emax=int(sys.argv[1]),int(sys.argv[2])
def isprime(x): return x>1 and all(x%d for d in range(2,int(x**.5)+1))
for p in range(119,331):
    if not isprime(p): continue
    for m in range(1,p,2):
        if (p-1)%(2*m): continue
        e=(p-1)//(2*m)
        if emin<=e<=emax: print(p,m)
PY
while read p m; do ./cyclo_w6 5 $p $m min | grep -E "^(RESULT|SN)" | cut -c1-200 >> $OUT; done < /tmp/claude-0/cyclo_jobs_$$.txt
rm -f /tmp/claude-0/cyclo_jobs_$$.txt
