// cyclo3: fast exhaustive existence check of property S_n over a cyclotomic family on Z_p.
// H = subgroup of F_p^* of odd order m, index 2e; cosets C_i = g^i H (i mod 2e), -C_i = C_{i+e}.
// Member <-> word a_1..a_{2e}, a_{i+1} = [C_i in S], a_{t+e} = !a_t. Multiplication by g^-1 rotates the word and
// (Z_p is a CI-group) rotations are exactly the isomorphisms inside the family: we enumerate one necklace
// (lexicographically least rotation) per orbit by the FKM algorithm with forced tail.
// The doubled bitset DN2 of -S is maintained incrementally along the DFS; IN[x] (vertices beating x) is the
// window DN2[p-x .. p-x+64W). Filter: cache of n-sets X found undominated in earlier members; X undominated iff
// AND_{x in X} IN[x] = 0, tested word by word (early exit at the first nonzero word = a dominator exists).
// Members passing the filter get a full check (bitset DFS, sncore.h); found sets are brute-force re-checked.
// usage: cyclo3 n p m [K k [cdepth]]   -- restrict to DFS prefixes (at depth cdepth) of rank = k mod K
#include "sncore.h"
#include <time.h>

static int powmod(long long a,long long e,long long p){ long long r=1; a%=p; while(e){ if(e&1) r=r*a%p; a=a*a%p; e>>=1; } return (int)r; }
static int is_prim_root(int g,int p){ int q=p-1; for(int f=2;(long long)f*f<=q;f++){ if(q%f==0){ if(powmod(g,(p-1)/f,p)==1) return 0; while(q%f==0) q/=f; } } if(q>1 && powmod(g,(p-1)/q,p)==1) return 0; return 1; }

#define DW (2*W+4)
static int P_, E_, M_, G_;
static int CI_[1<<15];
static uint64_t NEGMASK_[128][DW];      // doubled bitset of {k in [0,2p): (-k mod p) in C_i}
static uint64_t DNL_[130][DW];          // DN2 per DFS level
static int a_[260];
static long long ncand=0, nfull=0, nsn=0, hitsum=0;
static int K_=1, k_=0, cdepth_=0; static long long prefix_rank=0;
static uint64_t LASTMASK_;

#define MAXCACHE 4096
static int cx_[MAXCACHE][16];   // storage
static int cidx_[MAXCACHE]; static int ncache=0;

static inline uint64_t win(const uint64_t*D,int off,int t){ int ws=(off>>6)+t, bsh=off&63; return bsh? ((D[ws]>>bsh)|(D[ws+1]<<(64-bsh))) : D[ws]; }
static inline int undominated_in(const uint64_t*D,const int*X){
  for(int t=0;t<W;t++){
    uint64_t acc= (t==W-1)? LASTMASK_ : ~0ULL;
    for(int j=0;j<NK && acc;j++) acc&=win(D,P_-X[j],t);
    if(acc) return 0;
  }
  return 1;
}
static int rep_[128], nrep_;
static unsigned char S_[1<<15];

static void process(const uint64_t*D,int depth){
  ncand++;
  for(int c=0;c<ncache;c++){
    if(undominated_in(D,cx_[cidx_[c]])){
      hitsum+=c;
      if(c>0){ int t=cidx_[c]; memmove(&cidx_[1],&cidx_[0],sizeof(int)*c); cidx_[0]=t; }
      return; }
  }
  nfull++;
  uint64_t b=0; for(int i=0;i<E_;i++) if(a_[i+1]) b|=1ULL<<i;
  for(int y=1;y<P_;y++){ int ci=CI_[y]; S_[y]=(unsigned char)(ci<E_? a_[ci+1] : 1-a_[ci-E_+1]); }
  build_circulant_fast(P_,S_);
  int X[16]; int found=0;
  for(int i=0;i<nrep_ && !found;i++) if(find_undominated_pair(rep_[i],X)) found=1;
  if(found){
    if(is_dominated(X,NK)){ fprintf(stderr,"internal error: reported set is dominated\n"); exit(3); }
    if(!undominated_in(D,X)){ fprintf(stderr,"internal error: window test disagrees with DFS\n"); exit(3); }
    int slot;
    if(ncache<MAXCACHE){ slot=ncache; ncache++; memmove(&cidx_[1],&cidx_[0],sizeof(int)*(ncache-1)); }
    else { slot=cidx_[MAXCACHE-1]; memmove(&cidx_[1],&cidx_[0],sizeof(int)*(MAXCACHE-1)); }
    memcpy(cx_[slot],X,sizeof(int)*NK); cidx_[0]=slot;
    return;
  }
  nsn++;
  printf("SN n=%d p=%d m=%d e=%d b=%llx S=",NK,P_,M_,E_,(unsigned long long)b);
  for(int y=1;y<P_;y++) if(S_[y]) printf("%d,",y); printf("\n"); fflush(stdout);
}

static void gen(int t,int p){
  if(t==cdepth_+1 && cdepth_>0){ long long r=prefix_rank++; if(r%K_!=k_) return; }
  if(t>E_){
    int pp=p;
    for(int s=t;s<=2*E_;s++){ int v=1-a_[s-E_]; a_[s]=v; if(v<a_[s-pp]) return; if(v>a_[s-pp]) pp=s; }
    if((2*E_)%pp) return;
    process(DNL_[E_],t); return;
  }
  // a_t = value -> coset (a_t ? t-1 : t-1+e) in S
  int v0=a_[t-p];
  { a_[t]=v0; const uint64_t*m=NEGMASK_[v0? t-1 : t-1+E_]; for(int w=0;w<DW;w++) DNL_[t][w]=DNL_[t-1][w]|m[w]; gen(t+1,p); }
  if(v0==0){ a_[t]=1; const uint64_t*m=NEGMASK_[t-1]; for(int w=0;w<DW;w++) DNL_[t][w]=DNL_[t-1][w]|m[w]; gen(t+1,t); }
}

int main(int argc,char**argv){
  if(argc<4){ fprintf(stderr,"usage: cyclo3 n p m [K k [cdepth]]\n"); return 1; }
  NK=atoi(argv[1]); P_=atoi(argv[2]); M_=atoi(argv[3]);
  if(argc>5){ K_=atoi(argv[4]); k_=atoi(argv[5]); cdepth_= argc>6? atoi(argv[6]) : 0; }
  init_binom();
  if(P_>MAXV){ fprintf(stderr,"p too large for W\n"); return 1; }
  if((P_-1)%(2*M_) || M_%2==0){ fprintf(stderr,"m must be an odd divisor of p-1\n"); return 1; }
  E_=(P_-1)/(2*M_); if(E_>63){ fprintf(stderr,"e too large\n"); return 1; }
  if(K_>1 && cdepth_==0) cdepth_= E_<16? E_ : 16;
  if(cdepth_>E_) cdepth_=E_;
  G_=2; while(!is_prim_root(G_,P_)) G_++;
  long long x=1; for(int k=0;k<P_-1;k++){ CI_[x]=k%(2*E_); x=x*G_%P_; }
  nrep_=2*E_; x=1; for(int k=0;k<nrep_;k++){ rep_[k]=(int)x; x=x*G_%P_; }
  memset(NEGMASK_,0,sizeof NEGMASK_);
  for(int k=0;k<2*P_;k++){ int s=k%P_; if(!s) continue; int ns=(P_-s)%P_; int ci=CI_[ns]; NEGMASK_[ci][k>>6]|=1ULL<<(k&63); }
  LASTMASK_= (P_-64*(W-1))>=64? ~0ULL : ((1ULL<<(P_-64*(W-1)))-1);
  if(P_<=64*(W-1)){ fprintf(stderr,"use a smaller W (p=%d, W=%d)\n",P_,W); return 1; }
  memset(DNL_[0],0,sizeof DNL_[0]);
  clock_t t0=clock();
  a_[0]=0; gen(1,1);
  double secs=(double)(clock()-t0)/CLOCKS_PER_SEC;
  printf("RESULT3 n=%d p=%d m=%d e=%d chunk=%d/%d cdepth=%d ncand=%lld #SN=%lld fullchecks=%lld cache=%d avghitpos=%.2f time=%.1fs\n",
    NK,P_,M_,E_,k_,K_,cdepth_,ncand,nsn,nfull,ncache, ncand>nfull? (double)hitsum/(ncand-nfull):0.0, secs);
  return 0;
}
