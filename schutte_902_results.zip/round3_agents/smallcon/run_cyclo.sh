#!/bin/bash
# usage: run_cyclo.sh n NMIN NMAX EMIN EMAX mode binary outfile
n=$1; NMIN=$2; NMAX=$3; EMIN=$4; EMAX=$5; MODE=$6; BIN=$7; OUT=$8
python3 - $NMIN $NMAX $EMIN $EMAX << 'PY' > jobs_$$.txt
import sys
a,b,emin,emax=map(int,sys.argv[1:5])
def isprime(x): return x>1 and all(x%d for d in range(2,int(x**.5)+1))
jobs=[]
for p in range(a,b+1):
    if not isprime(p): continue
    for m in range(1,p,2):
        if (p-1)%(2*m): continue
        e=(p-1)//(2*m)
        if emin<=e<=emax: jobs.append((e,p,m))
for e,p,m in sorted(jobs): print(p,m)
PY
while read p m; do ./$BIN $n $p $m $MODE | grep -E "^(RESULT|SN)" | cut -c1-300 >> $OUT; done < jobs_$$.txt
rm -f jobs_$$.txt
echo DONE >> $OUT
