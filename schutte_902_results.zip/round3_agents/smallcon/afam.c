// afam: exhaustive search of an M-invariant family of Cayley tournaments on an abelian group G = Z_n1 x ... x Z_nk
// for property S_n. The family: S = union over orbit pairs j of (O_j if b_j=1 else -O_j), with b_0 fixed to 0
// (S -> -S is an isomorphism), Gray-code enumeration with incremental update of in/out bitsets.
// usage: afam famfile [min|exist] [lo hi]   (enumerate Gray-code ranks in [lo,hi) of the 2^(P-1) members)
// famfile format: "N n" / "moduli k n1..nk" / "pairs P" / P lines "sz e1..esz" / "reps R r1 w1 ... rR wR"
#include "sncore.h"
#include <time.h>

static int K_, MOD_[8], STR_[8];
static int addg(int a,int b){ int r=0; for(int i=0;i<K_;i++){ int ca=(a/STR_[i])%MOD_[i], cb=(b/STR_[i])%MOD_[i]; r+=((ca+cb)%MOD_[i])*STR_[i]; } return r; }
static int negg(int a){ int r=0; for(int i=0;i<K_;i++){ int ca=(a/STR_[i])%MOD_[i]; r+=((MOD_[i]-ca)%MOD_[i])*STR_[i]; } return r; }

#define MAXP 64
static int P_, OSZ_[MAXP], *OEL_[MAXP];
static int nrep_, rep_[MAXV], wt_[MAXV];
static unsigned short *ADD_; // ADD_[a*N+b]
static int NEG_[MAXV];

#define MAXCACHE 4096
static int cacheX[MAXCACHE][16]; static int ncache=0;
static int cache_hit(void){
  for(int c=0;c<ncache;c++){ bs_t A=IN_[cacheX[c][0]]; int nz=1;
    for(int j=1;j<NK && nz;j++) nz=bs_and_nz(&A,&A,&IN_[cacheX[c][j]]);
    if(!nz) return c; }
  return -1;
}
static inline void bs_flip(bs_t*a,int i){ a->w[i>>6]^=1ULL<<(i&63); }
// toggle pair j: elements O_j and -O_j swap membership in S
static void toggle_pair(int j){
  for(int t=0;t<OSZ_[j];t++){ int s=OEL_[j][t], ns=NEG_[s];
    for(int a=0;a<NV;a++){ int b1=ADD_[a*NV+s], b2=ADD_[a*NV+ns];
      bs_flip(&OUT_[a],b1); bs_flip(&IN_[b1],a); bs_flip(&OUT_[a],b2); bs_flip(&IN_[b2],a); } }
}
int main(int argc,char**argv){
  if(argc<2){ fprintf(stderr,"usage: afam famfile [min|exist] [lo hi]\n"); return 1; }
  FILE*f=fopen(argv[1],"r"); if(!f){ perror("famfile"); return 1; }
  const char*mode= argc>2? argv[2]:"exist"; int exist=!strcmp(mode,"exist");
  char tok[64];
  if(fscanf(f,"%d %d",&NV,&NK)!=2) return 1;
  if(NV>MAXV){ fprintf(stderr,"N too large for W\n"); return 1; }
  if(fscanf(f,"%s %d",tok,&K_)!=2) return 1; for(int i=0;i<K_;i++) if(fscanf(f,"%d",&MOD_[i])!=1) return 1;
  { int s=1; for(int i=K_-1;i>=0;i--){ STR_[i]=s; s*=MOD_[i]; } if(s!=NV){ fprintf(stderr,"moduli product %d != N\n",s); return 1; } }
  if(fscanf(f,"%s %d",tok,&P_)!=2) return 1; if(P_>MAXP||P_<1){ fprintf(stderr,"bad P\n"); return 1; }
  static unsigned char inS[MAXV]; memset(inS,0,sizeof inS);
  static int seen[MAXV]; memset(seen,0,sizeof seen);
  for(int j=0;j<P_;j++){ if(fscanf(f,"%d",&OSZ_[j])!=1) return 1; OEL_[j]=malloc(sizeof(int)*OSZ_[j]); for(int t=0;t<OSZ_[j];t++){ if(fscanf(f,"%d",&OEL_[j][t])!=1) return 1; } }
  if(fscanf(f,"%s %d",tok,&nrep_)!=2) return 1; for(int i=0;i<nrep_;i++) if(fscanf(f,"%d %d",&rep_[i],&wt_[i])!=2) return 1;
  fclose(f);
  init_binom();
  ADD_=malloc(sizeof(unsigned short)*NV*NV); for(int a=0;a<NV;a++){ NEG_[a]=negg(a); for(int b=0;b<NV;b++) ADD_[a*NV+b]=(unsigned short)addg(a,b); }
  // check the pairs partition G\{0}
  for(int j=0;j<P_;j++) for(int t=0;t<OSZ_[j];t++){ int s=OEL_[j][t]; if(s<=0||s>=NV||seen[s]||seen[NEG_[s]]||s==NEG_[s]){ fprintf(stderr,"bad orbit data at pair %d elt %d\n",j,s); return 1; } seen[s]=seen[NEG_[s]]=1; }
  for(int s=1;s<NV;s++) if(!seen[s]){ fprintf(stderr,"element %d not covered\n",s); return 1; }
  { long long ws=0; for(int i=0;i<nrep_;i++) ws+=wt_[i]; if(ws!=NV-1){ fprintf(stderr,"rep weights sum %lld != N-1\n",ws); return 1; } }
  // initial S: b=0 -> all negative orbits
  for(int j=0;j<P_;j++) for(int t=0;t<OSZ_[j];t++) inS[NEG_[OEL_[j][t]]]=1;
  for(int v=0;v<NV;v++){ bs_clear(&IN_[v]); bs_clear(&OUT_[v]); }
  for(int a=0;a<NV;a++) for(int s=1;s<NV;s++) if(inS[s]){ int b=ADD_[a*NV+s]; bs_set(&OUT_[a],b); bs_set(&IN_[b],a); }
  uint64_t total=1ULL<<(P_-1); uint64_t lo=0, hi=total;
  if(argc>4){ lo=strtoull(argv[3],0,0); hi=strtoull(argv[4],0,0); if(hi>total) hi=total; }
  // move to Gray code rank lo: gray(lo) = lo ^ (lo>>1); bits are b_1..b_{P-1} (b_0 fixed 0)
  uint64_t gcur=0, gl=lo^(lo>>1);
  for(int j=1;j<P_;j++) if((gl>>(j-1))&1){ toggle_pair(j); }
  gcur=gl;
  long long best=1LL<<60, nbest=0, nfull=0, nsn=0, ncand=0; clock_t t0=clock();
  for(uint64_t r=lo;r<hi;r++){
    if(r>lo){ uint64_t g=r^(r>>1); uint64_t d=g^gcur; int j=__builtin_ctzll(d)+1; toggle_pair(j); gcur=g; }
    ncand++;
    long long u;
    if(exist){
      int h=cache_hit();
      if(h>=0){ if(h>0){ int tmp[16]; memcpy(tmp,cacheX[h],sizeof tmp); memmove(cacheX[1],cacheX[0],sizeof(cacheX[0])*h); memcpy(cacheX[0],tmp,sizeof tmp); } continue; }
      nfull++; int X[16]; int found=0;
      for(int i=0;i<nrep_ && !found;i++) if(find_undominated_pair(rep_[i],X)) found=1;
      if(found){ if(is_dominated(X,NK)){ fprintf(stderr,"internal error\n"); return 3; }
        int slot= ncache<MAXCACHE? ncache++ : MAXCACHE-1; memmove(cacheX[1],cacheX[0],sizeof(cacheX[0])*slot); memcpy(cacheX[0],X,sizeof(int)*NK); continue; }
      u=0;
    } else {
      u=count_v0_orbits(nrep_,rep_,wt_,best+1);
      if(u<best){ best=u; nbest=1; printf("BEST U0=%lld gray=%llx\n",u,(unsigned long long)gcur); fflush(stdout); } else if(u==best) nbest++;
    }
    if(u==0){ nsn++; printf("SN gray=%llx S=",(unsigned long long)gcur);
      // S = O_j if b_j=1 (j>=1, bit j-1 of gcur) else -O_j
      for(int j=0;j<P_;j++){ int bj= j? (int)((gcur>>(j-1))&1) : 0; for(int t=0;t<OSZ_[j];t++) printf("%d,", bj? OEL_[j][t] : NEG_[OEL_[j][t]]); }
      printf("\n"); fflush(stdout); }
  }
  double secs=(double)(clock()-t0)/CLOCKS_PER_SEC;
  if(exist) printf("RESULT %s N=%d n=%d P=%d range=[%llu,%llu) ncand=%lld #SN=%lld fullchecks=%lld time=%.1fs\n",argv[1],NV,NK,P_,(unsigned long long)lo,(unsigned long long)hi,ncand,nsn,nfull,secs);
  else printf("RESULT %s N=%d n=%d P=%d range=[%llu,%llu) ncand=%lld minU0=%lld nmin=%lld time=%.1fs\n",argv[1],NV,NK,P_,(unsigned long long)lo,(unsigned long long)hi,ncand,best,nbest,secs);
  return 0;
}
