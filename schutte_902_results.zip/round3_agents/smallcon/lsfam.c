// lsfam: heuristic minimisation of U0 (#undominated n-sets through 0) over a multiplier-invariant circulant
// family (afam2/mkfam2 file format). Iterated local search: first-improvement single-pair flips in random order,
// every neighbour evaluated exactly with cutoff = current U0 (so accepted values are exact); at a local optimum
// perturb the incumbent by flipping 1+rand%kmax pairs (restart from random every R non-improving kicks).
// usage: lsfam famfile seconds seed [start_hex|rand] [kmax]
#include "sncore.h"
#include <time.h>
#define MAXP 128
static int N_, P_, OSZ_[MAXP], *OEL_[MAXP], MSZ_, MEL_[4096];
static int rep_[2*MAXP], wt_[2*MAXP], nrep_;
static unsigned char S_[1<<14];
static uint64_t rng=88172645463325252ULL; static inline uint64_t xr(void){ rng^=rng<<13; rng^=rng>>7; rng^=rng<<17; return rng; }
typedef struct { uint64_t w[2]; } bv_t;  // P <= 128
static inline int bget(const bv_t*b,int j){ return (b->w[j>>6]>>(j&63))&1; }
static inline void bflip(bv_t*b,int j){ b->w[j>>6]^=1ULL<<(j&63); }
static long long nevals=0;
static long long evalU(const bv_t*b,long long limit){
  memset(S_,0,N_);
  for(int j=0;j<P_;j++){ int bj=bget(b,j); for(int t=0;t<OSZ_[j];t++){ int s=OEL_[j][t]; if(bj) S_[s]=1; else S_[(N_-s)%N_]=1; } }
  build_circulant_fast(N_,S_); nevals++;
  return count_v0_orbits(nrep_,rep_,wt_,limit);
}
static void printS(const char*tag,const bv_t*b,long long u,double t){
  memset(S_,0,N_);
  for(int j=0;j<P_;j++){ int bj=bget(b,j); for(int t2=0;t2<OSZ_[j];t2++){ int s=OEL_[j][t2]; if(bj) S_[s]=1; else S_[(N_-s)%N_]=1; } }
  printf("%s N=%d n=%d U0=%lld t=%.1fs evals=%lld b=%016llx%016llx S=",tag,N_,NK,u,t,nevals,(unsigned long long)b->w[1],(unsigned long long)b->w[0]);
  for(int y=1;y<N_;y++) if(S_[y]) printf("%d,",y); printf("\n"); fflush(stdout);
}
int main(int argc,char**argv){
  if(argc<4){ fprintf(stderr,"usage: lsfam famfile seconds seed [start_hex|rand] [kmax]\n"); return 1; }
  FILE*f=fopen(argv[1],"r"); if(!f){ perror(argv[1]); return 1; }
  double tmax=atof(argv[2]); rng^=(uint64_t)atoll(argv[3])*0x9E3779B97F4A7C15ULL; for(int i=0;i<10;i++) xr();
  int kmax= argc>5? atoi(argv[5]) : 3;
  char tok[16]; int G;
  if(fscanf(f,"%d %d",&N_,&NK)!=2 || fscanf(f,"%d",&P_)!=1) return 1;
  if(P_>MAXP || N_>MAXV){ fprintf(stderr,"too large\n"); return 1; }
  for(int j=0;j<P_;j++){ if(fscanf(f,"%d",&OSZ_[j])!=1) return 1; OEL_[j]=malloc(sizeof(int)*OSZ_[j]); for(int t=0;t<OSZ_[j];t++) if(fscanf(f,"%d",&OEL_[j][t])!=1) return 1; }
  if(fscanf(f,"%15s %d",tok,&G)!=2) return 1;
  for(int g=0;g<G;g++) for(int j=0;j<P_;j++){ int a,b; if(fscanf(f,"%d %d",&a,&b)!=2) return 1; }
  if(fscanf(f,"%15s %d",tok,&MSZ_)!=2) return 1; for(int i=0;i<MSZ_;i++) if(fscanf(f,"%d",&MEL_[i])!=1) return 1;
  fclose(f);
  init_binom();
  nrep_=0; for(int j=0;j<P_;j++){ rep_[nrep_]=OEL_[j][0]; wt_[nrep_++]=OSZ_[j]; rep_[nrep_]=(N_-OEL_[j][0])%N_; wt_[nrep_++]=OSZ_[j]; }
  bv_t cur={{0,0}};
  int randstart = !(argc>4 && strcmp(argv[4],"rand"));
  if(!randstart && !strncmp(argv[4],"S:",2)){ // start from a connection set given as S:a,b,c,... (must be in the family)
    static unsigned char inS[1<<14]; const char*q=argv[4]+2; while(*q){ int v=atoi(q); if(v>0&&v<N_) inS[v]=1; while(*q && *q!=',') q++; if(*q==',') q++; }
    for(int j=0;j<P_;j++){ int pos=inS[OEL_[j][0]]; for(int t=0;t<OSZ_[j];t++){ int s=OEL_[j][t]; if(inS[s]!=pos || inS[(N_-s)%N_]==pos){ fprintf(stderr,"start set not in family (pair %d)\n",j); return 1; } } if(pos) bflip(&cur,j); }
  }
  else if(!randstart){ const char*h=argv[4]; int L=strlen(h); for(int i=0;i<L;i++){ int c=h[L-1-i]; int v= c<='9'? c-'0' : (c|32)-'a'+10; for(int k=0;k<4;k++) if((v>>k)&1){ int j=4*i+k; if(j<P_) bflip(&cur,j);} } }
  else for(int j=0;j<P_;j++) if(xr()&1) bflip(&cur,j);
  clock_t t0=clock(); double el=0;
  long long ucur=evalU(&cur,1LL<<60); bv_t best=cur; long long ubest=ucur;
  printS("START",&cur,ucur,0);
  int order[MAXP]; long long kicks=0, sincebest=0, restarts=0;
  while(1){
    el=(double)(clock()-t0)/CLOCKS_PER_SEC; if(el>tmax) break;
    for(int j=0;j<P_;j++) order[j]=j;
    for(int j=P_-1;j>0;j--){ int k=xr()%(j+1); int t=order[j]; order[j]=order[k]; order[k]=t; }
    int improved=0;
    for(int i=0;i<P_;i++){ int j=order[i]; bflip(&cur,j); long long u=evalU(&cur,ucur);
      if(u<ucur){ ucur=u; improved=1; break; } bflip(&cur,j); }
    if(improved){ if(ucur<ubest){ ubest=ucur; best=cur; sincebest=0; printS("BEST",&best,ubest,(double)(clock()-t0)/CLOCKS_PER_SEC); if(ubest==0) break; } continue; }
    // local optimum: kick from the incumbent
    kicks++; sincebest++;
    if(sincebest>=30){ restarts++; sincebest=0; for(int j=0;j<P_;j++) if(xr()&1) bflip(&cur,j); ucur=evalU(&cur,1LL<<60); continue; }
    cur=best; int k=1+xr()%kmax; for(int i=0;i<k;i++) bflip(&cur,xr()%P_); ucur=evalU(&cur,1LL<<60);
  }
  printf("RESULTLS %s N=%d n=%d P=%d |M|=%d bestU0=%lld evals=%lld kicks=%lld restarts=%lld time=%.1fs\n",argv[1],N_,NK,P_,MSZ_,ubest,nevals,kicks,restarts,el);
  printS("FINAL",&best,ubest,el);
  return 0;
}
