"""Build permutation actions of an odd-order group G on unions of coset spaces G/H_i.

G is given faithfully by generator permutations on some set; elements are enumerated by closure.
A transitive G-set is G/H for a subgroup H (given by generator permutations from G).
combine(...) concatenates several orbit actions into one action on n points and writes a
generator file in the format used by genum / gen_cnf / gls:  "n g" then g lines of images.
"""
import sys
from itertools import product

def compose(p, q):            # (p*q)(x) = p(q(x))  -- apply q first
    return tuple(p[i] for i in q)

def closure(gens):
    idt = tuple(range(len(gens[0])))
    elems = {idt}; frontier = [idt]
    while frontier:
        nf = []
        for g in frontier:
            for s in gens:
                h = compose(s, g)
                if h not in elems:
                    elems.add(h); nf.append(h)
        frontier = nf
    return elems

def coset_action(gens, Hgens):
    """Action of the generators on left cosets gH. Returns list of permutations on range(|G/H|)."""
    G = closure(gens)
    H = closure(Hgens) if Hgens else {tuple(range(len(gens[0])))}
    # canonical label of coset gH = min over h of g*h
    idx = {}; reps = []
    for g in sorted(G):
        key = min(compose(g, h) for h in H)
        if key not in idx:
            idx[key] = len(reps); reps.append(key)
    def lab(g):
        return idx[min(compose(g, h) for h in H)]
    perms = []
    for s in gens:
        perms.append([lab(compose(s, r)) for r in reps])
    return perms, len(G), len(H)

def combine(orbit_actions):
    """orbit_actions: list of lists of permutations (one per generator, same generator order)."""
    ng = len(orbit_actions[0])
    n = sum(len(a[0]) for a in orbit_actions)
    out = [[None]*n for _ in range(ng)]
    off = 0
    for act in orbit_actions:
        m = len(act[0])
        for gi in range(ng):
            for x in range(m):
                out[gi][off+x] = off + act[gi][x]
        off += m
    return n, out

def write_gens(fn, n, gens):
    with open(fn, 'w') as f:
        f.write(f"{n} {len(gens)}\n")
        for g in gens:
            f.write(' '.join(map(str, g)) + '\n')

# ---------- concrete groups ----------
def affine_Zp(p, d):
    """G = Z_p x| C_d (d | p-1) acting on Z_p: generators t: x->x+1, m: x->a x (a of order d)."""
    a = None
    for c in range(2, p):
        if pow(c, d, p) == 1 and all(pow(c, e, p) != 1 for e in range(1, d)):
            a = c; break
    if d == 1: a = 1
    t = tuple((x+1) % p for x in range(p))
    m = tuple((a*x) % p for x in range(p))
    return [t, m], a

def gf_elements(p, k, modpoly):
    """GF(p^k) elements as tuples of k coefficients (low degree first); modpoly: monic coeffs c0..c_{k-1} of x^k = -(...)"""
    els = list(product(range(p), repeat=k))
    return els

def gf_mul(a, b, p, k, red):
    # red: list r0..r_{k-1} with x^k = sum r_i x^i
    res = [0]*(2*k-1)
    for i in range(k):
        for j in range(k):
            res[i+j] = (res[i+j] + a[i]*b[j]) % p
    for deg in range(2*k-2, k-1, -1):
        c = res[deg]
        if c:
            res[deg] = 0
            for i in range(k):
                res[deg-k+i] = (res[deg-k+i] + c*red[i]) % p
    return tuple(res[:k])

def affine_GF(p, k, red, mult_order, frob=False):
    """G = GF(p^k) x| <c> (x| <Frobenius>) acting on GF(p^k).
    red: x^k = sum red_i x^i defines the field. c chosen of the requested multiplicative order."""
    els = gf_elements(p, k, red); index = {e: i for i, e in enumerate(els)}
    q = p**k
    one = tuple([1] + [0]*(k-1)); zero = tuple([0]*k)
    def power(a, e):
        r = one
        for _ in range(e): r = gf_mul(r, a, p, k, red)
        return r
    def order(a):
        r = a; o = 1
        while r != one:
            r = gf_mul(r, a, p, k, red); o += 1
            if o > q: return None
        return o
    # find primitive element
    prim = None
    for e in els:
        if e == zero: continue
        if order(e) == q-1: prim = e; break
    assert prim is not None, "not a field?"
    c = power(prim, (q-1)//mult_order)
    gens = []
    for i in range(k):  # translations by basis vectors
        b = tuple(1 if j == i else 0 for j in range(k))
        gens.append(tuple(index[tuple((e[j]+b[j]) % p for j in range(k))] for e in els))
    gens.append(tuple(index[gf_mul(c, e, p, k, red)] for e in els))
    if frob:
        gens.append(tuple(index[power(e, p)] for e in els))
    return gens, els, index

if __name__ == "__main__":
    pass
