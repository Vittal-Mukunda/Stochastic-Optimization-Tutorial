#!/bin/bash
# Rerun the two timed-out families, each split into 2 halves (top variable bit) run in parallel.
for f in fam0129.txt fam0135.txt; do
  for h in 0 1; do
    ( r=$(VORD=1 ./genum2v 4 fams/$f 62 1 $h 2>/dev/null | tail -1); echo "$f half $h => $r" >> reruns_log.txt ) &
  done
  wait
done
echo RERUNS_DONE >> reruns_log.txt
