// Dominator-count distribution of 4-sets in QR_p, and effect of deleting vertices.
#include "sk.h"
int main(int argc,char**argv){
  int p=atoi(argv[1]); init_bin();
  int isq[256]={0}; for(int x=1;x<p;x++) isq[(x*x)%p]=1;
  static unsigned char A[MAXN*MAXN]; memset(A,0,sizeof A);
  for(int i=0;i<p;i++)for(int j=0;j<p;j++) if(i!=j && isq[((j-i)%p+p)%p]) A[i*p+j]=1;
  Tour T; tour_from_adj(&T,p,A);
  long long hist[64]={0}; long long uniq_by_dom[256]={0};
  int n=p;
  for(int a=0;a<n;a++)for(int b=a+1;b<n;b++){ u128 m2=T.in[a]&T.in[b];
    for(int c=b+1;c<n;c++){ u128 m3=m2&T.in[c];
      for(int d=c+1;d<n;d++){ u128 m4=m3&T.in[d]; int D=popc(m4); hist[D]++;
        if(D==1){ int w=0; while(!((m4>>w)&1)) w++; uniq_by_dom[w]++; } } } }
  printf("QR_%d dominator-count histogram over 4-sets:\n",p);
  for(int D=0;D<64;D++) if(hist[D]) printf("  D=%d: %lld\n",D,hist[D]);
  printf("4-sets with unique dominator v (per vertex): %lld (vertex 0)\n",uniq_by_dom[0]);
  // pairs/triples stats
  long long h3[64]={0}; for(int a=0;a<n;a++)for(int b=a+1;b<n;b++)for(int c=b+1;c<n;c++){ int D=popc(T.in[a]&T.in[b]&T.in[c]); h3[D]++; }
  printf("triples: "); for(int D=0;D<64;D++) if(h3[D]) printf("D=%d:%lld ",D,h3[D]); printf("\n");
  return 0; }
