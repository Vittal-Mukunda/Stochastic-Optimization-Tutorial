import sys; sys.path.insert(0,'.')
from gact import *
# positive control: AGL-type Z_67 x| C_33 on 67 points
gens,a = affine_Zp(67,33)
acts,_,_ = coset_action(gens, [gens[1]])   # cosets of the multiplier subgroup = action on Z_67
n,g = combine([acts]); write_gens('g_ctrl67.txt', n, g)
# vertex-transitive non-Cayley candidate: Z_19 x| C_9 acting on cosets of C_3 (degree 57)
gens,a = affine_Zp(19,9)
m3 = compose(gens[1], compose(gens[1], gens[1]))
acts,oG,oH = coset_action(gens, [m3]); n,g = combine([acts]); write_gens('g_vt57.txt', n, g); print('vt57', n, oG, oH)
