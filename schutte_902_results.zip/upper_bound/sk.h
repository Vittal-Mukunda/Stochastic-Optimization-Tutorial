// Bitset S_k checker for tournaments with n <= 128 vertices.
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef unsigned __int128 u128;
#define MAXN 128
static inline int popc(u128 x){ return __builtin_popcountll((uint64_t)x) + __builtin_popcountll((uint64_t)(x>>64)); }
static inline u128 bit(int i){ return ((u128)1) << i; }

// binomial table
static long long BIN[MAXN+1][12];
static void init_bin(void){ for(int a=0;a<=MAXN;a++){ BIN[a][0]=1; for(int b=1;b<12;b++) BIN[a][b]= (a==0)?0: BIN[a-1][b-1]+BIN[a-1][b]; } }

typedef struct { int n; u128 in[MAXN]; u128 out[MAXN]; } Tour;

// count k-sets X (with all elements >= start, choosing `rem` more) whose common in-neighbourhood is empty
static long long cnt_rec(const Tour*T, int start, int rem, u128 mask, long long limit, long long *acc){
  long long c=0;
  for(int i=start;i<=T->n-rem;i++){
    u128 m2 = mask & T->in[i];
    if(rem==1){ if(!m2){ c++; if(*acc+c>=limit) return c; } }
    else if(!m2){ c += BIN[T->n-i-1][rem-1]; if(*acc+c>=limit) return c; }
    else { long long a2=*acc+c; c += cnt_rec(T,i+1,rem-1,m2,limit,&a2); if(*acc+c>=limit) return c; }
  }
  return c;
}
// number of undominated k-sets (stops early once count reaches limit)
static long long count_bad(const Tour*T, int k, long long limit){
  long long acc=0; u128 all = (T->n==128)? ~(u128)0 : (bit(T->n)-1);
  return cnt_rec(T,0,k,all,limit,&acc);
}
// number of undominated k-sets containing vertex 0 (enough for vertex-transitive tournaments)
static long long count_bad_v0(const Tour*T, int k, long long limit){
  long long acc=0;
  return cnt_rec(T,1,k-1,T->in[0],limit,&acc);
}
static void tour_from_adj(Tour*T,int n,const unsigned char*A){ // A[i*n+j]=1 iff i->j
  T->n=n; for(int i=0;i<n;i++){T->in[i]=0;T->out[i]=0;}
  for(int i=0;i<n;i++) for(int j=0;j<n;j++) if(A[i*n+j]){ T->out[i]|=bit(j); T->in[j]|=bit(i);} }
static int tour_valid(const Tour*T){ for(int i=0;i<T->n;i++){ if(T->in[i]&bit(i)) return 0; for(int j=i+1;j<T->n;j++){ int a=(T->out[i]>>j)&1, b=(T->out[j]>>i)&1; if(a+b!=1) return 0; } } return 1; }
