# Write QR_p with a given set of vertices deleted, as an adjacency matrix file.
# usage: python3 gen_qr_minus.py p out.txt [v1 v2 ...]
import sys
p=int(sys.argv[1]); out=sys.argv[2]; dele=set(int(x) for x in sys.argv[3:])
sq={(x*x)%p for x in range(1,p)}
V=[v for v in range(p) if v not in dele]
with open(out,'w') as f:
    f.write(f"{len(V)}\n")
    for i in V:
        f.write(''.join('1' if (i!=j and ((j-i)%p) in sq) else '0' for j in V)+'\n')
