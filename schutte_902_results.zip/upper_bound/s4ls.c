// s4ls: focused local search (WalkSAT-style) for property S_4 on general tournaments.
// Maintains, for every 4-set X, D(X) = #vertices beating all of X, plus
//   cnt1[u][v] = #4-sets X with D(X)=1, unique dominator u, and v in X  (= "break" count of flipping u->v)
// and the list of undominated 4-sets. One arc flip costs O(C(outdeg,3)) updates.
// usage: s4ls infile seed maxsteps noise_permille tenure [outprefix]
// infile: n, then n rows of '0'/'1' (row i, col j = 1 iff i->j)
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
typedef unsigned __int128 u128;
#define MAXN 100
static inline u128 bit(int i){ return ((u128)1)<<i; }
static inline int popc(u128 x){ return __builtin_popcountll((uint64_t)x)+__builtin_popcountll((uint64_t)(x>>64)); }
static inline int ctz128(u128 x){ uint64_t lo=(uint64_t)x; if(lo) return __builtin_ctzll(lo); return 64+__builtin_ctzll((uint64_t)(x>>64)); }

static int n;
static u128 out_[MAXN], in_[MAXN];
static long long Cb[MAXN+1][5];
static uint8_t *D;
static int *pos;
static long long *badid; static u128 *badmask; static int nbad;
static int cnt1[MAXN][MAXN];
static uint64_t rs=88172645463325252ULL;
static inline uint64_t rnd(void){ rs^=rs<<13; rs^=rs>>7; rs^=rs<<17; return rs; }

static inline long long idxm(u128 m){ // index of 4-set given by mask
  int a=ctz128(m); m&=m-1; int b=ctz128(m); m&=m-1; int c=ctz128(m); m&=m-1; int d=ctz128(m);
  return Cb[a][1]+Cb[b][2]+Cb[c][3]+Cb[d][4]; }
static inline void add_bad(long long id,u128 mask){ pos[id]=nbad; badid[nbad]=id; badmask[nbad]=mask; nbad++; }
static inline void rem_bad(long long id){ int p=pos[id]; nbad--; if(p!=nbad){ badid[p]=badid[nbad]; badmask[p]=badmask[nbad]; pos[badid[p]]=p; } pos[id]=-1; }
static inline void cnt1_add(int w,u128 mask,int dl){ while(mask){ int x=ctz128(mask); mask&=mask-1; cnt1[w][x]+=dl; } }

static void flip(int u,int v){ // precondition: u->v.  After: v->u.
  out_[u]&=~bit(v); in_[v]&=~bit(u); out_[v]|=bit(u); in_[u]|=bit(v);
  int el[MAXN],m=0; u128 s=out_[u]; while(s){ el[m++]=ctz128(s); s&=s-1; }
  u128 bv=bit(v);
  for(int i=0;i<m;i++){ u128 mi=bit(el[i])|bv; u128 ii=in_[el[i]]&in_[v];
    for(int j=i+1;j<m;j++){ u128 mj=mi|bit(el[j]); u128 ij=ii&in_[el[j]];
      for(int k=j+1;k<m;k++){ u128 mask=mj|bit(el[k]); long long id=idxm(mask); int d=D[id]; D[id]=d-1;
        if(d==1){ cnt1_add(u,mask,-1); add_bad(id,mask); }
        else if(d==2){ u128 dm=ij&in_[el[k]]; cnt1_add(ctz128(dm),mask,+1); } } } }
  s=out_[v]&~bit(u); m=0; while(s){ el[m++]=ctz128(s); s&=s-1; }
  u128 bu=bit(u);
  for(int i=0;i<m;i++){ u128 mi=bit(el[i])|bu; u128 ii=in_[el[i]]&in_[u];
    for(int j=i+1;j<m;j++){ u128 mj=mi|bit(el[j]); u128 ij=ii&in_[el[j]];
      for(int k=j+1;k<m;k++){ u128 mask=mj|bit(el[k]); long long id=idxm(mask); int d=D[id]; D[id]=d+1;
        if(d==0){ rem_bad(id); cnt1_add(v,mask,+1); }
        else if(d==1){ u128 dm=(ij&in_[el[k]])&~bv; cnt1_add(ctz128(dm),mask,-1); } } } }
}
static void init_all(void){
  long long tot=Cb[n][4]; D=malloc(tot); pos=malloc(sizeof(int)*tot); badid=malloc(sizeof(long long)*tot); badmask=malloc(sizeof(u128)*tot);
  nbad=0; memset(cnt1,0,sizeof cnt1);
  for(int a=0;a<n;a++)for(int b=a+1;b<n;b++){ u128 m2=in_[a]&in_[b];
    for(int c=b+1;c<n;c++){ u128 m3=m2&in_[c];
      for(int d=c+1;d<n;d++){ u128 m4=m3&in_[d]; long long id=Cb[a][1]+Cb[b][2]+Cb[c][3]+Cb[d][4]; int k=popc(m4); D[id]=k>255?255:k; pos[id]=-1;
        u128 mask=bit(a)|bit(b)|bit(c)|bit(d);
        if(k==0) add_bad(id,mask); else if(k==1) cnt1_add(ctz128(m4),mask,+1); } } }
}
static long long full_count(void){ long long c=0; for(int a=0;a<n;a++)for(int b=a+1;b<n;b++){ u128 m2=in_[a]&in_[b]; if(!m2){ c+=Cb[n-b-1][2]; continue;} for(int c2=b+1;c2<n;c2++){ u128 m3=m2&in_[c2]; for(int d=c2+1;d<n;d++) if(!(m3&in_[d])) c++; } } return c; }
static int make_cnt(int u,int v){ // flipping u->v makes v dominate bad sets X with u in X, v not in X, X\{u} subset out[v]
  int c=0; u128 bu=bit(u), bv=bit(v), ov=out_[v];
  for(int i=0;i<nbad;i++){ u128 m=badmask[i]; if((m&bu) && !(m&bv) && !((m&~bu)&~ov)) c++; }
  return c; }
static void write_tour(const char*fn){ FILE*o=fopen(fn,"w"); fprintf(o,"%d\n",n); for(int i=0;i<n;i++){ for(int j=0;j<n;j++) fputc(((out_[i]>>j)&1)?'1':'0',o); fputc('\n',o);} fclose(o); }

int main(int argc,char**argv){
  if(argc<6){ fprintf(stderr,"usage: s4ls infile seed maxsteps noise_permille tenure [outprefix]\n"); return 1; }
  FILE*f=fopen(argv[1],"r"); if(!f||fscanf(f,"%d",&n)!=1){ fprintf(stderr,"bad infile\n"); return 1; }
  char row[MAXN+8]; for(int i=0;i<n;i++){ out_[i]=in_[i]=0; }
  for(int i=0;i<n;i++){ if(fscanf(f,"%s",row)!=1) return 1; for(int j=0;j<n;j++) if(row[j]=='1'){ out_[i]|=bit(j); in_[j]|=bit(i);} } fclose(f);
  for(int i=0;i<n;i++) for(int j=i+1;j<n;j++){ int a=(out_[i]>>j)&1, b=(out_[j]>>i)&1; if(a+b!=1){ fprintf(stderr,"not a tournament at %d %d\n",i,j); return 1; } }
  rs ^= (uint64_t)atoll(argv[2])*0x9E3779B97F4A7C15ULL; for(int i=0;i<50;i++) rnd();
  long long maxsteps=atoll(argv[3]); int noise=atoi(argv[4]); int tenure=atoi(argv[5]); const char*pref= argc>6? argv[6] : "s4found";
  for(int a=0;a<=MAXN;a++){ Cb[a][0]=1; for(int b=1;b<5;b++) Cb[a][b]= a? Cb[a-1][b-1]+Cb[a-1][b] : 0; }
  init_all();
  fprintf(stderr,"n=%d initial undominated 4-sets: %d\n",n,nbad);
  static long long tabu[MAXN][MAXN]; memset(tabu,0,sizeof tabu);
  int best=nbad; time_t t0=time(0); long long lastimp=0;
  static u128 bestout[MAXN];
  memcpy(bestout,out_,sizeof(u128)*n);
  for(long long step=1; step<=maxsteps && nbad>0; step++){
    int r=rnd()%nbad; u128 X=badmask[r];
    int cu[MAXN],cv[MAXN],cd[MAXN],nc=0;
    for(int w=0;w<n;w++){ if((X>>w)&1) continue; u128 miss=X&~out_[w]; if(popc(miss)!=1) continue;
      int x=ctz128(miss); // currently x->w ; flip to w->x
      cu[nc]=x; cv[nc]=w; cd[nc]=cnt1[x][w]-make_cnt(x,w); nc++; }
    if(nc==0) continue;
    int pick=-1;
    if((int)(rnd()%1000)<noise){ pick=rnd()%nc; }
    else { int bd=1<<30, ties=0;
      for(int c=0;c<nc;c++){ int a=cu[c], b=cv[c]; int tb = tabu[a<b?a:b][a<b?b:a] > step && !(nbad+cd[c]<best);
        if(tb) continue;
        if(cd[c]<bd){ bd=cd[c]; pick=c; ties=1; } else if(cd[c]==bd){ ties++; if(rnd()%ties==0) pick=c; } }
      if(pick<0) pick=rnd()%nc; }
    int a=cu[pick], b=cv[pick];
    flip(a,b); tabu[a<b?a:b][a<b?b:a]=step+tenure;
    if(nbad<best){ best=nbad; lastimp=step; memcpy(bestout,out_,sizeof(u128)*n);
      fprintf(stderr,"step %lld: undominated=%d (t=%lds)\n",step,nbad,(long)(time(0)-t0)); }
    if(step%2000000==0) fprintf(stderr,"  step %lld cur=%d best=%d (t=%lds)\n",step,nbad,best,(long)(time(0)-t0));
  }
  // restore best
  for(int i=0;i<n;i++){ out_[i]=bestout[i]; in_[i]=0; } for(int i=0;i<n;i++) for(int j=0;j<n;j++) if((out_[i]>>j)&1) in_[j]|=bit(i);
  long long fc=full_count();
  printf("RESULT n=%d best=%d full_recount=%lld\n",n,best,fc);
  if(fc==0){ char fn[256]; sprintf(fn,"%s_n%d_seed%s.txt",pref,n,argv[2]); write_tour(fn); printf("WROTE %s\n",fn); }
  else { char fn[256]; sprintf(fn,"%s_best_n%d_seed%s.txt",pref,n,argv[2]); write_tour(fn); }
  return 0; }
